<?php

/**
 * before running this script, 
 * simply set all leadID = PDLoan_Rcvd for any STANDARD loans.
 * ie the leadIDs for standard loans are provided in the PDLoan_Rcvd field
 *
 * this script will then populate all the renewal rows
 */
set_time_limit(0);

require_once __DIR__ . '/../BootScript.php';

error_reporting(E_ALL);
ini_set('display_errors', '1');

$db = Zend_Registry::get('db');

$counter = 0;

# Loan_App Renewals only (do little at a time)
$sql = "select Cust_ID, Cust_SSN, Loan_Type, Merch_Store_ID, ApplicationDate 
	from Loan_App 
	where Loan_Type = 'R' 
	order by ApplicationDate asc";

$rows = $db->fetchAll($sql);

foreach ($rows as $row) 
{
	$Matcher = new LeadMatcherLoanApp($row['Cust_ID'], 
		$row['Cust_SSN'], 
		$row['Loan_Type'], 
		$row['Merch_Store_ID'], 
		$row['ApplicationDate']);

	if ($leadID = $Matcher->execute()) 
	{
		$sql = "update Loan_App set leadID = $leadID 
			WHERE Cust_ID = " . $row['Cust_ID'] . 
			" AND ApplicationDate = '" . $row['ApplicationDate'] . "'";
		$db->query($sql);
		$counter++;
	}
}

echo $counter . " rows updated" . "\r\n";
echo "=== DONE ===";
