<?php

set_time_limit(0);

require_once __DIR__ . '/../BootScript.php';

error_reporting(E_ALL);
ini_set('display_errors', '1');

$db = Zend_Registry::get('db');

$LECustomerDisposition = new LECustomerDisposition();

$counter = 0;

$sql = "SELECT id,leadID FROM LECustomerDispositions WHERE email IS NULL";

$stmt = $db->query($sql);

while($row = $stmt->fetch()) {

    $leadID = $row['leadID'];
    $id = $row['id'];

    $leadSql = 'SELECT email FROM Leads where id = '.$leadID;
    $leadRow = $db->fetchRow($leadSql);

    if($leadRow != NULL) {
        $updateData = array('email' => $leadRow['email']);
        $LECustomerDisposition->update($updateData,'id = '.$id);
        $counter++;
    }
}

echo $counter . " rows updated" . "\r\n";
echo "=== DONE ===";
