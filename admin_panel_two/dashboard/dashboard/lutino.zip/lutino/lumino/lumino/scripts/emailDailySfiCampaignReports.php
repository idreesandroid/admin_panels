<?php

require_once __DIR__ . '/../BootScript.php';

error_reporting(E_ERROR);
//ini_set('display_errors', '-1');

$dailyCampaignReports = new DailySfiCampaignReports();
$dailyCampaignReports->execute();

?>
