<?php

set_time_limit(0);

require_once __DIR__ . '/../BootScript.php';

error_reporting(E_ALL);
ini_set('display_errors', '1');

$OriginationsAlert = new CampaignsOriginationsCapAlert();
$OriginationsAlert->execute();

$LeadSoldPerDayAlert = new CampaignsLeadSoldCapPerDayAlert();
$LeadSoldPerDayAlert->execute();

$LeadSoldPerWeekAlert = new CampaignsLeadSoldCapPerWeekAlert();
$LeadSoldPerWeekAlert->execute();

$LeadSoldPerMonthAlert = new CampaignsLeadSoldCapPerMonthAlert();
$LeadSoldPerMonthAlert->execute();
