<?php

require_once __DIR__ . '/../BootScript.php';
error_reporting(E_ERROR);

// command line argument "i" stands for ini file name like digitaljobler.ini, cashfairy.ini, bartlett.ini
$args = getopt("i:");

if(isset($args['i'])) {

    $ConfigININame = $args['i'];
    $ConfigINIPath =  APPLICATION_PATH . "/configs/".$ConfigININame;

    if (!file_exists($ConfigINIPath)) {
        echo "Specified config ini file does not exsists\n";
        return;
    }
}
else {
    echo "Please specify config ini file to be used using 'i' as argument name\n";
    return;
}

/***** load  database configuration  ******/
$config = new Zend_Config_Ini($ConfigINIPath, APPLICATION_ENV);
$registry = Zend_Registry::getInstance();
$registry->set('config', $config);

/***** setup databse  ******/
$db = Zend_Db::factory($config->db->adapter, $config->db->config->toArray());
Zend_Db_Table::setDefaultAdapter($db);
Zend_Registry::set('db', $db);

// Use try catch to see if any exception occured
try {
    $dailyCampaignReports = new DailyCampaignReports();
    $dailyCampaignReports->execute();
}
catch (Exception $e) {
    echo "Exception occured:".$e->getMessage();
}
?>