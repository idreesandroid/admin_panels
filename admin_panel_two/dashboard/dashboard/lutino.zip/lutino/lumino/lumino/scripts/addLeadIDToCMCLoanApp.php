<?php

/**
 * before running this script, 
 * simply set all leadID = PDLoan_Rcvd for any STANDARD loans.
 * ie the leadIDs for standard loans are SOMETIMES provided in the PDLoan_Rcvd field
 *
 * this script will then populate all the renewal rows
 */
set_time_limit(0);

require_once __DIR__ . '/../BootScript.php';

error_reporting(E_ALL);
ini_set('display_errors', '1');

$db = Zend_Registry::get('db');

$counter = 0;

# CMCLoan_App
$sql = "select Cust_ID, Cust_SSN, Loan_Type, ApplicationDate, Merch_Store_ID 
	from CMCLoan_App 
	where Merch_Store_ID = '42100000003' 
	and leadID = 0
	order by ApplicationDate asc";

$rows = $db->fetchAll($sql);

foreach ($rows as $row) 
{
	$Matcher = new LeadMatcherLoanApp($row['Cust_ID'], 
		$row['Cust_SSN'], 
		$row['Loan_Type'], 
		$row['Merch_Store_ID'], 
		$row['ApplicationDate']);

	if ($leadID = $Matcher->execute()) 
	{
		$sql = "update CMCLoan_App set leadID = $leadID 
			WHERE Cust_ID = " . $row['Cust_ID'] . 
			" AND ApplicationDate = '" . $row['ApplicationDate'] . "'";
		$db->query($sql);
		$counter++;
	}
}

echo $counter . " rows updated" . "\r\n";
echo "=== DONE ===";
