<?php

set_time_limit(0);

require_once __DIR__ . '/../BootScript.php';

error_reporting(E_ALL);
ini_set('display_errors', '1');

$CMCImportTranReport = new CMCImportTranReport();

$CMCImportTranReport->importSystem();

echo "Importing Cover Me Cash data has completed\n";

echo date('Y-m-d H:i:s') . "\n";
