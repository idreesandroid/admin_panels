<?php

class VeritecSSNValitator implements IVeritecSubmitter
{
	private $HttpClient;

	/**
	 * live Veritec's URL
	 * @var
	 */
	const POST_URL = "https://www.ilpdl.com/ProcessRequest.aspx";
	/**
	 * the accept response from Veritec
	 * @var
	 */
	const ACCEPTED = '211';

	public function __construct()
	{
		$this->HttpClient = new Zend_Http_Client();
		$this->Logger = new DataLogger("VeritecSSNValitator", "daily");
	}

	function submit($lead)
	{
		$this->Logger->logtofile('*** Start submitting data to Veritec ***');

		// post to vendor
		$this->HttpClient->setUri(self::POST_URL);

		try
		{
			$response = $this->HttpClient->setRawData(
				$this->prepareParams($lead), 'text/xml')->request('POST');

			$this->Logger->logtofile('leadID:' . $lead['ssn'] .
				" response returned:" . $response->getBody());

			$parsedResponse = $this->parseResponse($response->getBody());

			$this->Logger->logtofile('*** End submitting data to Veritec ***');

			return $parsedResponse;
		}
		catch (Exception $e)
		{
			$this->Logger->logtofile('leadID:' . $lead['ssn'] .
				" Exception:" . $e->getMessage());
			return NULL;
		}
	}

	/**
	 * prepare parameters for posting
	 *
	 * @param array $lead
	 * @return xml
	 */
	public function prepareParams($lead)
	{
		$xml = '<?xml version="1.0" encoding="utf-8"?>
				<msponline>
			    <transactionrequest>
					<reglicnum>1945</reglicnum>
				    <username>'.$lead['username'].'</username>
				    <password>'.$lead['password'].'</password>
					<actioncode>SN</actioncode>
					<ssn>' . $lead['ssn'] . '</ssn>
					<custdateofbirth>' . $lead['dob'] . '</custdateofbirth>
				</transactionrequest>
			</msponline>';

		return $xml;
	}

	/**
	 * parse the xml response body to set the 'postStatus' element.
	 * which is used to determine if the lead score passed or not
	 *
	 * @param xml $xmlResponseBody
	 * @return array
	 */
	public function parseResponse($xmlResponseBody)
	{
		$parsedResponse = simplexml_load_string($xmlResponseBody);
		$response = array();
		$response['postStatus']	= "no";
		$response['xml'] = $xmlResponseBody;

		if ((string)$parsedResponse->transactionresponse->responsecode == self::ACCEPTED) {
			$response['postStatus']	= "accept";
		}
		return $response;
	}
}