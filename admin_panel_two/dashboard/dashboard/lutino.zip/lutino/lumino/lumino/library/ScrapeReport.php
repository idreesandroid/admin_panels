<?php

/** 
 * Scrape Report base class
 *
 * @category	Library
 * @package	Library
 * @author	Andrew Ahn <ahn.andrews@gmail.com>
 */
abstract class ScrapeReport {

	public function __construct(DateTime $startDate = NULL, DateTime $endDate = NULL)
	{

		if(is_null($startDate)) { 
			$this->startDate = new DateTime();
		}
		else {
			$this->startDate = $startDate;
		}
	
		if(is_null($endDate)) {
			$this->endDate = new DateTime();
		}
		else {
			$this->endDate = $endDate;
		}

	}

	/**
	 * Scrape the file from other system
	 *
	 * @return			array	scraped data
	 */
	abstract public function pullFile();

	/**
	 * Imports the scraped data to the database
	 *
	 */
	abstract public function importToDB();

	/**
	 * Runs the whole scrape/import process
	 *
	 */
	abstract public function scrapeSystem();

        /*
         * Gets the value of a specific input field from an html page
         *
         * @param       inputName       string  name of the input field
         * @param       html            string  html page
         *
         * @return                      string value of the input field
         */
        public function getInputValue($inputName, $html)
        {

                preg_match_all("/\<input[^>]*>/", $html, $matches);

                foreach($matches[0] as $key => $value) {

                        if(preg_match("/name=\"([^\"]*)\"/", $value, $inputname)) {
                                if(preg_match("/value=\"?([^(\"|>)]*)\"?/", $value, $inputval)) {
                                        if($inputname[1] == $inputName) {
                                                $inputValue = $inputval[1];
                                                break;
                                        }
                                }
                        }
                }

                return $inputValue;
        }

}
