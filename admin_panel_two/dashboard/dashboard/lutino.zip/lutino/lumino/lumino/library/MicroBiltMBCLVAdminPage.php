<?php

class GetReport
{
	public $inquiry; // MBCLVRq_Type
}

class GetReportResponse
{
	public $GetReportResult; // MBCLVRs_Type
}

class GetRawReport
{
	public $guid; // string
}

class GetRawReportResponse
{
	public $GetRawReportResult; // string
}

class GetArchiveReport
{
	public $guid; // string
}

class GetArchiveReportResponse
{
	public $GetArchiveReportResult; // MBCLVRs_Type
}

class Transform
{
	public $inquiry; // MBCLVRq_Type
}

class TransformResponse
{
	public $TransformResult; // string
}

class Map
{
	public $bureauResponse; // string
}

class MapResponse
{
	public $MapResult; // MBCLVRs_Type
}


/**
 * MBCLV1_1 class
 *
 *
 *
 * @author    {author}
 * @copyright {copyright}
 * @package   {package}
 */
class MicroBiltMBCLVAdminPage extends SoapClient
{

	private static $classmap = array(
		'GetReport' => 'GetReport',
		'GetReportResponse' => 'GetReportResponse',
		'GetRawReport' => 'GetRawReport',
		'GetRawReportResponse' => 'GetRawReportResponse',
		'GetArchiveReport' => 'GetArchiveReport',
		'GetArchiveReportResponse' => 'GetArchiveReportResponse',
		'Transform' => 'Transform',
		'TransformResponse' => 'TransformResponse',
		'Map' => 'Map',
		'MapResponse' => 'MapResponse',
	);

	public function MicroBiltMBCLVAdminPage($wsdl = "https://sdkstage.microbilt.com/WebServices/MBCLV11/MBCLV.svc?wsdl", $options = array())
	{
		foreach (self::$classmap as $key => $value) {
			if (!isset($options['classmap'][$key])) {
				$options['classmap'][$key] = $value;
			}
		}
		parent::__construct($wsdl, $options);
	}

	/**
	 *
	 *
	 * @param GetReport $parameters
	 * @return GetReportResponse
	 */
	public function GetReport($post_string)
	{
		$thisRequestParameters = new GetReport();
		$resultArr = $this->makeParametersArrayFromXMLString($post_string);
//		var_dump($resultArr);
		$thisRequestParameters->inquiry = $resultArr;

		return $this->__soapCall('GetReport', array($thisRequestParameters), array(
				'uri' => 'http://services.microbilt.com/MBCLVWorkflow/v1.1',
				'soapaction' => ''
			)
		);
	}

	/**
	 *
	 *
	 * @param GetRawReport $parameters
	 * @return GetRawReportResponse
	 */
	public function GetRawReport(GetRawReport $parameters)
	{
		return $this->__soapCall('GetRawReport', array($parameters), array(
				'uri' => 'http://services.microbilt.com/MBCLVWorkflow/v1.1',
				'soapaction' => ''
			)
		);
	}

	/**
	 *
	 *
	 * @param GetArchiveReport $parameters
	 * @return GetArchiveReportResponse
	 */
	public function GetArchiveReport(GetArchiveReport $parameters)
	{
		return $this->__soapCall('GetArchiveReport', array($parameters), array(
				'uri' => 'http://services.microbilt.com/MBCLVWorkflow/v1.1',
				'soapaction' => ''
			)
		);
	}

	/**
	 *
	 *
	 * @param Transform $parameters
	 * @return TransformResponse
	 */
	public function Transform(Transform $parameters)
	{
		return $this->__soapCall('Transform', array($parameters), array(
				'uri' => 'http://services.microbilt.com/MBCLVWorkflow/v1.1',
				'soapaction' => ''
			)
		);
	}

	/**
	 *
	 *
	 * @param Map $parameters
	 * @return MapResponse
	 */
	public function Map(Map $parameters)
	{
		return $this->__soapCall('Map', array($parameters), array(
				'uri' => 'http://services.microbilt.com/MBCLVWorkflow/v1.1',
				'soapaction' => ''
			)
		);
	}

	function makeParametersArrayFromXMLString($xmlstr)
	{
		$doc = new DOMDocument();
		$doc->loadXML($xmlstr);
		return $this->domnode_to_array($doc->documentElement);
	}

	function domnode_to_array($node)
	{
		$output = array();
		switch ($node->nodeType) {
			case XML_CDATA_SECTION_NODE:
			case XML_TEXT_NODE:
				$output = trim($node->textContent);
				break;
			case XML_ELEMENT_NODE:
				for ($i = 0, $m = $node->childNodes->length; $i < $m; $i++) {
					$child = $node->childNodes->item($i);
					$v = $this->domnode_to_array($child);
					if (isset($child->tagName)) {
						$t = $child->tagName;
						if (!isset($output[$t])) {
							$output[$t] = array();
						}
						$output[$t][] = $v;
					} elseif ($v) {
						$output = (string)$v;
					}
				}
				if (is_array($output)) {
					if ($node->attributes->length) {
						$a = array();
						foreach ($node->attributes as $attrName => $attrNode) {
							$a[$attrName] = (string)$attrNode->value;
						}
						$output['@attributes'] = $a;
					}
					foreach ($output as $t => $v) {
						if (is_array($v) && count($v) == 1 && $t != '@attributes') {
							$output[$t] = $v[0];
						}
					}
				}
				break;
		}
		return $output;
	}

}

?>
