<?php

/**
 * this will determine the correct model to use for getting campaign report data.
 * ie different instances will use different LMS's. (TDC, Epic, etc)
 */
class DailyCampaignReportLMSFactory
{
	/**
	 * NOTE: switch statement okay here as it will not be duplicated anywhere.
	 *
	 * @param string name of lms in config
	 * @return CampaignReportAbstract concrete class (defaults to tdc)
	 */
	public function create($lmsName = NULL)
	{
		switch ($lmsName)
		{
			case 'tdc':
				return new TdcDailyCampaignReport();
				break;
			case 'epic':
				return new EpicDailyCampaignReport();
				break;
			case 'infinity':
				return new InfinityDailyCampaignReport();
				break;
			default:
				return new TdcDailyCampaignReport();
				break;
		}

		return new TdcDailyCampaignReport();
	}
}
