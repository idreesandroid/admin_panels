<?php
require_once 'Zend/Log.php';
require_once 'Zend/Log/Writer/Stream.php';
require_once 'Zend/Log/Formatter/Simple.php';

class DataLogger
{
	private $format;
	private $formatter;
	private $logger;
	private $logfilename;
	private $writer;
	
	function __construct($logfile,$duration="month")
	{
	    $format = '%message%' . PHP_EOL;
	    $formatter = new Zend_Log_Formatter_Simple($format);
		$this->logger = new Zend_Log();

	    $logfiledir = "application/logs/";
	    $logfilename = $logfiledir . date("m-Y")."-$logfile.txt";
	    if ($duration != "month")
	        $logfilename = $logfiledir . date("m-d-Y")."-$logfile.txt";
	    $writer = new Zend_Log_Writer_Stream($logfilename);
	    $writer->setFormatter($formatter);
	    $this->logger->addWriter($writer);
	}

	function logtofile($data)
	{
		$data = date("m-d-y H:i:s") . "_" . $data;
		$this->logger->info($data);
	}
	
	function removewhitespace ($data)
	{
		$whitespace_array = array("\n","\r\n","\r","\t","\x0B","\0");
		$data = str_replace($whitespace_array,"",$data);
		$data = preg_replace('/(\\s){2,}/', '$1', $data);
		
		return $data;
	}
}
?>
