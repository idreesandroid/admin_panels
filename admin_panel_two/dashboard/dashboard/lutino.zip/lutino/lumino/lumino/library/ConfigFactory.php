<?php

/**
 * this will determine the correct config file to use
 * depending on the HTTP_HOST value
 */
class ConfigFactory
{
	public function __construct()
	{

	}

	/**
	 * NOTE: switch statement okay here for now
	 * as it will not be duplicated anywhere.
	 *
	 * @param array $server the $_SERVER superglobal
	 * @return string the complete path to config file
	 */
	public function create($server)
	{
		// unit tests dont have this value
		if (!isset($server['HTTP_HOST'])) {
			return APPLICATION_PATH . "/configs/digitaljobler.ini";
		}

		$pieces = explode('.', $server['HTTP_HOST']);

		switch ($pieces[0])
		{
			case 'admin':
				$config = 'digitaljobler.ini';
				break;
			case 'tc-admin':
				$config = 'turbo.ini';
				break;
			case 'coboste-admin':
				$config = 'coboste.ini';
				break;
			case 'pinelake-admin':
				$config = 'pinelake.ini';
				break;
			case 'atlas-admin':
				$config = 'atlas.ini';
				break;
			case 'cfu-admin':
				$config = 'cashfactory.ini';
				break;
			case 'sf-admin':
				$config = 'sokaogon.ini';
				break;
			case 'mci-admin':
				$config = 'mci.ini';
				break;
			case 'emo-admin':
				$config = 'emoney.ini';
				break;
			case 'roi-admin':
				$config = 'roi.ini';
				break;
			case 'cmc-admin':
				$config = 'cmc.ini';
				break;
			case 'cl-admin':
				$config = 'cl.ini';
				break;
			case 'bennys-admin':
				$config = 'bennys.ini';
				break;
			case 'ntm-admin':
				$config = 'nationaltm.ini';
				break;
			case 'uso-admin':
				$config = 'uso.ini';
				break;
			case 'lsusa-admin':
				$config = 'loanstarusa.ini';
				break;
			case 'bm-admin':
				$config = 'bartlett.ini';
				break;
			case 'fxq-admin':
				$config = 'fxq.ini';
				break;
			case 'cf-admin':
				$config = 'cashfairy.ini';
				break;
			case 'hh-admin':
				$config = 'helpinghand.ini';
				break;
			case 'uni-admin':
				$config = 'united.ini';
				break;
			case 'hyper-admin':
				$config = 'hyper.ini';
				break;
			case 'ess-admin':
				$config = 'essential.ini';
				break;
			case 'ef-admin':
				$config = 'extrafunds.ini';
				break;
			case 'apo-admin':
				$config = 'apo.ini';
				break;
			case 'clake-admin':
				$config = 'clearlake.ini';
				break;
			case 'sw-admin':
				$config = 'springwater.ini';
				break;
			case 'sm-admin':
				$config = 'soaren.ini';
				break;
			case 'cashland-admin':
				$config = 'cashland.ini';
				break;
			case 'allegro-admin':
				$config = 'allegro.ini';
				break;
			case 'pocketfund-admin':
				$config = 'pocketfund.ini';
				break;
			case 'ltowers-admin':
				$config = 'ltowers.ini';
				break;
			case 'arcsun-admin':
				$config = 'arcsun.ini';
				break;
			case 'mnl-admin':
				$config = 'mynetlender.ini';
				break;
			case 'lendmart-admin':
				$config = 'lendmart.ini';
				break;
			case 'staging-admin':
				$config = 'staging.ini';
				break;
			default:
				die("oops.. Invalid admin url");
				break;
		}

		return APPLICATION_PATH . "/configs/$config";
	}
}
