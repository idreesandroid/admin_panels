<?php

/**
 * this will determine the correct model to use for getting dashboard data.
 * ie different instances will use different LMS's. (TDC, Epic, etc)
 */
class DashboardReportLMSFactory
{

	/**
	 * NOTE: switch statement okay here as it will not be duplicated anywhere.
	 *
	 * @param string name of lms in config
	 * @return DashboardReportData concrete class (defaults to tdc)
	 */
	public function create($lmsName = NULL)
	{
		switch ($lmsName)
		{
			case 'tdc':
				return new DashboardData();
				break;
			case 'epic':
				return new EpicDashboardData();
				break;
			case 'infinity':
				return new InfinityDashboardData();
				break;
			default:
				return new DashboardData();
				break;
		}

		return new DashboardData();
	}
}
