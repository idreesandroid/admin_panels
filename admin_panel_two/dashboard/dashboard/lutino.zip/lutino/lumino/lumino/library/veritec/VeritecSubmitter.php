<?php

/**
 *
 */
class VeritecSubmitter
{
	private $DataSubmitter;

	/**
	 * FormValidator constructor.
	 * @param $formValidator
	 */
	public function __construct(IVeritecSubmitter $DataSubmitter)
	{
		$this->DataSubmitter = $DataSubmitter;
	}

	public function submit($data) {
		return $this->DataSubmitter->submit($data);
	}
}