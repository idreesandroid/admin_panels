<?php

class ReportCalc {

	/**
 	 * Calculates the costPerLead
	 *
	 * @param		cost		double	total cost of leads
	 * @param		leadsold	int	number of lead sold
	 *
	 * @return				double	costPerLead
	 */	
	static public function costPerLead($cost, $leadsold)
	{
		return ($cost > 0 && $leadsold > 0) ? $cost / $leadsold : 0;
	}

	/**
	 * Calculates the total price
	 *
	 * @param		cost		double	total cost of leads
	 * @param		leadsold	int	number of lead sold
	 *
	 * @return				double	costPerLead
	 */
	static public function totalPrice($cost, $leadsold)
	{
		return ($cost > 0 && $leadsold > 0) ? $cost * $leadsold : 0;
	}
	/**
	 * Calulates the costPerOriginated
	 * 
	 * @param		totalCost	double	total cost of leads
	 * @param		originated	int	number of originated
	 *
	 * @return				double	cost per originated
	 */
	static public function costPerOriginated($totalCost, $originated)
	{
		return ($originated == 0) ? 0 : ($totalCost / $originated);
	}

	/**
 	 * Percent originated from leads bought
	 *
	 * @param		originated	int	number of originated
	 * @param		bought		int	number of leads bought
	 *
	 * @return				double	percent originated over leads bought
	 */
	static public function percentOriginatedvsBought($originated, $bought)
	{
		return ($originated > 0 && $bought > 0) ? 100 * ($originated / $bought) : 0;
	}

	/**
 	 * Percent bought from attempted leads
	 * 
	 * @param		bought		int	number of leads bought
	 * @param		leads		int	number of leads attempted
	 *
	 * @return				double	percent bought over attempted leads
	 */
	static public function percentBoughtvsAttempted($bought, $leads)
	{
		return ($bought > 0 && $leads > 0) ? 100 * ($bought / $leads) : 0;
	}

	/**
 	 * Esignature Rate
	 * 
	 * @param		esigs		int	number of valid esigs
	 * @param		leads		int	number of leads
	 * 
	 * @return				double	esignature rate
	 */	
	static public function esigRate($esigs, $leads)
	{
		return ($esigs > 0 && $leads > 0) ? 100 * ($esigs / $leads) : 0;
	}


	/**
	 * applicants redirect rate
	 *
	 * @param		esigs		int	number of leads bought
	 * @param		leads		int	number of redirects for an applicant
	 *
	 * @return		double	redirect rate
	 */
	static public function redirectsRate($bought, $redirects)
	{
		return ($redirects > 0 && $bought > 0) ? 100 * ($redirects / $bought) : 0;
	}

	/**
	 * first payment default rate
	 *
	 * @param		fpd		int	number of first payment default
	 * @param		totaloriginated		int	number of originated
	 *
	 * @return		double	redirect rate
	 */
	static public function fpdRate($totaloriginated, $fpd)
	{
		return ($fpd > 0 && $totaloriginated > 0) ? 100 * ($fpd / $totaloriginated) : 0;
	}

}
