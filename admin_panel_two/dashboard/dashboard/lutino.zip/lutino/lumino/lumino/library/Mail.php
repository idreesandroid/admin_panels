<?php
class Mail
{
    private $file;
    private $fileName;
    private $zendMail;
    
    public function __construct () {
        $this->zendMail = new Zend_Mail();
    }
    
    public function setFromEmail($fromemail,$fromname) {
        $this->zendMail->setFrom($fromemail, $fromname);
    }
    
    public function setToEmail($toemail,$toname) {
        $this->zendMail->addTo($toemail, $toname); 
    }
    
    public function setSubject($subject) {
        $this->zendMail->setSubject($subject);
    }
    
    public function setBody($body) {
        $this->zendMail->setBodyText($body);
    }
    
    public function setAttachment($attachmentData) {
        $this->file = $this->zendMail->createAttachment($attachmentData);
    }
    
    public function setFileName($filename) {
        $this->file->filename = $filename;
    }
    
    public function send() {
        $this->zendMail->send();
    }
    
}

?>