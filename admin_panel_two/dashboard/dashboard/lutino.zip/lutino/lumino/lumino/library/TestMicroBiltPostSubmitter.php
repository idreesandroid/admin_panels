<?php
/**
 *
 */

class TestMicroBiltPostSubmitter
{
	private $isApproved;
	private $isResponseOK;
	private $childstest = array();
	public function sendRequestToMicroBilt($postSetupId) {
		$xmlRequestString = $this->buildXMLRequest();

		$formatedXMLrequest = $this->formatFields($xmlRequestString);
		$response = $this->postXML($formatedXMLrequest['formattedPostXMLString']);
		$postStatus = $this->isApproved ? 'accept' : 'no';

		$this->saveToPostLogs(  $formatedXMLrequest['lead'],
								$postSetupId,
								$response['postXMLString'],
								$response['responseXMLString'],
								$postStatus,
								$response['startPostTime'],
								$response['endPostTime']);

		if ($this->isResponseOK()) {
			$microBiltParser = new MicroBiltParser();
			$data = $microBiltParser->parseResponse($response['simpleXML'], $formatedXMLrequest['lead']);
			$this->saveResponse($data);
		}
		return $response;
	}

	public function formatFields($xmlRequestString) {
		$obj = new Commonfunctions();
		#**** Define all legends here ****#
		$temp = array();
		$offerid = "1034";
		$lead = array();
		$lead['memberId'] = "CCC0006921";
		$lead['memberPwd'] = "1217090911";
		$lead['id'] = "1034";
		$lead['fname'] = "Nader".chr(97 + mt_rand(0, 25));
		$lead['lname'] = "Samuel".chr(97 + mt_rand(0, 25));
		$lead['address'] = "546 Terry Vista";
		$lead['city']= "Central";
		$lead['state']= "AL";
		$lead['zip'] = "36024";
		$lead['email'] = "test".rand(3,99)."@domain.com";
		$lead['hphone']="213334".rand(1001,9999);
		$lead['wphone'] = "213334".rand(1001,9999);
		$lead['wphone_ext'] = "436";
		$lead['dob'] = "1979-0".rand(1,9)."-".rand(10,30);
		$lead['title'] = "title";
		$lead['optin'] = 1;
		$lead['productcode'] = "cash";
		$lead['originaldate'] = date("Y-m-d");
		$lead['originaltime']=date("H:i:s");
		$lead['leadsold'] = 1;
		$lead['masteraff'] = "CD101";
		$lead['campaign'] = "2191";
		$lead['subid'] = "subid1";
		$lead['leadID'] = rand(3953,90321);
		$lead['employer'] = "Acne International";
		$lead['monthlyincome'] = "6000";
		$lead['military'] = 0;
		$lead['paymethod']= "checking";
		$lead['payperiod'] = "biweekly";
		$lead['paydate1'] = date("Y-m-d",strtotime('+7 days'));
		$lead['paydate2'] = date("Y-m-d",strtotime('+21 days'));
		$lead['ssn'] = "44925".rand(1001,9999);
		$lead['aba']="122000661";
		$lead['ownrent'] = "own";
		$lead['timetocall'] = "evening";
		$lead['licensenumber'] = rand(1000000,9999999);
		$lead['licensestate'] = "AL";
		$lead['citizen'] = 1;
		$lead['incomesource'] = "employed";
		$lead['timeatjob'] = 3;
		$lead['occupation'] = "Software development";
		$lead['empaddress'] = "3321 Roseview";
		$lead['empcity'] = "Queens";
		$lead['empstate'] = "NY";
		$lead['empzip'] = "86001";
		$lead['bank'] = "Bank of Amercia";
		$lead['accountnumber'] = rand(10,99)."3456789101";
		$lead['accounttype'] = "checking";
		$lead['bankphone'] = "4525629941";
		$lead['loanamount'] = "1500";
		$lead['ref1name'] = "Michael Josh";
		$lead['ref2name'] = "Peter Duran";
		$lead['ref1phone'] = "6238854496";
		$lead['ref2phone'] = "5449227654";
		$lead['ref1relation'] = "friend";
		$lead['ref2relation'] = "family";
		$temp['offeridenc'] = md5($offerid);
		$temp['hphone_area'] = "334";
		$temp['hphone_prefix'] = rand(200,989);
		$temp['hphone_suffix'] = "4681";
		$temp['wphone_area'] = "334";
		$temp['wphone_prefix'] = rand(200,989);
		$temp['wphone_suffix'] = "5681";
		$temp['dob_slash'] = "02/29/1912";
		$temp['time_long'] = date("H:i:s");
		$temp['time_ampm'] = date("g:ia");
		$temp['dob_month'] = "08";
		$temp['dob_day'] = "13";
		$temp['dob_year'] = "1979";
		$temp['date_slash'] = date("m/d/Y");
		$temp['nextworkday_slash'] = $obj->getNextWorkDay();

		$temp['pd1_year'] = date("Y",$lead['paydate1']);

		list($temp['pd1_year'],$temp['pd1_month'],$temp['pd1_day']) = explode("-",$lead['paydate1']);
		list($temp['pd2_year'],$temp['pd2_month'],$temp['pd2_day']) = explode("-",$lead['paydate2']);
		$temp['date_year'] = date("Y");
		$temp['date_month'] = date("m");
		$temp['date_day'] = date("d");
		$temp['date_dash'] = date("Y-m-d");
		$temp['ref1phone_area'] = "543";
		$temp['ref1phone_prefix'] = "583";
		$temp['ref1phone_suffix'] = "6553";
		$temp['ref2phone_area'] = "563";
		$temp['ref2phone_prefix'] = "383";
		$temp['ref2phone_suffix'] = "6533";
		$temp['paydate1_slash'] = $temp['pd1_month']."/".$temp['pd1_day']."/".$temp['pd1_year'];
		$temp['paydate2_slash'] = $temp['pd2_month']."/".$temp['pd2_day']."/".$temp['pd2_year'];
		$temp['bphone_area'] = "842";
		$temp['bphone_prefix'] = "532";
		$temp['bphone_suffix'] = "5955";
		$lead['ownrent'] = "own";
		$lead['ip'] = "192.168.1.1";
		$lead['monthsatresidence'] = "4";
		$lead['yearsatresidence'] = "7";

		$temp1    = "";
		$temp2    = "";
		$temp3    = "";
		$temp4    = "";
		$temp5    = "";
		$temp6    = "";
		$temp7    = "";
		$temp8    = "";
		$temp9    = "";
		$temp10   = "";

		// $temp1 = how long is the residency
		$this->doFieldsNormalization($lead, $temp1);

		foreach ($temp as $field => $value)
		{
			$xmlRequestString = str_replace("{".$field."}",$value,$xmlRequestString);
		}

		foreach ($lead as $field => $value)
		{
			$xmlRequestString = str_replace("{".$field."}",$value,$xmlRequestString);
		}

		$xmlRequestString = str_replace("{temp1}",$temp1,$xmlRequestString);
		$xmlRequestString = str_replace("{temp2}",$temp2,$xmlRequestString);
		$xmlRequestString = str_replace("{temp3}",$temp3,$xmlRequestString);
		$xmlRequestString = str_replace("{temp4}",$temp4,$xmlRequestString);
		$xmlRequestString = str_replace("{temp5}",$temp5,$xmlRequestString);
		$xmlRequestString = str_replace("{temp6}",$temp6,$xmlRequestString);
		$xmlRequestString = str_replace("{temp7}",$temp7,$xmlRequestString);
		$xmlRequestString = str_replace("{temp8}",$temp8,$xmlRequestString);
		$xmlRequestString = str_replace("{temp9}",$temp9,$xmlRequestString);
		$xmlRequestString = str_replace("{temp10}",$temp10,$xmlRequestString);


		$data = array();
		$data['lead'] = $lead;
		$data['formattedPostXMLString'] = $xmlRequestString;
		return $data;
	}

	public function doFieldsNormalization(&$lead, &$temp1) {
		switch ($lead['payperiod']) {
			case "biweekly":
				$lead['payperiod'] = "8";
				break;
			case "semimonthly":
				$lead['payperiod'] = "3";
				break;
			case "weekly":
				$lead['payperiod'] = "2";
				break;
			default:
				$lead['payperiod'] = "4";
				break;
		}

		switch ($lead['ownRent']) {
			case "own":
				$lead['ownRent'] = "1";
				break;
			case "rent":
				$lead['ownRent'] = "2";
				break;
			default:
				$lead['ownRent'] = "5";  // Other
				break;
		}

		$residenceTime = mktime(0, 0, 0, date("m")-$lead['monthsatresidence'], date("d"), date("y")-$lead['yearsatresidence']);
		$temp1 = date("Y-m-d", $residenceTime);
	}

	public function buildXMLRequest() {
//		return TestMicroBiltRequests::xmlRequest;
		return TestMicroBiltRequests::xmlRequestTestCase9_1;

//		return TestMicroBiltRequests::testRequest; // only for testing
	}

	public function postXML($postXMLString) {
		$thisClient = new MicroBiltMBCLVAdminPage();
		$startPostTime = date("H:i:s");
		$result = $thisClient->GetReport($postXMLString);
		$endPostTime = date("H:i:s");

		$obj = new ObjectAndXML();
		$responseXMLString = $obj->objToXML($result);

		$simpleXML= new SimpleXMLElement($responseXMLString);

		$this->isApproved = false;
		$this->isResponseOK = false;

		if ($result->GetReportResult->RESPONSE->CONTENT->DECISION->decision->_ == 'Approved') {
			$this->isApproved = true;
		}
		if ($result->GetReportResult->MsgRsHdr->Status->StatusCode == 0) {
			$this->isResponseOK = true;
		}

		return array("startPostTime" => $startPostTime,
					 "endPostTime" => $endPostTime,
					"postXMLString" => $postXMLString,
					"responseXMLString" => $responseXMLString,
					"responseStatusDesc" => $this->getResponseStatusDesc($result),
					"simpleXML" => $simpleXML);
	}




	function saveResponse($data) {
		$microBiltData = new MicroBiltData();
		$microBiltData->insert($data);
	}

	public function isApproved() {
		return $this->isApproved;
	}

	public function isResponseOK() {
		return $this->isResponseOK;
	}

	public function getResponseStatusDesc($result) {
		$statusCode = $result->GetReportResult->MsgRsHdr->Status->StatusCode;

		$statusDesc = '';
		switch ($statusCode) {
			case 0:
				$statusDesc = 'OK';
				break;
			case -1:
				$statusDesc = 'BUR. ERROR (Bureau Error)';
				break;
			case -2:
				$statusDesc = 'INTERNAL ERROR';
				break;
			case -3:
				$statusDesc = 'LINE ERROR';
				break;
			case -4:
				$statusDesc = 'NO HIT';
				break;
			case -5:
				$statusDesc = 'AUTHENTICATION ERROR';
				break;
			case -6:
				$statusDesc = 'IN_PROC';
				break;
		}
		return $statusDesc;
	}

	function saveToPostLogs($lead, $postSetupId, $requestXMLString, $responseXMLString, $postStatus, $startPostTime, $endPostTime) {
				$postlogdata = array(	'postSetupID' 	=> $postSetupId,
										'clientID' 		=> 4,
										'leadID' 		=> $lead['leadID'],
										'campaign' 		=> $lead['campaign'],
										'email' 		=> $lead['email'],
										'ssn' 		=> $lead['ssn'],
										'postStatus'	=> $postStatus,
										'postQueryString'	=> $requestXMLString,
										'postResponse'	=> $responseXMLString,
										'postDate'		=> date('Y-m-d'),
										'startTime'		=> $startPostTime,
										'endTime'       => $endPostTime,
										'productCode' 	=> "scoring");

		$postlogger = new PostLogs();
		$postlogger->insert($postlogdata);
	}
}
