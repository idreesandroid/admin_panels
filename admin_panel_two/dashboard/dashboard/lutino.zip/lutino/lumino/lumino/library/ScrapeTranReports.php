<?php

/** 
 * Scrape Report base class
 *
 * @category	Library
 * @package	Library
 * @author	Andrew Ahn <ahn.andrews@gmail.com>
 */
class ScrapeTranReports extends ScrapeReport {

	const BASE_URL = "https://web.tdclms.com/";
	const STORE_NO = "13420000004";
	const USERID = "MediaEnvyTech";
	const PASSWORD = "3nvyScr@p3rz";
	const COOKIE_FILE = "/tmp/trandot_scrape_cookie.txt";
	const ACCOUNT_FILE_TYPE = "A";
	const NOTE_FILE_TYPE = "N";
	const WHITELIST_FILE_TYPE = "G";

	public function __construct(DateTime $startDate, DateTime $endDate) 
	{

		parent::__construct($startDate, $endDate);

		$this->fileImports = array(
					array("name" => "Customer File",
					"modelName" => "CustFile",
					),
					array("name" => "Loan Application File",
						"modelName" => "LoanApp",
					),
					array("name" => "Master Loan File",
						"modelName" => "Master",
					),
					array("name" => "Payment File",
						"modelName" => "PayFile",
					),
					array("name" => "Accounting File",
						"modelName" => "AccountFile",
					),
					array("name" => "Call Notes",
						"modelName" => "CallNote",
					),
					array("name" => "Good Customer File",
						"modelName" => "CustomerWhitelist",
					)
		);

		$this->TRANStore = new TRANStore();

		$this->Logger = new DataLogger('ScrapeTranReports', 'daily');
	}

	/**
	 * Runs the whole scrape process
	 *
	 */
	public function scrapeSystem()
	{
		$this->Logger->logtofile('-- beginning ' . __METHOD__);

		$this->curlConnection = curl_init();

		if(!$this->loginProcess()) { 
			curl_close($this->curlConnection);

			$this->Logger->logtofile('Login Failed');
			throw Exception("Login Failed");
		}
		else {
			$this->Logger->logtofile('Login Successful');

			foreach($this->fileImports as $fileData) { 
				$this->Logger->logtofile('processing:' . $fileData['modelName']);

				$this->FileModel = new $fileData['modelName']();
				$this->modelName = $fileData['modelName'];

				if ($this->FileModel->cboFileType == self::WHITELIST_FILE_TYPE) {
					$stores = $this->TRANStore->fetchAll();
	
					foreach($stores as $store) { 
						$this->Logger->logtofile('beginning store:' . $store->storeID);

						$this->FileModel->storeID = $store->storeID;

						$downloadData = $this->pullFile();	

						$this->filePath = "scrapeDownloads/" . $this->FileModel->fileName . "_" . $store->storeID . "_" . $this->startDate->format("m_d_Y") . "_" . $this->endDate->format("m_d_Y");
						$this->Logger->logtofile('saving data file to:' . $this->filePath);

						$fp = fopen($this->filePath, "w+");
						fwrite($fp, $downloadData);
						fclose($fp);

						$this->Logger->logtofile('beginning importToDB()');
						$this->importToDB();
						$this->Logger->logtofile('importToDB() complete');
					}
				}
				else {
					$downloadData = $this->pullFile();	

					$this->filePath = "scrapeDownloads/" . $this->FileModel->fileName . "_" . $this->startDate->format("m_d_Y") . "_" . $this->endDate->format("m_d_Y");
					$this->Logger->logtofile('saving data file to:' . $this->filePath);

					$fp = fopen($this->filePath, "w+");
					fwrite($fp, $downloadData);
					fclose($fp);

					$this->Logger->logtofile('beginning importToDB()');
					$this->importToDB();
					$this->Logger->logtofile('importToDB() complete');
				}
			}
		}

		curl_close($this->curlConnection);
	}

	/**
	 * Logs into the system that is being scraped
	 */
	public function loginProcess()
	{

		curl_setopt($this->curlConnection, CURLOPT_SSL_VERIFYPEER, FALSE);

		// hit the login page
		$loginPage = CurlUtility::curlGet($this->curlConnection, self::BASE_URL . "LMSWEB/Menuman/Login.aspx", FALSE, self::COOKIE_FILE);

		$this->viewState = $this->getInputValue("__VIEWSTATE", $loginPage);

		$loginData = array("__EVENTTARGET" => "",
				"__EVENTARGUMENT" => "",
				"__VIEWSTATE" => $this->viewState,
				"__SCROLLPOSITIONX" => 0,
				"__SCROLLPOSITIONY" => 0,
				"ctl00_nav_ctl00_RadMenu1_ClientState" => "",
				"txtStoreNo" => self::STORE_NO,
				"txtUserId" => self::USERID,
				"txtPasswd" => self::PASSWORD
				);

		// post to log in to system
		$loggedIn = CurlUtility::curlPost($this->curlConnection, self::BASE_URL . "LMSWEB/Menuman/Login.aspx", $loginData);

		// hit the report page
		$reportPage = CurlUtility::curlGet($this->curlConnection, self::BASE_URL . "LMSWEB/UtilityManager/FileExport.aspx");

		$this->viewState = $this->getInputValue("__VIEWSTATE", $reportPage);

		if(!empty($reportPage)) { 
			return TRUE;
		}
		else {
			return FALSE;
		}

	}

	/**
	 * Pulls the specified file
	 *
	 * @return		string	csv file data
	 */
	public function pullFile()
	{
		/* 								
		    This checks if we are pulling the GoodCustomer/Whitelist exports
		    The export iterates through each store individually starting with the
		    self::FIRST_STORE and ending with self::LAST_STORE. 
		*/
		if ($this->FileModel->cboFileType == self::WHITELIST_FILE_TYPE)
		{	

			$csvData = '';
			/* 
			   This is the first of two posts to the tran system.  This one sets up 
			   the report with the correct dates, times and store.  
			 */
			$reportPost = array("__EVENTTARGET" => "cmdSearch",
                                        "__EVENTARGUMENT" => "",
                                        "__LASTFOCUS" => "",
                                        "__VIEWSTATE" => $this->viewState,
                                        "__SCROLLPOSITIONX" => 0,
                                        "__SCROLLPOSITIONY" => 0,
                                        "cboFileType" => $this->FileModel->cboFileType,
                                        "txtPaidOffDateFm" => $this->startDate->format("m/d/Y"),
                                        "txtPaidOffDateTo" => $this->endDate->format("m/d/Y"),
					"ddlStore" => $this->FileModel->storeID,
					"txtApplActivityDays" => "",
					"chkApplActivity" => "on",
					"txtAppsFundedFm" => "",
					"txtAppsFundedTo" => "",
					"txtRevenueFm" => "",
					"txtRevenueTo" => ""
                                        );
			$reportData = CurlUtility::curlPost($this->curlConnection, self::BASE_URL . "LMSWEB/UtilityManager/FileExport.Aspx",$reportPost);
			$this->viewState = $this->getInputValue("__VIEWSTATE", $reportData);

			/*
			   This post pulls down the csv data
			 */	
			$csvPost = array("__EVENTTARGET" => "",
						"__EVENTARGUMENT" => "",
						"__LASTFOCUS" => "",
						"__VIEWSTATE" => $this->viewState,
						"__SCROLLPOSITIONX" => 0,
						"__SCROLLPOSITIONY" => 209,
						"cboFileType" => $this->FileModel->cboFileType,
						"txtPaidOffDateFm" => $this->startDate->format("m/d/Y"),
						"txtPaidOffDateTo" => $this->endDate->format("m/d/Y"),
						"ddlStore" => $this->FileModel->storeID,
						"txtApplActivityDays" => "",
						"chkApplActivity" => "on",
						"txtAppsFundedFm" => "",
						"txtAppsFundedTo" => "",
						"txtRevenueFm" => "",
						"txtRevenueTo" => "",
						"cmdGetFile" => "Get File"
					);						
			$csvData = CurlUtility::curlPost($this->curlConnection, self::BASE_URL . "LMSWEB/UtilityManager/FileExport.Aspx", $csvPost);
		} 
		else
		{
	
			$reportPost = array("__EVENTTARGET" => "cmdSearch",
					"__EVENTARGUMENT" => "",
					"__LASTFOCUS" => "",
					"__VIEWSTATE" => $this->viewState,
					"__SCROLLPOSITIONX" => 0,
					"__SCROLLPOSITIONY" => 0,
					"cboFileType" => $this->FileModel->cboFileType,
					"txtDateFrom" => $this->startDate->format("m/d/Y"),
					"txtDateTo" => $this->endDate->format("m/d/Y")
					);

			if($this->FileModel->cboFileType == self::ACCOUNT_FILE_TYPE) {
				$reportPost['ddStoreNo'] = self::STORE_NO;
			}
			else if($this->FileModel->cboFileType == self::NOTE_FILE_TYPE) { 
				$reportPost['ddStoreNo'] = NULL;
				$reportPost['ddNoteType'] = "B";
			}
			
			// post to get report data	
			$reportData = CurlUtility::curlPost($this->curlConnection, self::BASE_URL . "LMSWEB/UtilityManager/FileExport.Aspx", $reportPost);
			$this->viewState = $this->getInputValue("__VIEWSTATE", $reportData);
	
			$csvPost = array("__EVENTTARGET" => "",
					"__EVENTARGUMENT" => "",
					"__LASTFOCUS" => "",
					"__VIEWSTATE" => $this->viewState,
					"__SCROLLPOSITIONX" => 0,
					"__SCROLLPOSITIONY" => 191,
					"cboFileType" => $this->FileModel->cboFileType,
					"txtDateFrom" => $this->startDate->format("m/d/Y"),
					"txtDateTo" => $this->endDate->format("m/d/Y"),
					"cmdGetFile" => "Get File"
					);

			if($this->FileModel->cboFileType == self::ACCOUNT_FILE_TYPE) { 
				$csvPost['ddStoreNo'] = self::STORE_NO;
			}
			else if($this->FileModel->cboFileType == self::NOTE_FILE_TYPE) { 
				$csvPost['ddStoreNo'] = NULL;
				$csvPost['ddNoteType'] = "B";
			}
			// post to get csv format data
			$csvData = CurlUtility::curlPost($this->curlConnection, self::BASE_URL . "LMSWEB/UtilityManager/FileExport.Aspx", $csvPost);
		}

		return $csvData;
	}

	/**
	 * Imports the data from the data file into the database
	 *
	 */
	public function importToDB() 
	{
		$fp = fopen($this->filePath, "r+");

		$i = 0;

		while(($fields = fgetcsv($fp, 1000, ",", '"')) !== FALSE) {
			if($i == 0) { 
				$i++;
				continue;
			}
			// remove semicolon at end of lines
			$lastColumn = sizeof($fields) - 1;
			$fields[$lastColumn] = substr($fields[$lastColumn], 0, strlen($fields[$lastColumn]) - 1);
		
			foreach($this->FileModel->dateFields as $dateField) {
				if(isset($fields[$dateField])) {
					$fields[$dateField] = $this->formatDate($fields[$dateField]);
				}
			}
			
			$insertData = $this->FileModel->buildInsertArray($fields);
			try {
				$this->FileModel->upsert($insertData);
			}
			catch(Zend_Exception $e)
			{
				$this->Logger->logtofile('exception occurred:' . $e->getMessage());
			}
			
			$i++;
		}
	}

	/**
  	 * Changes the date format from m/d/Y to Y-m-d
	 *
	 * @param		date	date	date to format
	 * 
	 * @return			date	date formatted as Y-m-d or Y-m-d h:i:s
	 */
	public function formatDate($date)
	{
		if(!empty($date)) { 	
			$dateTimeParts = explode(" ", str_replace(';', "", $date));
			
			if(isset($dateTimeParts[0])) { 
				$dateParts = explode("/", $dateTimeParts[0]);

				$newDate = $dateParts[2] . "-" . $dateParts[0] . "-" . $dateParts[1];
				
				if(isset($dateTimeParts[1])) { 
					$newDate .= " " . $dateTimeParts[1];
				}

			}
			else {
				$newDate = "0000-00-00";
			}
		}
		else {
			$newDate = "0000-00-00";
		}

		return $newDate;	
	}
}
