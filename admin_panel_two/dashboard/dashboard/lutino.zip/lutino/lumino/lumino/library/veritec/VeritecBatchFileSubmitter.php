<?php

class VeritecBatchFileSubmitter
{
	private $numberOfImportedRow = 0;
	private $HttpClient;

	/**
	 * live Veritec's URL
	 * @var
	 */
	const POST_URL = "https://www.ilpdl.com/ProcessRequest.aspx";

	/**
	 * the accept response from Veritec
	 * @var
	 */
	const ACCEPTED = '701';

	public function __construct()
	{
		$this->HttpClient = new Zend_Http_Client();
		$this->HttpClient->setConfig(array(
			'keepalive' => TRUE,
			'timeout'=> 180));
		$this->Logger = new DataLogger("VeritecBatchFileSubmitter", "daily");
	}

	function submit($csvfile)
	{
		ini_set("auto_detect_line_endings", true);

		$ini_get_temp = (int)ini_get("memory_limit");
		ini_set('memory_limit', '-1');

		$startDate = date('m-d-Y');

		$fileName = "Veritec_batch_result_" . $startDate . '.csv';
		$name = pathinfo($fileName, PATHINFO_FILENAME);
		$extension = pathinfo($fileName, PATHINFO_EXTENSION);

		$increment = ''; //start with no suffix

		$logfiledir = "/tmp/veritec/result/";

		// now we have to be sure that we already don't have the same name in the directory.
		// If we do have it, we will append postfix to the file name
		while (file_exists($logfiledir . $name . $increment . '.' . $extension) || file_exists($logfiledir . $name . '_' . $increment . '.' . $extension)) {
			$increment++;
		}

		$resultFileName = $name . '_' . $increment . '.' . $extension;

		$resultFileLocation = $logfiledir . $resultFileName;
		$resultFile = fopen($resultFileLocation, 'w');

		$delimiter = ';';
		fputcsv($resultFile, array('sep=;'), $delimiter);

		$lineCounter = 1;

		if (($handle = fopen($csvfile, "r")) !== FALSE) {
			while (($row = fgetcsv($handle, 5000)) !== FALSE) {
				if ($lineCounter == 1) {
					fputcsv($resultFile, array($row[0], $row[1], 'PostStatus', 'ResponseCode', 'ResponseDescription', 'ResponseOther'), $delimiter);
					++$lineCounter;
					continue;
				}

				$lead = array();
				$lead['ssn'] = str_replace("-", "", $row[0]);
				$lead['monthlyincome'] = $row[1];

				// skip the row if any of the required fields are empty
				if ($this->isNullOrEmptyString($lead['ssn']) || $this->isNullOrEmptyString($lead['monthlyincome'])) {
					continue;
				}

				// post to vendor
				$this->HttpClient->setUri(self::POST_URL);

				$this->Logger->logtofile('*** Start to submit the batch file: ' . $csvfile . ' to Veritec ***');
				try {
					$response = $this->HttpClient->setRawData(
						$this->prepareParams($lead), 'text/xml')->request('POST');

					$this->Logger->logtofile('leadID:' . $lead['ssn'] .
						" response returned:" . $response->getBody());

					$parsedResponse = $this->parseResponse($response->getBody());
					$row[] = $parsedResponse['postStatus'];
					$row[] = $parsedResponse['responsecode'];
					$row[] = $parsedResponse['responsedescription'];
					$row[] = $parsedResponse['responseother'];
					fputcsv($resultFile, $row, $delimiter);

					$this->numberOfImportedRow++;
				} catch (Exception $e) {
					$this->Logger->logtofile('lead ID:' . $lead['ssn'] .
						" Exception:" . $e->getMessage());
					$row[] = " Exception:" . $e->getMessage();
					fputcsv($resultFile, $row, $delimiter);
				}
			}

			fclose($handle);
		}

		fclose($resultFile);

		ini_set('memory_limit', $ini_get_temp);

		$this->Logger->logtofile('*** Finished submitting the batch file to Veritec. Submitted ' . $this->numberOfImportedRow . ' leads ***');

		return $resultFileName;
	}


	/**
	 * prepare parameters for posting
	 *
	 * @param array $lead
	 * @return xml
	 */
	public function prepareParams($lead)
	{
		$VeritecAdminPageCredential = new VeritecAdminPageCredential();
		$credentials = $VeritecAdminPageCredential->getCurrentCredentials();

		// if ssn contains less than 9 digits we should put 0 in front
		$ssn = str_pad($lead['ssn'], 9, '0', STR_PAD_LEFT);
		$xml = '<?xml version="1.0" encoding="utf-8"?>
				<msponline>
				<transactionrequest>
				    <reglicnum>1945</reglicnum>
				    <username>'.$credentials->username.'</username>
				    <password>'.$credentials->password.'</password>
				    <actioncode>CEI</actioncode>
				    <ssn>' . $ssn . '</ssn>
				    <custmonthlyincome>' . $lead['monthlyincome'] . '</custmonthlyincome>
				    <opencila>N</opencila>
				</transactionrequest>
				</msponline>';

		return $xml;
	}

	/**
	 * parse the xml response body to set the 'postStatus' element.
	 * which is used to determine if the lead score passed or not
	 *
	 * @param xml $xmlResponseBody
	 * @return array
	 */
	public function parseResponse($xmlResponseBody)
	{
		$parsedResponse = simplexml_load_string($xmlResponseBody);
		$response = array();
		$response['postStatus'] = "no";

		if ((string)$parsedResponse->transactionresponse->responsecode == self::ACCEPTED) {
			$response['postStatus'] = "accept";
		}

		$response['responsedescription']  = (string)$parsedResponse->transactionresponse->responsedescription;
		$response['responseother']  = (string)$parsedResponse->transactionresponse->responseother;
		$response['responsecode']  = (string)$parsedResponse->transactionresponse->responsecode;

		return $response;
	}

	function isNullOrEmptyString($question){
		return (!isset($question) || trim($question)==='');
	}
}