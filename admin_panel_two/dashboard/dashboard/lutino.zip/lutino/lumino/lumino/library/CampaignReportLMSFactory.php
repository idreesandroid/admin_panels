<?php

/**
 * this will determine the correct model to use for getting campaign report data.
 * ie different instances will use different LMS's. (TDC, Epic, etc)
 */
class CampaignReportLMSFactory
{
	public function __construct()
	{

	}

	/**
	 * NOTE: switch statement okay here as it will not be duplicated anywhere.
	 *
	 * @param string name of lms in config
	 * @return CampaignReportAbstract concrete class (defaults to tdc)
	 */
	public function create($lmsName = NULL)
	{
		switch ($lmsName)
		{
			case 'tdc':
				return new CampaignReport();
				break;
			case 'epic':
				return new EpicCampaignReport();
				break;
			case 'infinity':
				return new InfinityCampaignReport();
				break;
			default:
				return new CampaignReport();
				break;
		}

		return new CampaignReport();
	}
}
