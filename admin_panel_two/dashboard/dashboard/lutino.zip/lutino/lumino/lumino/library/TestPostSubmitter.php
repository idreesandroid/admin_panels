<?php
include_once "Commonfunctions.php";

class TestPostSubmitter
{
	/**
	 * @string default storeID for TRANDOTCOM
	 */
	const STORE_ID = '13420000001';

	public static function getCashLegend()
	{
		$legend = array();
		$Leads = new Leads();
		$LeadOptionals = new LeadOptionals();
		$Cash = new CashData();

		$leadColumns = array_values($Leads->info(Zend_Db_Table_Abstract::COLS));
		$optionalColumns = array_values($LeadOptionals->info(Zend_Db_Table_Abstract::COLS));
		$cashColumns = array_values($Cash->info(Zend_Db_Table_Abstract::COLS));

		$key = array_search("storeID", $leadColumns);
		if(!empty($key)) {
			$leadColumns[$key] = "store_id";
		}

		$temps = array("temp1","temp2","temp3","temp4","temp5","temp6","temp7","temp8","temp9","temp10");
		$mods  = array("leadidenc","hphone_area","hphone_prefix","hphone_suffix","wphone_area","wphone_prefix","wphone_suffix",
						"dob_slash","time_long","time_ampm","siteid","dob_month","dob_day","dob_year",
						"date_slash","date_dash","ref1phone_area","ref1phone_prefix","ref1phone_suffix",
						"ref2phone_area","ref2phone_prefix","ref2phone_suffix","paydate1_slash","pd1_month","pd1_day","pd1_year",
						"pd2_month","pd2_day","pd2_year","paydate2_slash","bphone_area","bphone_prefix","bphone_suffix","nextworkday_slash",
						"mphone_area","mphone_prefix","mphone_suffix", "last_payday", "last_payday_mdY", "clarity_tracking_number",
		                "masteraff","last_payday_future_adjust","gender","tierkey","storeID","date_year","date_month","date_day","dob_mmddyyyy",
		                "paydate1_dash","paydate1_mmddyyyy","paydate2_mmddyyyy","timeatjob_years","timeatjob_months_rounded",
		                "hiredate","paydate2_dash","clarity_cbb_score","clarity_clear_fraud_score","dl_request_code","price","underwriteio_score","variate_id","multivariate_id"
		);
		$megaArray = array_merge($leadColumns, $optionalColumns, $cashColumns, $mods, $temps);
		return $megaArray;
	}

	public static function prepareLegendsForView($cashlegends)
	{


	    $cashlegends = array_unique($cashlegends);
		sort($cashlegends);

		$columns = 3;
		$values = array();
		$numRows = count($cashlegends);
		$rowsPerColumn = ceil($numRows / $columns);

		for ($c=1;$c<=$columns;$c++)
		{
		    $values['col_'.$c] = array();
		}

		$column = 1;
		$row = 1;

		foreach ($cashlegends as $legend) {
		    $values['col_'.$column][$row] = $legend;
		    if ($row == $rowsPerColumn)
		    {
		        $column++;
		        $row = 1;
		    }
		    else {
		        $row++;
		    }
		}

		$result ='';
		for ($r=1;$r<=$rowsPerColumn;$r++) {
		    $result.= '<div class="row" style="margin-top:5px;">';
		    for ($c=1;$c<=$columns;$c++) {
		        $result.= '<div class="col-xs-4" style="color: #30a5ff">'.$values['col_'.$c][$r].'</div>';
		    }
		    $result.= '</div>';
		}

		return $result;
	}

	function Translate_Postdata($testurl,$postheader,$translation,$poststring,$postmethod)
	{
		$post_string = $poststring;
		$obj = new Commonfunctions();

		#**** Define all legends here ****#
		if(getenv('REMOTE_ADDR'))
		{
			$ip = getenv('REMOTE_ADDR');
		}
		else
		{
			 $ip = getenv('HTTP_X_FORWARDED_FOR');
		}

		#**** These are general i.e list managers  legends ****#
		$lead = array();

		$offerid = "1034";
		$lead['id'] = "1034";
		$lead['fname'] = "Nader".chr(97 + mt_rand(0, 25));
		$lead['lname'] = "Samuel".chr(97 + mt_rand(0, 25));
		$lead['address'] = rand(1,999)." Terry Vista";
		$lead['address2'] = "Terry Town White Palms";
		$lead['city']= "Central";
		$lead['state']= "AL";
		$lead['zip'] = "36024";
		$lead['email'] = "test".rand(3,99)."@domain.com";
		$lead['hphone']="213334".rand(1001,9999);
		$lead['wphone'] = "213334".rand(1001,9999);
		$lead['mphone'] = "213334".rand(1001,9999);
		$lead['wphone_ext'] = "436";
		$lead['dob'] = "1979-0".rand(1,9)."-".rand(1,30);
		$lead['title'] = "title";
		$lead['optin'] = 1;
		$lead['productcode'] = "cash";
		$lead['originaldate'] = date("Y-m-d");
		$lead['originaltime']=date("H:i:s");
		$lead['leadsold'] = 1;
		$lead['masteraff'] = "CD101";
		$lead['campaign'] = "2191";
		$lead['subid'] = "subid1";
		$lead['subid2'] = "subid2";
		$lead['subid3'] = "subid3";
		$lead['leadID'] = rand(3953,90321);
		$lead['employer'] = "Acne International";
		$lead['monthlyincome'] = "6000";
		$lead['military'] = 0;
		$lead['paymethod']= "checking";
		$lead['payperiod'] = "biweekly";
		$lead['paydate1'] = date("Y-m-d",strtotime('+7 days'));
		$lead['paydate2'] = date("Y-m-d",strtotime('+21 days'));
		$lead['ssn'] = "44925".rand(1001,9999);
		$lead['aba']="122000661";
		$lead['ownrent'] = "own";
		$lead['timetocall'] = "evening";
		$lead['licensenumber'] = rand(1000000,9999999);
		$lead['licensestate'] = "AL";
		$lead['citizen'] = 1;
		$lead['incomesource'] = "employed";
		$lead['timeatjob'] = 3;
		$lead['occupation'] = "Software development";
		$lead['empaddress'] = "3321 Roseview";
		$lead['empcity'] = "Queens";
		$lead['empstate'] = "NY";
		$lead['empzip'] = "86001";
		$lead['bank'] = "Bank of Amercia";
		$lead['accountnumber'] = rand(10,99)."3456789101";
		$lead['accounttype'] = "checking";
		$lead['bankphone'] = "4525629941";
		$lead['loanamount'] = "1500";
		$lead['ref1name'] = "Michael Josh";
		$lead['ref2name'] = "Peter Duran";
		$lead['ref1phone'] = "6238854496";
		$lead['ref2phone'] = "5449227654";
		$lead['ref1relation'] = "friend";
		$lead['ref2relation'] = "family";
		$lead['offeridenc'] = md5($offerid);
		$lead['hphone_area'] = "334";
		$lead['hphone_prefix'] = rand(200,989);
		$lead['hphone_suffix'] = "4681";
		$lead['wphone_area'] = "334";
		$lead['wphone_prefix'] = rand(200,989);
		$lead['wphone_suffix'] = "5681";
		$lead['mphone_area'] = "646";
		$lead['mphone_prefix'] = rand(200,989);
		$lead['mphone_suffix'] = "5632";
		$lead['dob_slash'] = "02/29/1912";
		$lead['time_long'] = date("H:i:s");
		$lead['time_ampm'] = date("g:ia");
		$lead['dob_month'] = "08";
		$lead['dob_day'] = "13";
		$lead['dob_year'] = "1979";
		$lead['date_slash'] = date("m/d/Y");
		$lead['nextworkday_slash'] = $obj->getNextWorkDay();
		$lead['monthsatresidence'] = "8";
		$lead['yearsatresidence'] = "2";
		$lead['ach'] = "1";
		$lead['affiliateID'] = 2309;
		$lead['bankbranchnumber'] = "5445907654";
		$lead['bankinstitutionnumber'] = "8475907630";
		$lead['bankruptcy'] = "0";
		$lead['leadidenc'] 	= md5("38554");

		$lead['pd1_year'] = date("Y",$lead['paydate1']);

		list($lead['pd1_year'],$lead['pd1_month'],$lead['pd1_day']) = explode("-",$lead['paydate1']);
		list($lead['pd2_year'],$lead['pd2_month'],$lead['pd2_day']) = explode("-",$lead['paydate2']);
		$lead['date_year'] = date("Y");
		$lead['date_month'] = date("m");
		$lead['date_day'] = date("d");
		$lead['date_dash'] = date("Y-m-d");
		$lead['ref1phone_area'] = "543";
		$lead['ref1phone_prefix'] = "583";
		$lead['ref1phone_suffix'] = "6553";
		$lead['ref2phone_area'] = "563";
		$lead['ref2phone_prefix'] = "383";
		$lead['ref2phone_suffix'] = "6533";
		$lead['paydate1_slash'] = $lead['pd1_month']."/".$lead['pd1_day']."/".$lead['pd1_year'];
		$lead['paydate2_slash'] = $lead['pd2_month']."/".$lead['pd2_day']."/".$lead['pd2_year'];
		$lead['bphone_area'] = "842";
		$lead['bphone_prefix'] = "532";
		$lead['bphone_suffix'] = "5955";
		$lead['ownrent'] = "own";
		$lead['ip'] = "192.168.1.1";

		$lead['last_payday'] = "2015-02-09";
		$lead['last_payday_mdY'] = "02/09/2015";

		$lead['last_payday_future_adjust'] = $lead['last_payday'];
		$lead['gender'] = "Male";
		$lead['tierkey'] = "zsdd45w2e";
		$lead['storeID'] = "storexx";
		$lead['date_year'] = substr(date("Y-m-d"),0,4);
		$lead['date_month'] = substr(date("Y-m-d"),5,2);
		$lead['date_day'] = substr(date("Y-m-d"),8,2);
		$lead['dob_mmddyyyy'] = $lead['dob_month'] . "/" . $lead['dob_day'] . "/" . $lead['dob_year'];
		$lead['paydate1_dash'] =  $lead['pd1_year'] . "-" . $lead['pd1_month'] . "-" . $lead['pd1_day'];
		$lead['paydate2_dash'] = $lead['pd2_year'] . "-" . $lead['pd2_month'] . "-" . $lead['pd2_day'];
		$lead['paydate1_mmddyyyy'] = $lead['pd1_month'] . "-" . $lead['pd1_day'] . "-" . $lead['pd1_year'];
		$lead['paydate2_mmddyyyy'] = $lead['pd2_month'] . "-" . $lead['pd2_day'] . "-" . $lead['pd2_year'];
		$lead['timeatjob_years'] = floor($lead['timeatjob']/12);
		$lead['timeatjob_months_rounded']  = ceil($lead['timeatjob']/12) * 12;
		$lead['hiredate'] = date('Y-m-d', strtotime('-' . $lead['timeatjob'] . ' months'));
		$lead['clarity_cbb_score'] = "xddert532";
		$lead['clarity_clear_fraud_score'] = 50;
		$lead['dl_request_code'] = 200;
		$lead['underwriteio_score'] = 0.83;
		$lead['variate_id'] = 5;
		$lead['multivariate_id'] = 10;


		$temp1    = "";
		$temp2    = "";
		$temp3    = "";
		$temp4    = "";
		$temp5    = "";
		$temp6    = "";
		$temp7    = "";
		$temp8    = "";
		$temp9    = "";
		$temp10   = "";

		eval($translation);

		$encodeit = (stristr($postheader,"urlencoded")) ? true : false;

   		foreach ($lead as $field => $value)
   		{
			$value = ($encodeit == true) ? urlencode($value) : $value;
   			$post_string = str_replace("{".$field."}",$value,$post_string);
   		}

		$post_string = str_replace("{temp1}",$temp1,$post_string);
		$post_string = str_replace("{temp2}",$temp2,$post_string);
		$post_string = str_replace("{temp3}",$temp3,$post_string);
		$post_string = str_replace("{temp4}",$temp4,$post_string);
		$post_string = str_replace("{temp5}",$temp5,$post_string);
		$post_string = str_replace("{temp6}",$temp6,$post_string);
		$post_string = str_replace("{temp7}",$temp7,$post_string);
		$post_string = str_replace("{temp8}",$temp8,$post_string);
		$post_string = str_replace("{temp9}",$temp9,$post_string);
		$post_string = str_replace("{temp10}",$temp10,$post_string);

		// storeID token
		$post_string = str_replace("{store_id}", self::STORE_ID, $post_string);

		#**** Now post data to the url and return the response ****#
		if (preg_match("/get/",$postmethod) || preg_match("/post/",$postmethod))
		{
			if($postmethod=="get")
			{
				$testurl.="?".$post_string;
			}

			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,$testurl);
	    	curl_setopt($ch, CURLOPT_VERBOSE, 0);
	    	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
	    	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	    	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);

		    if($postmethod=="post")
	    	{
	    		curl_setopt($ch, CURLOPT_POST, 1);
	    		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_string);
	    	}

	    	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
	    	if($postheader)
			{
				$headers_array = array();
				$headers_array[] = $postheader;
				curl_setopt($ch,CURLOPT_HTTPHEADER,$headers_array);
			}

	    	$result = curl_exec($ch);
	    	curl_close ($ch);

    		return array($post_string,$result);
		}
		elseif ($postmethod == "soap")
		{
			list($testurl,$soapcall) = explode(",",$testurl);
			$client = new SoapClient($testurl);
			$result = $client->$soapcall($post_string);
			return array($post_string,$result);
		}
	}
}
?>
