<?php

/** 
 * Import Report base class
 *
 * @category	Library
 * @package	Library
 * @author	Andrei Shkolin <andrews@mediaenvy.com>
 */
class CMCImportTranReport extends CMCImportReport {

	const CMC_IMPORT_DIR = 'scripts/cmcimport';

	public function __construct()
	{

		parent::__construct();

		$this->modelImports = array(
			array("name" => "CMC Call Notes",
				"modelName" => "CMCCallNote",
			),
			array("name" => "CMC Customer File",
				"modelName" => "CMCCustFile",
			),
			array("name" => "CMC Master Loan File",
				"modelName" => "CMCMaster",
			),
			array("name" => "CMC Payment File",
				"modelName" => "CMCPayFile",
			),
			array("name" => "CMC Accounting File",
				"modelName" => "CMCAccountFile",
			),
			array("name" => "CMC Loan Application File",
				"modelName" => "CMCLoanApp",
			),
			array("name" => "CMC Customer White List",
				"modelName" => "CMCCustomerWhitelist",
			)
		);
	}

	/**
	 * Runs the whole import process
	 *
	 */
	public function importSystem()
	{
		echo date('Y-m-d H:i:s') . "\n";
		$fileNames = $this->getFileNames(self::CMC_IMPORT_DIR);
		foreach ($fileNames as $vfilename) {
			$fileName = $this->getCurrentDataFileName($vfilename);
			echo $vfilename . "\n";

			foreach($this->modelImports as $fileData) {
				if ($fileName == $fileData['modelName']) {
					$this->FileModel = new $fileData['modelName']();
					$this->modelName = $fileData['modelName'];

					$this->importToDB($vfilename);
				}
			}
			continue;
		}
	}

	/**
	 * Imports the data from the data file into the database
	 *
	 */
	public function importToDB($fileName)
	{
		$fp = fopen(self::CMC_IMPORT_DIR . '/' . $fileName, "r");

		$i = 0;

		while(($fields = fgetcsv($fp, 1000, ",", '"')) !== FALSE) {
			if($i == 0) { 
				$i++;
				continue;
			}
			// remove semicolon at end of lines
			$lastColumn = sizeof($fields) - 1;
			$fields[$lastColumn] = substr($fields[$lastColumn], 0, strlen($fields[$lastColumn]) - 1);
		
			foreach($this->FileModel->dateFields as $dateField) {
				if(isset($fields[$dateField])) {
					$fields[$dateField] = $this->formatDate($fields[$dateField]);
				}
			}
			
			$insertData = $this->FileModel->buildInsertArray($fields);
			try {
				$this->FileModel->upsert($insertData);
			}
			catch(Zend_Exception $e)
			{
				echo $e->getMessage();
			}
			
			$i++;
		}
	}

	/**
  	 * Changes the date format from m/d/Y to Y-m-d
	 *
	 * @param		date	date	date to format
	 * 
	 * @return			date	date formatted as Y-m-d or Y-m-d h:i:s
	 */
	public function formatDate($date)
	{

		if(!empty($date)) { 	
			$dateTimeParts = explode(" ", str_replace(';', "", $date));
			
			if(isset($dateTimeParts[0])) { 
				$dateParts = explode("/", $dateTimeParts[0]);

				$newDate = $dateParts[2] . "-" . $dateParts[0] . "-" . $dateParts[1];
				
				if(isset($dateTimeParts[1])) { 
					$newDate .= " " . $dateTimeParts[1];
				}

			}
			else {
				$newDate = "0000-00-00";
			}
		}
		else {
			$newDate = "0000-00-00";
		}

		return $newDate;	
	}

	public function getCurrentDataFileName($file)
	{
		if (preg_match('/ACCTS/i', $file) == 1) {
			return 'CMCAccountFile';
		}
		if (preg_match('/CUSTS/i', $file) == 1) {
			return 'CMCCustFile';
		}
		if (preg_match('/GCUST/i', $file) == 1) {
			return 'CMCCustomerWhitelist';
		}
		if (preg_match('/LOANS/i', $file) == 1) {
			return 'CMCLoanApp';
		}
		if (preg_match('/MLNTS/i', $file) == 1) {
			return 'CMCMaster';
		}
		if (preg_match('/NOTES/i', $file) == 1) {
			return 'CMCCallNote';
		}
		if (preg_match('/PYMTS/i', $file) == 1) {
			return 'CMCPayFile';
		}
	}


	public function getFileNames($dir)
	{
		$fileNames = array();
		// Open a known directory, and proceed to read its contents
		if (is_dir($dir)) {
			if ($dh = opendir($dir)) {
				while (($file = readdir($dh)) !== false) {
					if ($file != '..' && $file != '.') {
						array_push($fileNames, $file);
					}
				}
				closedir($dh);
			}
		}
		return $fileNames;
	}


}
