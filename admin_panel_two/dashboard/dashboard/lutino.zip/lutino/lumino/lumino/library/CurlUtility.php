<?php

/**
 * Curl Helper Functions
 * 
 * @category	Library
 * @package	Library
 * @author	Andrew Ahn <ahn.andrews@gmail.com>
 */
class CurlUtility {

        /*
         * Takes an array of key/value post pairs and puts it in a url format key=urlencode(value)
         *
         * @param       postData        array   array of post key/value pairs
         *
         * @return                      string  post string of the format &key=value
         */
        public static function createPostString($postData)
        {
                $postString = "";

                foreach($postData as $key => $value) {
                        if(!empty($postString)) {
                                $postString .= "&";
                        }

                        $postString .= $key . "=" . urlencode($value);
                }

                return $postString;

        }

        /**
         * Uses the curl connection to do a post
         *
         * @param               curlConnection  obj     curlConnection object from a curl_init
         * @param               url             string  url to the page to post to
         * @param               postFields      array   array of post parameters
         *
         * @return                              string  html of the page returned from the post
         */
        public static function curlPost($curlConnection, $url, $postFields)
        {
	

		curl_setopt($curlConnection, CURLOPT_URL, $url);
                curl_setopt($curlConnection, CURLOPT_POST, TRUE);
                curl_setopt($curlConnection, CURLOPT_POSTFIELDS, self::createPostString($postFields));
                curl_setopt($curlConnection, CURLOPT_FOLLOWLOCATION, TRUE);

                return curl_exec($curlConnection);

        }

        /**
         * Uses the curl connection to do a get request
         *
         * @param               curlConnection  obj     curlConnection object from a curl_init
         * @param               url             string  url for the get request
         * @param               followLocation  boolean true to follow the redirect
 	 * @param		cookieFile	string	cookie file path
         *
         * @return                              string  html of the page returned from the get request
         */
        public static function curlGet($curlConnection, $url, $followLocation = TRUE, $cookieFile = "")
        {

                curl_setopt($curlConnection, CURLOPT_URL, $url);
                curl_setopt($curlConnection, CURLOPT_HTTPGET, TRUE);

                if($followLocation) {
                        curl_setopt($curlConnection, CURLOPT_FOLLOWLOCATION, TRUE);
                }

                curl_setopt($curlConnection, CURLOPT_RETURNTRANSFER, 1);
		
		if(!empty($cookieFile)) { 
			curl_setopt($curlConnection, CURLOPT_COOKIEJAR, $cookieFile);
		}

                return curl_exec($curlConnection);

        }
}
