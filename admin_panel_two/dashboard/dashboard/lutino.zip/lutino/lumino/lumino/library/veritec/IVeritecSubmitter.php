<?php

/**
 * 
 */
interface IVeritecSubmitter
{
	public function submit($data);
}