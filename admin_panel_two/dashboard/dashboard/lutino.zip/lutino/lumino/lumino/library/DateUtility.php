<?php

class DateUtility 
{
	/**
	 * finds the date for a given weekday.
	 * ie. can be used to find ALL dates for the last 4 mondays.
	 *
	 * @param string $dayOfWeek the day we are interested in e.g. 'Monday'
	 * @param integer $weeksRange how many weeks to look back
	 * @return array all dates for the given day
	 */
	public function getWeekdayDates($dayOfWeek, $weeksRange)
	{
		$dayCount = 1;
		$dates = array();

		while ($dayCount <= $weeksRange) {
			$date = date('Y-m-d', strtotime("$dayCount $dayOfWeek ago"));
			array_push($dates, $date);
			$dayCount++;
		}
		return $dates;
	}

	/**
	 * Gets time blocks between two time periods with the period in minutes
	 *
	 * @param		time		$start	start time in H:i:s format (e.g. 00:00:00)
	 * @param		time		$end		end time in H:i:s format (e.g. 00:00:00)
	 * @param		int		$minutes	number of minutes in each time block
	 *
	 * @return	array			array of time blocks
 	 */
	public function getTimeBlocks($start, $end, $minutes)
	{

          $Today = new DateTime();
          $Start = new DateTime($Today->format("Y-m-d") . " " . $start);
          $End = new DateTime($Today->format("Y-m-d") . " " . $end);

		$blocks = array();

		while($Start <= $End) {
			$currBlock['startTime'] = $Start->format("H:i:s");
			
			$Start->add(new DateInterval("PT" . $minutes . "M"));			

			if($Start > $End) {
				$currBlock['endTime'] = $End->format("H:i:s");
			}
			else {
				$currBlock['endTime'] = $Start->format("H:i:s");
			}
	
			$blocks[] = $currBlock;
		}

		return $blocks;
	}

	/**
	 * Gets an array of the days of the week
	 *
	 * @return	array		array of days of the week
	 */
	public function getDaysOfWeek()
	{
		return array(1 => "Sunday",
					2 => "Monday",
					3 => "Tuesday",
					4 => "Wednesday",
					5 => "Thursday",
					6 => "Friday",
					7 => "Saturday");
	}

}
