<?php

/** 
 * Cover me cash Report base class
 *
 * @category Library
 * @package Library
 * @author	Andrei Shkolin <andrews@mediaenvy.com>
 */
abstract class CMCImportReport {

	public function __construct()
	{

	}

	/**
	 * Imports csv data to the database
	 *
	 */
	abstract public function importToDB($fileName);

}
