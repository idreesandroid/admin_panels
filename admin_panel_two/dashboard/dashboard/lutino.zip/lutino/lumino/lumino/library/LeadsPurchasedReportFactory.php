<?php

/**
 * this will determine the correct model to use for Leads purchased report.
 * ie different instances will use different model like AffiliateLeadsPurchasedReport
 */
class LeadsPurchasedReportFactory
{
	public function __construct()
	{

	}

	/**
	 * Get DashBoard concreted class based on logged in user role
	 *
	 * @param string name of lms in config
	 * @return DashBoard concrete class
	 */
	public function create()
	{
	    $UserSession = new Zend_Session_Namespace('UserSession');

	    if($UserSession->role =='affiliate') {
	        return new AffiliateLeadsPurchasedReport();
	    }
	    else
	        return new LeadsPurchased();
	}
}
