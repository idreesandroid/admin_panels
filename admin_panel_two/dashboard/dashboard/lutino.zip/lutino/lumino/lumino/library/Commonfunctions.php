<?php

#********************************************************************************************************
# File: Commonfunctions.php  
# Desciption: This class contains all common functions to be used in all scripts
# Author: Yasir Siddiqui
# Date: 28/5/2009
#********************************************************************************************************	
class Commonfunctions
{
	private $sessiondata;
	private $baseurl;

    function isvalidemail($str)
	  {
	  	if (!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$",$str))
	  	{
			return 0;
	  	}
	  	else
	  	{
	  		return 1;
	  	}
	  }
	  
	  function checkStrHasNumbers($str)
  	{
	    preg_match('/[0-9]/', $str, $matches);
	    $result = (count($matches) != 0) ? 1 : 0;
	    return $result;
  	}
  	
  	function isinvalidphone($str)
  	{
  		preg_match('/([0-9]{3})-([0-9]{3})-([0-9]{4})/', $str, $matches);
	    $result = (count($matches) != 0) ? 1 : 0;
	    return $result;
  	}
  	
  	function checkStrHasLetters($str)
  {
    preg_match('/[a-zA-z]/', $str, $matches);
    $result = (count($matches) != 0) ? 1 : 0;
    return $result;
  }
  
  function setdefaultvalues($array){
  	$finalarray = array();
  	foreach ($array as $ind=> $val){
  		$finalarray[$ind] = array("starttime"=>"00:00:00","endtime"=>"23:59:00");
  	}
  	return $finalarray;
  }
  
  function setpostvalues($postglobal,$arr,$indextodays){
  	$finalarray = array();
  	foreach ($arr as $ind => $val){
    if($val){

	$index = $indextodays[$val];
	$starttimeindex = $index."_starttime";
	$starttime=  $_POST[$starttimeindex];
					    		
	$endtimeindex = $index."_endtime";
	$endtime = $_POST[$endtimeindex];
					    		
	$finalarray[$val] = array("starttime"=>$starttime,"endtime"=>$endtime);
					   
	}
    }
    return $finalarray;
  }
	function isWeekend($date)
	{
		$weekDay = date('w', strtotime($date));
    return ($weekDay == 0 || $weekDay == 6);
	}

  function getNextWorkDay($date=null)
  {
    $time = is_string($date) ? strtotime($date) : (is_int($date) ? $date : time());
    $y = date('Y', $time);
    // calculate federal holidays
    $holidays = array();
    // month/day (jan 1st). iteration/wday/month (3rd monday in january)
		// if two digits, it's a specific day of the month, no matter the year
		// if three digits, it's a specific weekday of the month and use digits to determine date
    $hdata = array('1/1'/*newyr*/, '7/4'/*jul4*/, '11/11'/*vet*/, '12/25'/*xmas*/, '3/1/1'/*mlk*/, '3/1/2'/*pres*/, '5/1/5'/*memo*/, '1/1/9'/*labor*/, '2/1/10'/*col*/, '4/4/11'/*thanks*/);
    foreach ($hdata as $h1) {
        $h = explode('/', $h1);
        if (sizeof($h)==2) { // by date
            $htime = mktime(0, 0, 0, $h[0], $h[1], $y); // time of holiday
            $w = date('w', $htime); // get weekday of holiday
            $htime += $w==0 ? 86400 : ($w==6 ? -86400 : 0); // if weekend, adjust
        } else { // by weekday
            $htime = mktime(0, 0, 0, $h[2], 1, $y); // get 1st day of month
            $w = date('w', $htime); // weekday of first day of month
            $d = 1+($h[1]-$w+7)%7; // get to the 1st weekday
            for ($t=$htime, $i=1; $i<=$h[0]; $i++, $d+=7) { // iterate to nth weekday
                 $t = mktime(0, 0, 0, $h[2], $d, $y); // get next weekday
                 if (date('n', $t)>$h[2]) break; // check that it's still in the same month
                 $htime = $t; // valid
            }
        }
        $holidays[] = $htime; // save the holiday
    }
    $time+=86400;
    $nextworkday = getdate($time);
    for ($i=0; $i<5; $i++, $time+=86400)
    { // 5 days should be enough to get to workday
        if (in_array(date('w', $time), array(0, 6))) continue; // skip weekends
        foreach ($holidays as $h)
        { // iterate through holidays
            if ($time>=$h && $time<=$h+86399)
            {
                 continue 2; // skip holidays
            }
        }
        break; // found the workday
    }
    $nextworkday = getdate($time);
    return $nextworkday['mon'] . "/" . $nextworkday['mday'] . "/" . $nextworkday['year'];
  }
}
?>
