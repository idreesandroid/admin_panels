<?php

/**
 * for testing methods of the CampaignReportLMSFactory model
 *
 * @package admin
 */
class CampaignReportLMSFactoryTest extends ControllerTestCase
{
    public function setUp()
    {
        parent::setUp();
    }

    public function tearDown()
    {
    }

    public function testWithTdcValueShouldReturnCorrectConcreteClass()
    {
		$expected = new CampaignReport();

        $Factory = new CampaignReportLMSFactory();
        $concreteClass = $Factory->create('tdc');

        $this->assertEquals($expected, $concreteClass);
    }

	public function testWithEpicValueShouldReturnCorrectConcreteClass()
    {
		$expected = new EpicCampaignReport();

        $Factory = new CampaignReportLMSFactory();
        $concreteClass = $Factory->create('epic');

        $this->assertEquals($expected, $concreteClass);
    }

	public function testWithMissingValueShouldReturnCorrectConcreteClass()
    {
		$expected = new CampaignReport();

        $Factory = new CampaignReportLMSFactory();
        $concreteClass = $Factory->create();

        $this->assertEquals($expected, $concreteClass);
    }
}
