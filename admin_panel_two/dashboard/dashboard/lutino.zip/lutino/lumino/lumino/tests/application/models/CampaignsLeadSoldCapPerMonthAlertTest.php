<?php
/**
 * for testing methods of the CampaignsLeadSoldCapPerMonthAlert model
 *
 * @package admin
 */
class CampaignsLeadSoldCapPerMonthAlertTest extends ControllerTestCase
{
	public function setUp()
	{
		parent::setUp();

		$today = '2013-06-18';
		$this->Alert = new CampaignsLeadSoldCapPerMonthAlert();
		$this->Alert->setTestMode(true);
		$this->Alert->setToday($today);

		// fixtures
		$this->Lead = new Leads();
		$this->Campaign = new Campaigns();
		$this->Lead->delete("campaign IN (1000,2000)");
		$this->Campaign->delete("id IN (1000,2000)");

		// seeding so that only campaign 1000 will go above leadsold_per_month cap.
		// (campaign 2000 has a leadsold from previous month)
		$this->Campaign->insert(array('id' => 1000, 'maxLeadsSoldPerMonth' => 1));
		$this->Campaign->insert(array('id' => 2000, 'maxLeadsSoldPerMonth' => 2));

		$this->Lead->insert(array('id' => 808080, 
			'campaign' => 1000, 
			'leadsold' => 1, 
			'originaldate' => '2013-06-18'));

		// this leadsold was last month, so should not count towards this months total
		$this->Lead->insert(array('id' => 707070, 
			'campaign' => 2000, 
			'leadsold' => 1, 
			'originaldate' => '2013-05-29'));
		$this->Lead->insert(array('id' => 606060, 
			'campaign' => 2000, 
			'leadsold' => 1, 
			'originaldate' => '2013-06-17'));
	}

	public function tearDown()
	{
		$this->Lead->delete("campaign IN (1000,2000)");
		$this->Campaign->delete("id IN (1000,2000)");
	}

	public function testExecuteShouldFindOnlyCampaign1000WhoHasHitTheMaxLeadSoldCapForThisMonth()
	{
		$expected = 1;

		$result = $this->Alert->execute();

		$this->assertEquals($expected, count($result));
	}
}
