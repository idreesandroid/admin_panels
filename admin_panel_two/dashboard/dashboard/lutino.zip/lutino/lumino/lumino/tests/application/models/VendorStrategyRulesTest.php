<?php

/**
 * for testing methods of the VendorStrategyRules model
 *
 * @package admin
 */
class VendorStrategyRulesTest extends ControllerTestCase
{
    public function setUp()
    {
        parent::setUp();

        $this->Rule = new VendorStrategyRule();
        $this->Rule->delete('id >= 1');

        // old rules
        $this->Rule->insert(array('id' => 1,
            'vendorStrategyRulesetID' => 444,
            'comparisonOperatorID' => 1,
            'vendorResponseParameterID' => 1,
            'value' => 10,
            'priority' => 1,
            'referrerVendorStrategyRuleID' => null,
            'logicalOperatorID' => null));

        $this->Rule->insert(array('id' => 2,
            'vendorStrategyRulesetID' => 444,
            'comparisonOperatorID' => 1,
            'vendorResponseParameterID' => 1,
            'value' => 20,
            'priority' => 2,
            'referrerVendorStrategyRuleID' => 1,
            'logicalOperatorID' => 2));

        $this->Rule->insert(array('id' => 3,
            'vendorStrategyRulesetID' => 444,
            'comparisonOperatorID' => 1,
            'vendorResponseParameterID' => 1,
            'value' => 30,
            'priority' => 3,
            'referrerVendorStrategyRuleID' => 2,
            'logicalOperatorID' => 2));

        // new rules
        $this->Rule->insert(array('id' => 4,
            'vendorStrategyRulesetID' => 444,
            'comparisonOperatorID' => 1,
            'vendorResponseParameterID' => 1,
            'value' => 20,
            'priority' => 2,
            'referrerVendorStrategyRuleID' => null,
            'logicalOperatorID' => null));

        $this->Rule->insert(array('id' => 5,
            'vendorStrategyRulesetID' => 444,
            'comparisonOperatorID' => 1,
            'vendorResponseParameterID' => 1,
            'value' => 20,
            'priority' => 2,
            'referrerVendorStrategyRuleID' => 4,
            'logicalOperatorID' => 2));
    }

    public function tearDown()
    {
        $this->Rule->delete('id >= 1');
    }

    public function testDeleteOldRulesWithThreeOldRulesShouldReturnTwoNew()
    {
        // we know that the new rules have these IDs
        $ruleIds = array(4, 5);

        $expected = array();
        $expected[] = array('id' => 4,
            'vendorStrategyRulesetID' => 444,
            'comparisonOperatorID' => 1,
            'vendorResponseParameterID' => 1,
            'value' => 20,
            'priority' => 2,
            'referrerVendorStrategyRuleID' => null,
            'logicalOperatorID' => null);

        $expected[] = array('id' => 5,
            'vendorStrategyRulesetID' => 444,
            'comparisonOperatorID' => 1,
            'vendorResponseParameterID' => 1,
            'value' => 20,
            'priority' => 2,
            'referrerVendorStrategyRuleID' => 4,
            'logicalOperatorID' => 2);


        $VendorStrategyRule = new VendorStrategyRule();
        $VendorStrategyRule->deleteOldRules(444, $ruleIds);

        $rules = $VendorStrategyRule->getAllByVendorStrategyRulesetID(444);
        $rules = $rules->toArray();

        $this->assertEquals($expected, $rules);
    }
}

