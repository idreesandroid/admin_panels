<?php
/**
 * Post Delivery test class
 *
 * @category    UnitTest
 * @package     ControllerTestCase
 * @subpackage  PostDeliveryTest 
 * @author      Andrew Ahn <andrewa@mediaenvy.com>
 */
class PostDeliveryTest extends ControllerTestCase
{
	public function setUp()
	{
		parent::setUp();

		$this->PostDelivery = new PostDelivery();

		$this->testPostSetupID = 1;

	}

	public function tearDown()
	{


		unset($this->PostDelivery);
	}

	public function testGetPostDeliveryForPostSetupWithDeliveryTimesShouldReturnData()
	{

		for($day = 1; $day < 8; $day++) { 
			$postDeliveryData = array("postSetupID" => $this->testPostSetupID,
						 		"dayOfWeek" => $day,
								"startTime" => "00:00:00",
								"endTime" => "23:59:59");

			$this->PostDelivery->insert($postDeliveryData);
		}

		$result = $this->PostDelivery->getPostDeliveryForPostSetup($this->testPostSetupID);

		$dayOfWeek = 1;	
		foreach($result as $value) {
			$this->assertEquals($dayOfWeek, $value->dayOfWeek);
			$this->assertEquals(1, $value->postSetupID);
			$this->assertEquals("00:00:00", $value->startTime);
			$this->assertEquals("23:59:59", $value->endTime);

			$dayOfWeek++;
		}

		$this->PostDelivery->delete("postSetupID = 1");
	}

	public function testGetPostDeliveryForPostSetupWithNoDeliveryTimesShouldReturnFalse()
	{

		$result = $this->PostDelivery->getPostDeliveryForPostSetup(999999999);

		$this->assertEquals(0, count($result));	
	}

	public function testGetDeliveryTimesForPostSetupWithDeliveryTimesShouldReturnTimes()
	{

		$postDeliveryData = array("postSetupID" => $this->testPostSetupID,
						 		"dayOfWeek" => 1,
								"startTime" => "00:00:00",
								"endTime" => "23:59:59");

		$this->PostDelivery->insert($postDeliveryData);

		$result = $this->PostDelivery->getDeliveryTimesForPostSetup($this->testPostSetupID);

		$day = 1;
		foreach($result as $value) { 
			$this->assertEquals($day, $value['dayOfWeek']);

			$day++;
		}

		$this->assertEquals(1, $result[1]['postSetupID']);
		$this->assertEquals(1, $result[1]['dayOfWeek']);
		$this->assertEquals("00:00:00", $result[1]['startTime']);
		$this->assertEquals("23:59:59", $result[1]['endTime']);

		$this->PostDelivery->delete("postSetupID = 1");
	}

}
