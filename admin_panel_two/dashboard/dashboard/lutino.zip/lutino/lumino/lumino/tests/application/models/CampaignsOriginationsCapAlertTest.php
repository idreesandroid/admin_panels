<?php
/**
 * for testing methods of the CampaignsOriginationsCapAlert model
 *
 * @package admin
 */
class CampaignsOriginationsCapAlertTest extends ControllerTestCase
{
	public function setUp()
	{
		parent::setUp();

		$this->Alert = new CampaignsOriginationsCapAlert();
		$this->Alert->setTestMode(true);

		// fixtures
		$this->Lead = new Leads();
		$this->Master = new Master();
		$this->Campaign = new Campaigns();
		$this->Master->delete("Loan_Number >= 1");
		$this->Lead->delete("campaign IN (1000,2000)");
		$this->Campaign->delete("id IN (1000,2000)");

		// seeding so that both campaigns will go above their maxOriginations cap
		$this->Campaign->insert(array('id' => 1000, 'maxOriginations' => 2));
		$this->Campaign->insert(array('id' => 2000, 'maxOriginations' => 1));

		$this->Lead->insert(array('id' => 808080, 'campaign' => 1000));
		$this->Lead->insert(array('id' => 707070, 'campaign' => 2000));
	
		$this->Master->insert(array('Loan_Number' => 11111, 
			'Cust_ID' => 11111, 
			'Loan_Type' => 'S', 
			'Loan_Status' => 'Z', 
			'applicationDate' => date('Y-m-d'),
			'leadID' => 808080));
		$this->Master->insert(array('Loan_Number' => 22222, 
			'Cust_ID' => 22222, 
			'Loan_Type' => 'S', 
			'Loan_Status' => 'Z', 
			'applicationDate' => date('Y-m-d'),
			'leadID' => 808080));
		$this->Master->insert(array('Loan_Number' => 33333, 
			'Cust_ID' => 33333, 
			'Loan_Type' => 'S', 
			'Loan_Status' => 'Z', 
			'applicationDate' => date('Y-m-d'),
			'leadID' => 707070));
	}

	public function tearDown()
	{
		$this->Master->delete("Loan_Number >= 1");
		$this->Lead->delete("campaign IN (1000,2000)");
		$this->Campaign->delete("id IN (1000,2000)");
	}

	public function testExecuteShouldFindTwoCampaignsWhoHaveHitTheirMaxOriginationsCap()
	{
		$expected = 2;

		$result = $this->Alert->execute();

		$this->assertEquals($expected, count($result));
	}
}
