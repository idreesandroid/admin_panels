<?php

error_reporting(E_ALL | E_STRICT);

// Define application environment as testing
defined('APPLICATION_ENV') || define('APPLICATION_ENV', 'development');

// real bootstrap
require_once realpath(dirname(__FILE__)) . '/../../application/base.php';

// setting config and db into registry for tests to use
$config = new Zend_Config_Ini(APPLICATION_PATH  .'/configs/digitaljobler.ini', 'development');
Zend_Registry::set('config', $config);

if($config->db->config->host !== 'localhost')
  die("Tests are to be run on DEV's localhost only.\n");

$db = Zend_Db::factory($config->db->adapter, $config->db->config->toArray());
Zend_Db_Table::setDefaultAdapter($db);
Zend_Registry::set('db', $db);

ini_set('include_path', ini_get('include_path').":/software/ZendFramework/ZendFramework/library");
date_default_timezone_set('America/New_York');

set_include_path(
    '.' .
    PATH_SEPARATOR . './../library'.
    PATH_SEPARATOR . './../application/models/'.
    PATH_SEPARATOR . get_include_path()
);

$loader = Zend_Loader_Autoloader::getInstance();
$loader->setFallbackAutoloader(true);
$loader->suppressNotFoundWarnings(false);

// unit tests
require_once realpath(dirname(__FILE__)) . '/ControllerTestCase.php';

