<?php
/**
 * for testing methods of the EpicCampaignReportDataModel model
 *
 * @package admin
 */
class EpicCampaignReportDataModelTest extends ControllerTestCase
{
	public function setUp()
	{
		parent::setUp();

		$this->EpicCampaignReportDataModel = new EpicCampaignReportDataModel();
		$this->EpicCampaignReportDataModel->initSettingsForSlaveDB();

		$this->Leads = new Leads();
		$this->Leads->delete("originaldate = '1986-01-12'");
	}

	public function tearDown()
	{
		$this->Leads->delete("originaldate = '1986-01-12'");
	}

	public function testGetEarliestLeadIDShouldFindCorrectLeadID()
	{
		$expected = 10;

		$date = '1986-01-12';
		$time = '13:00:00';

		$this->Leads->insert(array('id' => 10, 'originaldate' => $date, 'originaltime' => '13:12:00'));
		$this->Leads->insert(array('id' => 11, 'originaldate' => $date, 'originaltime' => '13:13:00'));
		$this->Leads->insert(array('id' => 12, 'originaldate' => $date, 'originaltime' => '13:14:00'));

		$result = $this->EpicCampaignReportDataModel->getEarliestLeadID($date, $time);

		$this->assertEquals($expected, $result);
	}

	public function testGetLatestLeadIDShouldFindCorrectLeadID()
	{
		$expected = 12;

		$date = '1986-01-12';
		$time = '13:15:00';

		$this->Leads->insert(array('id' => 10, 'originaldate' => $date, 'originaltime' => '13:12:00'));
		$this->Leads->insert(array('id' => 11, 'originaldate' => $date, 'originaltime' => '13:13:00'));
		$this->Leads->insert(array('id' => 12, 'originaldate' => $date, 'originaltime' => '13:14:00'));

		$result = $this->EpicCampaignReportDataModel->getLatestLeadID($date, $time);

		$this->assertEquals($expected, $result);
	}
}
