<?php
/**
 * for testing methods of the LeadMatcher model
 *
 * @package admin
 */
class LeadMatcherTest extends ControllerTestCase
{
	public function setUp()
	{
		parent::setUp();

		$this->custID = 2222;
		$this->leadID = 100;
		$this->leadID2 = 200;
		$this->date = date('Y-m-d');

		// for adding fixtures
		$this->db = Zend_Registry::get('db');

		// fixture for loanapps
		$loanSql = "insert into Loan_App(Cust_ID,Cust_SSN,ApplicationDate) 
			values(" . 
				$this->custID . 
				",4443332222,'" . 
				$this->date . " 09:20:00')";
		$this->db->query($loanSql);

		// fixtures for leads
		$leadSql = "insert into Leads(id,originaldate,originaltime) 
			values(
				" . $this->leadID . ",'" . 
				$this->date . "','09:18:00')";
		$this->db->query($leadSql);
		// this should be the chosen lead
		$leadSql2 = "insert into Leads(id,originaldate,originaltime) 
			values(
				" . $this->leadID2 . ",'" . 
				$this->date . "','09:19:00')";
		$this->db->query($leadSql2);

		// fixtures for cashdata
		$cashSql = "insert into CashData(leadID, ssn) 
			values(
				" . $this->leadID . ",
				4443332222)";
		$this->db->query($cashSql);
		$cashSql2 = "insert into CashData(leadID, ssn) 
			values(
				" . $this->leadID2 . ",
				4443332222)";
		$this->db->query($cashSql2);

		// fixtures for postlogs
		$postLogSql = "insert into PostLogs(leadID,postStatus,clientID) 
			values(
				" . $this->leadID . ",
				'accept',
				72)";
		$this->db->query($postLogSql);
		$postLogSql2 = "insert into PostLogs(leadID,postStatus,clientID) 
			values(
				" . $this->leadID2 . ",
				'accept',
				72)";
		$this->db->query($postLogSql2);
	}

	public function tearDown()
	{
		$loanSql = "delete from Loan_App";
		$this->db->query($loanSql);
		$loanSql = "delete from Leads where id IN (" . $this->leadID . "," . $this->leadID2 . ")";
		$this->db->query($loanSql);
		$cashSql = "delete from CashData where leadID IN (" . $this->leadID . "," . $this->leadID2 . ")";
		$this->db->query($cashSql);
		$postLogSql = "delete from PostLogs where leadID IN (" . $this->leadID . "," . $this->leadID2 . ")";
		$this->db->query($postLogSql);
	}

	public function testExecuteShouldChooseCorrectLeadID()
	{
		$expected = $this->leadID2;

		$LeadMatcher = new LeadMatcher($this->custID, $this->date . " 09:19:30");

		$result = $LeadMatcher->execute();
		$this->assertEquals($expected, $result);
	}

	public function testExecuteWithInvalidCustIDShouldReturnNull()
	{
		$bogusCustID = 44444;

		$LeadMatcher = new LeadMatcher($bogusCustID, $this->date . " 09:19:30");

		$result = $LeadMatcher->execute();
		$this->assertNull($result);
	}
}
