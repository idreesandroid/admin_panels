<?php
/**
 * for testing methods of the CampaignsMultiVariate model
 *
 * @package admin
 */
class CampaignsMultiVariateTest extends ControllerTestCase
{
	public function setUp()
	{
		parent::setUp();

		// add a test multivariate
		$this->MultiVariate = new MultiVariate();
		$this->multiVariateID = 1000;
		$this->MultiVariate->delete("id = " . $this->multiVariateID);
		$this->MultiVariate->insert(array(
			'id' => $this->multiVariateID,
			'name' => 'bogusVariate',
			'active' => 0));

		$this->CampaignsMultiVariate = new CampaignsMultiVariate();
		$this->campaignID = 888;
	}

	public function tearDown()
	{
		$this->CampaignsMultiVariate->delete("campaignID = " . $this->campaignID);
		$this->MultiVariate->delete("id = " . $this->multiVariateID);
	}

	public function testSaveNewWithNewCampaignMultiVariateShouldCreateNewRowInCampaignsMultiVariatesTable()
	{
		$expected = 1;

		$result = $this->CampaignsMultiVariate->saveNew($this->campaignID, 
			$this->multiVariateID);

		$rows = $this->CampaignsMultiVariate->fetchAll("campaignID = " . $this->campaignID);
		$this->assertEquals($expected, count($rows));
	}

	public function testSaveNewWithNewCampaignMultiVariateShouldCreateNewRowInCampaignsMultiVariatesTableWithCorrectData()
	{
		$expected = array(
			'campaignID' => $this->campaignID, 
			'multiVariateID' => $this->multiVariateID);

		$result = $this->CampaignsMultiVariate->saveNew($this->campaignID, 
			$this->multiVariateID);

		$row = $this->CampaignsMultiVariate->fetchRow("campaignID = " . $this->campaignID);
		$result = array(
			'campaignID' => $row->campaignID, 
			'multiVariateID' => $row->multiVariateID);

		$this->assertEquals($expected, $result);
	}

	public function testSaveNewWithNewCampaignMultiVariateShouldRemoveCurrentCampaignBeforeSavingNewCampaignMultiVariate()
	{
		$expected = 1;

		// seed a row with this campaignID
		$this->CampaignsMultiVariate->insert(array(
			'campaignID' => $this->campaignID, 
			'multiVariateID' => 101));

		$result = $this->CampaignsMultiVariate->saveNew($this->campaignID, 
			$this->multiVariateID);

		$rows = $this->CampaignsMultiVariate->fetchAll("campaignID = " . $this->campaignID);
		$this->assertEquals($expected, count($rows));
	}

	public function testSaveNewWithNewCampaignMultiVariateShouldAlsoSetMultiVariateToActive()
	{
		$expected = 1;

		$result = $this->CampaignsMultiVariate->saveNew($this->campaignID, 
			$this->multiVariateID);

		$multiVariate = $this->MultiVariate->fetchRow("id = " . $this->multiVariateID);
		$this->assertEquals($expected, $multiVariate->active);
	}
}
