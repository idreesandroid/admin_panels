<?php
/**
 * for testing methods of the DateUtility model
 *
 * @package admin
 */
class DateUtilityTest extends ControllerTestCase
{
	public function setUp()
	{
		parent::setUp();
	}

	public function tearDown()
	{

	}

	// TODO: should be able to validate exact dates
	public function testGetWeekdayDatesShouldReturnDates()
	{
		// number of dates in array
		$expected = 6;

		$DateUtil = new DateUtility();

		$result = $DateUtil->getWeekdayDates('Tuesday', 6);
		$this->assertEquals($expected, count($result));
	}
}
