<?php
/**
 * for testing methods of the MessageReport model
 *
 * @package admin
 */
class PostSetupsTest extends ControllerTestCase
{
  public function setUp()
  {
    parent::setUp();

    $this->PostSetups = new PostSetups();
  }

  public function tearDown()
  {
    unset($this->PostSetups);
  }

  public function testGetPostSetupTypeClientMatches()
  {
		$postSetupID = "239";
		$expectedResult = "Client";
    $result = $this->PostSetups->getPostSetupType($postSetupID);

    // currently there are much more than 10 rows
    $this->assertEquals($expectedResult, $result);
  }

  public function testGetPostSetupTypeClientNoMatch()
  {
		$postSetupID = "247";
		$expectedResult = "Client";
    $result = $this->PostSetups->getPostSetupType($postSetupID);

    // currently there are much more than 10 rows
    $this->assertNotEquals($expectedResult, $result);
  }

  public function testGetPostSetupTypeVendorMatches()
  {
		$postSetupID = "247";
		$expectedResult = "Vendor";
    $result = $this->PostSetups->getPostSetupType($postSetupID);

    // currently there are much more than 10 rows
    $this->assertEquals($expectedResult, $result);
  }

  public function testGetPostSetupTypeVendorNoMatch()
  {
		$postSetupID = "239";
		$expectedResult = "Vendor";
    $result = $this->PostSetups->getPostSetupType($postSetupID);

    // currently there are much more than 10 rows
    $this->assertNotEquals($expectedResult, $result);
  }
}
