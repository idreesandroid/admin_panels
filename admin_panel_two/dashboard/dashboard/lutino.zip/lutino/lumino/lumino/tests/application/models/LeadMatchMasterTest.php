<?php
/**
 * for testing methods of the LeadMatchMaster model
 *
 * @package admin
 */
class LeadMatchMasterTest extends ControllerTestCase
{
	public function setUp()
	{
		parent::setUp();

		$this->loanNumber = 9000;
		$this->leadID = 100;
		$this->date = date('Y-m-d');

		// for adding fixtures
		$this->db = Zend_Registry::get('db');

		// fixture for loanapp
		$loanSql = "insert into Loan_App(Appl_No,Cust_SSN,ApplicationDate,leadID) 
			values(" . 
				$this->loanNumber. 
				",4443332222,'" . 
				$this->date . " 09:20:00',
				$this->leadID)";
		$this->db->query($loanSql);
	}

	public function tearDown()
	{
		$loanSql = "delete from Loan_App";
		$this->db->query($loanSql);
	}

	public function testExecuteWithExistingLoanNumberShouldFindLeadID()
	{
		$expected = $this->leadID;

		$LeadMatcher = new LeadMatchMaster($this->loanNumber);
		$result = $LeadMatcher->execute();

		$this->assertEquals($expected, $result);
	}

	public function testExecuteWithNonExistingLoanNumberShouldReturnNull()
	{
		$loanNumberBogus = 2222;
		$expected = 0;

		$LeadMatcher = new LeadMatchMaster($loanNumberBogus);
		$result = $LeadMatcher->execute();

		$this->assertEquals($expected, $result);
	}
}
