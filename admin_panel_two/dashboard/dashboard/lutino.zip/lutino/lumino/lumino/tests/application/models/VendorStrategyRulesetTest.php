<?php

/**
 * for testing methods of the VendorStrategyRuleset model
 *
 * @package admin
 */
class VendorStrategyRulesetTest extends ControllerTestCase
{
    public function setUp()
    {
        parent::setUp();

        $this->Ruleset = new VendorStrategyRuleset();
        $this->Ruleset->delete('id >= 1');

        $this->Ruleset->insert(array('id' => 1,
            'vendorStrategyID' => 444,
            'name' => 'ruleset1',
            'priority' => 1,
            'referrerVendorStrategyRulesetID' => null,
            'logicalOperatorID' => null));

        $this->Ruleset->insert(array('id' => 2,
            'vendorStrategyID' => 444,
            'name' => 'ruleset2',
            'priority' => 1,
            'referrerVendorStrategyRulesetID' => 1,
            'logicalOperatorID' => 1));

        $this->Ruleset->insert(array('id' => 3,
            'vendorStrategyID' => 444,
            'name' => 'ruleset3',
            'priority' => 1,
            'referrerVendorStrategyRulesetID' => 2,
            'logicalOperatorID' => 1));

        $this->Ruleset->insert(array('id' => 4,
            'vendorStrategyID' => 444,
            'name' => 'ruleset1',
            'priority' => 1,
            'referrerVendorStrategyRulesetID' => null,
            'logicalOperatorID' => null));

        $this->Ruleset->insert(array('id' => 5,
            'vendorStrategyID' => 444,
            'name' => 'ruleset2',
            'priority' => 1,
            'referrerVendorStrategyRulesetID' => 4,
            'logicalOperatorID' => 1));
    }

    public function tearDown()
    {
        $this->Ruleset->delete('id >= 1');
    }

    public function testDeleteOldRulessetsWithThreeOldRulesetShouldReturnTwoNew()
    {
        $ruleIds = array(4, 5);

        $expected = array();
        $expected[] = array('id' => 4,
            'vendorStrategyID' => 444,
            'name' => 'ruleset1',
            'priority' => 1,
            'referrerVendorStrategyRulesetID' => null,
            'logicalOperatorID' => null);

        $expected[] = array('id' => 5,
            'vendorStrategyID' => 444,
            'name' => 'ruleset2',
            'priority' => 1,
            'referrerVendorStrategyRulesetID' => 4,
            'logicalOperatorID' => 1);


        $VendorStrategyRuleset = new VendorStrategyRuleset();
        $VendorStrategyRuleset->deleteOldRulesets(444, $ruleIds);

        $rules = $VendorStrategyRuleset->getAllByVendorStrategyID(444);
        $rules = $rules->toArray();

        $this->assertEquals($expected, $rules);
    }
}

