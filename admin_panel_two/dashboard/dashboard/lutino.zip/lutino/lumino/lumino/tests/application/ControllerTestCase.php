<?php

class ControllerTestCase extends Zend_Test_PHPUnit_ControllerTestCase
{
		/**
		 * @var Zend_Application
		 */
	protected $application;

	public function setUp()
	{
		$this->bootstrap = array($this, 'appBootstrap');
		parent::setUp();

		$this->userInitials = '';
		$directory = dirname(__FILE__);
		if (strpos($directory, 'clydes') > 1) {
			$this->userInitials = 'cs';
		} elseif (strpos($directory, 'aouie') > 1) {
			$this->userInitials = 'ag';
		} elseif (strpos($directory, 'raph') > 1) {
			$this->userInitials = 'ro';
		} elseif (strpos($directory, 'andrew') > 1) {
			$this->userInitials = 'aa';
		} elseif (strpos($directory, 'charle') > 1) {
			$this->userInitials = 'cm';
		} elseif (strpos($directory, 'patrick') > 1) {
			$this->userInitials = 'pq';
		}

		// As some tests fail on date switches delay if too close to a date switch.
		if(date("H:i:s") > '23:59:50')
		{
			echo "Sleeping for 10 secs as date is about to switch.\n";
			sleep(10);
		}
	}

	public function tearDown()
	{
	}

	public function appBootstrap()
	{
		global $application;
		$this->application = $application;
		$application->bootstrap();
	}
}
