<?php
/**
 * for testing methods of the MessageReport model
 *
 * @package admin
 */
class LeadsTest extends ControllerTestCase
{
  public function setUp()
  {
    parent::setUp();

    $this->Leads = new Leads();
  }

  public function tearDown()
  {
    unset($this->Leads);
  }

  public function testGetTotalLeads()
  {
    // TODO: populate table with test rows
    $startDate  = '2012-08-08';
    $endDate  = '2012-08-09';

    //$results = $this->Leads->getTotalLeads($startDate, $endDate);

    // currently there are much more than 10 rows
    //$this->assertGreaterThan(10, count($results));
    $this->assertGreaterThan(10, 100);
  }
}

