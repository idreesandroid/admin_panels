<?php
/**
 * Client Post Setup Time Block test class
 *
 * @category    UnitTest
 * @package     ControllerTestCase
 * @subpackage  ClientPostSetupTimeBlockTest 
 * @author      Andrew Ahn <andrewa@mediaenvy.com>
 */
class ClientPostSetupTimeBlockCapTest extends ControllerTestCase
{
	public function setUp()
	{
		parent::setUp();

		$this->ClientPostSetupTimeBlockCap = new ClientPostSetupTimeBlockCap();

		$this->testPostSetupID = 1;

	}

	public function tearDown()
	{

		unset($this->ClientPostSetupTimeBlockCap);
	}

	public function testGetSpecificTimeblockForPostSetupWithTimeBlockShouldReturnData()
	{

		$testMaxSold = 5;

		$timeBlockData = array("postSetupID" => $this->testPostSetupID,	
							"dayOfWeek" => 1,
							"startTime" => "00:00:00",
							"endTime" => "00:15:00",
							"maxLeadSold" => $testMaxSold);

		$this->ClientPostSetupTimeBlockCap->insert($timeBlockData);

		$result = $this->ClientPostSetupTimeBlockCap->getSpecificTimeBlockForPostSetup($this->testPostSetupID, 1, "00:00:00", "00:15:00");

		$this->assertEquals($testMaxSold, $result['maxLeadSold']);

		$this->ClientPostSetupTimeBlockCap->delete($this->ClientPostSetupTimeBlockCap->getAdapter()->quoteInto("postSetupID = ?", $this->testPostSetupID));
	}

	public function testGetFullDayBlocksForPostSetupWithCapsShouldReturnAllBlocksWithCaps()
	{
	
		$testMaxSold = 3;

		$timeBlockData = array("postSetupID" => $this->testPostSetupID,
							"dayOfWeek" => 2,
							"startTime" => "00:00:00",
							"endTime" => "00:15:00",
							"maxLeadSold" => $testMaxSold);

		$this->ClientPostSetupTimeBlockCap->insert($timeBlockData);
		
		$result = $this->ClientPostSetupTimeBlockCap->getFullDayBlocksForPostSetup($this->testPostSetupID);

		$this->assertEquals($testMaxSold, $result[2][0]['cap']);

		$this->ClientPostSetupTimeBlockCap->delete($this->ClientPostSetupTimeBlockCap->getAdapter()->quoteInto("postSetupID = ?", $this->testPostSetupID));


	}

	public function testSaveTimeBlocksWithCorrectDataShouldInsertData()
	{
		
		$testMaxSold = 3;

		$timeBlockData[2][] = array("postSetupID" => $this->testPostSetupID,
							"dayOfWeek" => 2,
							"startTime" => "00:00:00",
							"endTime" => "00:15:00",
							"cap" => $testMaxSold);

		$this->ClientPostSetupTimeBlockCap->saveTimeBlocks($this->testPostSetupID, $timeBlockData);
	
		$result = $this->ClientPostSetupTimeBlockCap->getSpecificTimeBlockForPostSetup($this->testPostSetupID, 2, "00:00:00", "00:15:00");

		$this->assertEquals($testMaxSold, $result['maxLeadSold']);

		$this->ClientPostSetupTimeBlockCap->delete($this->ClientPostSetupTimeBlockCap->getAdapter()->quoteInto("postSetupID = ?", $this->testPostSetupID));
	
	}

}
