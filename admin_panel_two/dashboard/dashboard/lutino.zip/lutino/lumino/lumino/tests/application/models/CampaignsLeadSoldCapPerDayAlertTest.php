<?php
/**
 * for testing methods of the CampaignsLeadSoldCapPerDayAlert model
 *
 * @package admin
 */
class CampaignsLeadSoldCapPerDayAlertTest extends ControllerTestCase
{
	public function setUp()
	{
		parent::setUp();

		$this->Alert = new CampaignsLeadSoldCapPerDayAlert();
		$this->Alert->setTestMode(true);

		// fixtures
		$this->Lead = new Leads();
		$this->Campaign = new Campaigns();
		$this->Lead->delete("campaign IN (1000,2000)");
		$this->Campaign->delete("id IN (1000,2000)");

		// seeding so that both campaigns will go above their leadsold_per_day cap
		$this->Campaign->insert(array('id' => 1000, 'maxLeadsSoldPerDay' => 1));
		$this->Campaign->insert(array('id' => 2000, 'maxLeadsSoldPerDay' => 2));

		$this->Lead->insert(array('id' => 808080, 
			'campaign' => 1000, 
			'leadsold' => 1, 
			'originaldate' => date('Y-m-d')));
		$this->Lead->insert(array('id' => 707070, 
			'campaign' => 2000, 
			'leadsold' => 1, 
			'originaldate' => date('Y-m-d')));
		$this->Lead->insert(array('id' => 606060, 
			'campaign' => 2000, 
			'leadsold' => 1, 
			'originaldate' => date('Y-m-d')));
	}

	public function tearDown()
	{
		$this->Lead->delete("campaign IN (1000,2000)");
		$this->Campaign->delete("id IN (1000,2000)");
	}

	public function testExecuteShouldFindTwoCampaignsWhoHaveHitTheirMaxLeadSoldCapForToday()
	{
		$expected = 2;

		$result = $this->Alert->execute();

		$this->assertEquals($expected, count($result));
	}
}
