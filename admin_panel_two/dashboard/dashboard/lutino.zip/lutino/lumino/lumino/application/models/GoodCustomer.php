<?php
class GoodCustomer extends Zend_Db_Table
{
	protected $_name = 'GoodCustomers';
	
	public function init()
    	{
        	$this->db = Zend_Registry::get('db');
    	}
	
	/**
	 * Updates or inserts a row
	 */
	public function upsert($insertData)
	{
		if (!empty($insertData['ssn']) && $insertData['ssn'] !="000000000" && !empty($insertData['storeID'])) {
			$existingRow = $this->findBySSNAndStoreID($insertData['ssn'], $insertData['storeID']);
		}
		else {
			$existingRow = $this->findByEmail($insertData['email']);
		}
		
		if($existingRow) {
			$this->update($insertData, $this->_db->quoteInto("id = ?", $existingRow['id']));
			return $existingRow['id'];
		}
		else {
			return $this->insert($insertData);
		}
	}
	
	public function getTotalCustomers($search = "") {
		
		$searchSql = "";
		if (!empty($search)) {
			$searchSql = " where email like '%$search%' OR ssn like '%$search%' OR storeID like '%$search%'";
		}
		$sql = "select count(*) as cnt from GoodCustomers
		$searchSql";
		return $this->db->fetchRow($sql);
	}
	
	public function getCustomers($search = "", $offset = 0, $limit = 100, $sortBy = 'email', $sortOrder = 'ASC')
	{
		$searchSql = "";
		if (!empty($search)) {
			$searchSql = " where email like '%$search%' OR ssn like '%$search%' OR storeID like '%$search%'";
		}
		$sql = "select * from GoodCustomers
		$searchSql
		order by $sortBy $sortOrder
		limit $offset,$limit";
		return $this->db->fetchAll($sql);
	}

	public function findBySSNAndStoreID($ssn, $storeID) {
		$sql = $this->select()
			->where("ssn = " . $ssn)
			->where("storeID = '$storeID'");
		return $this->fetchRow($sql);
	}
	
	public function findByEmail($email) {
		$sql = $this->select()
			->where("email = ?" , $email);
		return $this->fetchRow($sql);
	}
}
