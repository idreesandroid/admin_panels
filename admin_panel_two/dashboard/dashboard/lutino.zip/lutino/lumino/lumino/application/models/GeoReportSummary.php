<?php
/**
 * facade class that handles getting all data for building Geo charts
 */
class GeoReportSummary extends ReportAbstract
{
	public function getLeadAttemptsByState()
	{
		$sql = "SELECT
			count(1) amount,
			state
		FROM
			Leads
		WHERE
			originaldate >= '" . $this->fromDate . "'
			and originaldate <= '" . $this->toDate . "'
			and originaltime >= '" . $this->fromTime . "'
			and originaltime <= '" . $this->toTime . "'
		GROUP BY
			state";

		return $this->slave->fetchAll($sql);
	}

	public function getLeadPurchasedByState()
	{
		$sql = "SELECT
			count(1) amount,
			state
		FROM
			Leads
		WHERE
			originaldate >= '" . $this->fromDate . "'
			and originaldate <= '" . $this->toDate . "'
			and originaltime >= '" . $this->fromTime . "'
			and originaltime <= '" . $this->toTime . "'
			and leadsold = '1'
		GROUP BY
			state";

		return $this->slave->fetchAll($sql);
	}
}
