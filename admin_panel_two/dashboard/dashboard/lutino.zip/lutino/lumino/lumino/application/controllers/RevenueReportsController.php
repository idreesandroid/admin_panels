<?php

class RevenueReportsController extends Zend_Controller_Action
{
	public function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if(!$AdminNameSpace->userid)
		{
			$this->_redirect('index/login');	
		}
		$this->baseurl = $this->_request->getBaseUrl();
	}

	public function indexAction()
	{
		$fromDate = ($this->_request->fromDate) ? 
			$this->_request->fromDate : date('Y-m-d');
		$toDate = ($this->_request->toDate) ? 
			$this->_request->toDate : date('Y-m-d');

		$Report = new RevenueReport($fromDate, $toDate);
		$reports = $Report->execute();

		$this->view->reports = $reports;
		$this->view->totalsRow = $Report->totalsRow($reports, array('campaign'));
		$this->view->fromDate = $fromDate;
		$this->view->toDate = $toDate;

		$this->view->flashMessages = $this->_helper->flashMessenger->getMessages();
	}
}
