<?php

class InfinityDashboardData {


    public function __construct()
    {
        // we want to run all queries against slave db
        $bootstrap = Zend_Controller_Front::getInstance()->getParam("bootstrap");
        $resource = $bootstrap->getPluginResource('multidb');
        $this->slave = $resource->getDb('slave');
    }

    /**
     *
     * Gets total new customers originated
     *
     * @param	fromDate  date    start of date range
     * @param	toDate    date    end of date range
     *
     * @return	int	number of customers originated
     */
    public function getTotalNewCustomersOriginations($fromDate,$toDate,$affiliateID = "", $campaignID = "") {
        if($affiliateID) {
            $affiliateID = " AND l.affiliateID IN($affiliateID)";
        }

        if ($campaignID != "") {
            $campaignID = " AND l.campaign IN($campaignID)";
        }

        $sql = "SELECT
                count(1) total
                FROM
                InfinityApprovedLoansScrape
                LEFT OUTER JOIN Leads l ON l.id = InfinityApprovedLoansScrape.leadID
                LEFT JOIN ReturningCustomers rc ON l.id = rc.leadID
                WHERE InfinityApprovedLoansScrape.createdDate >= '$fromDate'
                AND InfinityApprovedLoansScrape.createdDate <= '$toDate'
                and InfinityApprovedLoansScrape.leadID is not null
                AND
				l.leadsold = 1
				{$affiliateID}
				{$campaignID}
				AND ISNULL(rc.leadID)";

        $result = $this->slave->fetchRow($sql);
        return $result['total'];
    }
}