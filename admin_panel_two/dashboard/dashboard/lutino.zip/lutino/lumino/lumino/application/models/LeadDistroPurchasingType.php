<?php
class LeadDistroPurchasingType extends Zend_Db_Table
{
	protected $_name = 'LeadDistroPurchasingTypes';

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}

	public function getClientData()
	{
		$sql = "SELECT
					company,
					postSetupID,
					ps.active,
					priority
				FROM
					Clients c
				LEFT JOIN ClientPostSetups cps ON c.id = cps.clientID
				LEFT JOIN PostSetups ps ON ps.id = cps.postSetupID";

		$result = $this->db->fetchAll($sql);

		return $result;
	}
}
?>
