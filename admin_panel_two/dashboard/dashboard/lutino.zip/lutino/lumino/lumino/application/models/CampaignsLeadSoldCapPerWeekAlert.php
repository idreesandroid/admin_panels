<?php
/**
 * this class determines if any campaigns have hit their leadsold cap for the week.
 * If so, send an email alert
 */
class CampaignsLeadSoldCapPerWeekAlert extends CampaignsAlertAbstract
{
	public function __construct()
	{
		parent::__construct();

		$this->today = date('Y-m-d');
	}

	// custom setting the date for testing purposes
	public function setToday($date)
	{
		$this->today = $date;
	}

	/**
	 * this is main interface to this class.
	 * it looks at leadsold grouped by campaign and sends an email alert
	 *
	 * @return array
	 */
	public function execute()
	{
		if ($totals = $this->getTotals()) {
			if (!$this->testMode) {
				$headers = 'From: tech@mediaenvy.com' . "\r\n" .
					    'Reply-To: tech@mediaenvy.com' . "\r\n" .
						    'X-Mailer: PHP/' . phpversion();
				$subj = 'Campaign Weekly LeadSold Cap Alert';
				$body  = "=== These Campaigns have hit their Weekly LeadSold Cap ===" . "\r\n\r\n";
				foreach ($totals as $total) {
					$body .= 'campaign ' . $total['campaign'] . ", total leadsold this week:" . 
						$total['totalForWeek'] . ", weekly cap setting:" . 
						$total['maxLeadsSoldPerWeek'] . "\r\n";
				}
				mail('Marketing@mediaenvy.com, tech@mediaenvy.com', $subj, $body, $headers);
			}
		}
		return $totals;
	}
	
	/**
	 * we only want totals for THIS week. (ie not past 7 days)
	 * @return array
	 */
	public function getTotals()
	{
		$sql = "select IFNULL(l.campaign, 'other') campaign, 
			count(1) totalForWeek,
			c.maxLeadsSoldPerWeek 
			from Leads l 
			join Campaigns c on c.id = l.campaign 
			where l.originaldate > '" . $this->today . "' - interval 7 day 
			and l.originaldate <= '" . $this->today . "'
			and weekday(l.originaldate) <= weekday('" . $this->today . "') 
			and l.leadsold = 1 
			group by l.campaign 
			having totalForWeek >= c.maxLeadsSoldPerWeek";

		return $this->db->fetchAll($sql);
	}
}
