<?php

/**
 * Lead Dupe class 
 *
 * @category    Table 
 * @package     Zend_Db_Table      
 * @subpackage  Lead
 * @author      Andrew Ahn <andrewa@mediaenvy.com>
 */
class LeadDupe extends Zend_Db_Table
{

	protected $_name = "LeadDupes";

	public function init()
	{
		$config = Zend_Registry::get("config");
		$this->db_slave = Zend_Db::factory($config->resources->multidb->slave->adapter, $config->resources->multidb->slave->toArray());
	}

	/**
 	 * Finds the lead dupes for past 7 days and inserts a lead dupe row for the lead 
	 *
	 * @param	int	$leadID		id of lead
	 * @param	int	$affiliateID	id of affiliate
	 * @param	string	$ssn		ssn of lead
	 * @param	date	$date		date of lead
 	 * @param	time	$time		time of lead
	 *
	 */
	public function findLeadDupes($leadID, $affiliateID, $email, $ssn, $date, $time)
	{	

                $sql = $this->db_slave->select()
					->from("Leads", array("id", "email", "affiliateID"))
					->join("CashData", "Leads.id = CashData.leadID", array("ssn"))
					->where($this->db_slave->quoteInto("Leads.email = ?", $email))
					->where($this->db_slave->quoteInto("Leads.originaldate >= DATE_SUB(?, INTERVAL 7 DAY)", $date))
					->where($this->db_slave->quoteInto("Leads.originaldate <= ?", $date))
					->where($this->db_slave->quoteInto("Leads.originaldate != ?", $date) . " OR " . $this->db_slave->quoteInto("Leads.originaltime < ?", $time))
					->where($this->db_slave->quoteInto("Leads.id != ?", $leadID));

                $sql2 = $this->db_slave->select()
                        		->from("Leads", array("id", "email", "affiliateID"))
					->join("CashData", "Leads.id = CashData.leadID", array("ssn"))
					->where($this->db_slave->quoteInto("CashData.ssn = ?", $ssn))
					->where($this->db_slave->quoteInto("Leads.originaldate >= DATE_SUB(?, INTERVAL 7 DAY)", $date))
					->where($this->db_slave->quoteInto("Leads.originaldate <= ?", $date))
					->where($this->db_slave->quoteInto("Leads.originaldate != ?", $date) . " OR " . $this->db_slave->quoteInto("Leads.originaltime < ?", $time))
					->where($this->db_slave->quoteInto("Leads.id != ?", $leadID));

                $sql3 = $this->db_slave->select()
					->union(array($sql, $sql2));

		$result = $this->db_slave->fetchAll($sql3);

		return $result;

	}

	/**
	 * Inserts or updates dupe rows for a lead
	 *
	 * @param	int	$leadID		id of lead
	 * @param	array	$dupes		array of dupe leads
	 * @param	int	$affiliateID	id of affiliate 
	 *
	 * @return	int			id of lead dupe row
	 */	
	public function upsertForLeadID($leadID, $affiliateID, $dupes)
	{

		$dupeCount = 0;
		$isUnique = 1;
		$numDiffLeadProviders = 0;

		if(!empty($dupes)) { 
			$affiliates = array();

			$dupeCount = count($dupes);
			foreach($dupes as $value) { 
				if($value['affiliateID'] != $affiliateID) { 
					$affiliates[] = $value['affiliateID'];
				}
			}

			if($dupeCount > 0) { 
				$isUnique = 0;
			}
	
			$numDiffLeadProviders = count(array_unique($affiliates));
		}
	
		$insertData = array("leadID" => $leadID,
					"isUnique" => $isUnique,
					"dupeCount" => $dupeCount,	
					"numDiffLeadProviders" => $numDiffLeadProviders
					);

		$leadDupeRow = $this->findByLeadID($leadID);
	
		if(!empty($leadDupeRow)) { 
			$this->update($insertData, $this->_db->quoteInto("leadID = ?", $leadID));
			$leadDupeID = $leadDupeRow['id'];
		}
		else {
			$leadDupeID = $this->insert($insertData);
		}

		return $leadDupeID;
	}

	/**
	 * Finds the lead dupe row by the leadID
	 *
	 * @param	int	$leadID		id of lead
	 *
	 * @return	array			array of lead dupe data
	 */
	public function findByLeadID($leadID)
	{

		$sql = $this->select()
				->from($this->_name)
				->where($this->_db->quoteInto("leadID = ?", $leadID));

		$result = $this->fetchRow($sql);

		return $result;
	}

	/**
	 * Gets leads that don't have a corresponding lead dupes rows
	 *
	 * @param	date	$date	date to check
	 *
	 * @return	array		array of leads
	 */
	public function findLeadsWithoutLeadDupesRow($date)
	{

		$sql = $this->db_slave->select()
					->from("Leads", array("id", "affiliateID", "email", "originaldate", "originaltime"))
					->join("CashData", "Leads.id = CashData.leadID", array("ssn"))
					->joinLeft("LeadDupes", "Leads.id = LeadDupes.leadID", array("leadDupeID" => "id"))
					->where($this->db_slave->quoteInto("Leads.originaldate = ?", $date))
					->where("LeadDupes.id IS NULL");

		$result = $this->db_slave->fetchAll($sql);

		return $result;
	
	}
}
