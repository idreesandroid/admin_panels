<?php

class LeadsAttempts extends ReportAbstract
{

    public function getTotalLeadsAttempts($customerType,$startDate,$endDate,$startTime,$endTime) {

	    if ($customerType == 'returning') {
		    $filter = " (rc.leadID) IS NOT NULL ";
	    }

	    if ($customerType == 'new' || $customerType == 'returning') {
	            $sql = "SELECT count(distinct l.email) total
			    FROM
				Leads l
			    LEFT JOIN ReturningCustomers rc ON l.id = rc.leadID
			    LEFT JOIN LECustomerDispositions cdp ON l.id = cdp.leadID
			    WHERE
				    l.originaldate >= '$startDate'
			    AND
				    l.originaldate <= '$endDate'
			    AND
				    l.originaltime >= '$startTime'
			    AND
				    l.originaltime <= '$endTime'
			    AND
			    ";
	        $sql.= $filter;
	    }
	    else if ($customerType == 'blacklisted') {

	        $sql = "SELECT count(distinct l.email) total
	        FROM Leads l
	        JOIN InternalRejects ir on ir.leadid = l.id
			JOIN InternalRejectCodes irc on irc.id = ir.rejectcode
	        WHERE
	            l.originaldate >= '$startDate'
    	    AND
    		    l.originaldate <= '$endDate'
    	    AND
    		    l.originaltime >= '$startTime'
    	    AND
    		    l.originaltime <= '$endTime'
    	    AND
    	        irc.id = 107";
	    }

	    return $this->slave->fetchRow($sql);
	}

	public function getLatestUniqueLeadAttemptsByEmail($customerType,$startDate,$endDate,$startTime,$endTime,$sortBy,$sortOrder,$offset,$limit) {

	    if ($sortBy == "datetime") {
		    $sortBy = "originaldate,originaltime";
	    }
	    else if ($sortBy == "endtime") {
		    $sortBy = "endTime";
	    }
	    else if ($sortBy == "cost") {
		    $sortBy = "cost";
	    }
	    else if ($sortBy == "price") {
		    $sortBy = "price";
	    }
	    else if ($sortBy == "sold") {
		    $sortBy = "leadsold";
	    }

	    if ($customerType == 'returning') {
		    $filter = " (rc.leadID) IS NOT NULL ";
	    }

	    $joinOriginationsTable = $this->getJoiningTableQueryForOrigination();

	    if ($customerType == 'new' || $customerType == 'returning') {

    	    $sql = "SELECT * FROM (SELECT l.id,IFNULL(ldpc.code, '') code,l.leadsold, l.originaldate,l.originaltime,l.storeID,l.state,
    		    l.campaign,l.email,l.hphone,pl.endTime,ps.title postSetupTitle,ps.id as postsetupid,ls.cost,ls.price
    		    ,Case WHEN IFNULL(orig.leadID,0) = 0 THEN 'No' ELSE 'Yes' END AS originated
    			    FROM
    			    Leads l
    			    LEFT JOIN ReturningCustomers rc ON l.id = rc.leadID
    			    LEFT JOIN LECustomerDispositions cdp ON l.email = cdp.email
    			    LEFT JOIN LeadDispositionCodes ldpc ON ldpc.id = cdp.dispositionCodeID
    			    {$joinOriginationsTable}
    			    LEFT JOIN PostLogs pl
    			    on
    			    (
    			        pl.LeadID = l.id AND pl.productcode='cash'
    			        AND pl.postStatus='accept'
    			    )
    			    LEFT JOIN PostSetups ps on pl.postSetupID = ps.id
    			    LEFT JOIN LeadSold ls on l.id = ls.leadID
    			    WHERE
    				    l.originaldate >= '$startDate'
    			    AND
    				    l.originaldate <= '$endDate'
    			    AND
    				    l.originaltime >= '$startTime'
    			    AND
    				    l.originaltime <= '$endTime'
    			    AND
    			    ";
    	    $sql.= $filter;
	    }
	    else if ($customerType == 'blacklisted') {

	        $sql = "SELECT * FROM (SELECT l.id,IFNULL(ldpc.code, '') code,l.leadsold, l.originaldate,l.originaltime,l.storeID,l.state,
    	        l.campaign,l.email,l.hphone,pl.endTime,ps.title postSetupTitle,ps.id as postsetupid,ls.cost,ls.price
    	        ,Case WHEN IFNULL(orig.leadID,0) = 0 THEN 'No' ELSE 'Yes' END AS originated
    	        FROM
    	        Leads l
                JOIN InternalRejects ir on ir.leadid = l.id
    			JOIN InternalRejectCodes irc on irc.id = ir.rejectcode
    	        LEFT JOIN LECustomerDispositions cdp ON l.email = cdp.email
    		    LEFT JOIN LeadDispositionCodes ldpc ON ldpc.id = cdp.dispositionCodeID
    		    {$joinOriginationsTable}
    		    LEFT JOIN PostLogs pl
    		    on
    		    (
    		        pl.LeadID = l.id AND pl.productcode='cash'
    		        AND pl.postStatus='accept'
    		    )
    		    LEFT JOIN PostSetups ps on pl.postSetupID = ps.id
    		    LEFT JOIN LeadSold ls on l.id = ls.leadID
    		    WHERE
    			    l.originaldate >= '$startDate'
    		    AND
    			    l.originaldate <= '$endDate'
    		    AND
    			    l.originaltime >= '$startTime'
    		    AND
    			    l.originaltime <= '$endTime'
    			AND
    	        irc.id = 107";
	    }

	    $sql.=" order by l.id desc,cdp.createdAt desc limit $offset,$limit";
	    $sql.=") as reportData GROUP BY reportData.email ORDER BY reportData.".$sortBy." ".$sortOrder;
	    return $this->slave->fetchAll($sql);
	}
}