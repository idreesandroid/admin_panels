<?php
class CopysettingsController extends Zend_Controller_Action 
{
    private $baseurl;
	
	
    function copypostsetupAction()
    {
    	$finalresults = array();
    	require_once 'Zend/Json.php';
    	$id = $_GET['id'];
			$PostSetups = new PostSetups();
    	$results = $PostSetups->fetchRow("id = $id")->toArray();
			$PostDelivery = new PostDelivery();
    	$results2 = $PostDelivery->fetchRow("postsetupid = $id")->toArray();
    	
	$results = array_change_key_case($results, CASE_LOWER);
	$results2 = array_change_key_case($results2, CASE_LOWER);
	
    	$finalresults['postsetup'] = $results;
    	$finalresults['delivery'] = $results2;
	
    	$json = Zend_Json::encode($finalresults);
  	$this->view->data = $json;
    }
    
    function copycriteriaAction()
    {
    	global $db;
    	$finalresults = array();
    	require_once 'Zend/Json.php';
    	$id = $_GET['cid'];
			$CashCriteria = new CashCriteria();
    	$results = $CashCriteria->fetchRow("id = $id");
    	$finalresults['criteria'] = $results;
    	$json = Zend_Json::encode($finalresults);
  		$this->view->data = $json;
    }
}
?>
