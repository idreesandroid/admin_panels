<?php

class BlacklistedCustomersController extends Zend_Controller_Action
{
	const SSN = 0;
	const EMAIL = 1;

	public function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if(!$AdminNameSpace->userid)
		{
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();
	}

	public function indexAction()
	{

	}

	public function getdataAction() {

		$offset = ($this->_request->offset) ? $this->_request->offset : 0;
		$limit  = ($this->_request->limit) ? $this->_request->limit : 100;
		$sortBy = ($this->_request->sort) ? $this->_request->sort : "email";
		$sortOrder = ($this->_request->order) ? $this->_request->order : "ASC";
		$search = ($this->_request->search) ? $this->_request->search : "";

		$Blacklist = new BlacklistedCustomer();
		$customersCount = $Blacklist->getTotalCustomers($search);
		$customers = $Blacklist->getCustomers($search,$offset,$limit,$sortBy,$sortOrder);

		$data = array('total' => $customersCount['cnt']);
		$data['rows'] = array();

		foreach($customers as $customer) {
			$tuple = array();
			$tuple['id'] = $customer['id'];
			$tuple['ssn'] = substr_replace($customer['ssn'], "xxx-xx-", 0, 5);
			$tuple['email'] = $customer['email'];
			$tuple['createdAt'] = $customer['createdAt'];
			$data['rows'][] = $tuple;
		}

		echo json_encode($data);
		exit;
	}

	public function uploadAction()
	{
		$ini_get_temp = (int)ini_get("auto_detect_line_endings");
		$post_max_size_temp = ini_get("post_max_size");
		$upload_max_filesize_temp = ini_get("upload_max_filesize");
		$memory_limit_temp = ini_get("memory_limit");
		ini_set('memory_limit', '-1');

		ini_set('auto_detect_line_endings', 1);
		ini_set('post_max_size', '32M');
		ini_set('upload_max_filesize', '32M');

		$this->_helper->viewRenderer->setnoRender();

		if (isset($_POST['submit'])) {

			$BlacklistedCustomer = new BlacklistedCustomer();

			$file_handle = NULL;
			$data = NULL;
			$keys = NULL;
			$record = NULL;

			$filename = $_FILES['filename']['tmp_name'];
			if (is_uploaded_file($filename)) {
				if (file_exists($filename)) {
					$filenameExt = explode(".", $_FILES['filename']['name']);
					if (strtolower($filenameExt[1]) == "csv") {
						$file_handle = fopen($filename, "r");

						while (!feof($file_handle)) {
							$row = fgetcsv($file_handle, 1024);

							if (is_array($row)) {
								//set record array keys from csv header
								if ($keys == NULL) {
									$keys = array_map('strtolower',$row);
									$keys = array_flip($keys);
								} //set record array values from csv row

								else if ($keys != NULL) {
									foreach ($keys as $key => $value) {
										// if ssn has length less than 9 characters let's insert leading zeroes in front
										if ($value == self::SSN) {
											$record[$key] = sprintf('%09d', $row[$value]);
										}
										else if ($value == self::EMAIL ) {
											$record[$key] = $row[$value];
										}
									}
									$data[] = $record;
								}
							}
						}

						foreach ($data as $v) {
							try {
								$BlacklistedCustomer->upsert($v);
							} catch (Exception $e) {
								$this->_helper->flashMessenger->addMessage(array(
									'message' => array("File " . $_FILES['filename']['name'] . " has wrong data." => 'error')));
							}
						}
					} else {
						$this->_helper->flashMessenger->addMessage(array(
							'message' => array("File " . $_FILES['filename']['name'] . " has wrong format." => 'error')));
					}
				} else {
					$this->_helper->flashMessenger->addMessage(array(
						'message' => array("File " . $_FILES['filename']['name'] . " not found." => 'error')));
				}

				$this->_helper->flashMessenger->addMessage(array(
					'message' => array("File " . $_FILES['filename']['name'] . " uploaded successfully." => 'success')));
			}
			if ($file_handle) fclose($file_handle);
		}
		ini_set('auto_detect_line_endings', $ini_get_temp);
		ini_set('post_max_size', $post_max_size_temp);
		ini_set('upload_max_filesize', $upload_max_filesize_temp);
		ini_set('memory_limit', $memory_limit_temp);

		return $this->_helper->redirector('index');
	}

	public function exportAction() {

		$Blacklist = new BlacklistedCustomer();
		$customers = $Blacklist->fetchAll();
		$this->view->customers = $customers;
	}

	public function newAction()
	{
		$this->view->ssn = $this->_request->ssn;
		$this->view->email = $this->_request->email;

		$this->view->flashMessages = $this->_helper->flashMessenger->getMessages();
	}

	public function createAction()
	{
		if (!$this->_request->ssn && !$this->_request->email) {
			$this->_helper->flashMessenger->addMessage(array(
				'errors' => array('You did not enter anything.' => 'fail')));

			return $this->_helper->redirector('new', 'blacklisted-customers');
		}

		$Blacklist = new BlacklistedCustomer();
		$savingErrors = array();

		// TODO: create a helper for this.
		// (converts linebreaks to \n. ie windows uses \r\n for linebreak)
		$ssnsCleaned = str_replace("\r\n", "\n", $this->_request->ssn);
		$ssns = explode("\n", $ssnsCleaned);

		// lets save SSNs first (also check if its already blacklisted)
		foreach ($ssns as $ssn) {
			try {
				if ($ssn) {
					if (!$Blacklist->exists($ssn)) {
						$Blacklist->insert(array('ssn' => trim($ssn)));
					}
				}
			} catch(Exception $e) {
				$savingErrors[] = $ssn;
			}
		}

		// lets save emails now (also check if its already blacklisted)
		$emailsCleaned = str_replace("\r\n", "\n", $this->_request->email);
		$emails = explode("\n", $emailsCleaned);

		foreach ($emails as $email) {
			try {
				if ($email) {
					if (!$Blacklist->exists(NULL, $email)) {
						$Blacklist->insert(array('email' => trim($email)));
					}
				}
			} catch(Exception $e) {
				$savingErrors[] = $email;
			}
		}

		// output any that failed to save
		if (!empty($savingErrors)) {
			$this->_helper->flashMessenger->addMessage(array(
				'errors' => array('following SSNs/emails could not be added:' .
				implode(',', $savingErrors) => 'fail')));

			return $this->_helper->redirector('new', 'blacklisted-customers');
		}

		$this->_helper->flashMessenger->addMessage(array(
				'message' => array('Customer(s) has been added to Blacklist.' => 'success')));

		return $this->_helper->redirector('index');
	}

	public function deleteAction()
	{
		if ($this->_request->id) {
			$Blacklist = new BlacklistedCustomer();
			$Blacklist->delete("id = " . $this->_request->id);

			$this->_helper->flashMessenger->addMessage(array(
				'message' => array('Customer has been removed from Blacklist.' => 'success')));
		}
		return $this->_helper->redirector('index');
	}
}
