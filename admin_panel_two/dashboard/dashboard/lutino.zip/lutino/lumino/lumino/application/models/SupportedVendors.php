<?php
class SupportedVendors extends Zend_Db_Table
{
    protected $_name = 'SupportedVendors';

    public function getCompanyById($id) {
        $sql = $this->select()
            ->where("id = " . $id);
        $result = $this->fetchRow($sql)->toArray();
        return $result['company'];
    }
}
?>