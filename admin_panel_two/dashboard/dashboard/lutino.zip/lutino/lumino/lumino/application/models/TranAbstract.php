<?php

/*
 * TRAN Abstract Class 
 * 
 * a base abstract class for TRAN table models
 *
 */
abstract class TranAbstract extends Zend_Db_table {

	public function init() 
	{

		$this->fieldNames = array();

	}
	
	/** 
 	 * Builds the insert array from the table field names and an array of values
	 *
	 */
	public function buildInsertArray($fieldData)
	{
	
		$insertData = array();
	
		foreach($this->fieldNames as $key =>$name) {
			$insertData[$name] = trim($fieldData[$key]);
		}

		return $insertData;
	}

}
