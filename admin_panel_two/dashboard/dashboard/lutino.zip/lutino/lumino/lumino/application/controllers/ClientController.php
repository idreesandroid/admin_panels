<?php
class ClientController extends Zend_Controller_Action 
{
    private $baseurl;
	
	function init()
    {
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if(!$AdminNameSpace->userid)
		{
	    		$this->_redirect('index/login');	
		}
	    $this->baseurl = $this->_request->getBaseUrl();
    }

    function addnewAction()
    {
    	global $db;
    	$message = "";
    	$error = 0;
    	$success = 0;

    	if ($this->_request->isPost()) 
		{
			$commonobj = new Commonfunctions();

			$f = new Zend_Filter_StripTags();

			$aeid = $this->_request->getPost('aeid');
			$pcode = $this->_request->getPost('pcode');
			$company = $f->filter($this->_request->getPost('company'));
			$phone = $this->_request->getPost('phone');
			$fname = $this->_request->getPost('fname');
			$lname = $this->_request->getPost('lname');
			$email = $this->_request->getPost('email');
			$status = $this->_request->getPost('status');
			$leadprice = $this->_request->getPost('price');
			$ledsperday = $this->_request->getPost('lpd');
			$leadspermonth = $this->_request->getPost('lpm');
			$totalleads = $this->_request->getPost('tl');

			$dayscsv = "";

			if(!$leadprice) $leadprice = 0;
			if(!$leadspermonth) $leadspermonth = 10000;
			if(!$ledsperday) $ledsperday = 1000;
			if(!$totalleads) $totalleads = 100000;

			if(empty($company)){
				$message.="Please provide company name.<br>";
				$error = 1;
			}
				if(empty($phone)){
    			$message.="Please provide phone number.<br>";
    			$error = 1;
    		}
    		if(!empty($phone)){
    			if($commonobj->isinvalidphone($phone)==0){
    			$message.="Invalid phone number.<br>";
    			$error = 1;
    			}
    		}
    		if(empty($fname)){
    			$message.="Please provide first name.<br>";
    			$error = 1;
    		}
    		if(empty($lname)){
    			$message.="Please provide last name.<br>";
    			$error = 1;
    		}

    		if(empty($email)){
    			$message.="Please provide email.<br>";
    			$error = 1;
    		}
    		if(!empty($email)){
    			if($commonobj->isvalidemail($email)==0){
    			$message.="Invalid email.<br>";
    			$error = 1;
    			}
    		}
    		if(!empty($leadprice)){
    			if(!is_numeric($leadprice)){
    			$message.="Lead price should be numeric value.<br>";
    			$error = 1;
    			}
    		}
    		if(!empty($ledsperday)){
    			if(!is_numeric($ledsperday)){
    			$message.="Lead per day should be numeric value.<br>";
    			$error = 1;
    			}
    		}
    		if(!empty($leadspermonth)){
    			if(!is_numeric($leadspermonth)){
    			$message.="Lead per month should be numeric value.<br>";
    			$error = 1;
    			}
    		}
    		if(!empty($totalleads)){
    			if(!is_numeric($totalleads)){
    			$message.="Total leads should be numeric value.<br>";
    			$error = 1;
    			}
    		}

    		if($error==0)
    		{
				$Form_Data = array('company'=>$company,
					'accexecutiveid'=>$aeid,
					'fname'=>$fname,
					'lname'=>$lname,
					'email'=>$email,
					'wphone'=>$phone,
					'price'=>$leadprice,
					'leadsperday'=>$ledsperday,
					'leadspermonth'=>$leadspermonth,
					'leadsperlife'=>$totalleads,
					'active'=>$status,
					'productcode'=>$pcode);

			    $cli  = new Clients();
			    try 
			    { 
			   		$cli->insert($Form_Data);	
					$message = "Client successfully added.";

					return $this->_helper->redirector('view');
			    }
			    catch (Zend_Exception $e)
			    {
			   		$error = 1;
			    	$message = "Some error occurred please try later.";
			   }
    		}
    		if ($error==1){
    			$this->view->aeid = $aeid;
	    		$this->view->pcode = $pcode;
	    		$this->view->company = $company;
	    		$this->view->phone = $phone;
	    		$this->view->email = $email;
	    		$this->view->fname = $fname;
	    		$this->view->lname = $lname;
	    		$this->view->status = $status;
	    		$this->view->leadprice = $leadprice;
	    		$this->view->leadsperday = $ledsperday;
	    		$this->view->leadspermonth = $leadspermonth;
	    		$this->view->totalleads = $totalleads;
    		}
    	}

    	$query = "select * from accountexecutives order by fname";
    	$accountexecutives = $db->fetchAll($query);

    	$query = "select * from products order by productcode ";
    	$productdata = $db->fetchAll($query);

    	$this->view->baseurl = $this->baseurl;
    	$this->view->message = $message;
    	$this->view->error = $error;
    	$this->view->success = $success;
    	$this->view->aedata = $accountexecutives;
    	$this->view->pdata = $productdata;
    }

    function editAction()
    {
    	global $db;
    	$id = $_REQUEST['id'];

    	$message = "";
    	$error = 0;
    	$success = 0;

    	if ($this->_request->isPost()) 
			{
    		$commonobj = new Commonfunctions();

				$f = new Zend_Filter_StripTags();
			
				$aeid = $this->_request->getPost('aeid');
				$pcode = $this->_request->getPost('pcode');
				$company = $f->filter($this->_request->getPost('company'));
				$phone = $this->_request->getPost('phone');
				$fname = $this->_request->getPost('fname');
				$lname = $this->_request->getPost('lname');
				$email = $this->_request->getPost('email');
				$status = $this->_request->getPost('status');
				$leadprice = $this->_request->getPost('price');
				$ledsperday = $this->_request->getPost('lpd');
				$leadspermonth = $this->_request->getPost('lpm');
				$totalleads = $this->_request->getPost('tl');
				$deliverydays = $this->_request->getPost('leaddays');
				
				if(!$leadprice) $leadprice = 0;
				if(!$leadspermonth) $leadspermonth = 10000;
				if(!$ledsperday) $ledsperday = 1000;
				if(!$totalleads) $totalleads = 100000;
	
				
				if(empty($company)){
    			$message.="Please provide company name.<br>";
    			$error = 1;
    		}
				if(empty($phone)){
    			$message.="Please provide phone number.<br>";
    			$error = 1;
    		}
    		if(!empty($phone)){
    			if($commonobj->isinvalidphone($phone)==0){
    			$message.="Invalid phone number.<br>";
    			$error = 1;
    			}
    		}
    		if(empty($fname)){
    			$message.="Please provide first name.<br>";
    			$error = 1;
    		}
    		if(empty($lname)){
    			$message.="Please provide last name.<br>";
    			$error = 1;
    		}

    		if(empty($email)){
    			$message.="Please provide email.<br>";
    			$error = 1;
    		}
    		if(!empty($email)){
    			if($commonobj->isvalidemail($email)==0){
    			$message.="Invalid email.<br>";
    			$error = 1;
    			}
    		}
    		if(!empty($leadprice)){
    			if(!is_numeric($leadprice)){
    			$message.="Lead price should be numeric value.<br>";
    			$error = 1;
    			}
    		}
    		if(!empty($ledsperday)){
    			if(!is_numeric($ledsperday)){
    			$message.="Lead per day should be numeric value.<br>";
    			$error = 1;
    			}
    		}
    		if(!empty($leadspermonth)){
    			if(!is_numeric($leadspermonth)){
    			$message.="Lead per month should be numeric value.<br>";
    			$error = 1;
    			}
    		}
    		if(!empty($totalleads)){
    			if(!is_numeric($totalleads)){
    			$message.="Total leads should be numeric value.<br>";
    			$error = 1;
    			}
    		}

    		if($error==0)
    		{
    			$Form_Data = array('company'=>$company,'accexecutiveid'=>$aeid,'fname'=>$fname,'lname'=>$lname,'email'=>$email
    			,'wphone'=>$phone,'price'=>$leadprice,'leadsperday'=>$ledsperday,'leadspermonth'=>$leadspermonth,'leadsperlife'=>$totalleads,
    			'active'=>$status,'productcode'=>$pcode);

			    $cli  = new Clients();
			    try 
			    { 
			   		$where = "id = $id";
			    	$cli->update($Form_Data,$where);	
			   		$message = "Client successfully updated.";	
			   		$success = 1;		   		
			    }
			    catch (Zend_Exception $e)
			    {
			   		$error = 1;
			    	$message = "Some error occurred please try later." . $e;
			    	
			    }
    		}
    		if ($error==1){
    		$this->view->fname = $fname;
    		$this->view->lname = $lname;
    		$this->view->email = $email;
    		$this->view->company = $company;
    		$this->view->phone = $phone;
    		$this->view->leadprice  = $leadprice;
    		$this->view->leadsperday  = $ledsperday;
    		$this->view->leadspermonth   = $leadspermonth;
    		$this->view->totalleads   = $totalleads;
    		$this->view->status   = $status;
    		$this->view->pcode   = $pcode;
    		$this->view->aeid   = $aeid;
    		$this->view->id    = $id;	
    		}
    	}

    	if($error==0) {
				$Clients = new Clients();
    		$data = $Clients->fetchRow("id = $id");

    		$this->view->fname = $data['fname'];
    		$this->view->lname = $data['lname'];
    		$this->view->email = $data['email'];
    		$this->view->company = $data['company'];
    		$this->view->phone = $data['wphone'];
    		$this->view->leadprice  = $data['price'];
    		$this->view->leadsperday  = $data['leadsperday'];
    		$this->view->leadspermonth   = $data['leadspermonth'];
    		$this->view->totalleads   = $data['leadsperlife'];
    		$this->view->status   = $data['active'];
    		$this->view->pcode   = $data['productcode'];
    		$this->view->aeid   = $data['accexecutiveid'];
    		$this->view->id    = $data['id'];	
    	}

    	$query = "select * from accountexecutives order by fname";
    	$accountexecutives = $db->fetchAll($query);

    	$query = "select * from products order by productcode ";
    	$productdata = $db->fetchAll($query);

    	$this->view->baseurl = $this->baseurl;
    	$this->view->message = $message;
    	$this->view->error = $error;
    	$this->view->success = $success;
    	$this->view->aedata = $accountexecutives;
    	$this->view->pdata = $productdata;
    }

    function viewAction()
    {
	$activeClients = array();
	$inactiveClients = array();

	$Clients = new Clients();
    	$clients = $Clients->fetchAll(NULL,"company");
	foreach ($clients as $client) {
		if ($client['active'] == 1) {
			$activeClients[] = $client;
		}
		else {
			$inactiveClients[] = $client;
		}
	}
    	$this->view->baseurl = $this->baseurl;
    	$this->view->allClients = $clients;
    	$this->view->activeClients = $activeClients;
    	$this->view->inActiveClients = $inactiveClients;
    }

    function deleteAction()
    {
    	$id= $_GET['id'];
			if ($id > 0)
			{
    		$where = "id=$id";
				$cli  = new Clients();
		    $cli->delete($where);
			}

	    $this->_redirect('client/view');	
    }
}
