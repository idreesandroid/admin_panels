<?php

/**
 *  The model is using by Vendor Transactions Breakdown Report
 */
class VendorTransactionsReportDataModel
{

	private $db_slave;

	public function initSettingsForSlaveDB()
	{

		$config = Zend_Registry::get("config");

		$this->db_slave = Zend_Db::factory($config->resources->multidb->slave->adapter, $config->resources->multidb->slave->toArray());
	}

	/**
	 *
	 * Gets vendor transactions report data
	 *
	 * @param    startDate    string    start of date range
	 * @param    endDate        string    end of date range
	 * @param    startTime    string    start time of date range
	 * @param    endTime    string    start   end time of date range
	 * @param    $affiliateID    string    affiliate ID
	 * @param    $campaignID    string    Campaign ID
     *
	 * @return    array    array of report data
	 */
	public function getReportData($startDate, $endDate, $startTime, $endTime, $affiliateID, $campaignID)
	{
		if ($affiliateID != "") {
			$affiliateIDStatement = "AND l.affiliateID = '$affiliateID'";
		}
		if($campaignID != "") {
            $campaignIDStatement = "AND l.campaign = '$campaignID'";
        }

		$sql = "SELECT
					v.id vendorID,
					v.company vendor,
					count(pl.leadID) attempted,
					SUM(CASE WHEN pl.postStatus = 'accept' THEN 1 ELSE 0 END) accepted,
					SUM(CASE WHEN pl.postStatus = 'no' THEN 1 ELSE 0 END) rejected,
					SUM(pl.cost) cost
				FROM
					Leads l
				LEFT JOIN
					PostLogs pl ON pl.leadID = l.id
				LEFT JOIN
					VendorPostSetups vps ON pl.postSetupID = vps.postSetupID
				LEFT JOIN
					Vendors v ON vps.vendorID = v.id
				WHERE
					  ((originaldate >= '$startDate' AND originaldate <= '$endDate')
                      AND
                      (originaltime >= '$startTime' AND originaltime <= '$endTime'))
				AND
					v.id IS NOT NULL
				{$affiliateIDStatement}
				{$campaignIDStatement}
				GROUP BY
					pl.clientID
				ORDER BY
					vendor";

        $result = $this->db_slave->fetchAll($sql);

        $totalAttempted = 0;
        $totalCost = 0;

        $formattedResult = array();
        foreach  ($result as $v) {
            $data['vendorID'] = $v['vendorID'];
            $data['vendor'] = $v['vendor'];
            $data['attempted'] = $v['attempted'];
	        $totalAttempted += $v['attempted'];
            $data['accepted'] = $v['accepted'];
            $data['rejected'] = $v['rejected'];
            $data['cost'] = number_format($v['cost'],2);
	        $totalCost += $v['cost'];
            $data['acceptedRate'] = ($v['attempted'] > 0 && $v['accepted'] > 0) ? round(100 * ($v['accepted'] / $v['attempted'])) : 0;
            $data['rejectedRate'] = ($v['attempted'] > 0 && $v['rejected'] > 0) ? round(100 * ($v['rejected'] / $v['attempted'])) : 0;
            $formattedResult[] = $data;
        }
	    $formattedResult["total"] = array("attempted" => $totalAttempted, "cost" => number_format($totalCost,2));

        return $formattedResult;
    }

    /**
     *
     * Gets vendor strategies transactions report data
     *
     * @param    startDate    string    start of date range
     * @param    endDate        string    end of date range
     * @param    startTime    string    start time of date range
     * @param    endTime    string    start   end time of date range
     * @param    $affiliateID    string    affiliate ID
     * @param    $vendorID    string    vendor ID
     *
     * @return    array    array of report data
     */
    public function getVendorStrategiesData($startDate, $endDate, $startTime, $endTime, $affiliateID, $vendorID, $campaignID)
    {
        if ($affiliateID != "") {
            $affiliateIDStatement = "AND l.affiliateID = '$affiliateID'";
        }
		    if($campaignID != "") {
			    $campaignIDStatement = "AND l.campaign = '$campaignID'";
		    }
        $sql = "SELECT
					vs.description,
					vs.id,
				    count(pl.leadID) attempted,
				    SUM(CASE WHEN pl.postStatus = 'accept' THEN 1 ELSE 0 END) accepted,
					SUM(CASE WHEN pl.postStatus = 'no' THEN 1 ELSE 0 END) rejected,
					SUM(pl.cost) cost
				FROM
					Leads l
				LEFT JOIN
					PostLogs pl ON pl.leadID = l.id
				LEFT JOIN
					VendorPosts vp ON pl.id = vp.postLogID
				LEFT JOIN
					VendorStrategies vs ON vs.id = vp.vendorStrategyID
				WHERE
					  ((pl.postDate >= '$startDate' AND pl.postDate <= '$endDate')
				AND
					  (pl.startTime >= '$startTime' AND pl.startTime <= '$endTime'))
				AND
					pl.clientID = '$vendorID'
				AND
					vs.id IS NOT NULL
				{$affiliateIDStatement}
				{$campaignIDStatement}
				GROUP BY
					vp.vendorStrategyID	";

        $result = $this->db_slave->fetchAll($sql);

        $formattedResult = array();
        foreach  ($result as $v) {
            $data['vendorStrategyName'] = $v['description'] != "" ? $v['description'] : "empty";
            $data['vendorStrategyID'] = $v['id'];
            $data['attempted'] = $v['attempted'];
            $data['accepted'] = $v['accepted'];
            $data['rejected'] = $v['rejected'];
            $data['cost'] = number_format($v['cost'],2);
            $data['acceptedRate'] = ($v['attempted'] > 0 && $v['accepted'] > 0) ? round(100 * ($v['accepted'] / $v['attempted'])) : 0;
            $data['rejectedRate'] = ($v['attempted'] > 0 && $v['rejected'] > 0) ? round(100 * ($v['rejected'] / $v['attempted'])) : 0;
            $formattedResult['data'][] = $data;
        }

        return $formattedResult;
    }

    public function getLeadsDataByVendorStrategy($fromDate, $toDate, $timeStart, $timeEnd, $affiliateID,$vendorID,$strategyID,$type)
    {
        $affiliateIDStatement = "";
        if ($affiliateID != "") {
            $affiliateIDStatement = "AND l.affiliateID = '$affiliateID'";
        }

        $typeSql = "";

        if ($type == "accept") {
            $typeSql = " AND l.leadsold = 1";
        }
        elseif ($type == "reject") {
            $typeSql = " AND l.leadsold = 0";
        }

        $sql = "SELECT
	    l.*,cd.ssn,cd.monthlyincome,aff.masteraff,pl.cost
	    FROM
	    Leads l
	    LEFT JOIN
            CashData cd on cd.leadid = l.id
        LEFT JOIN
            Affiliates aff on aff.id =  l.affiliateID
	    LEFT JOIN
	        PostLogs pl ON pl.leadID = l.id
	    LEFT JOIN
	        VendorPosts vp ON pl.id = vp.postLogID
	    LEFT JOIN
	        VendorStrategies vs ON vs.id = vp.vendorStrategyID
	    WHERE
	    ((pl.postDate >= ? AND pl.postDate <= ?)
	    AND
	    (pl.startTime >= ? AND pl.startTime <= ?))
	    AND
	    pl.clientID = ?
	    AND vs.id = ?
	    {$affiliateIDStatement}
	    $typeSql";

        $stmt = $this->db_slave->query($sql,array($fromDate,$toDate,$timeStart,$timeEnd,$vendorID,$strategyID));
        return $stmt->fetchAll();
    }

    public function getLeadsDataByVendor($fromDate, $toDate, $timeStart, $timeEnd, $affiliateID,$vendorID,$type)
    {
        $typeSql = "";

        if ($type == "accept") {
            $typeSql = " AND l.leadsold = 1";
        }
        elseif ($type == "reject") {
            $typeSql = " AND l.leadsold = 0";
        }

        $affiliateIDStatement = "";
        if ($affiliateID != "") {
            $affiliateIDStatement = "AND l.affiliateID = '$affiliateID'";
        }

        $sql = "
            SELECT
                l.*,cd.ssn,cd.monthlyincome,aff.masteraff,pl.cost
            FROM
                Leads l
            LEFT JOIN
                CashData cd on cd.leadid = l.id
            LEFT JOIN
                Affiliates aff on aff.id =  l.affiliateID
            LEFT JOIN
                PostLogs pl ON pl.leadID = l.id
            LEFT JOIN
                VendorPostSetups vps ON pl.postSetupID = vps.postSetupID
            LEFT JOIN
                Vendors v ON vps.vendorID = v.id
            WHERE
                  ((originaldate >= ? AND originaldate <= ?)
                  AND
                  (originaltime >= ? AND originaltime <= ?))
            AND
                v.id = ?
            $typeSql
            $affiliateIDStatement";

        $stmt = $this->db_slave->query($sql,array($fromDate,$toDate,$timeStart,$timeEnd,$vendorID));
        return $stmt->fetchAll();
    }
}
