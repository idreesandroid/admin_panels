<?php

class PrescrubController extends Zend_Controller_Action
{
	public function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if(!$AdminNameSpace->userid)
		{
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();
	}

	public function updateAction() {

	    $error = 0;

	    $PreScrub = new PreScrub();
	    $data = $PreScrub->fetchRow("id = 1");
	    $passingValue = $data['passingValue'];

	    if ($this->_request->isPost()) {

	        $passingValue = $this->_request->getPost('passingValue');

	        if(strlen($passingValue) == 0) {
	            $message.="Please provide prescrub passing value";
    			$error = 1;
	        }
	        else {
	            $where = "id = 1";
	            $updateData = array('passingValue' => $passingValue);
	            $PreScrub->update($updateData,$where);
	            $error = 0;
	            $message.="Prescrub passing value successfully updated";
	        }
	    }

	    $this->view->passingValue = $passingValue;
	    $this->view->error = $error;
	    $this->view->message = $message;
	}
}