<?php

class CampaignsCustomVendorSetting extends Zend_Db_Table 
{
	protected $_name = 'CampaignsCustomVendorSettings';
}
