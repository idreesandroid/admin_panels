<?php

class EpicPerformanceOverviewReportController extends Zend_Controller_Action
{
	private $baseurl;

	function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if (!$AdminNameSpace->userid) {
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();
	}

	public function indexAction()
	{
		$EpicPerformanceOverviewDataModel = new EpicPerformanceOverviewDataModel();

		$this->view->fromDate = date('m/d/Y');
		$this->view->toDate = date('m/d/Y');
		$this->view->timeStart = "00:00:00";
		$this->view->timeEnd = "23:59:59";
		$this->view->lastScrapeTime = $EpicPerformanceOverviewDataModel->getLastScrapeTime();
	}

	public function getdataAction()
	{
		$this->_helper->viewRenderer->setNoRender();

		$offset = ($this->_request->offset) ? $this->_request->offset : 0;
		$limit  = ($this->_request->limit) ? $this->_request->limit : 100;
		$sortBy = ($this->_request->sort) ? $this->_request->sort : "id";
		$sortOrder = ($this->_request->order) ? $this->_request->order : "DESC";

		$fromDate = ($this->_request->fromDate) ?
			date('Y-m-d', strtotime($this->_request->fromDate)) : date('Y-m-d');
		$toDate = ($this->_request->toDate) ?
			date('Y-m-d', strtotime($this->_request->toDate)) : date('Y-m-d');

		$EpicPerformanceOverviewDataModel = new EpicPerformanceOverviewDataModel();

		$dataCount = 	$EpicPerformanceOverviewDataModel->getTotalRecords($fromDate, $toDate);
		$reportData = $EpicPerformanceOverviewDataModel->getScrapeData($fromDate,$toDate,$sortBy,$sortOrder,$offset,$limit);

		$lastScrapeTime = $EpicPerformanceOverviewDataModel->getLastScrapeTime();

		$data = array('total' => $dataCount['total']);
		$data['rows'] = array();

		foreach($reportData as $rData) {

			$tuple = array();
			$tuple['leadID'] = $rData['leadID'];
			$tuple['emailAddress'] = $rData['emailAddress'];
			$tuple['loanNumber'] = $rData['loanNumber'];
			$tuple['accountStatus'] = $rData['accountStatus'];
			$tuple['store'] = $rData['store'];
			$tuple['eStatus'] = $rData['eStatus'];
			$tuple['leadSource'] = $rData['leadSource'];
			$tuple['dateOriginated'] = $rData['dateOriginated'];
			$tuple['effectiveDate'] = $rData['effectiveDate'];
			$tuple['dateApplicationReceived'] = $rData['dateApplicationReceived'];
			$tuple['dateDue'] = $rData['dateDue'];
			$tuple['denialReason'] = $rData['denialReason'];
			$tuple['withdrawnReason'] = $rData['withdrawnReason'];
			$tuple['ssn'] = substr_replace($rData['ssn'], "xxx-xx-", 0, 5);
			$tuple['originalPrincipalAmount'] = "$".$rData['originalPrincipalAmount'];
 			$data['rows'][] = $tuple;
		}

		echo json_encode($data);
	}
}
