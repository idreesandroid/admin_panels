<?php

class VendorPostSetups extends Zend_Db_Table
{
	protected $_name = 'VendorPostSetups';
}
?>
