<?php

/**
 * PayFile Model
 *
 * model for TRAN Pay_File table
 *
 */
class CMCPayFile extends TranAbstract
{

	protected $_name = 'CMCPay_File';
		
	public function init()
	{

		$this->fileName = "Pay_File";
		// db columns that are dates, used to format the date from data file
		$this->dateFields = array(10);
		// file type
		$this->cboFileType = "P";

		$this->fieldNames = array("Pmt_Tran_No",
				"Merch_Store_ID",
				"Cust_ID",
				"User_ID",
				"Pmt_Type",
				"Pmt_Mode",
				"Pmt_Amt",
				"Principal_Paid",
				"FinCharge_Paid",
				"FeeCharge_Paid",
				"Pmt_Date",
				"Check_No",
				"ABA_No",
				"Acct_No",
				"RefNo",
				"Appl_No",
				"Status_Flag",
				"ReversalCode",
				"MerchantRefID",
				);
	}

	/**
	 * Updates or inserts a row
	 */
	public function upsert($insertData)
	{

		$existingRow = $this->find($insertData['Pmt_Tran_No'], $insertData['Merch_Store_ID']);

		if(count($existingRow) > 0) {
			$this->update($insertData, $this->_db->quoteInto("Pmt_Tran_No = ?", $insertData['Pmt_Tran_No']) . " AND " . $this->_db->quoteInto("Merch_Store_ID = ?", $insertData['Merch_Store_ID']));
		}
		else {
			$this->insert($insertData);
		}

	}
}
