<?php

/**
 * Vendor Transactions Report is using to see transaction counts of each active vendor.
 */
class VendorTransactionsReportController extends Zend_Controller_Action
{
	public function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if (!$AdminNameSpace->userid) {
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();

		$this->config = Zend_Registry::get('config');
	}

	public function indexAction()
	{
		if ($this->getRequest()->isPost()) {
			$fromDate = ($this->_request->fromDate) ? $this->_request->fromDate : date('Y-m-d');
			$toDate = ($this->_request->toDate) ? $this->_request->toDate : date('Y-m-d');

			$timeStart = ($this->_request->timeStart) ? $this->_request->timeStart : date("H:i:s", strtotime("Today"));
			$timeEnd = ($this->_request->timeEnd) ? $this->_request->timeEnd : date("H:i:s", strtotime("Today last second"));
			$affiliateID = ($this->_request->affiliateID) ? $this->_request->affiliateID : "";
            $campaignID = ($this->_request->campaignID) ? $this->_request->campaignID : "";

			$fromDate = date('Y-m-d', strtotime($fromDate));
			$toDate = date('Y-m-d', strtotime($toDate));
		} else {
			$fromDate = date('Y-m-d');
			$toDate = date('Y-m-d');
			$timeStart = date("H:i:s", strtotime("Today"));
			$timeEnd = date("H:i:s", strtotime("Today last second"));
		}

		$ReportsDataModel = new VendorTransactionsReportDataModel();
		$ReportsDataModel->initSettingsForSlaveDB();

		$reportData = $ReportsDataModel->getReportData($fromDate, $toDate, $timeStart, $timeEnd, $affiliateID,$campaignID);

		$this->view->fromDate = $fromDate;
		$this->view->toDate = $toDate;
		$this->view->timeStart = $timeStart;
		$this->view->timeEnd = $timeEnd;
		$this->view->reportsData = $reportData;

		$Affiliates = new Affiliates();
		$this->view->affiliates = $Affiliates->getActive();
		$affiliateId = $this->_request->affiliateID;
		$this->view->affiliateID = $affiliateId;
		$this->view->campaignID = $campaignID;
	}

	/**
	 * Get Vendor Strategy Transactions data broken down by vendorStrategyID
	 */
	public function reportsdatabyvendorAction() {

		$fromDate = ($this->_request->fromDate) ? $this->_request->fromDate : date('Y-m-d');
		$toDate = ($this->_request->toDate) ? $this->_request->toDate : date('Y-m-d');

		$timeStart =  ($this->_request->timeStart) ? $this->_request->timeStart : date("H:i:s", strtotime("Today"));
		$timeEnd =($this->_request->timeEnd) ? $this->_request->timeEnd : date("H:i:s", strtotime("Today last second"));

		$fromDate = date('Y-m-d', strtotime($fromDate));
		$toDate = date('Y-m-d', strtotime($toDate));

		$affiliateID = $this->_request->affiliateID ? $this->_request->affiliateID : "";
		$vendorID = $this->_request->vendorID ? $this->_request->vendorID : "";
        $campaignID = ($this->_request->campaignID) ? $this->_request->campaignID : "";


		$ReportsDataModel = new VendorTransactionsReportDataModel();
		$ReportsDataModel->initSettingsForSlaveDB();
		$reportData = $ReportsDataModel->getVendorStrategiesData($fromDate, $toDate, $timeStart, $timeEnd, $affiliateID,$vendorID,$campaignID);

		echo json_encode($reportData);
		exit;
	}

	public function leadsdatabystrategyAction() {

	    $fromDate = ($this->_request->fromDate) ? $this->_request->fromDate : date('Y-m-d');
	    $toDate = ($this->_request->toDate) ? $this->_request->toDate : date('Y-m-d');

	    $timeStart =  ($this->_request->timeStart) ? $this->_request->timeStart : date("H:i:s", strtotime("Today"));
	    $timeEnd =($this->_request->timeEnd) ? $this->_request->timeEnd : date("H:i:s", strtotime("Today last second"));

	    $fromDate = date('Y-m-d', strtotime($fromDate));
	    $toDate = date('Y-m-d', strtotime($toDate));

	    $affiliateID = $this->_request->affiliateID ? $this->_request->affiliateID : "";
	    $vendorID = $this->_request->vendorID ? $this->_request->vendorID : "";
	    $type = $this->_request->type ? $this->_request->type : "";
	    $strategyID = $this->_request->strategyID ? $this->_request->strategyID : "";

	    $Vendors = new Vendors();
	    $vendorData = $Vendors->getDataById($vendorID);

	    $VendorStrategy = new VendorStrategy();
	    $strategy = $VendorStrategy->fetchRow('id ='.$strategyID);

	    $ReportsDataModel = new VendorTransactionsReportDataModel();
	    $ReportsDataModel->initSettingsForSlaveDB();

	    $leadData = $ReportsDataModel->getLeadsDataByVendorStrategy($fromDate, $toDate, $timeStart, $timeEnd, $affiliateID,$vendorID,$strategyID,$type);

	    $reportData = array();

	    foreach($leadData as $row) {
	        $dataRow = array();
	        $dataRow[] = $row['originaldate']." ".$row['originaltime'];
	        $dataRow[] = $row['id'];
	        $dataRow[] = $row['storeID'];
	        $dataRow[] = $row['masteraff'];
	        $dataRow[] = $row['campaign'];
	        $dataRow[] = $row['leadsold'];
	        $dataRow[] = $row['ip'];
	        $dataRow[] = ((!empty($row['city'])) ? $row['city'] . ", " : "") . $row['state'];
	        $dataRow[] = $row['fname'];
	        $dataRow[] = $row['lname'];
	        $dataRow[] = $row['email'];
	        $dataRow[] = (isset($row['ssn']) && !empty($row['ssn'])) ? substr_replace($row['ssn'], "xxx-xx-", 0, 5) : "";
	        $dataRow[] = isset($row['mphone']) ? $row['mphone'] : "";

	        if(!empty($row['dob'])) {
	            $DOB = new DateTime($row['dob']);
	            $Date = new DateTime();
	            $dobInterval = $Date->diff($DOB);
	            $dataRow[] = $row['dob'] . " (" . $dobInterval->y . ")";
	        }
	        else {
	            $dataRow[] = "";
	        }

	        $dataRow[] = $row['monthlyincome'];
		    $dataRow[] = number_format($row['cost'],2);

	        $reportData[] = $dataRow;
	    }

	    $this->_helper->viewRenderer('leadsdata');
	    $this->view->data = $reportData;
	    $this->view->vendor = $vendorData;
	    $this->view->title = "Vendor Leads Breakdown for ".$vendorData['company']." with (".$strategy['description'].") strategy";

	}

	public function leadsdatabyvendorAction() {

        $fromDate = ($this->_request->fromDate) ? $this->_request->fromDate : date('Y-m-d');
        $toDate = ($this->_request->toDate) ? $this->_request->toDate : date('Y-m-d');

        $timeStart =  ($this->_request->timeStart) ? $this->_request->timeStart : date("H:i:s", strtotime("Today"));
        $timeEnd =($this->_request->timeEnd) ? $this->_request->timeEnd : date("H:i:s", strtotime("Today last second"));

        $fromDate = date('Y-m-d', strtotime($fromDate));
        $toDate = date('Y-m-d', strtotime($toDate));

        $affiliateID = $this->_request->affiliateID ? $this->_request->affiliateID : "";
        $vendorID = $this->_request->vendorID ? $this->_request->vendorID : "";
        $type = $this->_request->type ? $this->_request->type : "";

        $Vendors = new Vendors();
        $vendorData = $Vendors->getDataById($vendorID);

        $ReportsDataModel = new VendorTransactionsReportDataModel();
        $ReportsDataModel->initSettingsForSlaveDB();

        $leadData = $ReportsDataModel->getLeadsDataByVendor($fromDate, $toDate, $timeStart, $timeEnd, $affiliateID,$vendorID,$type);

        $reportData = array();

        foreach($leadData as $row) {

            $dataRow = array();

            $dataRow[] = $row['originaldate']." ".$row['originaltime'];
            $dataRow[] = $row['id'];
            $dataRow[] = $row['storeID'];
            $dataRow[] = $row['masteraff'];
            $dataRow[] = $row['campaign'];
            $dataRow[] = $row['leadsold'];
            $dataRow[] = $row['ip'];
            $dataRow[] = ((!empty($row['city'])) ? $row['city'] . ", " : "") . $row['state'];
            $dataRow[] = $row['fname'];
            $dataRow[] = $row['lname'];
            $dataRow[] = $row['email'];
            $dataRow[] = (isset($row['ssn']) && !empty($row['ssn'])) ? substr_replace($row['ssn'], "xxx-xx-", 0, 5) : "";
            $dataRow[] = isset($row['mphone']) ? $row['mphone'] : "";

            if(!empty($row['dob'])) {
                $DOB = new DateTime($row['dob']);
                $Date = new DateTime();
                $dobInterval = $Date->diff($DOB);
                $dataRow[] = $row['dob'] . " (" . $dobInterval->y . ")";
            }
            else {
                $dataRow[] = "";
            }

            $dataRow[] = $row['monthlyincome'];
	        $dataRow[] = number_format($row['cost'],2);

            $reportData[] = $dataRow;
        }

        $this->_helper->viewRenderer('leadsdata');
        $this->view->data = $reportData;
        $this->view->vendor = $vendorData;
        $this->view->title = "Vendor Leads Breakdown for ".$vendorData['company'];
    }

	public function getcampaignsAction()
	{

		$this->_helper->viewRenderer->setnoRender();

		$affiliateID = $this->_request->affiliateID;
		$campaigns = new Campaigns();
		$affiliateCampaigns = $campaigns->getCampaignsByAffiliateID($affiliateID);

		echo json_encode($affiliateCampaigns);
	}

	public function downloadExcelAction()
	{
		$this->_helper->viewRenderer->setNoRender();
		$fromDate = ($this->_request->fromDate) ? $this->_request->fromDate : date('Y-m-d');
		$toDate = ($this->_request->toDate) ? $this->_request->toDate : date('Y-m-d');

		$timeStart =  ($this->_request->timeStart) ? $this->_request->timeStart : date("H:i:s", strtotime("Today"));
		$timeEnd =($this->_request->timeEnd) ? $this->_request->timeEnd : date("H:i:s", strtotime("Today last second"));

		$affiliateID = $this->_request->affiliateID ? $this->_request->affiliateID : "";
		$campaignID = $this->_request->campaignID ? $this->_request->campaignID : "";

		$ReportsDataModel = new VendorTransactionsReportDataModel();
		$ReportsDataModel->initSettingsForSlaveDB();

		$reportData = $ReportsDataModel->getReportData($fromDate, $toDate, $timeStart, $timeEnd, $affiliateID, $campaignID);


		header("Content-Disposition: attachment; filename=vendorTransactionsReport_" . $fromDate . "_" . $toDate . ".csv");

		echo '"Vendor ID","Vendor","Attempted","Accepted","Rejected","Cost"';
		echo "\n";

		foreach ($reportData as $key => $data) {
			if ($key === "total") continue;

			echo '"' . $data['vendorID'] . '",';
			echo '"' . $data['vendor'] . '",';
			echo '"' . $data['attempted'] . '",';
			echo '"' . $data['accepted'] . ' (' . $data['acceptedRate'] . '%)",';
			echo '"' . $data['rejected'] . ' (' . $data['rejectedRate'] . '%)",';
			echo '"$' . $data['cost'] . '"';
			echo "\n";

			$reportVendorStrategiesData = $ReportsDataModel->getVendorStrategiesData($fromDate, $toDate, $timeStart, $timeEnd, $affiliateID, $data['vendorID'], $campaignID);
			echo '"", "Vendor Strategy ID","Attempted","Accepted","Rejected","Cost"';
			echo "\n";

			foreach ($reportVendorStrategiesData['data'] as $vendorStrategiesdata) {
				echo '"",';
				echo '"' . $vendorStrategiesdata['vendorStrategyName'] . '",';
				echo '"' . $vendorStrategiesdata['attempted'] . '",';
				echo '"' . $vendorStrategiesdata['accepted'] . ' (' . $vendorStrategiesdata['acceptedRate'] . '%)",';
				echo '"' . $vendorStrategiesdata['rejected'] . ' (' . $vendorStrategiesdata['rejectedRate'] . '%)",';
				echo '"$' . $vendorStrategiesdata['cost'] . '"';
				echo "\n";
			}
			echo '"",';
			echo '"",';
			echo '"",';
			echo '"",';
			echo '"",';
			echo "\n";
		}

		echo '"",';
		echo '"Total",';
		echo '"' . $reportData['total']['attempted'] . '",';
		echo '"",';
		echo '"",';
		echo '"$' . $reportData['total']['cost'] . '",';

		echo "\n";
	}
}
