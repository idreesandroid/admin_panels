<?php
/**
 * this class looks at a customers Loan_App entry 
 * and matches the most likely leadID, 
 * depending on if the record is a renewal or standard
 */
class LeadMatcherLoanApp
{
	/**
	 * @string this row was created as a result of
	 * 	customer coming through our lead engine
	 */
	const STANDARD_LOAN = 'S';

	/**
	 * @string this row was not created
	 * 	as a result of passing via our lead engine
	 */
	const RENEWAL_LOAN = 'R';

	/**
	 * @param integer $custID
	 * @param integer $custSSN
	 * @param string $loanType ('S'|'R')
	 * @param string $storeID
	 * @param string $dateTime e.g. '2013-05-01 09:30:00'
	 */
	public function __construct($custID, $custSSN, $loanType, $storeID, $dateTime)
	{
		$this->db = Zend_Registry::get('db');

		$this->custID = $custID;
		$this->custSSN = $custSSN;
		$this->loanType = $loanType;
		$this->storeID = $storeID;

		$datePieces = explode(' ', $dateTime);
		$this->appDateTime = $dateTime;
		$this->appDate = $datePieces[0];
		$this->appTime = $datePieces[1];
	}

	/**
	 * main interface to this class
	 *
	 * @return integer the leadID or NULL
	 */
	public function execute()
	{
		// look at most likely row in Leads table
		if ($this->loanType == self::STANDARD_LOAN)
		{
			// lets now get all possible leads via CashData.ssn
			if (!$leads = $this->findPossibleLeads($this->appDate, $this->custSSN)) {
				return NULL;
			}

			// if multiple leads found, we must choose correct one 
			// using Leads.originaldate/originaltime and Loan_App.ApplicationDate
			$result = $this->chooseLead($leads, $this->appDateTime);
			return $result;
		}

		// else they are a 'renewal'. ie did not come through our system.
		// look for the renewals corresponding standard loan and use it's leadID value
		return $this->findLeadIDOfCorrespondingStandard($this->custSSN, 
			$this->storeID, 
			$this->appDateTime);
	}

	/**
	 * this is used when trying to match a STANDARD loan to a leadID.
	 * ie lookup Leads table
	 *
	 * @param string date e.g. '2013-05-21'
	 * @param string ssn
	 * @return array
	 */
	public function findPossibleLeads($date, $ssn)
	{
		$sql = "select l.id leadID,
			l.originaldate,
			l.originaltime,
			CONCAT_WS(' ', l.originaldate, l.originaltime) as leadDateTime,
			l.leadsold,
			cd.ssn 
			FROM Leads l 
			join CashData cd on l.id = cd.leadID 
			WHERE cd.ssn = '" . $ssn . "' 
			and l.originaldate = '" . $date . "' 
			and l.leadsold = 1";

		$result = $this->db->fetchAll($sql);
		return $result;
	}

	/**
	 * this is used when trying to find a RENEWALs leadID.
	 * ie find the STANDARD loan that corresponds to this RENEWAL,
	 * and use its leadID
	 *
	 * @param string $ssn
	 * @param string $dateTime e.g. '2013-05-21 09:23:00'
	 * @return integer
	 */
	public function findLeadIDOfCorrespondingStandard($ssn, $storeID, $dateTime)
	{
		$sql = "select leadID 
			from Loan_App 
			where Cust_SSN = '" . $ssn . "' 
			and Loan_Type = 'S' 
			and Loan_Status NOT IN ('I','V','W') 
			and Merch_Store_ID = '" . $storeID . "' 
			and ApplicationDate < '" . $dateTime . "' 
			order by ApplicationDate desc 
			limit 1";

		if ($result = $this->db->fetchRow($sql)) {
			return $result['leadID'];
		}
		return NULL;
	}

	/**
	 * if multiple leads found, we must choose correct one 
	 * using Leads.originaldate/originaltime and Loan_App.ApplicationDate
	 *
	 * @param array $leads
	 * @param string $loanAppDate 'Y-m-d H:i:s'
	 *
	 * @return integer leadID
	 */
	public function chooseLead($leads, $loanAppDate)
	{
		$chosenDate = NULL;
		$chosenLeadID = NULL;

		foreach ($leads as $lead)
		{
			if (strtotime($lead['leadDateTime']) <= 
				strtotime($this->fixDate($loanAppDate)))
			{
				if (!$chosenDate)
				{
					$chosenDate 	= $lead['leadDateTime'];
					$chosenLeadID 	= $lead['leadID'];
					continue;
				}

				// we only care about largest date
				if (strtotime($lead['leadDateTime']) >= strtotime($chosenDate))
				{
					$chosenDate 	= $lead['leadDateTime'];
					$chosenLeadID 	= $lead['leadID'];
				}
			}
		}

		return $chosenLeadID;
	}

	/**
	 * fastforward datetime 1min as we are finding small offsets in time (usually seconds)
	 *
	 * @param string $date 'Y-m-d H:i:s'
	 * @return string datetime
	 */
	public function fixDate($date)
	{
		$correctDate = $date;

		$correctDate = date('Y-m-d H:i:s', strtotime('+1 minutes', strtotime($correctDate)));	
		return $correctDate;
	}
}
