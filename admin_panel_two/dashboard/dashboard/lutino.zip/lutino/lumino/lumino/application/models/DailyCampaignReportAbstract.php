<?php

abstract class DailyCampaignReportAbstract {

    protected  $db_slave;

    public function initSettingsForSlaveDB () {

        $config = Zend_Registry::get("config");
        $this->db_slave = Zend_Db::factory($config->resources->multidb->slave->adapter, $config->resources->multidb->slave->toArray());
    }

    /**
     * Gets store IDs list
     *
     * @return  array	array of all store IDs
     */
    public function getStoreIDs()
    {
        $sql = "SELECT
					storeID
				FROM
					Leads
				GROUP BY
					storeID";

        $result1 = $this->db_slave->fetchAll($sql);

        $sql = "SELECT
					Store_number AS storeID
				FROM
					`Master` m
				GROUP BY
					Store_number";

        $result2 = $this->db_slave->fetchAll($sql);

        $array_merge_result = array_merge($result1, $result2);
        asort($array_merge_result);
        return $array_merge_result;
    }

    /**
     * returns report data with added calculated custom values. eg. CPF, etc.
     *
     * @param   reportData  array of report data
     * @return  $finalReport array of report data with calculated fields
     */
    public function calculateValues($reportData)
    {
        $finalReport = array();

        foreach($reportData as $value)
        {
            $calculatedRow = $value;

            $calculatedRow['costPerLead'] = ReportCalc::costPerLead($calculatedRow['TotalPrice'], $calculatedRow['bought']);
            $calculatedRow['cost'] = $calculatedRow['TotalPrice'] ? $calculatedRow['TotalPrice'] : 0;
            $calculatedRow['cpf'] = $calculatedRow['CPF'];
            $calculatedRow['esigRate'] = ReportCalc::esigRate($calculatedRow['esigs'], $calculatedRow['bought']);
            $calculatedRow['originated'] = $calculatedRow['TodaysOriginated'];
            $calculatedRow['totaloriginated'] = $calculatedRow['TotalOriginated'];
            $calculatedRow['date'] = $calculatedRow['odate'];
            $calculatedRow['redirectsRate'] = ReportCalc::redirectsRate($calculatedRow['bought'], $calculatedRow['redirects']);
            $calculatedRow['FPDRate'] = ReportCalc::fpdRate($calculatedRow['TotalOriginated'], $calculatedRow['FPD']);

            $finalReport[] = $calculatedRow;
        }

        return $finalReport;
    }

    /**
     * call this method if you want to total all the data returned in calculateValues()
     *
     * @param  $calculatedValues the array returned from calculatedValues()
     * @return our passed in $calculatedValues array with an added 'totals' array element
     */
    public function totalCalculatedValues($calculatedData)
    {
        // prepare totals array with initial values
        $totals = array("leads" => 0, "bought" => 0, "totalCost" => 0, "originated" => 0, "totaloriginated" => 0);

        // iterate to build totals
        foreach ($calculatedData as $value)
        {
            $totals['leads'] += $value['leads'];
            $totals['bought'] += $value['bought'];
            $totals['cost'] += $value['cost'];
            $totals['originated'] += $value['TodaysOriginated'];
            $totals['totaloriginated'] += $value['TotalOriginated'];
            $totals['esigs'] += $value['esigs'];
            $totals['FPD'] += $value['FPD'];
            $totals['redirects'] += $value['redirects'];
        }

        $totals['costPerLead'] = ReportCalc::costPerLead($totals['cost'], $totals['bought']);
        $totals['cpf'] = ReportCalc::costPerOriginated($totals['cost'], $totals['totaloriginated']);
        $totals['perTodayOrigBought'] = ReportCalc::percentOriginatedvsBought($totals['originated'], $totals['bought']);
        $totals['perTotalOrigBought'] = ReportCalc::percentOriginatedvsBought($totals['totaloriginated'], $totals['bought']);
        $totals['perBoughtAttempted'] = ReportCalc::percentBoughtvsAttempted($totals['bought'], $totals['leads']);
        $totals['esigRate'] = ReportCalc::esigRate($totals['esigs'], $totals['bought']);
        $totals['FPDRate'] = ReportCalc::fpdRate($totals['TotalOriginated'], $totals['FPD']);
        $totals['redirectsRate'] = ReportCalc::redirectsRate($totals['bought'], $totals['redirects']);

        $calculatedData['totals'] = $totals;

        return $calculatedData;
    }
}