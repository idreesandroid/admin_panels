<?php
/**
 * facade class that handles getting all data for building Denial Report
 * All common code to Denial Report and Denial Report Summary is here
 */
class DenialReportAbstract extends ReportAbstract
{

	protected function getInternalRejects()
	{
		$sql = "select replace(Leads.campaign,' ','') campaign,
			count(1) total,
			ir.rejectCode,
			irc.name rejectName 
			from Leads
			join InternalRejects ir on ir.leadid = Leads.id
			join InternalRejectCodes irc on irc.id = ir.rejectcode
			".$this->strategy."
			where Leads.originaldate >= '" . $this->fromDate . "'
			and Leads.originaldate <= '" . $this->toDate . "'
			and Leads.originaltime >= '" . $this->fromTime . "'
			and Leads.originaltime <= '" . $this->toTime . "'
			and LEFT (ir.createdAt, 10) >= '" . $this->fromDate . "'
			and LEFT (ir.createdAt, 10) <= '" . $this->toDate . "'";
			if(!empty($this->affiliateId)) {
				$sql.= " and Leads.affiliateID = ".$this->affiliateId." ";
			}
			if(count($this->storeIds)) {
				$sql.= "and Leads.storeID in (".implode(",",$this->storeIds).") ";
			}

			$sql.=$this->selectedStrategy."
			group by campaign, ir.rejectcode
			order by campaign";

		return $this->slave->fetchAll($sql);
	}

	protected function getClientCriteriaRejects()
	{
		$sql = "select replace(Leads.campaign,' ','') campaign,
			count(DISTINCT Leads.id) total,
			cr.rejectCode,
			crc.name rejectName 
			from Leads
			join ClientRejects cr on cr.leadid = Leads.id
			join ClientRejectCodes crc on crc.id = cr.rejectcode
			".$this->strategy."
			where Leads.originaldate >= '" . $this->fromDate . "'
			and Leads.originaldate <= '" . $this->toDate . "'
			and Leads.originaltime >= '" . $this->fromTime . "'
			and Leads.originaltime <= '" . $this->toTime . "'
			and LEFT (cr.createdAt, 10) >= '" . $this->fromDate . "'
			and LEFT (cr.createdAt, 10) <= '" . $this->toDate . "'";

			if (!empty($this->affiliateId)) {
				$sql.= " and Leads.affiliateID = ".$this->affiliateId." ";
			}
			if (count($this->storeIds)) {
				$sql.= " and Leads.storeID in (".implode(",",$this->storeIds).") ";
			}

			$sql.=$this->selectedStrategy."
			group by campaign, cr.rejectcode
			order by campaign";

		return $this->slave->fetchAll($sql);
	}

	protected function getCampaignRejects()
	{
		$sql = "select replace(Leads.campaign,' ','') campaign,
			count(1) total,
			cr.rejectCode,
			crc.name rejectName
			from Leads
			join CampaignRejects cr on cr.leadid = Leads.id
			join CampaignRejectCodes crc on crc.id = cr.rejectcode
			".$this->strategy."
			where Leads.originaldate >= '" . $this->fromDate . "'
			and Leads.originaldate <= '" . $this->toDate . "'
			and Leads.originaltime >= '" . $this->fromTime . "'
			and Leads.originaltime <= '" . $this->toTime . "' ";
		if (!empty($this->affiliateId)) {
			$sql.= " and Leads.affiliateID = ".$this->affiliateId." ";
		}
		if (count($this->storeIds)) {
			$sql.= " and Leads.storeID in (".implode(",",$this->storeIds).") ";
		}

		$sql.=$this->selectedStrategy."
			group by campaign, cr.rejectcode
			order by campaign";

		return $this->slave->fetchAll($sql);
	}

	protected function getClientRejects()
	{
		// first get all Client postsetupIDs
		$sqlClients = "select postSetupID 
			from ClientPostSetups";
		$clients = $this->slave->fetchAll($sqlClients);

		// flatten array so we can stringify it for sql query
		$clientPostSetupIDs = array();
		foreach ($clients as $v) {
			$clientPostSetupIDs[] = $v['postSetupID'];
		}

		$join = "";
		$condition = "";
		if (!empty($this->affiliateId) || count($this->storeIds)) {
			$join = " INNER JOIN Leads l on l.id = pl.leadID ";
			if (!empty($this->affiliateId)) {
				$condition.= " and l.affiliateID = ".$this->affiliateId." ";
			}
			if (count($this->storeIds)) {
				$condition.= " and l.storeID in (".implode(",",$this->storeIds).") ";
			}
		}

		$strategy = "";
		$selectedStrategy = "";

		if ($this->selectedStrategyID > 0) {
			$strategy = " LEFT OUTER JOIN LeadStrategies ON LeadStrategies.leadID = pl.leadID
								LEFT OUTER JOIN Variates ON Variates.id = LeadStrategies.variateID";

			$selectedStrategyID = $this->selectedStrategyID;
			$selectedStrategy = "AND Variates.id = $selectedStrategyID";
		}
		if (!empty($clientPostSetupIDs)) {
			$sql = "select count(1) total,
			postSetupID,
			replace(pl.campaign,' ','') campaign
			from PostLogs pl
			$join
			".$strategy."
			where pl.postdate >= '" . $this->fromDate . "'
			and pl.postdate <= '" . $this->toDate . "'
			and pl.startTime >= '" . $this->fromTime . "'
			and pl.startTime <= '" . $this->toTime . "'
			and postsetupid IN (" . implode(',', $clientPostSetupIDs) . ")
			and poststatus='no'
			$condition
			".$selectedStrategy."
			group by campaign, postSetupID";
			return $this->slave->fetchAll($sql);
		} else {
			return array();
		}
	}

	public function getLeadAttempts()
	{
		$sql = "select count(1) total,
			replace(campaign,' ','') campaign 
			from Leads
			".$this->strategy."
			where originaldate >= '" . $this->fromDate . "' 
			and originaldate <= '" . $this->toDate . "'
			and originaltime >= '" . $this->fromTime . "'
			and originaltime <= '" . $this->toTime . "' ";
			if (!empty($this->affiliateId)) {
				$sql.= " and Leads.affiliateID = ".$this->affiliateId." ";
			}
			if (count($this->storeIds)) {
				$sql.= " and Leads.storeID in (".implode(",",$this->storeIds).") ";
			}
			$sql.=$this->selectedStrategy."
			group by campaign";

		return $this->slave->fetchAll($sql);
	}


	public function getLeadSold()
	{
		$sql = "select count(1) total,
			replace(campaign,' ','') campaign 
			from Leads
			".$this->strategy."
			where originaldate >= '" . $this->fromDate . "' 
			and originaldate <= '" . $this->toDate . "'
			and originaltime >= '" . $this->fromTime . "'
			and originaltime <= '" . $this->toTime . "'
			and leadsold = 1 ";
			if (!empty($this->affiliateId)) {
				$sql.= " and Leads.affiliateID = ".$this->affiliateId." ";
			}
			if (count($this->storeIds)) {
				$sql.= " and Leads.storeID in (".implode(",",$this->storeIds).") ";
			}
			$sql.= $this->selectedStrategy."
			group by campaign";

		return $this->slave->fetchAll($sql);
	}

	/**
	 * @param int $rejectCode VendorRejectCodes.id
	 * @return array
	**/
	protected function getVendorRejectsByRejectCode($rejectCode)
	{
		$join = "";
		$condition = "";
		if (!empty($this->affiliateId) || count($this->storeIds)) {
			$join = " INNER JOIN Leads l on l.id = pl.leadID ";
			if (!empty($this->affiliateId)) {
				$condition.= " and l.affiliateID = ".$this->affiliateId." ";
			}
			if (count($this->storeIds)) {
				$condition.= " and l.storeID in (".implode(",",$this->storeIds).") ";
			}
		}

		$sql = "SELECT
					count(1) total,
					replace(campaign,' ','') campaign
				FROM Leads
				LEFT JOIN
					VendorRejects vr ON Leads.id = vr.leadID
				".$this->strategy."
				WHERE
					LEFT(vr.createdAt, 10) >= '" . $this->fromDate . "' AND
					LEFT(vr.createdAt, 10) <= '" . $this->toDate . "' ";

				if (!empty($this->affiliateId)) {
				$sql.= " and Leads.affiliateID = ".$this->affiliateId." ";
				}
				if (count($this->storeIds)) {
					$sql.= " and Leads.storeID in (".implode(",",$this->storeIds).") ";
				}

				$sql.= " AND vr.rejectCode = " . $rejectCode;
				$sql.= " GROUP BY campaign";

		return $this->slave->fetchAll($sql);
	}

	/**
	 * @return array
	 */
	public function prepareClientRejectHeader()
	{
		$Client = new Clients();
		$clientData = $Client->getClientData();
		$this->sortByPriority($clientData, "priority", TRUE);

		$clientsHeaders = array();
		foreach ($clientData AS $v) {
			if ($v['active'] == "0") {
				continue;
			} else {
				$clientsHeaders[] = $v;
			}
		}
		return $clientsHeaders;
	}


	/**
	 * @param $vendorsHeaders
	 * @param $headerVal
	 * @return bool
	 */

	protected function isClientRejectHeader($vendorsHeaders, $headerVal)
	{
		foreach ($vendorsHeaders as $v) {
			if ($v['company'] == $headerVal) {
				return TRUE;
			}
		}
		return FALSE;
	}

	/**
	 * @param $clientsHeaders
	 * @param $headerVal
	 * @return bool|string
	 */
	protected function getClientRejectPostSetupID($clientsHeaders, $headerVal)
	{
		foreach ($clientsHeaders as $v) {
			if ($v['company'] == $headerVal) {
				return 'client_' . $v['postSetupID'];
			}
		}
		return FALSE;
	}


	/**
	 * used by Denial Report
	 *
	 * @param array $csvHeaders
	 * @param array $reportsFormatted
	 * @return string
	 */
	public function makeCsv($csvHeaders, $reportsFormatted)
	{
		$csvFile = '';
		foreach ($csvHeaders as $v) {
			$csvFile .= "$v,";
		}
		$csvFile .= "\r\n";
		foreach ($reportsFormatted as $rowVal) {
			foreach ($rowVal as $v) {
				$csvFile .= "$v,";
			}
			$csvFile .= "\r\n";
		}
		return $csvFile;
	}

	/**
	 * This method can be used for sorting array by key, also we can set sorting order here
	 * @param $array
	 * @param string $subkey
	 * @param bool $sort_ascending
	 */
	public function sortByPriority(&$array, $subkey = "id", $sort_ascending = FALSE)
	{

		if (count($array))
			$temp_array[key($array)] = array_shift($array);

		foreach ($array as $key => $val) {
			$offset = 0;
			$found = FALSE;
			foreach ($temp_array as $tmp_key => $tmp_val) {
				if (!$found and strtolower($val[$subkey]) > strtolower($tmp_val[$subkey])) {
					$temp_array = array_merge((array)array_slice($temp_array, 0, $offset),
						array($key => $val),
						array_slice($temp_array, $offset)
					);
					$found = TRUE;
				}
				$offset++;
			}
			if (!$found) $temp_array = array_merge($temp_array, array($key => $val));
		}

		if ($sort_ascending) $array = array_reverse($temp_array);

		else $array = $temp_array;
	}

	/**
	 * Method sorts array by affiliate name
	 * @param $array
	 * @return array
	 */
	function sortReportByAffiliateName($array)
	{
		usort($array, array('DenialReportAbstract','compareByAffiliateName'));
		return $array;
	}

	/**
	 * callback using for sorting by usort() in sortReportByAffiliateName()
	 * @param $a
	 * @param $b
	 * @return int
	 */
	function compareByAffiliateName($a, $b) {
		return strcmp($a["affiliate"], $b["affiliate"]);
	}

	/**
	 * Gets lead providers
	 */
	public function getLeadProviders($originalDateStart, $originalDateEnd, $originalTimeStart, $originalTimeEnd)
	{
		$masteraffData[''] = '';
		$Leads = new Leads();
		$Leads->initSettingsForSlaveDB();

		$leadProviders = $Leads->getAllLeadProviders($originalDateStart, $originalDateEnd, $originalTimeStart, $originalTimeEnd);
		foreach ($leadProviders as $masteraff) {
			$masteraffData[$masteraff['affiliateID']] = $masteraff['masteraff'];
		}
		return $masteraffData;
	}

	public function getVendorStrategyRulesetRejectBreakdownByCampaignID($campaignID)
	{
		$sql = "select count(1) total, 
			vp.vendorstrategyid,
			vs.classname,
			ps.title,
			vs.description  
			from VendorRejects vr 
			join Leads l on l.id = vr.leadID 
			join PostLogs pl on pl.leadid = vr.leadid and vr.postsetupid = pl.postsetupid 
			join PostSetups ps on ps.id = pl.postsetupid 
			join VendorPosts vp on vp.postlogid = pl.id 
			join VendorStrategies vs on vs.id = vp.vendorstrategyid 
			where vr.rejectcode= " . VendorRejectCode::VENDORSTRATEGY_RULE_FAILED . " 
			and date(vr.createdat) >= '" . $this->fromDate . "' 
			and date(vr.createdat) <= '" . $this->toDate . "' 
			and l.campaign = $campaignID
			group by vp.vendorstrategyid";

		return $this->slave->fetchAll($sql);
	}
}
