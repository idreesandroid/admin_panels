<?php

class DataTwentyFourSevenCredentials extends Zend_Db_Table
{
	protected $_name = 'DataTwentyFourSevenCredentials';

	const VENDOR_ID = 1010;

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}

	public function getDefault()
	{
		$row = $this->fetchRow("isDefault = 1");
		if ($row)
			$row = $row->toArray();

		return($row);
	}

	/**
	 * Updates or inserts a row
	 */
	public function upsert($vendorStrategyID, $insertData)
	{
		$existingRow = $this->findByID($vendorStrategyID);

		if($existingRow) {
			$this->update($insertData, $this->_db->quoteInto("id = ?", $existingRow['id']));
			return $existingRow['id'];
		}
		else {
			return $this->insert($insertData);
		}
	}

	public function findByID($vendorStrategyID) {
		$DataTwentyFourSevenCredentialsVendorStrategy = new DataTwentyFourSevenCredentialsVendorStrategy();
		$result = $DataTwentyFourSevenCredentialsVendorStrategy->findByVendorStrategyID($vendorStrategyID);
		if ($result['dataTwentyFourSevenCredentialID']) {
			$sql = $this->select()
				->where("id = " . $result['dataTwentyFourSevenCredentialID']);
			return $this->fetchRow($sql);
		}
	}
}

