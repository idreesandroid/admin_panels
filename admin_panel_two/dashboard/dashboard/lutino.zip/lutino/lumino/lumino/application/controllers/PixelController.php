<?php
class PixelController extends Zend_Controller_Action
{                   

  function showTransparentImage()
  {		
    	$pixel = implode('\n', file('public/images/pixel_trans.gif'));
    	header('Content-type: image/gif');
    	echo $pixel;
    	die();    	
  }

  function firstpageAction()
  {
    

  	global $db;
  	Zend_Loader::loadClass('Tracking');
    Zend_Loader::loadClass('TrackingIps');
    Zend_Loader::loadClass('Zend_Filter_StripTags');
		
	if(isset($_SERVER['HTTP_REFERER']))
	{
	    $pairs = split('\?', $_SERVER['HTTP_REFERER']);
	    
		if(isset($pairs[1])){
  		  $pairs = $pairs[1];    
  	  	  $pairs = split('\&', $pairs);
  	  	  
	  	  foreach($pairs as $item){
    		  $element = split('=', $item);
  		    $_GET[$element[0]] = $element[1];
		    }
		}
	}
	
	$siteid = $_GET['siteid'];
    
	/*
	aff in query string = Campaign
	aff5 in query string = Subid
	masteraff in query string = masteraff
	*/

	$_GET['aff'] = isset($_GET['aff']) ? $_GET['aff'] : 1;
    $rows = $db->fetchAll("select count(*) cnt from campaigns where campaign = ".$_GET['aff']);
    if($rows[0]['cnt'] == 0) $_GET['aff'] = 1;	
    
    $tracking = new Tracking();
    
    $where = array(	'`trackingdate` = ?' => date('Y-m-d'),
					'`campaign` = ?' => $_GET['aff'],
					'`subid` = ?' => isset($_GET['aff5']) ? $_GET['aff5'] : "",
					'`masteraff`=?' => isset($_GET['masteraff']) ? $_GET['masteraff'] : "");
					
    $rows = $tracking->fetchAll($where);
    
    $trackingIps = new TrackingIps();
    
    $ip = (getenv('HTTP_X_FORWARDED_FOR')) ? getenv('HTTP_X_FORWARDED_FOR') : getenv('REMOTE_ADDR');
    
    if(count($rows) == 0)  /// Means this is a unique hit so insert record into tracking and trackingips table
    {
    	$data = array
      (  
        'trackingdate' => date('Y-m-d'),
        'masteraff' => $_GET['masteraff'],
		'campaign' => isset($_GET['aff']) ? $_GET['aff'] : "",
		'subid' => urldecode(isset($_GET['aff5']) ? $_GET['aff5'] : ""),
		'rawhits' => 1,
		'uniquehits' => 1,
		'pixelfires' => 1,
		'productcode' => $_GET['pcode'],		
		'siteid' => $_GET['siteid']
      );
      
      $tracking->insert($data);
	  $id = $db->lastInsertId();
	  
	  $trackingipsdata = array(
	  'trackingid' => $id,
	  'ip' => $ip
	  );
	  
      $trackingIps->insert($trackingipsdata);
    }
    else
    {
    	$row = $rows->current();
      $data = array
      (
		'pixelfires' => $row->pixelfires +1
      );
      
      $where = $tracking->getAdapter()->quoteInto('trackingid = ?', $row->trackingid);
      
      $tracking->update($data, $where);
      
      $data = array('TrackingID = ?' => $row->trackingid, 
				    'ip = ?' => $ip);
      $rows = $trackingIps->fetchAll($data);
      
      if(count($rows) == 0)
      {
      	$trackingipsdata = array(
	  	'trackingid' => $row->trackingid,
	  	'ip' => $ip
	  	);
	  	$trackingIps->insert($trackingipsdata);
      }
    }
  	$this->showTransparentImage();
  } 
}