<?php

/**
 *
 */
class LeadsPurchasedCsv
{
	/**
	 * prepare Lead Purchased Report for building column headers in CSV file
	 */
	public function prepareColumnHeadersForCsv()
	{
		$csvHeaders = array();
		$csvHeaders[] = 'DateTime';
		$csvHeaders[] = 'LeadID';
		$csvHeaders[] = 'Store';
		$csvHeaders[] = 'Campaign';
		$csvHeaders[] = 'CampaignType';
		$csvHeaders[] = 'Subid';
		$csvHeaders[] = 'Affiliate';
		$csvHeaders[] = 'Email';
		$csvHeaders[] = 'State';
		$csvHeaders[] = 'Originated';
		$csvHeaders[] = 'Disposition';
		$csvHeaders[] = 'Buyer';
		$csvHeaders[] = 'Variate';
		$csvHeaders[] = 'Multivarite Strategy';
		$csvHeaders[] = 'Sold Time';
		$csvHeaders[] = 'Cost';
		$csvHeaders[] = 'Price';
		$csvHeaders[] = 'Total Time';

		return $csvHeaders;
	}

	/**
	 * prepare Lead Purchased Report for building CSV file
	 *
	 * @param array $data
	 * @return array
	 */
	public function prepareReportForCsv($data)
	{
		$orderArray = array();
		$orderArray[] = 'datetime';
		$orderArray[] = 'id';
		$orderArray[] = 'storeID';
		$orderArray[] = 'campaign';
		$orderArray[] = 'campaignType';
		$orderArray[] = 'subid';
		$orderArray[] = 'masteraff';
		$orderArray[] = 'email';
		$orderArray[] = 'state';
		$orderArray[] = 'originated';
		$orderArray[] = 'dispositioncode';
		$orderArray[] = 'postsetup';
		$orderArray[] = 'variate';
		$orderArray[] = 'multivariate';
		$orderArray[] = 'endtime';
		$orderArray[] = 'cost';
		$orderArray[] = 'price';
		$orderArray[] = 'totaltime';

		$reportFormatted = array();

		foreach ($data as $v) {
			$ordered = array();
			foreach ($orderArray as $key) {
				if (array_key_exists($key, $v)) {
					$ordered[$key] = $v[$key];
				}
			}
			$reportFormatted[] = $ordered;
		}

		return $reportFormatted;
	}

	/**
	 * Builds CSV file
	 * @param array $csvHeaders
	 * @param array $preparedReport
	 * @return string
	 */
	public function makeCsv($csvHeaders, $preparedReport)
	{
		$output= fopen('php://output', 'w');

		fputcsv($output, $csvHeaders);

		foreach ($preparedReport as $fields)
		{
			fputcsv($output, $fields);
		}

		$csvFile = stream_get_contents($output);
		fclose($output);

		return $csvFile;
	}
}