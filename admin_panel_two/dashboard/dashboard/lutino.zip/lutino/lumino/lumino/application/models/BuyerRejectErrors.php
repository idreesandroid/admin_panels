<?php

class BuyerRejectErrors extends Zend_Db_Table
{
    protected $_name = 'BuyerRejectErrors';

    function getErrors($fromDate,$toDate)
    {
        $sql = "select br.parsedErrorMessage,pl.leadID,pl.postDate,pl.postSetupID,ps.title,l.email,pl.id as logid
                from BuyerRejectErrors br
                join PostLogs pl on br.postLogID = pl.id
                join PostSetups ps on pl.postSetupID = ps.id
                join Leads l on l.id = pl.leadID
                where pl.postDate >= ? and pl.postDate <= ?";

        $stmt = $this->_db->query($sql,array($fromDate,$toDate));
        $results = $stmt->fetchAll();

        return $results;
    }

    function getTodaysErrorsCount()
    {
        $sql = "select count(*) as cnt
                from BuyerRejectErrors br
                join PostLogs pl on br.postLogID = pl.id
                where pl.postDate = curdate()";

        $results = $this->_db->fetchRow($sql);

        return $results;
    }

	public function getClientNameErrorQuery() {

		$sql = $this->_db->select()
			->from("BuyerRejectErrors", array())
			->joinInner("PostLogs", "PostLogs.id = BuyerRejectErrors.postLogID", array())
			->joinInner("ClientPostSetups", "PostLogs.postSetupID = ClientPostSetups.postSetupID", array())
			->joinInner("Clients", "ClientPostSetups.clientID = Clients.id", array("vendorName"=>"company"))
			->where('PostLogs.leadID = Leads.id')
			->where('PostLogs.productCode = "cash"')
			->where('PostLogs.postStatus = "no"')
			->limit(1);

		return $sql;
	}

	public function getClientErrorReasonQuery() {

		$sql = $this->_db->select()
			->from("BuyerRejectErrors", array("denyDescription"=>"parsedErrorMessage"))
			->joinInner("PostLogs", "PostLogs.id = BuyerRejectErrors.postLogID", array())
			->where('PostLogs.leadID = Leads.id')
			->where('PostLogs.productCode = "cash"')
			->where('PostLogs.postStatus = "no"')
			->limit(1);

		return $sql;
	}
}

?>
