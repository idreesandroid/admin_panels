<?php

class VariateRuleset extends Zend_Db_Table
{
	protected $_name = 'VariateRulesets';
	private $ruleCounter;

	public function init()
	{
		$this->db = Zend_Registry::get('db');
		$this->ruleCounter = 0;
	}

	public function generateRulesetsDataByVariateID($variateID)
	{
		$sql = $this->select()
			->where("variateID = " . $variateID)
			->order('priority asc');
		$rulesets = $this->fetchAll($sql)->toArray();

		$VariateRule = new VariateRule();

		$result = array();
		$iRowCounter = 0;

		$firstRuleset = array();
		$prevRuleset = array();
		foreach ($rulesets as $currentRuleset) {
			$iRowCounter++;

			if ($iRowCounter == 1 && sizeof($rulesets) == 1) {
				$result[] = array(
					'type' => 'ruleset',
					'id' => 'set' . $currentRuleset['id'],
					'name' => $currentRuleset['name'],
					'priority' => $currentRuleset['priority'],
					'rules' => $VariateRule->generateRulesDataByVariateRulesetID($currentRuleset['id'])
				);
			}

			if (sizeof($rulesets) > 1) {
				if ($iRowCounter == 1) {
					$firstRuleset = $currentRuleset;
					continue;
				}
				if ($iRowCounter == 2) {
					$result[] = array(
						'type' => 'ruleset',
						'id' => 'set' . $firstRuleset['id'],
						'name' => $firstRuleset['name'],
						'priority' => $firstRuleset['priority'],
						'rules' => $VariateRule->generateRulesDataByVariateRulesetID($firstRuleset['id'])
					);
					$result[] = array(
						'type' => 'operator',
						'id' => 'set' . $firstRuleset['id'] . '-set' . $currentRuleset['id'],
						'operatorID' => $currentRuleset['logicalOperatorID'],
						'operatorName' => $this->getLogicalOperatorNameByID($currentRuleset['logicalOperatorID'])
					);
					$result[] = array(
						'type' => 'ruleset',
						'id' => 'set' . $currentRuleset['id'],
						'name' => $currentRuleset['name'],
						'priority' => $currentRuleset['priority'],
						'rules' => $VariateRule->generateRulesDataByVariateRulesetID($currentRuleset['id'])
					);
				} else {
					$result[] = array(
						'type' => 'operator',
						'id' => 'set' . $prevRuleset['id'] . '-set' . $currentRuleset['id'],
						'operatorID' => $currentRuleset['logicalOperatorID'],
						'operatorName' => $this->getLogicalOperatorNameByID($currentRuleset['logicalOperatorID'])
					);
					$result[] = array(
						'type' => 'ruleset',
						'id' => 'set' . $currentRuleset['id'],
						'name' => $currentRuleset['name'],
						'priority' => $currentRuleset['priority'],
						'rules' => $VariateRule->generateRulesDataByVariateRulesetID($currentRuleset['id'])
					);
				}
			}

			$prevRuleset = $currentRuleset;
		}
		return $result;
	}

	public function getLogicalOperatorNameByID($operatorID)
	{
		if (!$operatorID) {
			return null;
		}
		$sql = "SELECT
					*
				FROM
					LogicalOperators lo
				WHERE
					lo.id = $operatorID";

		$operator = $this->db->fetchRow($sql);
		return $operator['name'];
	}

	public function findByID($id) {
		$sql = $this->select()
			->where("id = " . $id);
		return $this->fetchRow($sql);
	}

	public function deleteByVariateID($variateID)
	{
		if ($this->hasRulesetsWithVariateD($variateID)) {
			$this->delete('variateID='. $variateID);
		}
	}

	public function deleteByID($rulesetID)
	{
		$existingRow = $this->findByID($rulesetID);
		if ($existingRow) {
			$this->delete('id='. $rulesetID);
		}
	}

	/**
	 * Updates or inserts a row
	 */
	public function upsert($id, $variateID, $insertData)
	{
		$sql = $this->select()
		->where("id = ?",$id)
		->where("variateID = ?",$variateID);

		$existingRow = $this->fetchRow($sql);

		if($existingRow) {
			$this->update($insertData, $this->_db->quoteInto("id = ?", $existingRow['id']));
			return $id;
		}
		else {
		    return $this->insert($insertData);
		}
	}



	public function hasRulesetsWithVariateD($variateID) {
		$sql = $this->select()
			->from($this->_name, array("count(*) AS amount"))
			->where($this->_db->quoteInto($this->_name . ".variateID = ?", $variateID));

		$result = $this->_db->fetchRow($sql);
		if ($result['amount'] < 1) {
			return FALSE;
		}
		return TRUE;
	}

	public function getAllByVariateID($variateID) {
		$sql = $this->select()
			->where("variateID = " . $variateID)
			->order('priority asc');
		return $this->fetchAll($sql);
	}

	public function deleteRemovedRulesets($variateID, $rulesetIds, $rulesetOperators) {
		$VariateRule = new VariateRule();
		$rulesets = $this->getAllByVariateID($variateID);
		$firstRowDeleted = false;
		if ($rulesets) {
			$rulesets = $rulesets->toArray();
			for ($i = 0; $i < count($rulesets); $i++) {
				if (!in_array($rulesets[$i]['id'], $rulesetIds)) {
					if ($i==0) {
						$firstRowDeleted = true;
					}
					$VariateRule->deleteByRulesetID($rulesets[$i]['id']);
					$this->deleteByID($rulesets[$i]['id']);

					if (isset($rulesets[$i + 1])) {
						$nextID = $rulesets[$i + 1]['id'];
						if (isset($rulesets[$i - 1])) {
							$prevID = $rulesets[$i - 1]['id'];
							$value = $this->findOperatorValueByRulesetID($rulesetOperators, $prevID);
							$updateData = array('logicalOperatorID' => $value);
							$this->update($updateData, $this->_db->quoteInto("id = ?", $nextID));
						}
					}

					if ($firstRowDeleted && isset($rulesets[$i + 1])) {
						$updateData = array('logicalOperatorID' => null,
							'referrerVariateRulesetID' => null);
						$this->update($updateData, $this->_db->quoteInto("id = ?", $rulesets[$i + 1]['id']));
					}
				}
			}
		}
	}

	public function findOperatorValueByRulesetID($rulesetOperators, $id) {
		foreach ($rulesetOperators as $operator) {
			$expload = explode('-',$operator['id']);
			$rulesetID = $expload['0'];
			if ('set'.$id == $rulesetID) {
				return $operator['value'];
			}
		}
		return null;
	}


	/**
	 * @param $rulesets
	 * @param $variateId
	 * @param $rulesetOperators
	 * @param $ruleIDs
	 * @param $ruleData
	 * @param $ruleOperators
	 */
	public function buildRuleset($rulesets, $variateId, $rulesetOperators, $ruleIDs, $ruleData, $ruleOperators)
	{
		$upsertedRulesetIDs = array();

		$VariateRule = new VariateRule();
		if (!isset($rulesets)) {
			$VariateRule->deleteAllRulesByVariateID($variateId);
			$this->deleteByVariateID($variateId);
		} else {
			$prevRulesetID = 0;
			foreach ($rulesets AS $ruleset) {
				$rulesetID = $ruleset['id'];
				$name = $ruleset['name'];
				$priority = $ruleset['priority'];
				$extractedID = substr($rulesetID, strlen('set'));
				if ($priority == 1) {
					$rulesetDataForSave = array(
						'variateID' => $variateId,
						'name' => $name,
						'priority' => $priority);
				} else {
					$rulesetDataForSave = array(
						'variateID' => $variateId,
						'name' => $name,
						'priority' => $priority,
						'referrerVariateRulesetID' => $prevRulesetID,
						'logicalOperatorID' => $this->getRulesetOperatorValueByRulesetID($rulesetOperators, $rulesetID));
				}

				$rulesetIDFromDB = $this->upsert($extractedID,$variateId,$rulesetDataForSave);
				if ($ruleIDs && $ruleData) {
					$this->saveRuleByRulesetID($ruleIDs, $ruleData, $ruleOperators, $rulesetID, $rulesetIDFromDB);
				} else {
					$VariateRule->deleteAllRulesByVariateID($variateId);
				}
				$prevRulesetID = $rulesetIDFromDB;
				$upsertedRulesetIDs[] = $rulesetIDFromDB;
			}
		}

		$this->deleteRemovedRulesets($variateId, $upsertedRulesetIDs, $rulesetOperators);
	}

	function saveRuleByRulesetID($ruleIDs, $ruleData, $ruleOperators, $rulesetID, $createdByDBRulesetID) {
		$VariateRule = new VariateRule();
		$prevRuleID = null;
		$upsertedRuleIDs = array();
		foreach ($ruleIDs AS $rule) {
			$id = $rule['id'];
			$priority = $rule['priority'];

			$exploded = explode('-', $id);
			$extratectedRulesetID = $exploded[0];
			$extratectedRuleID = $exploded[1];

			$extractedID = substr($extratectedRuleID, strlen('rule'));
			if ($rulesetID == $extratectedRulesetID) {
				if ($priority == 1) {
					$ruleDataForSave = array(
						'variateRulesetID' => $createdByDBRulesetID,
						'comparisonOperatorID' => $this->getParamValueByParamName($ruleData, 'operators', $extratectedRulesetID, $extratectedRuleID),
						'vendorResponseParameterID' => $this->getParamValueByParamName($ruleData, 'vendorparams', $extratectedRulesetID, $extratectedRuleID),
						'value' => $this->getParamValueByParamName($ruleData, 'paramvalue', $extratectedRulesetID, $extratectedRuleID),
						'priority' => $priority);
				} else {
					$ruleDataForSave = array(
						'variateRulesetID' => $createdByDBRulesetID,
						'comparisonOperatorID' => $this->getParamValueByParamName($ruleData, 'operators', $extratectedRulesetID, $extratectedRuleID),
						'vendorResponseParameterID' => $this->getParamValueByParamName($ruleData, 'vendorparams', $extratectedRulesetID, $extratectedRuleID),
						'value' => $this->getParamValueByParamName($ruleData, 'paramvalue', $extratectedRulesetID, $extratectedRuleID),
						'priority' => $priority,
						'referrerVariateRuleID'=>$prevRuleID,
						'logicalOperatorID' => $this->getRuleOperatorValueByRulesetIDAndRuleID($ruleOperators, $extratectedRulesetID, $extratectedRuleID, $priority));
				}

				$ruleIDFromDB = $ruleIDFromDB = $VariateRule->upsert($extractedID,$rulesetID,$ruleDataForSave);
				$prevRuleID = $ruleIDFromDB;
				$upsertedRuleIDs[] = $ruleIDFromDB;
			}
		}
		$VariateRule->deleteRemovedRules($createdByDBRulesetID, $upsertedRuleIDs, $ruleOperators);
	}

	function getParamValueByParamName($ruleData, $paramName, $rulesetID, $ruleID) {
		foreach ($ruleData AS $data) {
			$id = $data['id'];
			$value = $data['value'];

			$result = explode('-', $id);
			$currentRulesetID = $result[0];
			$currentRuleID = $result[1];
			$currentRuleParamName = $result[2];

			if (($currentRulesetID == $rulesetID) AND
				($currentRuleID == $ruleID) AND
				($currentRuleParamName == $paramName)) {
				return $value;
			}
		}
		return null;
	}


	function getRuleOperatorValueByRulesetIDAndRuleID($ruleOperators, $rulesetID, $ruleID,$priority) {

		if($priority == 1) {
		    return null;
		}
		else {
		    if (isset($ruleOperators[$this->ruleCounter])) {
		        $operator = $ruleOperators[$this->ruleCounter]['value'];
		        $this->ruleCounter++;
		        return $operator;
		    }
		}
		return null;
	}


	function getRulesetOperatorValueByRulesetID($rulesetOperators, $rulesetID) {
		foreach ($rulesetOperators AS $rulesetOperator) {
			$rulesetOperatorID = $rulesetOperator['id'];
			$value = $rulesetOperator['value'];

			$result = explode('-', $rulesetOperatorID);
			$rulsetIDOne = $result[0];
			$rulsetIDTwo = $result[1];

			if ($rulsetIDTwo == $rulesetID) {
				return $value;
			}
		}
		return null;
	}
}
