<?php

class LeadPurchasedReportsController extends Zend_Controller_Action
{
    const UNDERWRITEIO_API_ACTION = "api/underwriteio";
    const CLARITY_API_ACTION = "api/clarityapicall";

    private $baseurl;

	function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if (!$AdminNameSpace->userid) {
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();
	}

	public function indexAction()
	{
	    $config = Zend_Registry::get('config');

	    $customerType = ($this->_request->customertype) ? $this->_request->customertype : "new";
		$this->view->fromDate = (isset($this->_request->fromDate)) ? $this->_request->fromDate : date('m/d/Y');
		$this->view->toDate = (isset($this->_request->toDate)) ? $this->_request->toDate : date('m/d/Y');
		$this->view->timeStart = "00:00:00";
		$this->view->timeEnd = "23:59:59";
		$this->view->affiliateID = ($this->_request->affiliateID) ? $this->_request->affiliateID : "";
		$this->view->affiliateName = ($this->_request->affiliateName) ? $this->_request->affiliateName : "";
		$this->view->campaignID = ($this->_request->campaignID) ? $this->_request->campaignID : "";
		$this->view->customerType = $customerType;
		$this->view->orig = ($this->_request->orig) ? $this->_request->orig : 0;
		$leadDispositionCodes = new LeadDispositionCodes();
		$this->view->dispositionCodes = $leadDispositionCodes->fetchAll();

		if(isset($config->apiBaseUrl)) {
		    $this->view->underwriteioenabled = true;
		}
		else {
		    $this->view->underwriteioenabled = false;
		}

		if(isset($config->apiBaseUrl) && $config->isClarityCallEnabled) {
		    $this->view->claritycallenabled = true;
		}
		else {
		    $this->view->claritycallenabled = false;
		}
	}

	public function getdataAction()
	{
		$this->_helper->viewRenderer->setNoRender();

		if (!$this->_request->isCsv) {
			$offset = ($this->_request->offset) ? $this->_request->offset : 0;
			$limit  = ($this->_request->limit) ? $this->_request->limit : 100;
			$arrayLimit = $limit;
		}


		$sortBy = ($this->_request->sort) ? $this->_request->sort : "email";
		$sortOrder = ($this->_request->order) ? $this->_request->order : "ASC";
		$customerType = ($this->_request->customertype) ? $this->_request->customertype : 'all';
		$originated = ($this->_request->originated) ? $this->_request->originated : 'all';
		$searchString = ($this->_request->search) ? $this->_request->search : '';

		$fromDate = ($this->_request->fromDate) ?
			date('Y-m-d', strtotime($this->_request->fromDate)) : date('Y-m-d');
		$toDate = ($this->_request->toDate) ?
			date('Y-m-d', strtotime($this->_request->toDate)) : date('Y-m-d');

		$fromTime = ($this->_request->fromTime) ?
			date('Y-m-d', strtotime($this->_request->fromTime)) : "00:00:00";

		$toTime = ($this->_request->toTime) ?
			date('Y-m-d', strtotime($this->_request->toTime)) : "23:59:59";

		$DashBoardFaceory = new LeadsPurchasedReportFactory();
		$LeadsPurchased = $DashBoardFaceory->create();

		$affiliateID = ($this->_request->affiliateID && $this->_request->affiliateID != "null") ? $this->_request->affiliateID : "";
		$campaignID = ($this->_request->campaignID && $this->_request->campaignID != "null") ? $this->_request->campaignID : "";
		$affiliateID = $affiliateID ? "'" . implode("','", explode(",", $affiliateID)) . "'" : "";
		$campaignID = $campaignID ? "'" . implode("','", explode(",", $campaignID)) . "'" : "";

		$affiliateName = ($this->_request->affiliateName) ? $this->_request->affiliateName : "";

		if (!empty($searchString)) {
		    $limit = "";
		}

		$leadsCount = 	$LeadsPurchased->getTotalLeadsPurchased($customerType,$originated,$fromDate,$toDate,$fromTime,$toTime,$campaignID,$affiliateID, $affiliateName);
		$leadsData = $LeadsPurchased->getLeadsPurchased($customerType,$originated,$fromDate,$toDate,$fromTime,$toTime,$sortBy,$sortOrder,$offset,$limit,$campaignID,$affiliateID, $affiliateName);
		$leadsData = $LeadsPurchased->appendPostLeadAcquisitionData($leadsData);
		$leadsData = $LeadsPurchased->appendClarityPositiveResponseData($leadsData);

		$data = array('total' => $leadsCount['total']);
		$data['rows'] = array();

		foreach($leadsData as $leadData) {

			$totalTime = "";
			if (!empty($leadData['endTime'])) {

				$endTime = new DateTime($leadData['endTime']);
				$originalTime = new DateTime($leadData['originaltime']);
				$interval = $endTime->diff($originalTime);
				$totalTime = $interval->format('%H:%I:%S');
			}

			$tuple = array();

			// parse underwrite.io post response and extract status and score
			if (!empty($leadData['underwriteioresponse'])) {

			    libxml_use_internal_errors(true);
			    $parsedResponse = simplexml_load_string($leadData['underwriteioresponse']);
			    if(!$parsedResponse) {
			        $tuple['underwriteiocallstatus'] = $leadData['underwriteioresponse'];
			        $tuple['underwriteiocallscore'] = -1;
			    }
			    else {
			        $decision = (string)$parsedResponse->Decision;
			        if($decision == "Accept") {
			            $tuple['underwriteiocallstatus'] = "Accepted";
			            $tuple['underwriteiocallscore'] = (string)$parsedResponse->Score;
			        }
			        else {
			            $tuple['underwriteiocallstatus'] = "Rejected";
			            $tuple['underwriteiocallscore'] = -1;
			        }
			    }
			}

			// parse clarity post response and extract status
			if (!empty($leadData['claritycallresponse'])) {
				libxml_use_internal_errors(true);
				// let's remove all special characters '\n','\r\n' and spaces
				$XmlResponse = simplexml_load_string(trim(preg_replace('/\s\s+/', '', $leadData['claritycallresponse'])));

				if (!$XmlResponse) {
					$tuple['claritycallstatus'] = "Rejected";
				} else {
					$action = (string)$XmlResponse->action;
					if (isset($action) && $action == "Approve") {
						$tuple['claritycallstatus'] = "Accepted";
					} else {
						$tuple['claritycallstatus'] = "Rejected";
					}
				}
			}

			$tuple['id'] = $leadData['id'];
			$tuple['hasClarityPositiveResponse'] = $leadData['hasClarityPositiveResponse'];
			$tuple['underwriteiocall'] = $leadData['underwriteiocall'];
			$tuple['hasUnderwriteioCall'] = $leadData['hasUnderwriteioCall'];
			$tuple['hasClarityCall'] = $leadData['hasClarityCall'];
			$tuple['showClarityButton'] = $leadData['showClarityButton'];
			$tuple['showUnderwriteIOButton'] = $leadData['showUnderwriteIOButton'];
			$tuple['datetime'] = $leadData['originaldate']." ".$leadData['originaltime'];
			$tuple['storeID'] = $leadData['storeID'];
			$tuple['campaign'] = $leadData['campaign'];
			$tuple['masteraff'] = $leadData['masteraff'];
			$tuple['email'] = $leadData['email'];
			$tuple['endtime'] = $leadData['endTime'];
			$tuple['postsetup'] = $leadData['postSetupTitle']."(".$leadData['postsetupid'].")";
			$tuple['cost'] = $leadData['cost'];
			$tuple['price'] = $leadData['price'];
			$tuple['totaltime'] = $totalTime;
			$tuple['dispositioncode'] = $leadData['code'];
			$tuple['originated'] = $leadData['originated'];
			$tuple['variate'] = $leadData['leadvariate'];
			$tuple['multivariate'] = $leadData['leadmultivariate'];
			$tuple['state'] = $leadData['state'];
			$tuple['subid'] = $leadData['subid'];
			$tuple['campaignType'] = $leadData['campaignType'];
 			$data['rows'][] = $tuple;
		}

		if ($this->_request->isCsv && $this->_request->isCsv == 'true') {
			header("Content-type: text/csv");
			header("Content-Disposition: attachment; filename=lead_purchased_report_{$fromDate}_{$toDate}_{$this->_request->customertype}_customers.csv");
			header("Pragma: no-cache");
			header("Expires: 0");

			$this->_helper->viewRenderer->setNoRender();

			$LeadsPurchasedCsv = new LeadsPurchasedCsv();
			$csvHeaders = $LeadsPurchasedCsv->prepareColumnHeadersForCsv();
			$preparedReport = $LeadsPurchasedCsv->prepareReportForCsv($data['rows']);

			$csvFile = $LeadsPurchasedCsv->makeCsv($csvHeaders, $preparedReport);

			echo $csvFile;
			exit();
		}

		if (!empty($searchString)) {
    		// if they used search textbox, filter out matches
    		$finalData = array();
    		$finalData['rows'] = array();

    		foreach ($data as $outerK => $outerV) {
    			if ($outerK == 'total') {
    				continue;
    			}

    			if ($outerK == 'rows') {
    				foreach ($outerV as $k => $v) {
    					if (strpos(strtolower($v['storeID']), strtolower($searchString)) !== FALSE) {
    						$finalData['rows'][] = $data['rows'][$k];
    						continue;
    					}

    					if (strpos(strtolower($v['masteraff']), strtolower($searchString)) !== FALSE) {
    						$finalData['rows'][] = $data['rows'][$k];
    						continue;
    					}
    					if (strpos(strtolower($v['email']), strtolower($searchString)) !== FALSE) {
    						$finalData['rows'][] = $data['rows'][$k];
    						continue;
    					}
    					if (strpos(strtolower($v['postsetup']), strtolower($searchString)) !== FALSE) {
    						$finalData['rows'][] = $data['rows'][$k];
    						continue;
    					}
    				}
    			}
    		}
    		// search match total
    		$finalData['total'] = (string)count($finalData['rows']);
    		$finalData['rows'] = array_slice($finalData['rows'], $offset,$arrayLimit);
    		echo json_encode($finalData);
		}
		else {
		    echo json_encode($data);
		}
	}

	public function updateLeadDispositionAction() {

	    $this->_helper->viewRenderer->setNoRender();

	    $email = $this->_request->getPost('email');
	    $dispositionCode = $this->_request->getPost('code');

	    $leadDispositionCodes = new LeadDispositionCodes();

	    $codeID = $leadDispositionCodes->getIDByCode($dispositionCode);
	    // Check if valid code is posted?
	    if ($codeID != NULL) {
    		$LECustomerDisposition = new LECustomerDisposition();
    		$LECustomerDisposition->insert(array('email' => $email, 'dispositionCodeID' => $codeID));
    		echo '{"status":"ok"}';
	    }
	    else {
	        echo '{"status":"error"}';
	    }
	}

	public function underwriteioAction() {

	    $this->_helper->viewRenderer->setNoRender();

	    $leadID = $this->_request->getPost('leadID');

	    $config = Zend_Registry::get('config');
	    $apiUrl = $config->apiBaseUrl . self::UNDERWRITEIO_API_ACTION."?leadID=".$leadID;
	    $curlConnection = curl_init();
	    $response = CurlUtility::curlGet($curlConnection, $apiUrl);

	    echo $response;
	}

	/**
	 * Post Lead Acquisition Decision for Clarity as a vendor.
	 */
	public function claritycallAction() {

		$this->_helper->viewRenderer->setNoRender();

		$leadID = $this->_request->getPost('leadID');

		$config = Zend_Registry::get('config');
		$apiUrl = $config->apiBaseUrl . self::CLARITY_API_ACTION."?leadID=".$leadID;
		$curlConnection = curl_init();
		$response = CurlUtility::curlGet($curlConnection, $apiUrl);

		echo $response;
	}
}
