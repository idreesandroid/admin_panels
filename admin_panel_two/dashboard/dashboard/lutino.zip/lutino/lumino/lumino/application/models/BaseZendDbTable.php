<?php
/**
 * this class contains validation methods inspired by Rails ActiveRecord
 */
class BaseZendDbTable extends Zend_Db_Table_Abstract
{
	protected $errors = array();

	/**
	 * return false and add to errors array
	 */
	protected function validatesPresenceOf(array $data)
	{
		foreach ($data as $k => $v) {
			if (strlen($v) < 1) {
				$this->errors[$k] = $v;
			}
		}
	}

	/**
	 * return false and add to errors array
	 */
	protected function validatesNumericalityOf(array $data)
	{
		foreach ($data as $k => $v) {
			if (!is_numeric($v)) {
				$this->errors[$k] = $v;
			}
		}

	}

	public function displayErrors()
	{
		return $this->errors;
	}
}
