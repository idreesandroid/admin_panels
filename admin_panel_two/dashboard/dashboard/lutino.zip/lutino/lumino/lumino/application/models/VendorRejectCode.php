<?php

class VendorRejectCode extends Zend_Db_Table
{
	const CUST_DENIED_IN_THE_PAST = 1000;
	const API_TIMEOUT = 1001;
	const VENDORSTRATEGY_RULE_FAILED = 1002;

	protected $_name = 'VendorRejectCodes';
}
