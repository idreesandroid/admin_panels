<?php
/**
 * this class determines if any campaigns have hit their leadsold cap for the month.
 * If so, send an email alert
 */
class CampaignsLeadSoldCapPerMonthAlert extends CampaignsAlertAbstract
{
	public function __construct()
	{
		parent::__construct();

		$this->today = date('Y-m-d');
	}

	// custom setting the date for testing purposes
	public function setToday($date)
	{
		$this->today = $date;
	}

	/**
	 * this is main interface to this class.
	 * it looks at leadsold grouped by campaign and sends an email alert
	 *
	 * @return array
	 */
	public function execute()
	{
		if ($totals = $this->getTotals()) {
			if (!$this->testMode) {
				$headers = 'From: tech@mediaenvy.com' . "\r\n" .
					    'Reply-To: tech@mediaenvy.com' . "\r\n" .
						    'X-Mailer: PHP/' . phpversion();
				$subj = 'Campaign Monthly LeadSold Cap Alert';
				$body  = "=== These Campaigns have hit their Monthly LeadSold Cap ===" . "\r\n\r\n";
				foreach ($totals as $total) {
					$body .= 'campaign ' . $total['campaign'] . ", total leadsold this month:" . 
						$total['total'] . ", monthly cap setting:" . 
						$total['maxLeadsSoldPerMonth'] . "\r\n";
				}
				mail('Marketing@mediaenvy.com, tech@mediaenvy.com', $subj, $body, $headers);
			}
		}
		return $totals;
	}
	
	/**
	 * we only want totals for THIS month
	 * @return array
	 */
	public function getTotals()
	{
		$sql = "select IFNULL(l.campaign, 'other') campaign, 
			count(1) total, 
			c.maxLeadsSoldPerMonth 
			from Leads l 
			join Campaigns c on c.id = l.campaign 
			where YEAR(l.originaldate) = YEAR('" . $this->today . "') 
			and MONTH(l.originaldate) = MONTH('" . $this->today . "') 
			and l.leadsold = 1 
			group by l.campaign 
			having total >= c.maxLeadsSoldPerMonth";

		return $this->db->fetchAll($sql);
	}
}
