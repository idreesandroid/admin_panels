<?php

class CampaignsClientPostSetup extends Zend_Db_Table 
{
	protected $_name = 'CampaignsClientPostSetups';
	private $db_slave;

	/**
	 * @param integer $campaignID
	 * @param integer $postSetupID
	 * @return integer or NULL
	 */
	public function getStoreID($campaignID, $postSetupID)
	{
		$result = $this->fetchRow('campaignID = ' . $campaignID . ' 
			AND postSetupID = ' . $postSetupID);

		if ($result) {
			return $result['storeID'];
		}
		return NULL;
	}

	/**
	 * default is that NO ONE can skip vendor verification
	 *
	 * @param integer $campaignID
	 * @return boolean
	 */
	public function canSkipVendorVerification($campaignID)
	{
		if (!$result = $this->fetchRow('campaignID = ' . $campaignID)) {
			return FALSE;
		}

		if ($result['skipVendorVerification'] == 1) {
			return TRUE;
		}
		return FALSE;
	}
	
	/* Configure Slave DB to be used to fetch data
	 * 
	 */
	public function initSettingsForSlaveDB () {
        
		$config = Zend_Registry::get("config");
		$this->db_slave = Zend_Db::factory($config->resources->multidb->slave->adapter, $config->resources->multidb->slave->toArray());
	}
	
	/*
	 * get campaign ids which are mapped to the PROVIDED postsetups and
	 * campaign ids which are not mapped at all.
	 * NOTE: if a campaign is mapped to a postsetup NOT provided in param,
	 * 	it will not be in return array.
	 *
	 * @param array $setupids
	 * 
	 * @return campaign ids array
	 */
	public function  getPostSetupCampaigns($setupids) {
		
		$campaignIds = array();

		// Select campaign ids which are mapped to given postsetups
		if(count($setupids)) {
			$sql = "SELECT campaignID from ".$this->_name." WHERE postSetupID in (".implode(",",$setupids).")"; 
			$result = $this->db_slave->fetchAll($sql);
			foreach($result as $rowData) {
				$campaignIds[] = $rowData['campaignID'];
			}
		}

		// select campaigns ids which are not mapped to any postsetup at all
		$sql = "SELECT id from Campaigns WHERE id not in
			(SELECT campaignID from {$this->_name}) AND active=1";
			
		$result = $this->db_slave->fetchAll($sql);
		foreach($result as $rowData) {
			$campaignIds[] = $rowData['id'];
		}

		return $campaignIds;	
	}
	
	public function filterByCampaignId($campaign_id) {
		
		$sql = $this->select()
		->from($this->_name)
		->where('campaignID = ?',$campaign_id)
		->order("id");
		$result = $this->fetchAll($sql);
		return $result;
	}
	
}
