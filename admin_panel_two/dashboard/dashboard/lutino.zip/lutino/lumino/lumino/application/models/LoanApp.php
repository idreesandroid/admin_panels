<?php

/**
 * LoanApp Model
 *
 * model for TRAN Loan_App table
 *
 */
class LoanApp extends TranAbstract
{

	protected $_name = 'Loan_App';

	public function init()
	{

		$this->fileName = "Loan_App";
		// db columns that are dates, used to format the date from scrape
		$this->dateFields = array(6, 7, 19, 21, 29, 31);
		// scrape file type
		$this->cboFileType = "L";

		$this->fieldNames = array("Appl_No",
				"Cust_ID",
				"Cust_SSN",
				"Merch_Store_ID",
				"User_ID",
				"Req_Loan_Amt",
				"Req_Due_Date",
				"Loan_Eff_Date",
				"Cr_Bureau_Score",
				"Loan_Type",
				"Incomplete_App",
				"APR",
				"Fin_Charge",
				"Fee_Charge",
				"Appl_Status",
				"Loan_Status",
				"IsOriginated",
				"PrintedCheckNo",
				"Cust_Check_Amt",
				"Date_Created",
				"MerchantRefID",
				"ApplicationDate",
				"ActionID",
				"PDLoan_Rcvd",
				"Mkt_Code",
				"MarketingCodeDesc",
				"Cur_Ren_No",
				"MASID",
				"QuickID",
				"ESig_Date",
				"ESignature",
				"Last_Modified"
					);

		$this->Master = new Master();
		$this->CustFile = new CustFile();

		$this->Logger = new DataLogger('ScrapeLoanApp', 'daily');
	}

	/**
	 * Updates or inserts a row
	 */
	public function upsert($insertData)
	{

		$existingRow = $this->find($insertData['Appl_No'], $insertData['Cust_ID']);

		if(count($existingRow) > 0) {
			$this->update($insertData, $this->_db->quoteInto("Appl_No = ?", $insertData['Appl_No']) . " AND " . $this->_db->quoteInto("Cust_ID = ?", $insertData['Cust_ID']));
		}
		else {
			$this->insert($insertData);
		}

	}

	/** 
	 * Builds the insert array from the table field names and an array of values
	 *
	 */
	public function buildInsertArray($fieldData)
	{

		$insertData = array();

		foreach($this->fieldNames as $key =>$name) {
			$insertData[$name] = trim($fieldData[$key]);
		}

		$this->Logger->logtofile(__METHOD__ . " data prepared for saving. Appl_No:" . 
			$insertData['Appl_No'] . ", Cust_SSN:" . $insertData['Cust_SSN']);

		$insertData['leadID'] = $this->findLeadID($insertData);

		return $insertData;
	}

	/**
	 * Find the leadID
	 *
	 * @param $insertData array 
	 * @return leadID id of lead
	 */
	public function findLeadID($insertData)
	{
		$this->Logger->logtofile(__METHOD__ . " PDLoan_Rcvd:" . 
			$insertData['PDLoan_Rcvd'] . ", Loan_Type:" . $insertData['Loan_Type']);

		// PDLoan_Rcvd field for STANDARD loans sometimes has the leadID
		if ($insertData['PDLoan_Rcvd']) {
			if (is_numeric($insertData['PDLoan_Rcvd']) && 
				!empty($insertData['PDLoan_Rcvd']) &&
				$insertData['Loan_Type'] == 'S' 
			) {
				$Leads = new Leads();
				$result = $Leads->find($insertData['PDLoan_Rcvd']);

				if ($result) {
					$this->Logger->logtofile(__METHOD__ . " leadID found using PDLoan_Rcvd." . 
						" leadID:" . $insertData['PDLoan_Rcvd']);
					return $insertData['PDLoan_Rcvd'];
				}
			}
		}

		// lookup using algorithm
		$LeadMatcher = new LeadMatcherLoanApp(
			$insertData['Cust_ID'], 
			$insertData['Cust_SSN'], 
			$insertData['Loan_Type'], 
			$insertData['Merch_Store_ID'], 
			$insertData['ApplicationDate']);
		if ($leadID = $LeadMatcher->execute()) {
			$this->Logger->logtofile(__METHOD__ . " leadID found using algorithm:$leadID");
			return $leadID;
		}
		$this->Logger->logtofile(__METHOD__ . " no leadID could be found.");
		return 0;
	}
}
