<?php
class Affiliates extends Zend_Db_Table
{
	protected $_name = 'Affiliates';

	/**
	 * @param $affiliates
	 */
	public function getAffiliateNameByID($affiliates, $id)
	{
		if (!$affiliates) {
			return 'N/A';
		}
		foreach ($affiliates as $v) {
			if ($v['id'] == $id) {
				return $v['masteraff'];
			}
		}
		return 'N/A';
	}



	/**
	 * Gets a list of all active affiliates
	 *
	 * @return  array	array of all active affiliates
	 */
	public function getActive()
	{
		$sql = "SELECT
					a.id,
					a.masteraff,
					a.company
				FROM
					Affiliates a
				WHERE
					a.active = 1";

		$result = $this->_db->fetchAll($sql);
		if ($result) {
			$affiliates = array();
			foreach ($result as $value) {
				$affiliates[$value['id']] = $value['masteraff'];
			}
			return $affiliates;
		}
		return array();
	}
}
?>
