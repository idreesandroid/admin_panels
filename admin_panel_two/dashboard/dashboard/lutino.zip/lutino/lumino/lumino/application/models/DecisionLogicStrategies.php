<?php

class DecisionLogicStrategies extends Zend_Db_Table
{
	protected $_name = 'DecisionLogicStrategies';

}
?>