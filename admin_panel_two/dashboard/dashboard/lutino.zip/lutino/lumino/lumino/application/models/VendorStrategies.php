<?php
class VendorStrategies extends Zend_Db_Table
{
	protected $_name = 'VendorStrategies';

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}

	public function getStrategies()
	{
		$select = $this->db->select()->from(array(
			'vs' => 'VendorStrategies'
		), array(
			'vs.*',
			'strategyId' => 'vs.id',
			'v.company'
		))->joinLeft(array(
				'v' => 'Vendors'
			), 'v.id = vs.vendorID')
			->joinLeft(array(
				'vps' => 'VendorPostSetups'
			), 'vps.vendorID = v.id')
			->joinLeft(array(
				'ps' => 'PostSetups'
			), 'vps.postSetupID = ps.id')
			->order(array(
				'v.company ASC'
			));
		return $this->db->fetchAll($select);
	}

	public function saveStrategy($vendorId, $strategy, $ignorefailresponse, $cost)
	{
		// get the class for this vendor/DP
		// look up in vendorPostSetups
		if (!$className = $this->getClassNameByVendorId($vendorId)) {
			return FALSE;
		}

		// save it
		$data = array(
			'vendorID' => $vendorId,
			'className' => $className,
			'description' => $strategy,
			'ignoreFailResponse' => $ignorefailresponse,
		    'cost' => $cost
		);
		$id = $this->insert($data);

		return $id;
	}

	private function getClassNameByVendorId($vendorId)
	{
		$VendorPostSetups = new VendorPostSetups();
		$PostSetups = new PostSetups();
		$select = $VendorPostSetups->select()->where('vendorId=' . $vendorId);
		$result = $VendorPostSetups->fetchRow($select);

		// they must have a postsetup created for this vendor
		if (!$postSetupId = $result['postSetupID']) {
			return FALSE;
		}

		// now get the class
		$select = $PostSetups->select()->where('id=' . $postSetupId);
		$result = $PostSetups->fetchRow($select);

		return $result['postingClassName'];
	}

	public function updateStrategy($vendorId, $strategyId, $strategy, $ignorefailresponse, $cost)
	{
		// get the class for this
		// should do this again in case 'className' changes
		$className = $this->getClassNameByVendorId($vendorId);
		// update it
		$data = array(
			'className' => $className,
			'description' => $strategy,
			'ignoreFailResponse' => $ignorefailresponse,
		    'cost' => $cost
		);
		$this->update($data, 'id=' . $strategyId);
	}

	public function checkIfSafeToDelete($strategyId)
	{
		// first, get the variate that the dp strategy belongs to
		$VariatesVendorStrategy = new VariatesVendorStrategy();
		$LeadStrategies = new LeadStrategies();
		$arrOfVariates = $VariatesVendorStrategy->getVariatesByVendorStrategy($strategyId);
		$isUsed = $LeadStrategies->hasVariateBeenUsedHistorically($arrOfVariates);
		return ($isUsed ? false : true);
	}

	// NOTE: this method does not actually do a database update
	public function updateStrategyNameByCurrentState($strategyName, $ignoreFailResponseState = "0")
	{
		$additionalDescription = " - Collect Data Only";
		// first of all if we already have the additional description in the strategy name
		// we need to remove it
		if (strpos($strategyName, $additionalDescription) !== false) {
			$strategyName = str_replace($additionalDescription, "", $strategyName);
		}

		$collectDataOnlyDescription = $ignoreFailResponseState == "1" ? $additionalDescription : "";
		$strategyName = $strategyName . $collectDataOnlyDescription;

		return $strategyName;
	}

	public function getFactorTrustCredentialsByStrategyID($vendorStrategyId)
	{
		$select = $this->db->select()->from(array(
			'vs' => 'VendorStrategies'
		), array(
			'ftc.username',
			'ftc.password',
			'ftc.merchantID',
			'ftc.storeID',
			'ftc.lenderID',
			'ftc.isDefault'
		))->joinLeft(array(
				'ftcvs' => 'FTCredentialsVendorStrategies'
			), 'ftcvs.vendorStrategyID = vs.id', array())
			->joinLeft(array(
				'ftc' => 'FTCredentials'
			), 'ftc.id = ftcvs.FTCredentialID', array())
			->where('vs.id = ?', $vendorStrategyId);
		return $this->db->fetchAll($select);
	}

	public function getClarityCredentialsByStrategyID($vendorStrategyId)
	{
		$select = $this->db->select()->from(array(
			'vs' => 'VendorStrategies'
		), array(
			'cc.username',
			'cc.password',
			'cc.groupID',
			'cc.accountID',
			'cc.locationID',
			'cc.controlFileName',
		    'cc.inquiryTradelineType',
			'cc.isDefault'
		))->joinLeft(array(
				'ccvs' => 'ClarityCredentialsVendorStrategies'
			), 'ccvs.vendorStrategyID = vs.id', array())
			->joinLeft(array(
				'cc' => 'ClarityCredentials'
			), 'cc.id = ccvs.clarityCredentialID', array())
			->where('vs.id = ?', $vendorStrategyId);
		return $this->db->fetchAll($select);
	}

	public function getTrueScoreCredentialsByStrategyID($vendorStrategyId)
	{
		$select = $this->db->select()->from(array(
			'vs' => 'VendorStrategies'
		), array(
			'tsc.accountID',
			'tsc.apiKey',
			'tsc.isDefault'
		))->joinLeft(array(
				'tsvs' => 'TrueScoreCredentialsVendorStrategies'
			), 'tsvs.vendorStrategyID = vs.id', array())
			->joinLeft(array(
				'tsc' => 'TrueScoreCredentials'
			), 'tsc.id = tsvs.truescoreCredentialID', array())
			->where('vs.id = ?', $vendorStrategyId);
		return $this->db->fetchAll($select);
	}

	public function getDataXCredentialsByStrategyID($vendorStrategyId)
	{
		$select = $this->db->select()->from(array(
			'vs' => 'VendorStrategies'
		), array(
			'dxc.key',
			'dxc.password',
			'dxc.inquiryType',
			'dxc.isDefault'
		))->joinLeft(array(
				'dxvs' => 'DataXCredentialsVendorStrategies'
			), 'dxvs.vendorStrategyID = vs.id', array())
			->joinLeft(array(
				'dxc' => 'DataXCredentials'
			), 'dxc.id = dxvs.DataXCredentialID', array())
			->where('vs.id = ?', $vendorStrategyId);
		return $this->db->fetchAll($select);
	}


	public function getmbCredentialsByStrategyID($vendorStrategyId)
	{
		$select = $this->db->select()->from(array(
			'vs' => 'VendorStrategies'
		), array(

			'mbc.username',
			'mbc.password',
			'mbc.useTestUrl',
			'mbc.isDefault'
		))->joinLeft(array(
				'mbvs' => 'MBCredentialsVendorStrategies'
			), 'mbvs.vendorStrategyID = vs.id', array())
			->joinLeft(array(
				'mbc' => 'MBCredentials'
			), 'mbc.id = mbvs.MBCredentialID', array())
		->where('vs.id = ?', $vendorStrategyId);
		return $this->db->fetchAll($select);

	}

	public function getGverifyCredentialsByStrategyID($vendorStrategyId)
	{
		$select = $this->db->select()->from(array(
			'vs' => 'VendorStrategies'
		), array(
			'gvc.username',
			'gvc.password',
			'gvc.isDefault'
		))->joinLeft(array(
				'gvvs' => 'GVerifyCredentialsVendorStrategies'
			), 'gvvs.vendorStrategyID = vs.id', array())
			->joinLeft(array(
				'gvc' => 'GVerifyCredentials'
			), 'gvc.id = gvvs.GVerifyCredentialsID', array())

			->where('vs.id = ?', $vendorStrategyId);
		return $this->db->fetchAll($select);
	}

	public function getCPADectiveCredentialsByStrategyID($vendorStrategyId)
	{
		$select = $this->db->select()->from(array(
			'vs' => 'VendorStrategies'
		), array(
			'cpadc.key',
			'cpadc.isDefault'
		))->joinLeft(array(
				'cpadvs' => 'CPADetectiveCredentialsVendorStrategies'
			), 'cpadvs.vendorStrategyID = vs.id', array())
			->joinLeft(array(
				'cpadc' => 'CPADetectiveCredentials'
			), 'cpadc.id = cpadvs.CPADetectiveCredentialID', array())
			->where('vs.id = ?', $vendorStrategyId);

		return $this->db->fetchAll($select);
	}

	public function getRelianceMarkCredentialsByStrategyID($vendorStrategyId)
	{
		$select = $this->db->select()->from(array(
			'vs' => 'VendorStrategies'
		), array(
			'rmc.key',
			'rmc.isDefault'
		))->joinLeft(array(
				'rmcvs' => 'RelianceMarkCredentialsVendorStrategies'
			), 'rmcvs.vendorStrategyID = vs.id', array())
			->joinLeft(array(
				'rmc' => 'RelianceMarkCredentials'
			), 'rmc.id = rmcvs.RelianceMarkCredentialID', array())
			->where('vs.id = ?', $vendorStrategyId);

		return $this->db->fetchAll($select);
	}

	public function getDecisionLogicCredentialsByStrategyID($vendorStrategyId)
	{
		$select = $this->db->select()->from(array(
			'vs' => 'VendorStrategies'
		), array(
			'dlc.key',
			'dlc.guid',
			'dlc.isDefault'
		))->joinLeft(array(
			'dlcvs' => 'DecisionLogicCredentialsVendorStrategies'
		), 'dlcvs.vendorStrategyID = vs.id', array())
			->joinLeft(array(
				'dlc' => 'DecisionLogicCredentials'
			), 'dlc.id = dlcvs.decisionLogicCredentialID', array())
			->where('vs.id = ?', $vendorStrategyId);

		return $this->db->fetchAll($select);
	}

	public function getEbureauCredentialsByStrategyID($vendorStrategyId)
	{
		$select = $this->db->select()->from(array(
			'vs' => 'VendorStrategies'
		), array(
			'ebc.username',
			'ebc.password',
			'ebc.isDefault',
			'ebc.marketScore',
			'ebc.fraudScore',
			'ebc.marketScoreName',
			'ebc.fraudScoreName',
			'ebc.useTestUrl'
		))->joinLeft(array(
			'ebcvs' => 'EbureauCredentialsVendorStrategies'
		), 'ebcvs.vendorStrategyID = vs.id', array())
			->joinLeft(array(
				'ebc' => 'EbureauCredentials'
			), 'ebc.id = ebcvs.EbureauCredentialID', array())
			->where('vs.id = ?', $vendorStrategyId);

		return $this->db->fetchAll($select);
	}

	public function getBriteVerifyCredentialsByStrategyID($vendorStrategyId)
	{
		$select = $this->db->select()->from(array(
			'vs' => 'VendorStrategies'
		), array(
			'bvc.key',
			'bvc.isDefault',
		))->joinLeft(array(
			'bvcvs' => 'BriteVerifyCredentialsVendorStrategies'
		), 'bvcvs.vendorStrategyID = vs.id', array())
			->joinLeft(array(
				'bvc' => 'BriteVerifyCredentials'
			), 'bvc.id = bvcvs.BriteVerifyCredentialID', array())
			->where('vs.id = ?', $vendorStrategyId);

		return $this->db->fetchAll($select);
	}

	public function getPDSPaymentCredentialsByStrategyID($vendorStrategyId)
	{
		$select = $this->db->select()->from(array(
			'vs' => 'VendorStrategies'
		), array(
			'ppc.login',
			'ppc.password',
			'ppc.isDefault',
			'ppc.merchantid',
			'ppc.trancode',
			'ppc.sec',
			'ppc.description'
		))->joinLeft(array(
			'ppcvs' => 'PDSPaymentCredentialsVendorStrategies'
		), 'ppcvs.vendorStrategyID = vs.id', array())
			->joinLeft(array(
				'ppc' => 'PDSPaymentCredentials'
			), 'ppc.id = ppcvs.PDSPaymentCredentialsID', array())
			->where('vs.id = ?', $vendorStrategyId);

		return $this->db->fetchAll($select);
	}

	public function getDataTwentyFourSevenCredentialsByStrategyID($vendorStrategyId)
	{
		$select = $this->db->select()->from(array(
			'vs' => 'VendorStrategies'
		), array(
			'dtfsc.username',
			'dtfsc.password',
			'dtfsc.isDefault',
		))->joinLeft(array(
			'dtfscvs' => 'DataTwentyFourSevenCredentialsVendorStrategies'
		), 'dtfscvs.vendorStrategyID = vs.id', array())
			->joinLeft(array(
				'dtfsc' => 'DataTwentyFourSevenCredentials'
			), 'dtfsc.id = dtfscvs.dataTwentyFourSevenCredentialID', array())
			->where('vs.id = ?', $vendorStrategyId);

		return $this->db->fetchAll($select);
	}

	public function getVeritecCredentialsByStrategyID($vendorStrategyId)
	{
		$select = $this->db->select()->from(array(
			'vs' => 'VendorStrategies'
		), array(
			'vc.username',
			'vc.password',
			'vc.reglicnum',
			'vc.actioncode',
			'vc.isDefault'
		))->joinLeft(array(
			'vcvs' => 'VeritecCredentialsVendorStrategies'
		), 'vcvs.vendorStrategyID = vs.id', array())
			->joinLeft(array(
				'vc' => 'VeritecCredentials'
			), 'vc.id = vcvs.veritecCredentialsID', array())
			->where('vs.id = ?', $vendorStrategyId);

		return $this->db->fetchAll($select);
	}

	public function getWhitePapersCredentialsByStrategyID($vendorStrategyId)
	{
	    $select = $this->db->select()->from(array(
	        'vs' => 'VendorStrategies'
	    ), array(
	        'wpc.apiKey',
	        'wpc.products'
	    ))->joinLeft(array(
	        'wpcvs' => 'WhitePagesCredentialsVendorStrategies'
	    ), 'wpcvs.vendorStrategyID = vs.id', array())
	    ->joinLeft(array(
	        'wpc' => 'WhitePagesCredentials'
	    ), 'wpc.id = wpcvs.whitePagesCredentialsID', array())
	    ->where('vs.id = ?', $vendorStrategyId);

	    return $this->db->fetchAll($select);
	}
}
?>
