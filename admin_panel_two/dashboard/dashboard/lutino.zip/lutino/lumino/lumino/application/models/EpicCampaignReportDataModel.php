<?php

class EpicCampaignReportDataModel {

    private $db_slave;

    public function initSettingsForSlaveDB () {
        $config = Zend_Registry::get("config");
        $this->db_slave = Zend_Db::factory($config->resources->multidb->slave->adapter, $config->resources->multidb->slave->toArray());
    }

	public function getEarliestLeadID($date, $time)
	{
		$sql = "select min(id) as id from Leads where originaldate = '" . $date . "' and originaltime >= '" . $time . "'";
		$row = $this->db_slave->fetchRow($sql);

		if (!$row['id']) {
			return 0;
		}
		return $row['id'];
	}

	public function getLatestLeadID($date, $time)
	{
		$sql = "select max(id) as id from Leads where originaldate = '" . $date . "' and originaltime <= '" . $time . "'";
		$row = $this->db_slave->fetchRow($sql);

		if (!$row['id']) {
			return 0;
		}
		return $row['id'];
	}

    /**
    *
    * Gets the campaign report data
    *
    * @param	startDate	date	start of date range
    * @param	endDate		date	end of date range
    * @param	campaign	string	campaign filter
    *
    * @return	array	array of campaign report data
    */
   public function getCampaignReportData($startDateReport, $endDateReport, $originalTimeStart, $originalTimeEnd, $storeIds, $multiVarStart, $multiVarEnd, $originationDate="", $selectedStrategyID, $selectedAffiliateName="")
   {
		$minLeadID = $this->getEarliestLeadID($startDateReport, $originalTimeStart);
		$maxLeadID = $this->getLatestLeadID($endDateReport, $originalTimeEnd);

        $startDateTimeReport = $startDateReport . " " . $originalTimeStart;
        $endDateTimeReport = $endDateReport . " " . $originalTimeEnd;

        $storesIDs = "";
        $dateAndTimeWithoutStoreIDs = "2013-03-11 22:02:30";
        if(strtotime($startDateTimeReport) > strtotime($dateAndTimeWithoutStoreIDs)){
            $qLeadsStoresIDs = "";
        }

        $storeOne = "";
        $multiVar = "";
        if ($multiVarStart >= 0 && $multiVarEnd > 0) {
            $multiVar = "AND multiVarTestNum >= $multiVarStart
                        AND multiVarTestNum <= $multiVarEnd";
        }

        if ($originationDate != "")
             $originationDate = "AND originaldate >= '$originationDate'";

        $strategy = "";
        $strategyID = "";

        if ($selectedStrategyID != "" && $selectedStrategyID > 0) {
            $strategy = "LEFT OUTER JOIN LeadStrategies ON LeadStrategies.leadID = Leads.id
                        LEFT OUTER JOIN Variates ON Variates.id = LeadStrategies.variateID";
            $strategyID = "AND Variates.id = $selectedStrategyID";
        }

       $affiliate = "";
       if ($selectedAffiliateName != "") {
           $affiliate= "INNER JOIN Affiliates AS a ON Leads.affiliateID = a.id";
           $affiliateName = "AND a.masteraff = '$selectedAffiliateName'";
       }

        $sql = "SELECT
                        Leads.storeID,
                        Leads.affiliateID,
                        camp.isHotTransfer,
                        camp.title,
                        IFNULL(Leads.campaign, 1) campaign,
                        IFNULL(ocampaign, 1) campaigno,
                        IFNULL(tcampaign, 1) campaignt,
                        COUNT(1) AS leads,
                        IFNULL(leadPrice, 0) AS cost,
                        IFNULL(totalSold, 0) AS bought,
                        TotalPrice,
                        IFNULL(TodaysOriginated, 0) AS TodaysOriginated,
                        IFNULL(TotalOriginated, 0) AS TotalOriginated,
                        IFNULL(
                                FORMAT(
                                        leadPrice * totalSold / TotalOriginated,
                                        2
                                ),
                                0
                        ) AS CPF,
                        COUNT(DISTINCT EpicLEpaymentStatusOverview.ssn) AS esigs,
                        0 AS FPD,
                        COUNT(DISTINCT PixelFires.leadID) AS redirects
                FROM
                        Leads
                        ".$strategy."
                        ".$affiliate."
                LEFT JOIN (
                        SELECT
                                campaign,
                                SUM(totalSold) totalSold,
                                SUM(TotalPrice) TotalPrice,
                                IFNULL(
                                        FORMAT(
                                                TotalPrice / totalSold,
                                                2
                                        ),
                                        0
                                ) AS leadPrice
                        FROM
                                (
                                    SELECT
                                            ls.campaign,
                                            price,
                                            count(1) AS totalSold,
                                            COALESCE (price * count(1), 0) AS TotalPrice
                                    FROM
                                            LeadSold ls
                                    INNER JOIN Leads ON Leads.id = ls.leadID
                                    ".$strategy."
                                    ".$affiliate."
                                    WHERE
                                            Leads.id >= $minLeadID AND Leads.id <= $maxLeadID
                                    ".$multiVar."
                                    ".$qLeadsStoresIDs."
                                    ".$strategyID."
                                    ".$affiliateName."
                                    GROUP BY
                                            Leads.campaign,
                                            price
                                ) S
                        GROUP BY
                                campaign
                ) AS LeadSold ON LeadSold.campaign = Leads.campaign
                LEFT JOIN (
                        SELECT
                                campaign ocampaign,
                                count(1) totalOriginated
                        FROM
                                EpicLEperformanceOverview
                        LEFT OUTER JOIN Leads ON Leads.id = EpicLEperformanceOverview.leadID
                        ".$strategy."
                        ".$affiliate."
						WHERE dateOriginated >= '" . $startDateTimeReport . "' 
						AND dateOriginated <= '" . $endDateTimeReport . "' 
                        ".$multiVar."
                        ".$storeOne."
                        ".$originationDate."
                        ".$storesIDs."
                        ".$strategyID."
                        ".$affiliateName."
                        GROUP BY
                                ocampaign
                ) AS Originations ON ocampaign = Leads.campaign
                LEFT JOIN (
                        SELECT
                                campaign tcampaign,
                                count(1) todaysOriginated
                        FROM
                             EpicLEperformanceOverview
                        LEFT OUTER JOIN Leads ON Leads.id = EpicLEperformanceOverview.leadID
                        ".$strategy."
                        ".$affiliate."
                        WHERE leadID >= $minLeadID 
                        AND leadID <= $maxLeadID 
                        ".$multiVar."
                        ".$storeOne."
                        ".$originationDate."
                        ".$storesIDs."
                        ".$strategyID."
                        ".$affiliateName."
                        GROUP BY
                                tcampaign
                ) AS TodaysOriginated ON tcampaign = Leads.campaign

                LEFT JOIN EpicLEpaymentStatusOverview ON Leads.id = EpicLEpaymentStatusOverview.leadID
                AND
                        EpicLEpaymentStatusOverview.eStatus = 'Signed'
                LEFT JOIN PixelFires ON Leads.id = PixelFires.leadID
                        AND
                                PixelFires.leadID >= $minLeadID 
                        AND
                                PixelFires.leadID <= $maxLeadID 
                LEFT JOIN Campaigns camp ON Leads.campaign = camp.campaign
                WHERE
                        Leads.id >= $minLeadID AND Leads.id <= $maxLeadID 
                        ".$multiVar."
                        ".$qLeadsStoresIDs."
                         ".$strategyID."
                         ".$affiliateName."
                GROUP BY
                campaign,
                campaigno,
                campaignt";

        $result = $this->db_slave->fetchAll($sql);
        return $result;
    }


    public function getSubIDReportData($startDateReport, $endDateReport, $originalTimeStart, $originalTimeEnd, $storeIds, $campaign, $multiVarStart, $multiVarEnd, $originationDate="", $selectedStrategyID)	{

        $startDateTimeReport = $startDateReport . " " . $originalTimeStart;
        $endDateTimeReport = $endDateReport . " " . $originalTimeEnd;
        $campaign = trim($campaign);

        $storeOne = "";
        $multiVar = "";
        if ($multiVarStart >= 0 && $multiVarEnd > 0) {
                $multiVar = "AND multiVarTestNum >= $multiVarStart
                                         AND multiVarTestNum <= $multiVarEnd";
        }

        $storesIDs = "";
        $qLeadsStoresIDs = "";
        $dateAndTimeWithoutStoreIDs = "2013-03-11 22:02:30";
        if(strtotime($startDateTimeReport) > strtotime($dateAndTimeWithoutStoreIDs)){

                if (strlen($storeIds) == 0) {
                        $storeIds = "''";
                }
                $qLeadsStoresIDs = "AND storeID IN ($storeIds)";
        }

        if ($originationDate != "")
                $originationDate = "AND originaldate >= '$originationDate'";

        $strategy = "";
        $strategyID = "";

        if ($selectedStrategyID != "" && $selectedStrategyID > 0) {
                $strategy = "LEFT OUTER JOIN LeadStrategies ON LeadStrategies.leadID = Leads.id
                                        LEFT OUTER JOIN Variates ON Variates.id = LeadStrategies.variateID";
                $strategyID = "AND Variates.id = $selectedStrategyID";
        }


        $sql = "SELECT
                                IFNULL(Leads.campaign, 1) campaign,
                                IFNULL(Leads.subid, 'subid is null') subID,
                                COUNT(1) AS leads,
                                IFNULL(LeadSold.price, 0) AS cost,
                                IFNULL(totalSold, 0) AS bought,
                                IFNULL(totalPrice, 0) AS TotalPrice,
                                IFNULL(TodaysOriginated, 0) AS TodaysOriginated,
                                IFNULL(TotalOriginated, 0) AS TotalOriginated,
                                IFNULL( FORMAT( LeadSold.price * totalSold / TotalOriginated,2),0) AS CPF,
                                COUNT(DISTINCT EpicLEpaymentStatusOverview.ssn) AS esigs,
                                0 AS FPD,
                                COUNT(DISTINCT PixelFires.leadID) AS redirects
                        FROM
                                Leads
                                ".$strategy."
                        LEFT JOIN (
                                SELECT
                                        lssubid,
                                        price,
                                        SUM(totalSold) totalSold,
                                        SUM(totalPrice) totalPrice
                                FROM
                                        (
                                                SELECT
                                                        ls.subid AS lssubid,
                                                        price,
                                                        count(1) AS totalSold,
                                                        COALESCE (price * count(1), 0) AS totalPrice
                                                FROM
                                                        LeadSold ls
                                                INNER JOIN Leads ON Leads.id = ls.leadID
                                                ".$strategy."
                                                WHERE
                                                        Leads.originaldate >= '$startDateReport' AND Leads.originaldate <= '$endDateReport'
                                                        AND
                                                        Leads.originaltime >= '$originalTimeStart' AND Leads.originaltime <= '$originalTimeEnd'
                                                ".$multiVar."
                                                ".$qLeadsStoresIDs."
                                            ".$strategyID."
                                                AND
                                                        Leads.campaign = '$campaign'
                                                GROUP BY
                                                        ls.subid,
                                                        price
                                        ) S
                                GROUP BY
                                        lssubid
                        ) AS LeadSold ON lssubid = Leads.subid
                        LEFT JOIN (
                                SELECT
                                        subid AS osubid,
                                        count(1) AS TotalOriginated
                                FROM
                                        EpicLEperformanceOverview
                                LEFT OUTER JOIN Leads ON Leads.id = EpicLEperformanceOverview.leadID
                                ".$strategy."
                                WHERE dateOriginated >= '$startDateTimeReport'
                                AND dateOriginated <= '$endDateTimeReport'
                                ".$multiVar."
            ".$storeOne."
            ".$originationDate."
            ".$storesIDs."
            AND
                                        Leads.campaign = '$campaign'
                                GROUP BY
                                        osubid
                        ) AS Originations ON osubid = Leads.subid
                        LEFT JOIN (
                                SELECT
                                        subid AS tsubid,
                                        count(1) todaysOriginated
                                FROM
                                        EpicLEperformanceOverview
                                LEFT JOIN Leads ON Leads.id = EpicLEperformanceOverview.leadID
                                ".$strategy."
                                WHERE dateApplicationReceived >= '$startDateTimeReport'
                                AND dateApplicationReceived <= '$endDateTimeReport'
                                ".$multiVar."
            ".$storeOne."
            ".$originationDate."
            ".$storesIDs."
            ".$strategyID."
            AND
                                        Leads.campaign = '$campaign'
                                GROUP BY
                                        tsubid
                        ) AS TodaysOriginated ON tsubid = Leads.subid

                        LEFT JOIN EpicLEpaymentStatusOverview ON Leads.id = EpicLEpaymentStatusOverview.leadID
                        AND
                        EpicLEpaymentStatusOverview.eStatus = 'Signed'
                        LEFT JOIN PixelFires ON Leads.id = PixelFires.leadID
                                AND
                                        PixelFires.createdAt >= '$startDateTimeReport'
                                AND
                                        PixelFires.createdAt <= '$endDateTimeReport'
                        WHERE
                                        Leads.originaldate >= '$startDateReport' AND Leads.originaldate <= '$endDateReport'
                                AND
                                        Leads.originaltime >= '$originalTimeStart' AND Leads.originaltime <= '$originalTimeEnd'
                                ".$multiVar."
                                ".$qLeadsStoresIDs."
                                 ".$strategyID."
                                AND
                                        Leads.campaign = '$campaign'
                        GROUP BY
                                subid";

        $result = $this->db_slave->fetchAll($sql);

        return $result;

    }

    public function getSubID2ReportData($startDateReport, $endDateReport, $originalTimeStart, $originalTimeEnd, $storeIds, $campaign, $multiVarStart, $multiVarEnd, $originationDate="", $selectedStrategyID)	{

        $startDateTimeReport = $startDateReport . " " . $originalTimeStart;
        $endDateTimeReport = $endDateReport . " " . $originalTimeEnd;
        $campaign = trim($campaign);

        $storeOne = "";
        $multiVar = "";
        if ($multiVarStart >= 0 && $multiVarEnd > 0) {
                $multiVar = "AND multiVarTestNum >= $multiVarStart
                                         AND multiVarTestNum <= $multiVarEnd";
        }

        $storesIDs = "";
        $qLeadsStoresIDs = "";
        $dateAndTimeWithoutStoreIDs = "2013-03-11 22:02:30";
        if(strtotime($startDateTimeReport) > strtotime($dateAndTimeWithoutStoreIDs)){

                if (strlen($storeIds) == 0) {
                        $storeIds = "''";
                }
                $qLeadsStoresIDs = "AND storeID IN ($storeIds)";
        }

        if ($originationDate != "")
                $originationDate = "AND originaldate >= '$originationDate'";

        $strategy = "";
        $strategyID = "";

        if ($selectedStrategyID != "" && $selectedStrategyID > 0) {
                $strategy = "LEFT OUTER JOIN LeadStrategies ON LeadStrategies.leadID = Leads.id
                                        LEFT OUTER JOIN Variates ON Variates.id = LeadStrategies.variateID";
                $strategyID = "AND Variates.id = $selectedStrategyID";
        }


        $sql = "SELECT
                                IFNULL(Leads.campaign, 1) campaign,
                                IFNULL(Leads.subid2, 'subid2 is null') subID2,
                                COUNT(1) AS leads,
                                IFNULL(LeadSold.price, 0) AS cost,
                                IFNULL(totalSold, 0) AS bought,
                                IFNULL(totalPrice, 0) AS TotalPrice,
                                IFNULL(TodaysOriginated, 0) AS TodaysOriginated,
                                IFNULL(TotalOriginated, 0) AS TotalOriginated,
                                IFNULL( FORMAT( LeadSold.price * totalSold / TotalOriginated,2),0) AS CPF,
                                COUNT(DISTINCT EpicLEpaymentStatusOverview.ssn) AS esigs,
                                0 AS FPD,
                                COUNT(DISTINCT PixelFires.leadID) AS redirects
                        FROM
                                Leads
                                ".$strategy."
                        LEFT JOIN (
                                SELECT
                                        lssubid2,
                                        price,
                                        SUM(totalSold) totalSold,
                                        SUM(totalPrice) totalPrice
                                FROM
                                        (
                                                SELECT
                                                        Leads.subid2 AS lssubid2,
                                                        price,
                                                        count(1) AS totalSold,
                                                        COALESCE (price * count(1), 0) AS totalPrice
                                                FROM
                                                        LeadSold ls
                                                INNER JOIN Leads ON Leads.id = ls.leadID
                                                ".$strategy."
                                                WHERE
                                                        Leads.originaldate >= '$startDateReport' AND Leads.originaldate <= '$endDateReport'
                                                        AND
                                                        Leads.originaltime >= '$originalTimeStart' AND Leads.originaltime <= '$originalTimeEnd'
                                                ".$multiVar."
                                                ".$qLeadsStoresIDs."
                                            ".$strategyID."
                                                AND
                                                        Leads.campaign = '$campaign'
                                                GROUP BY
                                                        lssubid2,
                                                        price
                                        ) S
                                GROUP BY
                                        lssubid2
                        ) AS LeadSold ON lssubid2 = Leads.subid2
                        LEFT JOIN (
                                SELECT
                                        subid2 AS osubid2,
                                        count(1) AS TotalOriginated
                                FROM
                                        EpicLEperformanceOverview
                                LEFT OUTER JOIN Leads ON Leads.id = EpicLEperformanceOverview.leadID
                                ".$strategy."
                                WHERE dateOriginated >= '$startDateTimeReport'
                                AND dateOriginated <= '$endDateTimeReport'
                                ".$multiVar."
            ".$storeOne."
            ".$originationDate."
            ".$storesIDs."
            AND
                                        Leads.campaign = '$campaign'
                                GROUP BY
                                        osubid2
                        ) AS Originations ON osubid2 = Leads.subid2
                        LEFT JOIN (
                                SELECT
                                        subid2 AS tsubid2,
                                        count(1) todaysOriginated
                                FROM
                                        EpicLEperformanceOverview
                                LEFT JOIN Leads ON Leads.id = EpicLEperformanceOverview.leadID
                                ".$strategy."
                                WHERE dateApplicationReceived >= '$startDateTimeReport'
                                AND dateApplicationReceived <= '$endDateTimeReport'
                                ".$multiVar."
            ".$storeOne."
            ".$originationDate."
            ".$storesIDs."
            ".$strategyID."
            AND
                                        Leads.campaign = '$campaign'
                                GROUP BY
                                        tsubid2
                        ) AS TodaysOriginated ON tsubid2 = Leads.subid2

                        LEFT JOIN EpicLEpaymentStatusOverview ON Leads.id = EpicLEpaymentStatusOverview.leadID
                        AND
                        EpicLEpaymentStatusOverview.eStatus = 'Signed'
                        LEFT JOIN PixelFires ON Leads.id = PixelFires.leadID
                                AND
                                        PixelFires.createdAt >= '$startDateTimeReport'
                                AND
                                        PixelFires.createdAt <= '$endDateTimeReport'
                        WHERE
                                        Leads.originaldate >= '$startDateReport' AND Leads.originaldate <= '$endDateReport'
                                AND
                                        Leads.originaltime >= '$originalTimeStart' AND Leads.originaltime <= '$originalTimeEnd'
                                ".$multiVar."
                                ".$qLeadsStoresIDs."
                                 ".$strategyID."
                                AND
                                        Leads.campaign = '$campaign'
                        GROUP BY
                                subid2";

        $result = $this->db_slave->fetchAll($sql);

        return $result;

    }

    public function getSubID3ReportData($startDateReport, $endDateReport, $originalTimeStart, $originalTimeEnd, $storeIds, $campaign, $multiVarStart, $multiVarEnd, $originationDate="", $selectedStrategyID)	{
        $startDateTimeReport = $startDateReport . " " . $originalTimeStart;
        $endDateTimeReport = $endDateReport . " " . $originalTimeEnd;
        $campaign = trim($campaign);

        $storeOne = "";
        $multiVar = "";
        if ($multiVarStart >= 0 && $multiVarEnd > 0) {
                $multiVar = "AND multiVarTestNum >= $multiVarStart
                                         AND multiVarTestNum <= $multiVarEnd";
        }

        $storesIDs = "";
        $qLeadsStoresIDs = "";
        $dateAndTimeWithoutStoreIDs = "2013-03-11 22:02:30";
        if(strtotime($startDateTimeReport) > strtotime($dateAndTimeWithoutStoreIDs)){

                if (strlen($storeIds) == 0) {
                        $storeIds = "''";
                }
                $qLeadsStoresIDs = "AND storeID IN ($storeIds)";
        }

        if ($originationDate != "")
                $originationDate = "AND originaldate >= '$originationDate'";

        $strategy = "";
        $strategyID = "";

        if ($selectedStrategyID != "" && $selectedStrategyID > 0) {
                $strategy = "LEFT OUTER JOIN LeadStrategies ON LeadStrategies.leadID = Leads.id
                                        LEFT OUTER JOIN Variates ON Variates.id = LeadStrategies.variateID";
                $strategyID = "AND Variates.id = $selectedStrategyID";
        }


        $sql = "SELECT
                                IFNULL(Leads.campaign, 1) campaign,
                                IFNULL(Leads.subid3, 'subid3 is null') subID3,
                                COUNT(1) AS leads,
                                IFNULL(LeadSold.price, 0) AS cost,
                                IFNULL(totalSold, 0) AS bought,
                                IFNULL(totalPrice, 0) AS TotalPrice,
                                IFNULL(TodaysOriginated, 0) AS TodaysOriginated,
                                IFNULL(TotalOriginated, 0) AS TotalOriginated,
                                IFNULL( FORMAT( LeadSold.price * totalSold / TotalOriginated,2),0) AS CPF,
                                COUNT(DISTINCT EpicLEpaymentStatusOverview.ssn) AS esigs,
                                0 AS FPD,
                                COUNT(DISTINCT PixelFires.leadID) AS redirects
                        FROM
                                Leads
                                ".$strategy."
                        LEFT JOIN (
                                SELECT
                                        lssubid3,
                                        price,
                                        SUM(totalSold) totalSold,
                                        SUM(totalPrice) totalPrice
                                FROM
                                        (
                                                SELECT
                                                        Leads.subid3 AS lssubid3,
                                                        price,
                                                        count(1) AS totalSold,
                                                        COALESCE (price * count(1), 0) AS totalPrice
                                                FROM
                                                        LeadSold ls
                                                INNER JOIN Leads ON Leads.id = ls.leadID
                                                ".$strategy."
                                                WHERE
                                                        Leads.originaldate >= '$startDateReport' AND Leads.originaldate <= '$endDateReport'
                                                        AND
                                                        Leads.originaltime >= '$originalTimeStart' AND Leads.originaltime <= '$originalTimeEnd'
                                                ".$multiVar."
                                                ".$qLeadsStoresIDs."
                                            ".$strategyID."
                                                AND
                                                        Leads.campaign = '$campaign'
                                                GROUP BY
                                                        lssubid3,
                                                        price
                                        ) S
                                GROUP BY
                                        lssubid3
                        ) AS LeadSold ON lssubid3 = Leads.subid3
                        LEFT JOIN (
                                SELECT
                                        subid3 AS osubid3,
                                        count(1) AS TotalOriginated
                                FROM
                                        EpicLEperformanceOverview
                                LEFT OUTER JOIN Leads ON Leads.id = EpicLEperformanceOverview.leadID
                                ".$strategy."
                                WHERE dateOriginated >= '$startDateTimeReport'
                                AND dateOriginated <= '$endDateTimeReport'
                                ".$multiVar."
            ".$storeOne."
            ".$originationDate."
            ".$storesIDs."
            AND
                                        Leads.campaign = '$campaign'
                                GROUP BY
                                        osubid3
                        ) AS Originations ON osubid3 = Leads.subid3
                        LEFT JOIN (
                                SELECT
                                        subid3 AS tsubid3,
                                        count(1) todaysOriginated
                                FROM
                                        EpicLEperformanceOverview
                                LEFT JOIN Leads ON Leads.id = EpicLEperformanceOverview.leadID
                                ".$strategy."
                                WHERE dateApplicationReceived >= '$startDateTimeReport'
                                AND dateApplicationReceived <= '$endDateTimeReport'
                                ".$multiVar."
            ".$storeOne."
            ".$originationDate."
            ".$storesIDs."
            ".$strategyID."
            AND
                                        Leads.campaign = '$campaign'
                                GROUP BY
                                        tsubid3
                        ) AS TodaysOriginated ON tsubid3 = Leads.subid3

                        LEFT JOIN EpicLEpaymentStatusOverview ON Leads.id = EpicLEpaymentStatusOverview.leadID
                        AND
                        EpicLEpaymentStatusOverview.eStatus = 'Signed'
                        LEFT JOIN PixelFires ON Leads.id = PixelFires.leadID
                                AND
                                        PixelFires.createdAt >= '$startDateTimeReport'
                                AND
                                        PixelFires.createdAt <= '$endDateTimeReport'
                        WHERE
                                        Leads.originaldate >= '$startDateReport' AND Leads.originaldate <= '$endDateReport'
                                AND
                                        Leads.originaltime >= '$originalTimeStart' AND Leads.originaltime <= '$originalTimeEnd'
                                ".$multiVar."
                                ".$qLeadsStoresIDs."
                                 ".$strategyID."
                                AND
                                        Leads.campaign = '$campaign'
                        GROUP BY
                                subid3";

        $result = $this->db_slave->fetchAll($sql);

        return $result;
    }

    /**
     * Gets campaigns list with no subID
     *
     * @return  array	array of campaigns with no subID
     */
    public function campaignsWithNotSubIDs($startDateReport, $endDateReport, $originalTimeStart, $originalTimeEnd)
    {
        $sql = "SELECT
                campaign
                FROM
                        Leads
                WHERE
                        subid IS NULL
                AND
                        Leads.originaldate >= '$startDateReport' AND Leads.originaldate <= '$endDateReport'
                AND
                    Leads.originaltime >= '$originalTimeStart' AND Leads.originaltime <= '$originalTimeEnd'
                GROUP BY
                        campaign";

        $result = $this->db_slave->fetchAll($sql);

        return $result;

    }
}

?>
