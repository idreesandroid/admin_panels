<?php

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{
	protected function _initNavigation()
	{
	}

	public function _initConfigIni()
	{
		$ConfigFactory = new ConfigFactory();
		$configFile = $ConfigFactory->create($_SERVER);

		$config = new Zend_Config_Ini($configFile, APPLICATION_ENV);
		Zend_Registry::set('config', $config);
	}

	public function _initDbAdaptor()
	{
		$config = Zend_Registry::get('config');

		// TODO: remove global after we kill all dependencies to it in controllers
		global $db;
		$db = Zend_Db::factory($config->db->adapter, $config->db->config->toArray());

		try
		{
			// comment the reason for this?
			$db->query('SET CHARACTER SET \'UTF8\'');
		}
		catch (Exception $e)
		{
			die('We are temporarily unavailable.');
		}

		Zend_Db_Table::setDefaultAdapter($db);
		Zend_Registry::set('db', $db);
	}

	public function _initAutoloader()
	{
		$loader = Zend_Loader_Autoloader::getInstance();
		$loader->setFallbackAutoloader(true);
		$loader->suppressNotFoundWarnings(false);
	}

	public function _initActionHelper()
	{
		Zend_Controller_Action_HelperBroker::addPath('./application/helpers', '');
	}

	public function _initPlugins()
	{
		$front = Zend_Controller_Front::getInstance();

		// unit test autoloader breaking so explicitly including here
		require_once APPLICATION_PATH . '/../Plugin/MyAcl.php';
		$front->registerPlugin(new Plugin_MyAcl($request));
	}
}
