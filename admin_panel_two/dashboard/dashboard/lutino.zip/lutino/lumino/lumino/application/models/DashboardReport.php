<?php

/**
 *
 */
class DashboardReport
{
	private $fromDate;
	private $toDate;
	private $chartType;
	private $currentTime;
	private $affiliateID;
	private $affiliateName;
	private $campaignName;

	private $affID;
	private $campaignID;

	const HOURLY = 'hourly';
	const SEVEN_DAYS = 'sevendays';
	const FIVE_WEEKS = 'fiveweeks';

	public function __construct()
	{
		// we want to run all queries against slave db
		$bootstrap = Zend_Controller_Front::getInstance()->getParam("bootstrap");
		$this->config = Zend_Registry::get('config');
		$resource = $bootstrap->getPluginResource('multidb');
		$this->slave = $resource->getDb('slave');


		$dashboardReportLMSFactory = new DashboardReportLMSFactory();
		$this->dashboardReportLMSFactoryObject = $dashboardReportLMSFactory->create($this->config->lmsName);
	}

	public function setChartType($chartType, $fromDate, $toDate, $isCurrentTimeSnapshot = 'false', $selectedAffiliateIDs = "", $selectedCampaignIDs = "") {
		$this->affID = $selectedAffiliateIDs;
		$this->campaignID = $selectedCampaignIDs;
	    $this->fromDate = $fromDate;
	    $this->toDate = $toDate;
	    $this->chartType = $chartType;
	    $originalTimeStart = $date = date('H:i:s');
	    if ($isCurrentTimeSnapshot == 'true') {
	        $this->currentTime = "AND l.originaltime <= '$originalTimeStart'";
	    }

		if ($selectedAffiliateIDs != "") {
			$this->affiliateID = "AND l.affiliateID IN ($selectedAffiliateIDs)";
		}

		if ($selectedCampaignIDs != "") {
			$this->campaignName = "AND l.campaign IN ($selectedCampaignIDs)";
		}
	}

	public function getDashboardData()
	{
		$dashboardData = array();

		if ($this->chartType == self::HOURLY) {
			$dashboardData['totalAttemptsToday'] = number_format($this->getTotalAttemptsToday());
			$dashboardData['totalActiveCampaigns'] = $this->getTotalActiveCampaigns();
			$dashboardData['totalCostToday'] = number_format($this->getTotalCostToday(),2,".",",");
			$dashboardData['totalSoldToday'] = $this->getTotalSoldToday();

			$totalNewCustomers = $this->getTotalNewCustomers();
			$dashboardData['totalNewCustomers'] = $totalNewCustomers;
			$totalNewCustomersPercentage = ($totalNewCustomers > 0 && $dashboardData['totalSoldToday'] > 0) ? 100 * ($totalNewCustomers / $dashboardData['totalSoldToday']) : 0;
			$dashboardData['totalNewCustomersPercentage'] = number_format($totalNewCustomersPercentage,2,".",",");

			$totalReturningCustomers = $this->getTotalReturningCustomers();
			$dashboardData['totalReturningCustomers'] = $totalReturningCustomers;
			$totalReturningCustomersPercentage = ($totalReturningCustomers > 0 && $dashboardData['totalSoldToday'] > 0) ? 100 * ($totalReturningCustomers / $dashboardData['totalSoldToday']) : 0;
			$dashboardData['totalReturningCustomersPercentage'] = number_format($totalReturningCustomersPercentage,2,".",".");

			$totalNewCustomersOriginations = $this->getTotalNewCustomersOriginations();
			$totalNewCustomersOriginationsPercentage = ($totalNewCustomersOriginations > 0 && $dashboardData['totalSoldToday'] > 0) ? 100 * ($totalNewCustomersOriginations / $totalNewCustomers) : 0;
			$dashboardData['totalNewCustomersOriginations'] = number_format($totalNewCustomersOriginationsPercentage,2,".",".");

			$totalReturningCustomersOriginations = $this->getTotalReturningCustomersOriginations();
			$totalReturningCustomersOriginationsPercentage = ($totalReturningCustomersOriginations > 0 && $dashboardData['totalSoldToday'] > 0) ? 100 * ($totalReturningCustomersOriginations / $totalReturningCustomers) : 0;
			$dashboardData['totalReturningCustomersOriginations'] = number_format($totalReturningCustomersOriginationsPercentage,2,".",".");

			$totalLeadPurchasedByHour = $this->getTotalLeadPurchasedByHour();
			$totalLeadAttemptsByHour = $this->getTotalAttemptsByHour();

			$hours = array();
			foreach (range(0, 23) as $hour) {
				$hours[] = $hour;
			}

			$totalHourlyAttempts = array();
			foreach ($hours as $hour) {
				if ($total = $this->getDataByHour($totalLeadAttemptsByHour, $hour)) {
					$totalHourlyAttempts[] = $total;
				} else {
					$totalHourlyAttempts[] = 0;
				}
			}

			$totalHourlyPurchased = array();
			foreach ($hours as $hour) {
				if ($total = $this->getDataByHour($totalLeadPurchasedByHour, $hour)) {
					$totalHourlyPurchased[] = $total;
				} else {
					$totalHourlyPurchased[] = 0;
				}
			}

			$dashboardData['chartHours'] = json_encode($hours);
			$dashboardData['chartLeadsAttemptsHourly'] = json_encode($totalHourlyAttempts);
			$dashboardData['chartLeadsPurchaseHourly'] = json_encode($totalHourlyPurchased);

		} else if($this->chartType == self::SEVEN_DAYS) {
			$totalLeadPurchasedForLastSevenDays = $this->getTotalLeadPurchasedForLastSevenDays();
			$totalLeadAttemptsForLastSevenDays = $this->getTotalAttemptsForLastSevenDays();

			$labelNames = array();
			$chartLeadsAttemptsForLastSevenDaysData = array();
			foreach ($totalLeadAttemptsForLastSevenDays as $v) {
				$labelNames[] = $v['name'];
				$chartLeadsAttemptsForLastSevenDaysData[] = $v['total'];
			}

			$chartLeadsPurchaseForLastSevenDaysData = array();
			foreach ($labelNames as $date) {
				if ($total = $this->getDataByDate($totalLeadPurchasedForLastSevenDays, $date)) {
					$chartLeadsPurchaseForLastSevenDaysData[] = $total;
				} else {
					$chartLeadsPurchaseForLastSevenDaysData[] = 0;
				}
			}

			$dashboardData['chartDays'] = json_encode(empty($labelNames) ? array("no data") : $labelNames);
			$dashboardData['chartLeadsAttemptsForLastSevenDays'] = json_encode(empty($chartLeadsAttemptsForLastSevenDaysData) ? array(0) : $chartLeadsAttemptsForLastSevenDaysData);
			$dashboardData['chartLeadsPurchaseForLastSevenDays'] = json_encode(empty($chartLeadsPurchaseForLastSevenDaysData) ? array(0) : $chartLeadsPurchaseForLastSevenDaysData);

		} else if($this->chartType == self::FIVE_WEEKS) {
			$totalTotalLeadPurchasedCurrentDayForLastFiveWeeks = $this->getTotalLeadPurchasedCurrentDayForLastFiveWeeks();
			$totalLeadAttemptsCurrentDayForLastFiveWeeks = $this->getTotalLeadAttemptsCurrentDayForLastFiveWeeks();
			$labelNames = array();

			$chartLeadAttemptsCurrentDayForLastFiveWeeksData = array();
			foreach ($totalLeadAttemptsCurrentDayForLastFiveWeeks as $v) {
				$labelNames[] = $v['name'];
				$chartLeadAttemptsCurrentDayForLastFiveWeeksData[] = $v['total'];
			}

			$chartTotalLeadPurchasedCurrentDayForLastFiveWeeksData = array();
			foreach ($labelNames as $date) {
				if ($total = $this->getDataByDate($totalTotalLeadPurchasedCurrentDayForLastFiveWeeks, $date)) {
					$chartTotalLeadPurchasedCurrentDayForLastFiveWeeksData[] = $total;
				} else {
					$chartTotalLeadPurchasedCurrentDayForLastFiveWeeksData[] = 0;
				}
			}

			$dashboardData['chartDays'] = json_encode(empty($labelNames) ? array("no data") : $labelNames);
			$dashboardData['chartLeadPurchasedCurrentDayForLastFiveWeeksData'] = json_encode(empty($chartTotalLeadPurchasedCurrentDayForLastFiveWeeksData) ? array(0) : $chartTotalLeadPurchasedCurrentDayForLastFiveWeeksData);
			$dashboardData['chartLeadAttemptsCurrentDayForLastFiveWeeksData'] = json_encode(empty($chartLeadAttemptsCurrentDayForLastFiveWeeksData) ? array(0) : $chartLeadAttemptsCurrentDayForLastFiveWeeksData);
		}

		return $dashboardData;
	}

	/**
	 * gets the avg leads per hour from 0900 - 1800
	 * for the last 7 days
	 * @return array
	 */
	public function hourlyAvgForThePastWeek()
	{
	    $sql = "SELECT
				ROUND(AVG(hourly_totals.total),0) as averageLeads,
				hourly_totals.hour,
				CONCAT(hourly_totals.hour, ':00') as prettyHour
				FROM (
					select
					count(1) as total,
						originaldate,
						LEFT(originaltime,2) as hour
						from Leads
						where originaldate >= (curdate() - INTERVAL 7 DAY) and originaldate < curdate()
						GROUP BY originaldate,
						LEFT(originaltime,2)
					) as hourly_totals
					GROUP BY hourly_totals.hour
					having hourly_totals.hour >= 9 and hourly_totals.hour <= 18";

	    $results = $this->slave->fetchAll($sql);
	    return $results;
	}

	/**
	 * gets the leads per hour from 0900 - 1800 for today
	 * @return array
	 */
	public function totalTodayPerHour()
	{
	    $sql = "select
			count(1) as total,
			LEFT(originaltime,2) as hour,
			CONCAT(LEFT(originaltime,2), ':00') as prettyHour
			from Leads
			where originaldate=curdate()
			group by hour
			having hour >= 9 and hour <= 18";

	    $results = $this->slave->fetchAll($sql);
	    return $results;
	}

	/**
	 * gets the avg leads per hour from 0900 - 1800
	 * for a specific day, looking back 6 weeks.
	 * e.g. last 6 'Mondays', 2012-12-31, 2012-12-24, etc.
	 *
	 * @param string $dayOfWeekDates comma-delim string of 6 dates for a specific day
	 * @return array
	 */
	public function hourlyAvgForSpecificDay($dayOfWeekDates)
	{
	    $sql = "SELECT
	    ROUND(AVG(hourly_totals.total),0) as averageLeads,
	    hourly_totals.hour,
	    CONCAT(hourly_totals.hour, ':00') as prettyHour
	    FROM
	    (
	    select
	    count(1) as total,
	    originaldate,
	    LEFT(originaltime,2) as hour
	    from Leads
	    where originaldate IN ($dayOfWeekDates)
	    GROUP BY originaldate,
	    LEFT(originaltime,2)
	    ) as hourly_totals
	    GROUP BY hourly_totals.hour
	    having hourly_totals.hour >= 9 and hourly_totals.hour <= 18";

	    $results = $this->slave->fetchAll($sql);
	    return $results;
	}

	private function getTotalAttemptsToday()
	{
		$sql = "SELECT
					count(*) total
				FROM
					Leads l
				WHERE
					l.originaldate >= '" . $this->fromDate . "'
				AND
					l.originaldate <= '" . $this->toDate . "'
				{$this->affiliateID}
				{$this->campaignName}";
		$result = $this->slave->fetchAll($sql);
		if ($result) {
			return $result[0]['total'];
		}
		return 0;
	}

	private function getTotalSoldToday()
	{
		$sql = "SELECT
					count(*) total
				FROM
					Leads l
				WHERE
					l.originaldate >= '" . $this->fromDate . "'
				AND
					l.originaldate <= '" . $this->toDate . "'
				AND
					l.leadsold = 1
				{$this->affiliateID}
				{$this->campaignName}";

		$result = $this->slave->fetchAll($sql);
		if ($result) {
			return $result[0]['total'];
		}
		return array();
	}

	private function getTotalActiveCampaigns()
	{
		$sql = "SELECT
					count(*) total
				FROM
					Campaigns c
				WHERE
					c.active = 1";

		$result = $this->slave->fetchAll($sql);
		if ($result) {
			return $result[0]['total'];
		}
		return array();
	}

	private function getTotalCostToday()
	{
		$sql = "SELECT
					SUM(ls.price) total
				FROM
					Leads l
				INNER JOIN LeadSold ls ON l.id = ls.leadID
				WHERE
					l.originaldate >= '" . $this->fromDate . "'
				AND
					l.originaldate <= '" . $this->toDate . "'
				AND l.leadsold = 1
			    {$this->affiliateID}
				{$this->campaignName}";

		$result = $this->slave->fetchAll($sql);
		if ($result) {
			return $result[0]['total'];
		}
		return 0;
	}


	private function getTotalNewCustomers()
	{
		$sql = "SELECT
					count(*) total
				FROM
					Leads l
				LEFT JOIN ReturningCustomers rc ON l.id = rc.leadID
				WHERE
					l.originaldate >= '" . $this->fromDate . "'
				AND
					l.originaldate <= '" . $this->toDate . "'
				AND
					l.leadsold = 1
				{$this->affiliateID}
				{$this->campaignName}
				AND ISNULL(rc.leadID)
				";

		$result = $this->slave->fetchAll($sql);
		if ($result) {
			return $result[0]['total'];
		}
		return array();
	}

	private function getTotalReturningCustomers()
	{
		$sql = "SELECT
					count(*) total
				FROM
					Leads l
				LEFT JOIN ReturningCustomers rc ON l.id = rc.leadID
				WHERE
					l.originaldate >= '" . $this->fromDate . "'
				AND
					l.originaldate <= '" . $this->toDate . "'
				AND
					l.leadsold = 1
				{$this->affiliateID}
				{$this->campaignName}
				AND (rc.leadID) IS NOT NULL";

		$result = $this->slave->fetchAll($sql);
		if ($result) {
			return $result[0]['total'];
		}
		return array();
	}

	private function getTotalNewCustomersOriginations()
	{
	    return $this->dashboardReportLMSFactoryObject->getTotalNewCustomersOriginations($this->fromDate, $this->toDate, $this->affID, $this->campaignID);
	}

	private function getTotalReturningCustomersOriginations()
	{
		$sql = "SELECT
					count(1) total
				FROM
					Master m
				LEFT JOIN Leads l ON l.id = m.leadID
				LEFT JOIN ReturningCustomers rc ON l.id = rc.leadID
				WHERE
					m.Loan_Type = 'S'
				AND m.Loan_Status NOT IN ('I', 'V', 'W')
				AND LEFT(m.Loan_Date, 10) >= '" . $this->fromDate . "'
				AND LEFT(m.Loan_Date, 10) <= '" . $this->toDate . "'
				AND
					l.leadsold = 1
				{$this->affiliateID}
				{$this->campaignName}
				AND (rc.leadID) IS NOT NULL";

		$result = $this->slave->fetchAll($sql);
		if ($result) {
			return $result[0]['total'];
		}
		return array();
	}

	private function getTotalLeadPurchasedByHour()
	{
		$sql = "SELECT
					HOUR(l.originaltime) hour,
					count(1) total
				FROM
					Leads l
				JOIN CashData ON l.id = CashData.leadID
				WHERE
					l.leadsold = 1
				AND
					l.originaldate >= '" . $this->fromDate . "'
				AND
					l.originaldate <= '" . $this->toDate . "'
				{$this->affiliateID}
				{$this->campaignName}
				GROUP BY
					HOUR(l.originaltime)";

		$result = $this->slave->fetchAll($sql);
		if ($result) {
			return $result;
		}
		return array();
	}

	private function getTotalAttemptsByHour()
	{
		$sql = "SELECT
					HOUR(l.originaltime) hour,
					count(1) total
				FROM
					Leads l
				JOIN CashData ON l.id = CashData.leadID
				WHERE
					l.originaldate >= '" . $this->fromDate . "'
				AND
					l.originaldate <= '" . $this->toDate . "'
				{$this->affiliateID}
				{$this->campaignName}
				GROUP BY
					HOUR(l.originaltime)";

		$result = $this->slave->fetchAll($sql);
		if ($result) {
			return $result;
		}
		return array();
	}

	private function getDataByHour($data, $hour) {
		foreach ($data as $v) {
			if ($hour == $v['hour']) {
				return $v['total'];
			}
		}

		return NULL;
	}


	private function getDataByDate($data, $date) {
		foreach ($data as $v) {
			if ($date == $v['name']) {
				return $v['total'];
			}
		}

		return NULL;
	}

	private function getTotalLeadPurchasedForLastSevenDays()
	{
		$sql = "SELECT
					CONCAT(l.originaldate, ' (',DATE_FORMAT(l.originaldate,'%a'),')') name,
					count(1) total
				FROM
					Leads l
				JOIN CashData ON l.id = CashData.leadID
				WHERE
					l.leadsold = 1
				AND
					l.originaldate > DATE_SUB(NOW(), INTERVAL 8 DAY)
					{$this->currentTime}
					{$this->affiliateID}
					{$this->campaignName}
				GROUP BY
					l.originaldate";

		$result = $this->slave->fetchAll($sql);
		if ($result) {
			return $result;
		}
		return array();
	}

	private function getTotalAttemptsForLastSevenDays()
	{
		$sql = "SELECT
					CONCAT(l.originaldate, ' (',DATE_FORMAT(l.originaldate,'%a'),')') name,
					count(1) total
				FROM
					Leads l
				JOIN CashData ON l.id = CashData.leadID
				WHERE
					l.originaldate > DATE_SUB(NOW(), INTERVAL 8 DAY)
					{$this->currentTime}
					{$this->affiliateID}
					{$this->campaignName}
				GROUP BY
					l.originaldate";

		$result = $this->slave->fetchAll($sql);
		if ($result) {
			return $result;
		}
		return array();
	}

	private function getTotalLeadPurchasedCurrentDayForLastFiveWeeks()
	{
		$sql = "SELECT
					l.originaldate name,
					count(1) total
				FROM
					Leads l
				JOIN CashData ON l.id = CashData.leadID
				WHERE
					l.leadsold = 1
				AND
					(DAYOFWEEK(l.originaldate) = DAYOFWEEK(NOW()))
				AND
					l.originaldate > DATE_SUB(NOW(), INTERVAL 5 WEEK)
					{$this->currentTime}
					{$this->affiliateID}
					{$this->campaignName}
				GROUP BY
					DAYOFWEEK(NOW()), l.originaldate";

		$result = $this->slave->fetchAll($sql);
		if ($result) {
			return $result;
		}
		return array();
	}

	private function getTotalLeadAttemptsCurrentDayForLastFiveWeeks()
	{
		$sql = "SELECT
					l.originaldate name,
					count(1) total
				FROM
					Leads l
				JOIN CashData ON l.id = CashData.leadID
				WHERE
					(DAYOFWEEK(l.originaldate) = DAYOFWEEK(NOW()))
				AND
					l.originaldate > DATE_SUB(NOW(), INTERVAL 5 WEEK)
					{$this->currentTime}
					{$this->affiliateID}
					{$this->campaignName}
				GROUP BY
					DAYOFWEEK(NOW()), l.originaldate";

		$result = $this->slave->fetchAll($sql);
		if ($result) {
			return $result;
		}
		return array();
	}



	/**
	 * Gets campaigns list of all affiliates
	 *
	 * @return  array	array of all affiliates
	 */
	public function getAllAffiliates()
	{
		$sql = "SELECT
					a.id,
					a.masteraff,
					a.company
				FROM
					Affiliates a
				WHERE
					a.active = 1";

		$result = $this->slave->fetchAll($sql);
		if ($result) {
			$affiliates = array();
			foreach ($result as $value) {
				$affiliates[$value['id']] = $value['masteraff'];
			}
			return $affiliates;
		}
		return array();
	}

	/**
	 * Gets list of campaigns  based on affiliateName
	 *
	 * @return  array campaigns
	 */
	public function getCampaignsByAffiliateName($affiliateName)
	{
		$sql = "SELECT
					c.campaign,
					c.title,
					a.masteraff
				FROM
					Affiliates a
				LEFT JOIN
					Campaigns c ON a.masteraff = c.masteraff
				WHERE
					c.campaign IS NOT NULL
				AND
					a.active = 1
				AND
					a.masteraff LIKE '{$affiliateName}'";

		$result = $this->slave->fetchAll($sql);
		if ($result) {
			$campaigns = array();
			foreach ($result as $value) {
				$campaigns[(int)$value['campaign']] = $value['title'];
			}
			return $campaigns;
		}
		return array();
	}
}
