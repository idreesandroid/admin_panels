<?php

class EpicPerformanceOverviewDataModel extends ReportAbstract
{
	public function getTotalRecords($startDate,$endDate) {

	    $sql = "SELECT count(*) total
			    FROM
				EpicLEperformanceOverview ep
			    WHERE
				ep.dateApplicationReceived >= '$startDate'
			    AND
				ep.dateApplicationReceived <= '$endDate' ";

	    return $this->slave->fetchRow($sql);
	}

	public function getScrapeData($startDate,$endDate,$sortBy,$sortOrder,$offset,$limit) {

	    $sql = "SELECT * FROM  EpicLEperformanceOverview ep
	            WHERE
	            ep.dateApplicationReceived >= '$startDate'
			    AND
			    ep.dateApplicationReceived <= '$endDate' ";

	    $sql.=" order by $sortBy $sortOrder limit $offset,$limit";

	    return $this->slave->fetchAll($sql);
	}

	public function getLastScrapeTime()
	{
		$sql = "SELECT max(createdAt) lastScrapeTime FROM EpicLEperformanceOverview limit 1";

		$result = $this->slave->fetchRow($sql);

		return $result['lastScrapeTime'];
	}
}