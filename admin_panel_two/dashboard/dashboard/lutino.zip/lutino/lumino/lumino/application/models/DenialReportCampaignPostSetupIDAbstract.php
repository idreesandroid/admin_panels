<?php
/**
 * facade class that handles getting all data for building 
 * Denial Report subID breakdown for a specific Campaign
 */
class DenialReportCampaignPostSetupIDAbstract extends ReportAbstract
{
    public function __construct($fromDate, $toDate, $campaignID, $timeStart, $timeEnd)
	{
		// we want to run all queries against slave db
	    $bootstrap = Zend_Controller_Front::getInstance()->getParam("bootstrap");
		$resource = $bootstrap->getPluginResource('multidb');
		$this->slave = $resource->getDb('slave');

		$this->fromDate = $fromDate;
		$this->toDate = $toDate;
		$this->campaignID = $campaignID;
		$this->fromTime = $timeStart;
		$this->toTime = $timeEnd;
		$this->fromDateTime = $fromDate .' ' .$timeStart;
		$this->toDateTime = $toDate .' ' .$timeEnd;
    }

	/**
	 * NOTE: maybe make this a view helper.
	 * It reformats the array so we can plug it right into the view.
	 * (each array key is the html table column)
	 *
	 * format: [['xxxx'] => ['subid'] => 'xxxx', [100] => NULL, [101] => 4,... [10] => NULL]]
	 *
	 * @param array $reports organized by campaign
	 * @return array
	 */
	public function restructureForView($reports)
	{
		$restructured = array();

		// all internal reject codes
		$InternalRejectCode = new InternalRejectCode();
		$internalResults = $InternalRejectCode->fetchAll(array('id'))->toArray();
		$internalCodes = array_map(function($v) { return $v['id']; }, $internalResults);

		// all criteria reject codes
		$ClientRejectCode = new ClientRejectCode();
		$criteriaResults = $ClientRejectCode->fetchAll(array('id'))->toArray();
		$criteriaCodes = array_map(function($v) { return $v['id']; }, $criteriaResults);

		foreach ($reports as $k => $report) 
		{
			$restructured[$k]['subid'] = $k;

			// internal rejects
			if (array_key_exists('internalRejects', $report)) {
				foreach ($internalCodes as $code) {
					foreach ($report['internalRejects'] as $reject) {
						if ($reject['rejectCode'] == $code) {
							$restructured[$k][$code] = $reject['total'];
						}
					}
				}
			}

			// clientCriteria rejects
			if (array_key_exists('clientCriteriaRejects', $report)) {
				foreach ($criteriaCodes as $code) {
					foreach ($report['clientCriteriaRejects'] as $reject) {
						if ($reject['rejectCode'] == $code) {
							$restructured[$k][$code] = $reject['total'];
						}
					}
				}
			}

			// vendor rejects
			if (array_key_exists('vendorRejects', $report)) {
				foreach ($report['vendorRejects'] as $vendorKey => $reject) {
					$restructured[$k]['vendor_' . $vendorKey] = $reject;
				}
			}

			// client rejects
			if (array_key_exists('clientRejects', $report)) {
				foreach ($report['clientRejects'] as $clientKey => $reject) {
					$restructured[$k]['client_' . $clientKey] = $reject;
				}
			}

			// lead attempts
			if (array_key_exists('leadAttempts', $report)) {
				$restructured[$k]['leadAttempts'] = $report['leadAttempts'];
			}

			// lead sold
			if (array_key_exists('leadSold', $report)) {
				$restructured[$k]['leadSold'] = $report['leadSold'];
			}

			if (array_key_exists('preCheckedVendorRejects', $report)) {
				$restructured[$k]['preCheckedVendorRejects'] = $report['preCheckedVendorRejects'];
			}

		}
		return $restructured;
	}

	/**
	 * get all postSetupIDs for this campaignID and organize as array with postSetupID as key
	 * @return array
	 */
	public function getPostSetupIDs()
	{
		$sql = "select postSetupID  
			from CampaignsClientPostSetups
			where campaignID = " . $this->campaignID;
		$sqlResults = $this->slave->fetchAll($sql);
		$postSetupIDs = array_map(function($v) { return $v['postSetupID']; }, $sqlResults);
                $this->setupIDs = $postSetupIDs;
		return $postSetupIDs;
	}

	public function getClientCriteriaRejects()
	{
                if(count($this->setupIDs)) {
                    $sql = "select postSetupID,
                            count(1) total,
                            cr.rejectCode,
                            crc.name rejectName 
                            from Leads l
                            join ClientRejects cr on cr.leadid = l.id 
                            join ClientRejectCodes crc on crc.id = cr.rejectcode 
                            where originaldate >= '" . $this->fromDate . "' 
                            and originaldate <= '" . $this->toDate . "'
                            and originaltime >= '" . $this->fromTime . "'
                            and originaltime <= '" . $this->toTime . "'
                            and campaign = " . $this->campaignID." ".
                            "and postSetupID IN (" . implode(',', $this->setupIDs) . ") ". 
                            "group by postSetupID, cr.rejectcode";   
                    return $this->slave->fetchAll($sql);
                }
                else return array();
	}

	public function getClientRejects()
	{
                 if(count($this->setupIDs)) {
                    $sql = "select count(1) total,
                            pl.postSetupID
                            from PostLogs pl 
                            join Leads l on l.id = pl.leadID 
                            where pl.postdate >= '" . $this->fromDate . "' 
                            and pl.postdate <= '" . $this->toDate . "'
                            and pl.startTime >= '" . $this->fromTime . "'
                            and pl.startTime <= '" . $this->toTime . "' 
                            and pl.postsetupid IN (" . implode(',', $this->setupIDs) . ")   
                            and pl.poststatus='no' 
                            and l.campaign = '" . $this->campaignID . "'  
                            group by pl.postSetupID";
                    return $this->slave->fetchAll($sql);
                }
                else return array();
	}

	public function getLeadSold()
	{
                if(count($this->setupIDs)) {
                    $sql = "select count(1) total,
                            postSetupID  
                            from PostLogs pl 
                            join Leads l on l.id = pl.leadID 
                            where pl.postdate >= '" . $this->fromDate . "' 
                            and pl.postdate <= '" . $this->toDate . "'
                            and pl.startTime >= '" . $this->fromTime . "'
                            and pl.startTime <= '" . $this->toTime . "' 
                            and pl.postsetupid IN (" . implode(',', $this->setupIDs) . ")   
                            and pl.poststatus='accept' 
                            and l.campaign = '" . $this->campaignID . "'  
                            group by pl.postSetupID";
                    return $this->slave->fetchAll($sql);
                }
                else return array();
	}

	/**
	 * @param int $rejectCode eg vendor reject code 1001
	 * @return array
	 */
	public function getVendorRejectsByRejectCode($rejectCode)
	{
		if(count($this->setupIDs)) {
			$sql = "SELECT
				count(1) total,
					postSetupID 
					FROM Leads
					LEFT JOIN VendorRejects vr ON Leads.id = vr.leadID
					WHERE LEFT(vr.createdAt, 10) >= '" . $this->fromDate . "'
					AND LEFT(vr.createdAt, 10) <= '" . $this->toDate . "'
					AND vr.rejectCode = " . $rejectCode . " 
					AND Leads.campaign = '" . $this->campaignID . "' ".          
					"AND postSetupID IN (" . implode(',', $this->setupIDs) . ") ". 
					"GROUP BY postSetupID"; 
			return $this->slave->fetchAll($sql);
		}
		else return array();
	}

	/**
	 * get all scorecard rejects for this campaignID and organize as array with subID as key
	 * @return array
	 */
	public function getHiddenVendorScorecardRejects()
	{
		if(count($this->setupIDs)) {
		$sql = "SELECT postSetupID , name, count(1) total 
			FROM  PostLogs pl  INNER JOIN Leads L ON L.id = pl.leadID
			LEFT OUTER JOIN LeadStrategies ON LeadStrategies.leadID = pl.leadID 
			LEFT OUTER JOIN Variates ON Variates.id = LeadStrategies.variateID 
			WHERE pl.postdate >= '" . $this->fromDate . "' 
			AND pl.postdate <= '" . $this->toDate . "'
			AND originaldate >= '" . $this->fromDate . "' 
			AND originaldate <= '" . $this->toDate . "'
			AND L.campaign = '" . $this->campaignID . "'
			AND pl.startTime >= '00:00:00' AND pl.startTime <= '23:59:59'"." ". 
			"AND postsetupid IN (".implode(',', $this->setupIDs).")
			AND poststatus = 'no' and Variates.hideInAdmin = 1 
			GROUP BY postSetupID";
		return $this->slave->fetchAll($sql);
	    
		}
		 else return array();
	}

	/**
	 * @return array
	 */
	public function prepareVendorRejectHeader()
	{
		$Vendors = new Vendors();
		$vendorData = $Vendors->getVendorData();
		$this->sortByPriority($vendorData, "priority", TRUE);
		$vendorsHeaders = array();
		foreach ($vendorData AS $v) {
			if ($v['active'] == "1") {
				$vendorsHeaders[] = $v;
			}
		}
		return $vendorsHeaders;
	}

	/**
	 * @return array
	 */
	public function prepareClientRejectHeader()
	{
		$Client = new Clients();
		$clientData = $Client->getClientData();
		$this->sortByPriority($clientData, "priority", TRUE);

		$clientsHeaders = array();
		foreach ($clientData AS $v) {
			if ($v['active'] == "0") {
				continue;
			} else {
				$clientsHeaders[] = $v;
			}
		}
		return $clientsHeaders;
	}

	/**
	 * Format Denial report data as it has missing array elements if there's no data
	 * @param array $vendorsHeaders
	 * @param array $clientHeaders
	 * @param array $reports
	 * @return array
	 */

	public function prepareReportForTableView($vendorsHeaders, $clientHeaders, $reports)
	{
		$reportsFormatted = array();
		$result = array();

		// If we don't have any data, we set empty fields to default empty
		if (empty($reports)) {
			foreach ($vendorsHeaders as $headerVal) {
				$header = 'vendor_' . $headerVal['postSetupID'];
				$result['empty'][$header] = '';
			}
			foreach ($clientHeaders as $headerVal) {
				$header = 'client_' . $headerVal['postSetupID'];
				$result['empty'][$header] = '';
			}

			return $result;
		}

		// prepare Vendor Rejects
		foreach ($reports as $reportKey => $reportValue) {
			foreach ($reportValue as $v) {
				foreach ($vendorsHeaders as $headerVal) {
					$header = 'vendor_' . $headerVal['postSetupID'];
					if (array_key_exists($header, $reportValue)) {
						$reportsFormatted[$reportKey][$header] = $reportValue[$header];
					} else {
						$reportsFormatted[$reportKey][$header] = '';
					}
				}
			}
			$result[$reportKey] = $reportValue + $reportsFormatted[$reportKey];
		}

		// prepare Client Rejects
		foreach ($reports as $reportKey => $reportValue) {
			foreach ($reportValue as $v) {
				foreach ($clientHeaders as $headerVal) {
					$header = 'client_' . $headerVal['postSetupID'];
					if (array_key_exists($header, $reportValue)) {
						$reportsFormatted[$reportKey][$header] = $reportValue[$header];
					} else {
						$reportsFormatted[$reportKey][$header] = '';
					}
				}
			}
			$result[$reportKey] = $reportValue + $reportsFormatted[$reportKey];
		}

		return $result;
	}

	/**
	 * This method can be used for sorting array by key, also we can set sorting order here
	 * @param $array
	 * @param string $subkey
	 * @param bool $sort_ascending
	 */
	public function sortByPriority(&$array, $subkey = "id", $sort_ascending = false)
	{

		if (count($array))
			$temp_array[key($array)] = array_shift($array);

		foreach ($array as $key => $val) {
			$offset = 0;
			$found = false;
			foreach ($temp_array as $tmp_key => $tmp_val) {
				if (!$found and strtolower($val[$subkey]) > strtolower($tmp_val[$subkey])) {
					$temp_array = array_merge((array)array_slice($temp_array, 0, $offset),
						array($key => $val),
						array_slice($temp_array, $offset)
					);
					$found = TRUE;
				}
				$offset++;
			}
			if (!$found) $temp_array = array_merge($temp_array, array($key => $val));
		}

		if ($sort_ascending) $array = array_reverse($temp_array);

		else $array = $temp_array;
	}
}
