<?php
class CustomholidayController extends Zend_Controller_Action
{
    private $baseurl;

	function init()
    {
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if(!$AdminNameSpace->userid)
		{
	    		$this->_redirect('index/login');
		}
	    $this->baseurl = $this->_request->getBaseUrl();
    }

    function viewAction()
    {
        $CustomHolidays = new CustomHolidays();
        $holidays = $CustomHolidays->fetchAll();
        $this->view->baseurl = $this->baseurl;
        $this->view->holidays = $holidays;
    }

    function updateAction()
    {
        if ($this->_request->isPost()) {

            $holidaysTitles = $this->_request->getPost('holidaystitle');
            $holidaysDates = $this->_request->getPost('holidaysdate');

            // Let us first delete all revious records and insert new ones
            $CustomHolidays = new CustomHolidays();
            $CustomHolidays->delete("id>=1");

            for ($a=0;$a<count($holidaysDates);$a++) {
                if (!empty($holidaysDates[$a]) && !empty($holidaysTitles[$a])) {
                    $data = array('title' => $holidaysTitles[$a], 'holidayDate' => date("Y-m-d",strtotime($holidaysDates[$a])));
                    $CustomHolidays->insert($data);
                }
            }

            $this->_redirect('/customholiday/view?action=success');
        }
    }




}