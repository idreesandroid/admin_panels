<?php

class LeadRequestParameter extends Zend_Db_Table
{
	protected $_name = 'LeadRequestParameters';

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}

	public function findParameterByName($paramName)
	{
		$sql = "SELECT
					*
				FROM
					LeadRequestParameters vrp
				WHERE
					vrp.name LIKE '%".$paramName."%'";

		$sqlresult = $this->db->fetchAll($sql);

		return $sqlresult;
	}
}
