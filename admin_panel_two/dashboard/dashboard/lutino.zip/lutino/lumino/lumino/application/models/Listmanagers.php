<?php
class Listmanagers extends Zend_Db_Table
{
	protected $_name = 'postsetups';
}
?>