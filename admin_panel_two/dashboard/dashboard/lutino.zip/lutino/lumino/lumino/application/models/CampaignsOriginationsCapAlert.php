<?php
/**
 * this class determines if any campaigns have hit their originations cap.
 * If so, send an email alert
 */
class CampaignsOriginationsCapAlert
{
	/**
	 * @boolean set this to TRUE if you don't want to send an email
	 */
	public $testMode = FALSE;

	public function __construct()
	{
		$this->db = Zend_Registry::get('db');
	}

	public function setTestMode($mode)
	{
		$this->testMode = $mode;
	}

	/**
	 * this is main interface to this class.
	 * it looks at originations grouped by campaign and sends an email alert
	 *
	 * @return array
	 */
	public function execute()
	{
		if ($totals = $this->getTotals()) {
			if (!$this->testMode) {
				$headers = 'From: tech@mediaenvy.com' . "\r\n" .
					    'Reply-To: tech@mediaenvy.com' . "\r\n" .
						    'X-Mailer: PHP/' . phpversion();
				$subj = 'Campaign Originations Cap Alert';
				$body  = "The following campaigns have hit their originations Cap:" . "\r\n\r\n";
				foreach ($totals as $total) {
					$body .= 'campaign ' . $total['campaign'] . ", total originations:" . 
						$total['totalOriginations'] . ", cap setting:" . 
						$total['originationsCap'] . "\r\n";
				}
				mail('Marketing@mediaenvy.com, tech@mediaenvy.com', $subj, $body, $headers);
			}
		}
		return $totals;
	}
	
	/**
	 * lets look back 60 days from today
	 * @return array
	 */
	public function getTotals()
	{
		$sql = "select IFNULL(l.campaign, 'other') campaign,
			count(1) totalOriginations,
			c.maxOriginations originationsCap 
			from Master m
			left join Leads l on l.id = m.leadID
			join Campaigns c on c.id = l.campaign 
			where m.Loan_Type = 'S'
			and m.Loan_Status NOT IN ('I','V','W')
			and m.applicationDate >= curdate() - interval 60 day 
			group by l.campaign 
			having totalOriginations >= originationsCap";

		return $this->db->fetchAll($sql);
	}
}
