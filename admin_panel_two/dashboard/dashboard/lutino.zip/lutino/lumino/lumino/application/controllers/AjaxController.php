<?php
class AjaxController extends Zend_Controller_Action
{
  public function init()
  {
    $this->_helper->viewRenderer->setnoRender();
  }
  
  public function getresponseAction()
  {
    global $db;
    $client_id   = $this->_getParam( 'client_id' );
    $action_flag = $this->_getParam( 'action_flag' );
    $from_date   = $this->_getParam( 'from_date' );
    $to_date     = $this->_getParam( 'to_date' );
    $start_time  = $this->_getParam( 'start_time' );
    $end_time    = $this->_getParam( 'end_time' );
    
    $from_datetime = $from_date . ' ' . $start_time;
    $to_datetime   = $to_date . ' ' . $end_time;

    // Get all the records for client within the date/time range.
    $query = 'SELECT postlog.postresponse, poststatus  
              FROM postlog 
              WHERE postlog.clientid = ' . $client_id . '
                AND CONCAT( postlog.postdate, " ", postlog.starttime ) >= "' . $from_datetime . '"
                AND CONCAT( postlog.postdate, " ", postlog.endtime ) <= "' . $to_datetime . '"
                AND postlog.postresponse NOT LIKE "%<REDIRECTURL>https://esuperoffers.com/bottomcashbuyer/id/test.asp?idbc</REDIRECTURL>%"';
    $result = $db->fetchAll( $query );

    $data = '';
    if( $action_flag == 0 )  // poststatus = accept
    {
      for( $i = 0; $i < count( $result ); $i++ )
      {
        if( $result[$i]['poststatus'] == 'accept' )
        {
          $data .= $result[$i]['postresponse'];
          $data .= '<br />***************************************<br /><br />';
        }
      }
    }
    else if( $action_flag == 2 )
    {
      for( $i = 0; $i < count( $result ); $i++ )
      {
        if( $result[$i]['postresponse'] == '' )
        {
          $data .= '<< no response text >>';
          $data .= '<br />***************************************<br /><br />';
        }
      }
    }
    else if( $action_flag == 1 )
    {
      for( $i = 0; $i < count( $result ); $i++ )
      {
//        $data .= $result[$i]['postresponse'];
//        $data .= '<br />***************************************<br /><br />';
        
        if( $result[$i]['poststatus'] == 'reject' || ( $result[$i]['poststatus'] == 'no' && $result[$i]['postresponse'] != '' ) )
        {
          $data .= $result[$i]['postresponse'];
          $data .= '<br />***************************************<br /><br />';
        }
      }
    }
    echo $data;
  }
}
?>