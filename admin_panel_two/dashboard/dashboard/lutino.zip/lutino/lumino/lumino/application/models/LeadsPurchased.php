<?php

class LeadsPurchased extends ReportAbstract
{
	CONST CLARITY_VENDOR_ID = 22;
	CONST UNDERWRITEIO_VENDOR_ID = 25;

	public function getTotalLeadsPurchased($customerType,$originated,$startDate,$endDate,$startTime,$endTime, $campaignID="", $affiliateID="", $affiliateName="") {

		// get new customers count
		if ($customerType == 'new') {
			$joinOnReturningCustomersTable = "LEFT JOIN ReturningCustomers rc ON l.id = rc.leadID";
			$customerTypeFilter = "AND ISNULL(rc.leadID) ";
		} else if ($customerType == 'returning') {
			$joinOnReturningCustomersTable = "LEFT JOIN ReturningCustomers rc ON l.id = rc.leadID";
			$customerTypeFilter = "AND (rc.leadID) IS NOT NULL ";
		} else if ($customerType == 'all') {
			$joinOnReturningCustomersTable = "";
			$customerTypeFilter = "";
		}

		$originatedFilter = "";
		$joinOriginationsTable = "";

		if ($originated == "originated") {
		    $originatedFilter = "AND orig.leadID IS NOT NULL";
		    $joinOriginationsTable = $this->getJoiningTableQueryForOrigination();
		}

		$filterByCampaignID = "";

		if ($campaignID != "") {
			$filterByCampaignID = "AND l.campaign IN ($campaignID)";
		}

		if($affiliateID != "") {
			$filterByAffiliateID = " AND l.affiliateID IN ($affiliateID)";
		}

		$joinAffiliate = "";
		$andAffiliate = "";
		if ($affiliateName != "") {
			$joinAffiliate= "INNER JOIN Affiliates AS a ON l.affiliateID = a.id";
			$andAffiliate = "AND a.masteraff = '$affiliateName'";
		}

	    $sql = "SELECT count(*) total
			    FROM
				    Leads l
				$joinOriginationsTable
			    {$joinOnReturningCustomersTable}
			    {$joinAffiliate}
			    WHERE
				    l.originaldate >= '$startDate'
			    AND
				    l.originaldate <= '$endDate'
			    AND
				    l.originaltime >= '$startTime'
			    AND
				    l.originaltime <= '$endTime'
			    AND
				    l.leadsold = 1
			    {$customerTypeFilter}
			    {$filterByAffiliateID}
			    {$filterByCampaignID}
			    {$originatedFilter}
			    {$andAffiliate}";

	    return $this->slave->fetchRow($sql);
	}

	public function getLeadsPurchased($customerType,$originated,$startDate,$endDate,$startTime,$endTime,$sortBy,$sortOrder,$offset=NULL,$limit=NULL, $campaignID="", $affiliateID="", $affiliateName="") {

	    if (($offset===0 || $offset) && $limit) {
			$limit = "LIMIT $offset,$limit";
		} else {
			$limit = "";
		}

		if ($sortBy == "datetime") {
		    $sortBy = "reportData.originaldate,reportData.originaltime";
		}
		else if ($sortBy == "endtime") {
		    $sortBy = "reportData.endTime";
		}
		else if ($sortBy == "cost") {
		    $sortBy = "reportData.cost";
		}
		else if ($sortBy == "price") {
		    $sortBy = "reportData.price";
		}
		else if ($sortBy == "originated") {
		    $sortBy = "reportData.originated";
		}
		else if ($sortBy == "masteraff") {
		    $sortBy = "reportData.masteraff";
		}
		else if ($sortBy == "variate") {
		    $sortBy = "reportData.leadvariate";
		}
		else if ($sortBy == "multivariate") {
		    $sortBy = "leadmultivariate";
		}
		else {
		    $sortBy = "reportData.".$sortBy;
		}

		$filterByCampaignID = "";
		if ($campaignID != "") {
			$filterByCampaignID = "AND l.campaign IN ({$campaignID})";
		}

		if($affiliateID != "") {
			$filterByAffiliateID = " AND l.affiliateID IN ($affiliateID)";
		}

		$joinAffiliate = "";
		$andAffiliate = "";
		if ($affiliateName != "") {
			$joinAffiliate= "INNER JOIN Affiliates AS a ON l.affiliateID = a.id";
			$andAffiliate = "AND a.masteraff = '$affiliateName'";
		}

	    // get new customers count
	    if ($customerType == 'new') {
		    $joinOnReturningCustomersTable = "LEFT JOIN ReturningCustomers rc ON l.id = rc.leadID";
		    $filter = "AND ISNULL(rc.leadID) ";
	    } else if ($customerType == 'returning') {
		    $joinOnReturningCustomersTable = "LEFT JOIN ReturningCustomers rc ON l.id = rc.leadID";
		    $filter = "AND (rc.leadID) IS NOT NULL ";
	    } else if ($customerType == 'all') {
		    $joinOnReturningCustomersTable = "";
		    $filter = "";
	    }

	    $joinOriginationsTable = $this->getJoiningTableQueryForOrigination();

	    $originatedFilter = "";
	    if ($originated == "originated") {
	        $originatedFilter = "AND orig.leadID IS NOT NULL";
	    }

	    $sql = "SELECT * FROM (SELECT IFNULL(plogs.postSetupID,'0') underwriteiocall,
	            CASE WHEN plogs.postSetupID IS NULL THEN '' ELSE plogs.postresponse END as underwriteioresponse,
	            l.id ,IFNULL(ldpc.code, '') code,l.originaldate,l.originaltime,l.storeID,l.campaign,l.email,
    		    pl.endTime,ps.title postSetupTitle,ps.id as postsetupid,camp.title,ls.cost,ls.price
    		    ,Case WHEN IFNULL(orig.leadID,0) = 0 THEN 'No' ELSE 'Yes' END AS originated,aff.masteraff,
    		    v.name AS leadvariate,mv.name AS leadmultivariate,l.state,l.subid,camp.campaignType, pl.id AS postLogID
			    FROM
				Leads l
			    {$joinOnReturningCustomersTable}
			    LEFT JOIN LECustomerDispositions cdp ON l.email = cdp.email
			    LEFT JOIN LeadDispositionCodes ldpc ON ldpc.id = cdp.dispositionCodeID
			    LEFT JOIN Affiliates aff ON aff.id = l.affiliateID
			    LEFT JOIN PostLogs plogs ON plogs.leadID = l.id AND plogs.postSetupID = 100
			    LEFT JOIN LeadStrategies leadstr ON leadstr.leadID = l.id
			    LEFT JOIN Variates v ON v.id = leadstr.variateID
			    LEFT JOIN MultiVariates mv ON mv.id = leadstr.multiVariateID
			    {$joinOriginationsTable}
			    INNER JOIN PostLogs pl on l.id = pl.LeadID
			    INNER JOIN PostSetups ps on pl.postSetupID = ps.id
			    INNER JOIN Campaigns camp on l.campaign = camp.id
			    INNER JOIN LeadSold ls on l.id = ls.leadID
			    {$joinAffiliate}
			    WHERE
				    l.originaldate >= '$startDate'
			    AND
				    l.originaldate <= '$endDate'
			    AND
				    l.originaltime >= '$startTime'
			    AND
				    l.originaltime <= '$endTime'
			    AND
				    l.leadsold = 1
			    AND
				pl.productcode='cash'
			    AND
				pl.postStatus='accept'
			    {$filter}
			    {$filterByAffiliateID}
			    {$filterByCampaignID}
			    {$originatedFilter}
			    {$andAffiliate}
			    ORDER BY l.id desc,cdp.createdAt desc
			    {$limit}) as reportData ORDER BY $sortBy $sortOrder";

	    return $this->slave->fetchAll($sql);
	}

	public function appendPostLeadAcquisitionData($leadsPurchased) {
		$Campaigns = new Campaigns();
		foreach ( $leadsPurchased AS $key => $lead) {

			$sql = "SELECT
						pl.postresponse,
						cvspa.vendorID
					FROM
						PostLogs pl
					INNER JOIN VendorPosts vp ON pl.id = vp.postLogID
					INNER JOIN CampaignVendorStrategyPostAcquisitions cvspa ON (
						cvspa.vendorStrategyID = vp.vendorStrategyID
						AND pl.campaign = cvspa.campaignID
					)
					WHERE
						pl.leadID = '{$lead['id']}' AND pl.campaign = '{$lead['campaign']}'
					GROUP BY 
						cvspa.vendorStrategyID";

			$result = $this->slave->fetchAll($sql);

			$lead['hasUnderwriteioCall'] = '0';
			$lead['underwriteioresponse'] = '';
			$lead['hasClarityCall'] = '0';
			$lead['claritycallresponse'] = '';

			$CampaignVendorStrategyPostAcquisition = new CampaignVendorStrategyPostAcquisition();
			$clairityMappedWithCampaign = $CampaignVendorStrategyPostAcquisition->getVendorStrategyIDByCampaignIDAndVendorID($lead['campaign'], self::CLARITY_VENDOR_ID);
			$underwriteIOMappedWithCampaign = $CampaignVendorStrategyPostAcquisition->getVendorStrategyIDByCampaignIDAndVendorID($lead['campaign'], self::UNDERWRITEIO_VENDOR_ID);

			$lead['showClarityButton'] = $clairityMappedWithCampaign && $Campaigns->isCampaignSplitOrOrganicType($lead['campaign']) ? '1' : '0';
			$lead['showUnderwriteIOButton'] = $underwriteIOMappedWithCampaign && $Campaigns->isCampaignSplitOrOrganicType($lead['campaign']) ? '1' : '0';

			if ($result) {
				foreach ($result as $value) {
					if ($value['vendorID'] == self::UNDERWRITEIO_VENDOR_ID) {
						$lead['hasUnderwriteioCall'] = '1';
						$lead['underwriteioresponse'] = $value['postresponse'];
					} else if ($value['vendorID'] == self::CLARITY_VENDOR_ID) {
						$lead['hasClarityCall'] = '1';
						$lead['claritycallresponse'] = $value['postresponse'];
					}
				}
			}

			$leadsPurchased[$key] = $lead;
		}
		return $leadsPurchased;
	}

	public function appendClarityPositiveResponseData($leadsPurchased) {
		foreach ( $leadsPurchased AS $key => $lead) {

			$sql = "SELECT 
						*
					FROM 
						PostLogs pl
					WHERE 
						pl.postSetupID = 2018
					AND 
						pl.postResponse LIKE \"%Positive Approve%\"
					AND 
						pl.leadID = '{$lead['id']}'";

			$result = $this->slave->fetchRow($sql);

			if ($result) {
				$lead['hasClarityPositiveResponse'] = '1';
				$lead['hasUnderwriteioCall'] = '1';
				$lead['hasClarityCall'] = '1';
			} else {
				$lead['hasClarityPositiveResponse'] = '0';
			}

			$leadsPurchased[$key] = $lead;
		}
		return $leadsPurchased;
	}
}
