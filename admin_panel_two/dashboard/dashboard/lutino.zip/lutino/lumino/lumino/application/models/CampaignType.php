<?php

class CampaignType extends Zend_Db_Table
{
	protected $_name = 'CampaignTypes';
}
?>
