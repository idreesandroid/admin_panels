<?php

class SettingsController extends Zend_Controller_Action
{
	private $baseurl;

	function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if (!$AdminNameSpace->userid) {
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();
	}

	function indexAction()
	{
		$EngineConfigSetting = new EngineConfigSetting();
		if ($existingRow = $EngineConfigSetting->fetchRow()) {
			$this->view->recentLeadsCheckStatus = $existingRow['recentLeadsCheckStatus'];
			$this->view->recentLeadsCronCutoffDays = $existingRow['recentLeadsCronCutoffDays'];
		}
		$this->view->baseurl = $this->baseurl;
	}

	function processAction() {
		$this->_helper->viewRenderer->setnoRender();

		$EngineConfigSetting = new EngineConfigSetting();

		$message = '';

		if ($this->_request->isPost()) {
			$recentLeadsCheckStatus = $this->_request->getPost('recentLeadsCheckStatus');
			$recentLeadsCronCutoffDays = $this->_request->getPost('recentLeadsCronCutoffDays');

			if (empty($recentLeadsCronCutoffDays)) {
				$message .= "Please provide global duplication cutoff days.<br>";
				$error = 1;
			} else if (!is_numeric($recentLeadsCronCutoffDays)) {
				$message .= "Global duplication cutoff days must be numeric value..<br>";
				$error = 1;
			} else if ($recentLeadsCronCutoffDays < 1) {
				$message .= "Global duplication cutoff days must be greater than 0<br>";
				$error = 1;
			}


			if ($error == 0) {
				$Form_Data = array(
					'recentLeadsCheckStatus' => $recentLeadsCheckStatus,
					'recentLeadsCronCutoffDays' => $recentLeadsCronCutoffDays
				);

				try {
					$EngineConfigSetting->upsert($Form_Data);
					$message = "Settings successfully updated.";
				} catch (Zend_Exception $e) {
					$message = "Some error occurred please try later.";

					echo json_encode(array(
						'e' => true,
						'content' => $message,
					));

					exit;
				}

				echo json_encode(array(
					'e' => false,
					'content' => $message,
				));

			} else {
				echo json_encode(array(
					'e' => true,
					'content' => $message,
				));
			}

		}
	}

	function dlogicAction()
	{
		$message = "";
		$success = 0;

		$DecisionLogicDenialURLs = new DecisionLogicDenialURLs();

		if ($this->_request->isPost()) {
			$url = $this->_request->getPost('failSafeUrl');
			$DecisionLogicDenialURLs->upsert($url);
			$message = "DecisionLogic decline page url successfully saved.";
			$success = 1;

		}

		$row = $DecisionLogicDenialURLs->fetchRow("id = 1");
		$url = $row['url'];

		$this->view->baseurl = $this->baseurl;
		$this->view->message = $message;
		$this->view->success = $success;
		$this->view->failSafeUrl = $url;
	}
}

?>
