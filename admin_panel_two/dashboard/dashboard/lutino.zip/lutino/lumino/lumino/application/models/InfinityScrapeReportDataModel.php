<?php

class InfinityScrapeReportDataModel extends ReportAbstract
{
	public function getTotalRecords($startDate,$endDate) {

	    $sql = "SELECT count(*) total
			    FROM
				InfinityApprovedLoansScrape inf
			    WHERE
				inf.createdDate >= '$startDate'
			    AND
				inf.createdDate <= '$endDate' ";

	    return $this->slave->fetchRow($sql);
	}

	public function getInfinityScrapeData($startDate,$endDate,$sortBy,$sortOrder,$offset,$limit) {

	    $sql = "SELECT * FROM  InfinityApprovedLoansScrape inf
	            WHERE
	            inf.createdDate >= '$startDate'
			    AND
			    inf.createdDate <= '$endDate' ";

	    $sql.=" order by $sortBy $sortOrder limit $offset,$limit";

	    return $this->slave->fetchAll($sql);
	}

	public function getLastScrapeTime()
	{
		$sql = "SELECT max(createdAt) lastScrapeTime FROM InfinityApprovedLoansScrape limit 1";

		$result = $this->slave->fetchRow($sql);

		return $result['lastScrapeTime'];
	}
}
