<?php
class Variate extends Zend_Db_Table
{
	protected $_name = 'Variates';

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}
	public function getAllVariates()
	{
		$sql = "SELECT
					id,
					multiVariateID,
					name,
					createdAt
				FROM
					Variates v";

		$sqlresult = $this->db->fetchAll($sql);

		$result = array();
		foreach ($sqlresult as $v) {
			$data = array("description"=> $v['description'],
						  "priority"=> $v['priority']);
			$result[$v['dataProviderStrategyID']] = $data;
		}

		return $result;
	}

	public function getNameByVariateID($variateID)
	{
		$sql = "SELECT
					name
				FROM
					Variates v
				WHERE
					v.id = $variateID";

		$sqlresult = $this->db->fetchAll($sql);

		$name = "";

		foreach ($sqlresult as $v) {
			$name = $v['name'] ;
		}

		return $name;
	}

	public function updateData($insertData, $variateID)
	{
		$this->update($insertData, $this->_db->quoteInto("id = ?", $variateID));
	}

	public function isThisVariateIDInUseByAnyCampaign($variateID)
	{
		$sql = "SELECT
					count(*)
				FROM
					Variates v
				LEFT JOIN
					MultiVariatesVariates mvv ON v.id = mvv.variateID
				LEFT JOIN
					CampaignsMultiVariates cmv ON mvv.multiVariateID = cmv.multiVariateID
				WHERE
					v.id = $variateID";

		$result = $this->_db->fetchRow($sql);

		if(count($result) > 0) {
			return TRUE;
		}

		return FALSE;
	}

	public function safeDelete($variateID) {
		$MultiVariate = new MultiVariate();
		$MultiVariatesVariate = new MultiVariatesVariate();
		$variates = $MultiVariatesVariate->getDataByVariateID($variateID);

		if ($variates) {
			$variates = $variates->toArray();
			// we have to make sure that we are deleting variate that in use by ONLY one multivariate
			if (count($variates) == 1) {
				foreach ($variates AS $variate) {
					$multivariateID = $variate['multiVariateID'];

					if ($MultiVariate->checkIfSafeToDelete($multivariateID)) {
						$count = $MultiVariate->countVariatesInMultivariateByMultivariateID($multivariateID);
						// if multivariate contains only one variate.. it is static scorecard
						if ($count == 1) {
							$VariateRule = new VariateRule();
							$VariateRule->deleteAllRulesByVariateID($variateID);
							$VariateRuleset = new VariateRuleset();
							$VariateRuleset->deleteByVariateID($variateID);

							$where = "id=$variateID";
							$this->delete($where);

							$where = "variateID=$variateID";
							$VariatesVendorStrategy = new VariatesVendorStrategy();
							$VariatesVendorStrategy->delete($where);

							$where = "variateID=$variateID";
							$MultiVariatesVariate->delete($where);

							$where = "id=$multivariateID";
							$MultiVariate->delete($where);

							$MultiVariateLeadExceptionMultiVariate = new MultiVariateLeadExceptionMultiVariate();
							$MultiVariateLeadExceptionMultiVariate->deleteByMultivariateID($multivariateID);

							return TRUE;
						}
					}
				}
			}
		}

		return FALSE;
	}

	public function isVariateInUseByMultipleMultivariates($variateID) {
		$MultiVariatesVariate = new MultiVariatesVariate();
		$variates = $MultiVariatesVariate->getDataByVariateID($variateID);

		if ($variates) {
			$variates = $variates->toArray();
			// we have to make sure that we are deleting variate that in use by ONLY one multivariate
			if (count($variates) > 1) {
				return TRUE;
			}
		}

		return FALSE;
	}
}
?>