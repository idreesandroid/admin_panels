<?php
/**
 * this class deals with Client Cash Criteria
 */
class ClientCashCriteria
{
	public function __construct()
	{
		$this->db = Zend_Registry::get('db');
	}
	public function all()
	{
		$query = "select cc.*, cc.id as cashCriteriaID, c.* from CashCriteria cc 
			left join PostSetups ps on cc.postSetupID = ps.id 
			left join ClientPostSetups cps on cps.postSetupID = ps.id 
			left join Clients c on c.id = cps.clientID 
			where c.productcode='cash' 
			order by c.company";
		$results = $this->db->fetchAll($query);
		return $results;
	}	
}
