<?php

class DenialReportsSummaryController extends Zend_Controller_Action
{
	public function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if(!$AdminNameSpace->userid)
		{
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();

		$this->config = Zend_Registry::get('config');
	}

	public function indexAction()
	{
		// for building column headers in table
		$InternalRejectCode = new InternalRejectCode();
		$internalCodeHeaders = $InternalRejectCode->fetchAll()->toArray();

		$CriteriaRejectCode = new ClientRejectCode();
		$clientCriteriaCodeHeaders = $CriteriaRejectCode->fetchAll()->toArray();

		$CampaignRejectCode = new CampaignRejectCode();
		$campaignRejectCodeHeaders = $CampaignRejectCode->fetchAll()->toArray();


		$fromDate = ($this->_request->fromDate) ? $this->_request->fromDate : date('Y-m-d');
		$toDate = ($this->_request->toDate) ? $this->_request->toDate : date('Y-m-d');

		$timeStart =  ($this->_request->timeStart) ? $this->_request->timeStart : date("H:i:s", strtotime("Today"));
		$timeEnd =
			($this->_request->timeEnd) ? $this->_request->timeEnd : date("H:i:s", strtotime("Today last second"));
		$selectedStrategy =  ($this->_request->selectedStrategy) ? $this->_request->selectedStrategy : 0;

		$affiliateId = $this->_request->affiliateId;
		$storeIDs = array();
		$storeIDparam = explode(',', $this->_request->storeIDParam);

		foreach ($storeIDparam AS $id) {
			$storeID = "storeID_" . $id;
			if ($this->_request->$storeID == "true") {
				$storeIDs[] = '"'.$id.'"';
			}
		}
		$DenialReportSummary = new DenialReportSummary($fromDate, $toDate, $timeStart, $timeEnd, $selectedStrategy,$affiliateId,$storeIDs);
		$reports = $DenialReportSummary->execute();

		$this->view->internalCodeHeaders = $internalCodeHeaders;
		$this->view->criteriaCodeHeaders = $clientCriteriaCodeHeaders;
		$this->view->campaignCodeHeaders = $campaignRejectCodeHeaders;
		$this->view->affiliateId = $affiliateId;

		// Prepare Scorecard Reject headers
		$scorecardHeaders = $DenialReportSummary->prepareScorecardRejectHeader();
		$this->view->scorecardHeaders = $scorecardHeaders;

		// Prepare Client Reject headers
		$clientsHeaders = $DenialReportSummary->prepareClientRejectHeader();
		$this->view->clientsHeaders = $clientsHeaders;

		// Needed for Totals Row to be aligned properly
		$reports = $DenialReportSummary->prepareReportForTableView($scorecardHeaders, $vendorsHeaders, $clientsHeaders, $reports);

		// Need to get affiliates to be shown in affiliate drop down
		$masteraffData = $DenialReportSummary->getLeadProviders($fromDate, $toDate, $timeStart, $timeEnd);
		$this->view->masteraff =  $masteraffData;

		$Factory = new CampaignReportLMSFactory();
		$CampaignReport	= $Factory->create($this->config->lmsName);
		$storeIDs = array();
		$storeIDs[''] = '';
		foreach ($CampaignReport->getStoreIDs() as $store) {
			if ($store['storeID']) {
				$storeIDs[$store['storeID']] = $store['storeID'];
			}
		}

		$this->view->storeid =  $storeIDs;
		$this->view->reports = $reports;
		$this->view->totalsRow = $DenialReportSummary->totalsRow($reports, array('campaign'));
		$this->view->fromDate = $fromDate;
		$this->view->toDate = $toDate;
		$this->view->timeStart = $timeStart;
		$this->view->timeEnd = $timeEnd;
		$this->view->flashMessages = $this->_helper->flashMessenger->getMessages();

		$strategies = array();
		$strategies[''] = '';
		$select = "<option value=''></option>";
		foreach ($DenialReportSummary->getVendorStrategies() as $strategy) {
			if ($strategy['id']) {
				$name = $strategy['name'];
				$id = $strategy['id'];

				$selected = "";
				if ($selectedStrategy == $id) {
					$selected = "selected='selected'";
				}

				if ($strategy['active'] == 1) {
					$select .= "<option value=$id class='activestrategy' $selected>$name</option>";
				} else if ($strategy['active'] == 0) {
					$select .= "<option value=$id class='noactivestrategy' $selected>$name</option>";
				}
			}
		}

		$this->view->strategies =  $select;

		if ($this->_request->format == 'csv') {
			header("Content-type: text/csv");
			header("Content-Disposition: attachment; filename=denial_report_summary_" . $fromDate . "_" . $toDate . ".csv");
			header("Pragma: no-cache");
			header("Expires: 0");

			$this->_helper->viewRenderer->setNoRender();

			$csvHeaders = $DenialReportSummary->prepareColumnHeadersForCsv($internalCodeHeaders,
				$clientCriteriaCodeHeaders, $campaignRejectCodeHeaders, $scorecardHeaders, $clientsHeaders);
			$totalsRow = $DenialReportSummary->totalsRow($reports, array('campaign'));
			$reportsFormatted = $DenialReportSummary->prepareReportForCsv($csvHeaders,
				$reports,
				$totalsRow,
				$scorecardHeaders,
				$clientsHeaders);
			$csvFile = $DenialReportSummary->makeCsv($csvHeaders, $reportsFormatted);

			echo $csvFile;
		}
	}
	
	public function postsetupAction() {
		// for building column headers in table
		$InternalRejectCode = new InternalRejectCode();
		$internalCodeHeaders = $InternalRejectCode->fetchAll()->toArray();
		$CriteriaRejectCode = new ClientRejectCode();
		$clientCriteriaCodeHeaders = $CriteriaRejectCode->fetchAll()->toArray();
		
		$fromDate = ($this->_request->fromDate) ? 
			$this->_request->fromDate : date('Y-m-d');
		$toDate = ($this->_request->toDate) ? 
			$this->_request->toDate : date('Y-m-d');

		$timeStart =  ($this->_request->timeStart) ? $this->_request->timeStart : date("H:i:s", strtotime("Today"));
		$timeEnd =
			($this->_request->timeEnd) ? $this->_request->timeEnd : date("H:i:s", strtotime("Today last second"));

		$this->view->internalCodeHeaders = $internalCodeHeaders;
		$this->view->criteriaCodeHeaders = $clientCriteriaCodeHeaders;
		
		$DenialReportPostSetupID = new DenialReportCampaignPostSetupIDSummary($fromDate, 
			$toDate, 
			$this->_request->campaignID,
			$timeStart,
			$timeEnd);
		$reports = $DenialReportPostSetupID->execute();
		
		// Prepare Scorecard Reject headers
		$scorecardHeaders = $DenialReportPostSetupID->prepareScorecardRejectHeader();
		$this->view->scorecardHeaders = $scorecardHeaders;

		// Prepare Client Reject headers
		$clientsHeaders = $DenialReportPostSetupID->prepareClientRejectHeader();
		$this->view->clientsHeaders = $clientsHeaders;

		$reports = $DenialReportPostSetupID->prepareReportForTableView($scorecardHeaders, $clientsHeaders, $reports);
		
		
		$this->view->reports = $reports;
		$this->view->fromDate = $fromDate;
		$this->view->toDate = $toDate;
		$this->view->timeStart = $timeStart;
		$this->view->timeEnd = $timeEnd;
		$this->view->campaignID = $this->_request->campaignID;

		$this->view->totalsRow = $DenialReportPostSetupID->totalsRow($reports, array('postSetupID'));
		$this->view->flashMessages = $this->_helper->flashMessenger->getMessages();
		
	}

	public function subidAction()
	{
		// for building column headers in table
		$InternalRejectCode = new InternalRejectCode();
		$internalCodeHeaders = $InternalRejectCode->fetchAll()->toArray();
		$CriteriaRejectCode = new ClientRejectCode();
		$clientCriteriaCodeHeaders = $CriteriaRejectCode->fetchAll()->toArray();
		$CampaignRejectCode = new CampaignRejectCode();
		$campaignRejectCodeHeaders = $CampaignRejectCode->fetchAll()->toArray();

		$fromDate = ($this->_request->fromDate) ? 
			$this->_request->fromDate : date('Y-m-d');
		$toDate = ($this->_request->toDate) ? 
			$this->_request->toDate : date('Y-m-d');

		$timeStart =  ($this->_request->timeStart) ? $this->_request->timeStart : date("H:i:s", strtotime("Today"));
		$timeEnd =
			($this->_request->timeEnd) ? $this->_request->timeEnd : date("H:i:s", strtotime("Today last second"));

		$this->view->internalCodeHeaders = $internalCodeHeaders;
		$this->view->criteriaCodeHeaders = $clientCriteriaCodeHeaders;
		$this->view->campaignCodeHeaders = $campaignRejectCodeHeaders;

		$DenialReportSubID = new DenialReportCampaignSubIDSummary($fromDate, 
			$toDate, 
			$this->_request->campaignID,
			$timeStart,
			$timeEnd);
		$reports = $DenialReportSubID->execute();

		// Prepare Scorecard Reject headers
		$scorecardHeaders = $DenialReportSubID->prepareScorecardRejectHeader();
		$this->view->scorecardHeaders = $scorecardHeaders;

		// Prepare Client Reject headers
		$clientsHeaders = $DenialReportSubID->prepareClientRejectHeader();
		$this->view->clientsHeaders = $clientsHeaders;

		$reports = $DenialReportSubID->prepareReportForTableView($scorecardHeaders, $clientsHeaders, $reports);


		$this->view->reports = $reports;
		$this->view->fromDate = $fromDate;
		$this->view->toDate = $toDate;
		$this->view->timeStart = $timeStart;
		$this->view->timeEnd = $timeEnd;
		$this->view->campaignID = $this->_request->campaignID;
		$this->view->campaignTitle = $DenialReportSubID->getCampaignTitleByCampaignID($this->_request->campaignID);

		$this->view->totalsRow = $DenialReportSubID->totalsRow($reports, array('subid'));
		$this->view->flashMessages = $this->_helper->flashMessenger->getMessages();
	}
}
