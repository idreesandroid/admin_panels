<?php

class InternalRejectCode extends Zend_Db_Table
{
	protected $_name = 'InternalRejectCodes';

	/**
	 * we dont want to display certain rejects. e.g. 119
	 */
	public function getDenialReportHeaders()
	{
		$sql = "select id, name from " . $this->_name . " where id NOT IN(119)";
		$result = $this->_db->fetchAll($sql);

		return $result;
	}
}
