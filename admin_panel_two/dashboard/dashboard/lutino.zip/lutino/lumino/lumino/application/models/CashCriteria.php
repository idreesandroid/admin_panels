<?php
class CashCriteria extends BaseZendDbTable
{
 	protected $_name = 'CashCriteria';

	// validate before saving
	public function insert(array $data)
	{
		$requiredFields = array('monthlyIncomeMin' => $data['monthlyIncomeMin'], 
			'monthlyIncomeMax' => $data['monthlyIncomeMax'],
			'loanAmountMin' => $data['loanAmountMin'],
			'loanAmountMax' => $data['loanAmountMax'],
			'bankAccountMax' => $data['bankAccountMax']);
		$this->validatesPresenceOf($requiredFields);
		$this->validatesNumericalityOf($requiredFields);

		if (count($this->errors) > 0) {
			return FALSE;
		}
		return parent::insert($data);
	}

	// validate before saving
	public function update(array $data, $where)
	{
		$requiredFields = array('monthlyIncomeMin' => $data['monthlyIncomeMin'], 
			'monthlyIncomeMax' => $data['monthlyIncomeMax'],
			'loanAmountMin' => $data['loanAmountMin'],
			'loanAmountMax' => $data['loanAmountMax'],
			'bankAccountMax' => $data['bankAccountMax']);
		$this->validatesPresenceOf($requiredFields);
		$this->validatesNumericalityOf($requiredFields);

		if (count($this->errors) > 0) {
			return FALSE;
		}
		return parent::update($data, $where);
	}

	public function findByID($id)
	{
		$result = $this->fetchRow($this->select()->where("id = $id"));
		return $result;
	}

	public function findByPostSetupID($postSetupID)
	{
		$result = $this->fetchRow($this->select()->where("postSetupID = $postSetupID"));
		return $result;
	}
}
