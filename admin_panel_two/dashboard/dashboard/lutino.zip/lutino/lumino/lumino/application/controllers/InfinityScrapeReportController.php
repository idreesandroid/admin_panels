<?php

class InfinityScrapeReportController extends Zend_Controller_Action
{
	private $baseurl;

	function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if (!$AdminNameSpace->userid) {
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();
	}

	public function indexAction()
	{
		$InfinityScrapeReportDataModel = new InfinityScrapeReportDataModel();

		$this->view->fromDate = date('m/d/Y');
		$this->view->toDate = date('m/d/Y');
		$this->view->timeStart = "00:00:00";
		$this->view->timeEnd = "23:59:59";
		$this->view->lastScrapeTime = $InfinityScrapeReportDataModel->getLastScrapeTime();
	}

	public function getdataAction()
	{
		$this->_helper->viewRenderer->setNoRender();

		$offset = ($this->_request->offset) ? $this->_request->offset : 0;
		$limit  = ($this->_request->limit) ? $this->_request->limit : 100;
		$sortBy = ($this->_request->sort) ? $this->_request->sort : "id";
		$sortOrder = ($this->_request->order) ? $this->_request->order : "DESC";

		$fromDate = ($this->_request->fromDate) ?
			date('Y-m-d', strtotime($this->_request->fromDate)) : date('Y-m-d');
		$toDate = ($this->_request->toDate) ?
			date('Y-m-d', strtotime($this->_request->toDate)) : date('Y-m-d');

		$InfinityScrapeReportDataModel = new InfinityScrapeReportDataModel();

		$dataCount = 	$InfinityScrapeReportDataModel->getTotalRecords($fromDate, $toDate);
		$reportData = $InfinityScrapeReportDataModel->getInfinityScrapeData($fromDate,$toDate,$sortBy,$sortOrder,$offset,$limit);

		$lastScrapeTime = $InfinityScrapeReportDataModel->getLastScrapeTime();

		$data = array('total' => $dataCount['total']);
		$data['rows'] = array();

		foreach($reportData as $rData) {

			$tuple = array();
			$tuple['leadID'] = $rData['leadID'];
			$tuple['homeState'] = $rData['homeState'];
			$tuple['apr'] = $rData['apr'];
			$tuple['loanType'] = $rData['loanType'];
			$tuple['store'] = $rData['store'];
			$tuple['loanNumber'] = $rData['loanNumber'];
			$tuple['name'] = $rData['name'];
			$tuple['loanStatus'] = $rData['loanStatus'];
			$tuple['loanAmount'] = $rData['loanAmount'];
			$tuple['createdDate'] = $rData['createdDate'];
			$tuple['approveDate'] = $rData['approveDate'];
			$tuple['originationDate'] = $rData['originationDate'];
			$tuple['createAdmin'] = $rData['createAdmin'];
			$tuple['newRenew'] = $rData['newRenew'];
			$tuple['advertisingMethod'] = $rData['advertisingMethod'];
			$tuple['email'] = $rData['email'];
			$tuple['processingAdmin'] = $rData['processingAdmin'];
			$tuple['approveAdmin'] = $rData['approveAdmin'];
			$tuple['scrapeUrl'] = $rData['scrapeUrl'];
			$tuple['createdAt'] = $rData['createdAt'];
			$tuple['leadRefID'] = $rData['leadRefID'];
 			$data['rows'][] = $tuple;
		}

		echo json_encode($data);
	}
}
