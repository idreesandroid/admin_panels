<?php

// Define path to application directory
defined('APPLICATION_PATH')
  || define('APPLICATION_PATH', realpath(dirname(__FILE__)));

// Define application environment
defined('APPLICATION_ENV')
|| define('APPLICATION_ENV', (getenv('APPLICATION_ENV') ? getenv('APPLICATION_ENV') : 'development'));

ini_set('include_path', ini_get('include_path').":/software/ZendFramework/ZendFramework/library");
date_default_timezone_set('America/New_York');

// Set the include path for Zend Framework
set_include_path(
    '.' .
    PATH_SEPARATOR . './library'.
    PATH_SEPARATOR . './library/veritec/'.
    PATH_SEPARATOR . './application/models/'.
    PATH_SEPARATOR . './Plugin'.
    PATH_SEPARATOR . get_include_path()
);

// for choosing config file based on the client thats logging in
require_once APPLICATION_PATH . '/../library/ConfigFactory.php';
$ConfigFactory = new ConfigFactory();

/** Zend_Application */
// Create application, bootstrap, and run
require_once 'Zend/Application.php';

$application = new Zend_Application(
	APPLICATION_ENV,
	$ConfigFactory->create($_SERVER)
);

