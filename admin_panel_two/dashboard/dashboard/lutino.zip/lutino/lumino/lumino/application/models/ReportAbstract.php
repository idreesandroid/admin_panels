<?php
/**
 * abstract facade class that handles getting all data for building Reports
 */
class ReportAbstract
{
    public function __construct($fromDate, $toDate, $timeStart, $timeEnd, $selectedStrategy=0,$affiliateId=0,$storeIds=NULL)
	{
		// we want to run all queries against slave db
	    $bootstrap = Zend_Controller_Front::getInstance()->getParam("bootstrap");
		$resource = $bootstrap->getPluginResource('multidb');
		$this->slave = $resource->getDb('slave');

		$this->fromDate = $fromDate;
		$this->toDate = $toDate;
		$this->fromTime = $timeStart;
		$this->toTime = $timeEnd;
		$this->fromDateTime = $fromDate .' ' .$timeStart;
		$this->toDateTime = $toDate .' ' .$timeEnd;
		$this->affiliateId = $affiliateId;
		$this->storeIds = $storeIds;

		$this->strategy = "";
		$this->selectedStrategy = "";
		$this->selectedStrategyID = $selectedStrategy;
		if ($selectedStrategy > 0) {
			$this->strategy = "LEFT OUTER JOIN LeadStrategies ON LeadStrategies.leadID = Leads.id
						LEFT OUTER JOIN Variates ON Variates.id = LeadStrategies.variateID";
			$this->selectedStrategy = "AND Variates.id = $selectedStrategy";
		}
    }

	/**
	 * get all campaigns and organize as array with campaignID as key
	 * @return array
	 */
	public function getCampaigns()
	{
		$sql = "select id,masteraff,title from Campaigns";

		$campaigns = $this->slave->fetchAll($sql);

		$campaignData = array();
		foreach ($campaigns as $campaign) {
			$campaignData['campignid'][$campaign['id']] = $campaign['id'];
			$campaignData['affname'][$campaign['id']] = $campaign['masteraff'];
			$campaignData['campaignTitle'][$campaign['id']] = $campaign['title'];
		}
		return $campaignData;
	}

	public function getLeadAttempts()
	{
		$sql = "select count(1) total,
			replace(campaign,' ','') campaign
			from Leads
			where originaldate >= '" . $this->fromDate . "'
			and originaldate <= '" . $this->toDate . "'
			and originaltime >= '" . $this->fromTime . "'
			and originaltime <= '" . $this->toTime . "'

			group by campaign";

		return $this->slave->fetchAll($sql);
	}

	public function getLeadSold()
	{
		$sql = "select count(1) total,
			replace(Leads.campaign,' ','') campaign ,
			IFNULL(Campaigns.masteraff, 'other') masteraff
			from Leads
			left join Campaigns on Leads.campaign = Campaigns.id
			where originaldate >= '" . $this->fromDate . "'
			and originaldate <= '" . $this->toDate . "'
			and originaltime >= '" . $this->fromTime . "'
			and originaltime <= '" . $this->toTime . "'
			and leadsold = 1
			group by Leads.campaign";

		return $this->slave->fetchAll($sql);
	}

	/**
	 * sums the totals of all array keys
	 *
	 * @param array $reports organized by campaign
	 * @param array $ignoreKeys keys that we dont want totals for. e.g. 'campaign'
	 *
	 * @return array  flattened with keys matching the input array
	 */
	public function totalsRow($reports, $ignoreKeys)
	{
		$totals = array();
		foreach ($reports as $report) {
			foreach ($report as $k => $v) {
				if (in_array($k, $ignoreKeys)) {
					continue;
				}
				$totals[$k] += $v;
			}
		}
		return $totals;
	}


	/**
	 * TODO: rename this as it doesnt actually get the vendor strategy
	 *
	 * Gets Vendor Strategy Names and IDs list
	 *
	 * @return  array	array of all strategy names and IDs
	 */
	public function getVendorStrategies()
	{
		$sql = "SELECT
				Variates.id variateID,
				Variates.`name` variateName,
				active
		        FROM
				Variates
		        LEFT JOIN
				MultiVariatesVariates ON MultiVariatesVariates.variateID = Variates.id
		        LEFT JOIN
				MultiVariates ON MultiVariates.id = MultiVariatesVariates.multiVariateID";

		$result = $this->slave->fetchAll($sql);

		$nresult = array();
		foreach ($result as $v) {
			$data = array();
			$data['variateID'] = $v['variateID'];
			$data['name'] = $v['variateName'];
			$data['active'] = $v['active'];
			$nresult[] = $data;
		}

		return $nresult;
	}

	/*
	 *
	 */
	public function getJoiningTableQueryForOrigination() {

	    $config = Zend_Registry::get('config');
	    $lmsName = $config->lmsName;

	    $joinningTableQuery = "";

	    if ($lmsName == 'tdc') {
	        $joinningTableQuery = "LEFT JOIN Master orig ON l.id = orig.leadID AND orig.Loan_Type = 'S' AND orig.Loan_Status NOT IN ('I', 'V', 'W')";
	    }
	    else if ($lmsName == 'epic') {
	        $joinningTableQuery = "LEFT JOIN EpicLEperformanceOverview orig ON l.id = orig.leadID";
	    }
	    else if ($lmsName == 'infinity') {
	        $joinningTableQuery = "LEFT JOIN InfinityApprovedLoansScrape orig ON l.id = orig.leadID";
	    }
	    else {
	        $joinningTableQuery = "LEFT JOIN Master orig ON l.id = orig.leadID AND orig.Loan_Type = 'S' AND orig.Loan_Status NOT IN ('I', 'V', 'W')";
	    }

	    return $joinningTableQuery;
	}
}
