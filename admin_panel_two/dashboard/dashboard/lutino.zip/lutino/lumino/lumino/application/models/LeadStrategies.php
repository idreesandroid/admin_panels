<?php

class LeadStrategies extends Zend_Db_Table 
{
	protected $_name = 'LeadStrategies';

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}
	public function hasVariateBeenUsedHistorically($arrVariates)
	{
	    $listOfVariates =  implode(',',$arrVariates);
	    $select = $this->select()
		->where('variateID IN (?)', $listOfVariates)
		->limit(1);
	     $result =  $this->fetchAll($select)->toArray();
         if(!empty($result))
		 return true;
	     else
		return false;
	}
	

}
