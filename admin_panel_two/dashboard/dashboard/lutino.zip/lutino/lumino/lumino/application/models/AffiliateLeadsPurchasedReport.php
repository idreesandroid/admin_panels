<?php

class AffiliateLeadsPurchasedReport extends ReportAbstract
{

    public function __construct()
    {
        $bootstrap = Zend_Controller_Front::getInstance()->getParam("bootstrap");
        $resource = $bootstrap->getPluginResource('multidb');
        $this->slave = $resource->getDb('slave');

        $userSession = new Zend_Session_Namespace('UserSession');
        $this->affiliateID = $userSession->userid;
    }

    public function getTotalLeadsPurchased($customerType,$originated,$startDate,$endDate,$startTime,$endTime) {

	    // get new customers count
	    if ($customerType == 'new') {
	        $filter = " ISNULL(rc.leadID) ";
	    }
	    else if ($customerType == 'returning') {
	        $filter = " (rc.leadID) IS NOT NULL ";
	    }

	    $originatedFilter = "";
	    $joinOriginationsTable = "";

	    if ($originated == "originated") {

	        $joinOriginationsTable = $this->getJoiningTableQueryForOrigination();
	        $originatedFilter = "AND orig.leadID IS NOT NULL";
	    }

	    $sql = "SELECT count(*) total
			    FROM
				    Leads l
			    LEFT JOIN ReturningCustomers rc ON l.id = rc.leadID
			    $joinOriginationsTable
			    WHERE
				    l.originaldate >= '$startDate'
			    AND
				    l.originaldate <= '$endDate'
			    AND
				    l.originaltime >= '$startTime'
			    AND
				    l.originaltime <= '$endTime'
			    AND
				    l.leadsold = 1
				AND
				l.affiliateID = $this->affiliateID
			    AND ";
	    $sql.= $filter;
	    $sql.=" ".$originatedFilter;

	    return $this->slave->fetchRow($sql);
	}

	public function getLeadsPurchased($customerType,$originated,$startDate,$endDate,$startTime,$endTime,$sortBy,$sortOrder,$offset,$limit,$campaignID="",$affiliateID="") {

	    if (($offset===0 || $offset) && $limit) {
	        $limit = "LIMIT $offset,$limit";
	    } else {
	        $limit = "";
	    }

	    if ($sortBy == "datetime") {
		    $sortBy = "l.originaldate,l.originaltime";
		}
		else if ($sortBy == "endtime") {
		    $sortBy = "pl.endTime";
		}
		else if ($sortBy == "cost") {
		    $sortBy = "ls.cost";
		}
		else if ($sortBy == "price") {
		    $sortBy = "ls.price";
		}
		else if ($sortBy == "originated") {
		    $sortBy = "originated";
		}
		else if ($sortBy == "masteraff") {
		    $sortBy = "aff.masteraff";
		}
		else if ($sortBy == "variate") {
		    $sortBy = "leadvariate";
		}
		else if ($sortBy == "multivariate") {
		    $sortBy = "leadmultivariate";
		}
		else {
		    $sortBy = "l.".$sortBy;
		}

	    // get new customers count
	    if ($customerType == 'new') {
	        $filter = " ISNULL(rc.leadID) ";
	    }
	    else if ($customerType == 'returning') {
	        $filter = " (rc.leadID) IS NOT NULL ";
	    }

	    $config = Zend_Registry::get('config');
	    $lmsName = $config->lmsName;

	    $joinOriginationsTable = $this->getJoiningTableQueryForOrigination();

	    $originatedFilter = "";
	    if ($originated == "originated") {
	        $originatedFilter = "AND orig.leadID IS NOT NULL";
	    }

	    $sql = "SELECT l.id ,IFNULL(ldpc.code, '') code,l.originaldate,l.originaltime,l.storeID,l.campaign,l.email,
		    pl.endTime,ps.title postSetupTitle,ps.id as postsetupid,camp.title,ls.cost,ls.price
		    ,Case WHEN IFNULL(orig.leadID,0) = 0 THEN 'No' ELSE 'Yes' END AS originated,aff.masteraff,
		    v.name AS leadvariate,mv.name AS leadmultivariate,l.state,l.subid
			    FROM
				Leads l
			    LEFT JOIN ReturningCustomers rc ON l.id = rc.leadID
			    LEFT JOIN LECustomerDispositions cdp ON l.id = cdp.leadID
			    LEFT JOIN LeadDispositionCodes ldpc ON ldpc.id = cdp.dispositionCodeID
			    LEFT JOIN Affiliates aff ON aff.id = l.affiliateID
			    LEFT JOIN LeadStrategies leadstr ON leadstr.leadID = l.id
			    LEFT JOIN Variates v ON v.id = leadstr.variateID
			    LEFT JOIN MultiVariates mv ON mv.id = leadstr.multiVariateID
			    {$joinOriginationsTable}
			    INNER JOIN PostLogs pl on l.id = pl.LeadID
			    INNER JOIN PostSetups ps on pl.postSetupID = ps.id
			    INNER JOIN Campaigns camp on l.campaign = camp.id
			    INNER JOIN LeadSold ls on l.id = ls.leadID
			    WHERE
				    l.originaldate >= '$startDate'
			    AND
				    l.originaldate <= '$endDate'
			    AND
				    l.originaltime >= '$startTime'
			    AND
				    l.originaltime <= '$endTime'
			    AND
				    l.leadsold = 1
			    AND
			        l.affiliateID = $this->affiliateID
				AND
				    pl.productcode='cash'
			    AND
			        pl.postStatus='accept'
			    AND ";
	    $sql.= $filter;
	    $sql.= " ".$originatedFilter;

	    $sql.=" order by $sortBy $sortOrder {$limit}";

	    return $this->slave->fetchAll($sql);
	}
}
