<?php

class PostDelivery extends Zend_Db_Table
{
	protected $_name = 'PostDelivery';

	/**
	 * Gets the Post Delivery for the post setup
	 *
	 * @param		int		$postSetupID		id of post setup
	 *
	 * @return	array					array of post setup
	 */
	public function getPostDeliveryForPostSetup($postSetupID)
	{

		$sql = $this->select()
					->where($this->_db->quoteInto("postSetupID = ?", $postSetupID));

		$result = $this->fetchAll($sql);

		return $result;

	}

	/**
	 * Gets the delivery times for a post setup
	 * 
	 * @param		int		$postSetupID		id of post setup
	 *
	 * @return	array					array of delivery times
	 */
	public function getDeliveryTimesForPostSetup($postSetupID)
	{

		$postDelivery = $this->getPostDeliveryForPostSetup($postSetupID);

		$deliveryTimes = array();

		$DateUtility = new DateUtility();
		$daysOfWeek = $DateUtility->getDaysOfWeek();

		// key for arrays is the day of the week
		foreach($daysOfWeek as $key => $value) { 
			$deliveryTimes[$key] = array("dayOfWeek" => $key);

			foreach($postDelivery as $deliveryData) { 
				if($deliveryData->dayOfWeek == $key) {
					$deliveryTimes[$key] = $deliveryData->toArray();
				}		
			}	
		}

		return $deliveryTimes;
	}

	/**
	 * Saves the delivery days for a post setup
	 *
	 * @param		int		$postSetupID		id of post setup
	 * @param		array	$deliveryDays		array of delivery days
	 *
	 */
	public function saveDeliveryDays($postSetupID, $deliveryDays)
	{

		foreach($deliveryDays as $dayOfWeek => $deliveryTime) { 
			$postDelivery = array("postSetupID" => $postSetupID,
							"dayOfWeek" => $dayOfWeek,
							"startTime" => $deliveryTime['startTime'],
							"endTime" => $deliveryTime['endTime']);

			$this->insert($postDelivery);
		}
	}

}
?>
