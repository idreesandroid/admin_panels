<?php

class ClientPostSetups extends Zend_Db_Table
{
	protected $_name = 'ClientPostSetups';

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}

	/**
	 * @param array $clientIDs
	 * @return array
	 */
	public function findAllByClientIDs($clientIDs)
	{
		$sql = "select * 
			from " . $this->_name . " cps 
			join Clients c on c.id = cps.clientID 
			where cps.clientID IN (" . implode(',', $clientIDs) . ")";

		$results = $this->db->fetchAll($sql);
		return $results;
	}

	/**
	 * @return array
	 */
	public function findAllActive()
	{
		$sql = "select * 
			FROM " . $this->_name . " cps 
			join Clients c on c.id = cps.clientID 
			join PostSetups ps on ps.id = cps.postSetupID 
			WHERE c.active = 1 
			AND ps.active = 1";

		$results = $this->db->fetchAll($sql);
		return $results;
	}
}
