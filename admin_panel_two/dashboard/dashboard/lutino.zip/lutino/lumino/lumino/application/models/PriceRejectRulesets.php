<?php

class PriceRejectRulesets extends Zend_Db_Table
{
	protected $_name = 'PriceRejectRulesets';

	/* function buildRuleset Build ruleset and rules for each ruleset and insert to DB
	 * @param int $variateID
	 * @param string $ruleSets Json encoded rulesets string
	 */
	public function buildRuleset($variateID,$ruleSets)
	{
	    $ruleSets = json_decode($ruleSets);
	    $prevRulesetID = null;

	    foreach ($ruleSets as $ruleSet) {

	        $ruleSetName = $ruleSet->name;
	        $ruleSetPriority = $ruleSet->rulesetPriority;
	        $ruleSetPrice = $ruleSet->rulesetPrice;
	        $ruleSetStoredID = $ruleSet->rulesetStoreID;
	        $ruleSetTierKey = $ruleSet->rulesetTierKey;
	        $ruleSetCustomCode = $ruleSet->customCode;
	        $rulesVendorParams = $ruleSet->rulesVendorParams;
	        $rulesVendorParamsValues = $ruleSet->rulesVendorParamsValues;
	        $rulesVendorParamsOperator = $ruleSet->rulesVendorParamsOperator;
	        $rulesOperators = $ruleSet->ruleOperators;

	        $insertData = array(
	            'variateID' => $variateID,
	            'name' => $ruleSetName,
	            'priority' => $ruleSetPriority,
	            'storeID' => $ruleSetStoredID,
	            'tierKey' => $ruleSetTierKey,
	            'price' => $ruleSetPrice,
	            'customCode' => $ruleSetCustomCode,
	            'referrerPriceRejectRulesetID' => $prevRulesetID
	        );

	        $rulesetIDFromDB = $this->insert($insertData);

	        if ($rulesetIDFromDB) {
	            $this->saveRuleByRulesetID($rulesetIDFromDB, $rulesVendorParams, $rulesVendorParamsOperator, $rulesVendorParamsValues, $rulesOperators);
	        }
	        $prevRulesetID = $rulesetIDFromDB;
	    }
	}

	/* function saveRuleByRulesetID Save price reject rules to DB
	 * @param int $ruleSetID
	 * @param array $rulesVendorParams  vendor parameters
	 * @param array $rulesVendorParamsOperator vendor param comparision operator
	 * @param array $rulesVendorParamsValues vendor rule passing value
	 * @param array $rulesOperators operators between rules
	 */
	public function saveRuleByRulesetID($ruleSetID,$rulesVendorParams,$rulesVendorParamsOperator,$rulesVendorParamsValues,$rulesOperators) {

	    $prevRuleID = null;
	    $priority = 1;
	    $PriceRejectRules = new PriceRejectRules();
	    // Lets process rules for this ruleset
	    for ($a=0;$a<count($rulesVendorParams);$a++) {
	        if($priority == 1) {
	            $insertData = array(
	                'priceRejectRulesetID' => $ruleSetID,
	                'comparisonOperatorID' => $rulesVendorParamsOperator[$a],
	                'vendorResponseParameterID' => $rulesVendorParams[$a],
	                'value' => $rulesVendorParamsValues[$a],
	                'priority' => $priority
	            );
	        }
	        else {
	            $insertData = array(
	                'priceRejectRulesetID' => $ruleSetID,
	                'comparisonOperatorID' => $rulesVendorParamsOperator[$a],
	                'vendorResponseParameterID' => $rulesVendorParams[$a],
	                'value' => $rulesVendorParamsValues[$a],
	                'priority' => $priority,
	                'referrerPriceRejectRuleID' => $prevRuleID,
	                'logicalOperatorID' => $rulesOperators[$a-1]
	            );
	        }
	        // insert into DB
	        $ruleIDFromDB = $PriceRejectRules->insert($insertData);
	        $prevRuleID = $ruleIDFromDB;
	        $priority++;
	    }
	}

	/* function generatePriceRejectRulesetsDataByVariateID
	 * @param int $variateID variateID to get ruleset data for
	 * @return array
	 */
	public function generatePriceRejectRulesetsDataByVariateID($variateID) {

	    $data = array();
	    $PriceRejectRules = new PriceRejectRules();
	    $ruleSets = $this->getRuleSetsByVariateID($variateID);

	    foreach ($ruleSets as $ruleSet) {

	        $tuple = array();
	        $tuple['rulesetname'] = $ruleSet['name'];
	        $tuple['rulesetPriority'] = $ruleSet['priority'];
	        $tuple['rulesetStoreID'] = $ruleSet['storeID'];
	        $tuple['rulesetTierKey'] = $ruleSet['tierKey'];
	        $tuple['rulesetPrice'] = $ruleSet['price'];
	        $tuple['rulesetCustomCode'] = $ruleSet['customCode'];
	        $tuple['rulesetRules'] = $PriceRejectRules->getRulesByPriceRejectRulesetID($ruleSet['id']);
	        $data[] = $tuple;
	    }
	    return $data;
	}

	public function getRuleSetsByVariateID($variateID) {

	    $sql = $this->select() ->where("variateID = ?", $variateID)->order('id asc');
	    return $this->fetchAll($sql);
	}

	public function deletePriceRejectRuleSetsDataByVariateID($variateID) {

	    $sql = $this->select() ->where("variateID = ?", $variateID)->order('id asc');
	    $priceRejectRuleSets = $this->fetchAll($sql);
	    $PriceRejectRules = new PriceRejectRules();

	    foreach ($priceRejectRuleSets as $ruleSet) {
	        $PriceRejectRules->delete("priceRejectRulesetID=".$ruleSet['id']);
	        $this->delete("id=".$ruleSet['id']);
	    }
	}
}
?>
