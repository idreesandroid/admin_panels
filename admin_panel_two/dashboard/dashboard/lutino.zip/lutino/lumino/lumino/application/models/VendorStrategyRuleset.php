<?php

class VendorStrategyRuleset extends Zend_Db_Table
{
	protected $_name = 'VendorStrategyRulesets';

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}

	public function generateRulesetsDataByVendorStrategyID($vendorStrategyID)
	{
		$sql = $this->select()
			->where("vendorStrategyID = " . $vendorStrategyID)
			->order('priority asc');
		$rulesets = $this->fetchAll($sql)->toArray();

		$VendorStrategyRule = new VendorStrategyRule();

		$result = array();
		$iRowCounter = 0;

		$firstRuleset = array();
		$prevRuleset = array();
		foreach ($rulesets as $currentRuleset) {
			$iRowCounter++;

			if ($iRowCounter == 1 && sizeof($rulesets) == 1) {
				$result[] = array(
					'type' => 'ruleset',
					'id' => 'set' . $currentRuleset['id'],
					'name' => $currentRuleset['name'],
					'priority' => $currentRuleset['priority'],
					'rules' => $VendorStrategyRule->generateRulesDataByVendorStrategyRulesetID($currentRuleset['id'])
				);
			}

			if (sizeof($rulesets) > 1) {
				if ($iRowCounter == 1) {
					$firstRuleset = $currentRuleset;
					continue;
				}
				if ($iRowCounter == 2) {
					$result[] = array(
						'type' => 'ruleset',
						'id' => 'set' . $firstRuleset['id'],
						'name' => $firstRuleset['name'],
						'priority' => $firstRuleset['priority'],
						'rules' => $VendorStrategyRule->generateRulesDataByVendorStrategyRulesetID($firstRuleset['id'])
					);
					$result[] = array(
						'type' => 'operator',
						'id' => 'set' . $firstRuleset['id'] . '-set' . $currentRuleset['id'],
						'operatorID' => $currentRuleset['logicalOperatorID'],
						'operatorName' => $this->getLogicalOperatorNameByID($currentRuleset['logicalOperatorID'])
					);
					$result[] = array(
						'type' => 'ruleset',
						'id' => 'set' . $currentRuleset['id'],
						'name' => $currentRuleset['name'],
						'priority' => $currentRuleset['priority'],
						'rules' => $VendorStrategyRule->generateRulesDataByVendorStrategyRulesetID($currentRuleset['id'])
					);
				} else {
					$result[] = array(
						'type' => 'operator',
						'id' => 'set' . $prevRuleset['id'] . '-set' . $currentRuleset['id'],
						'operatorID' => $currentRuleset['logicalOperatorID'],
						'operatorName' => $this->getLogicalOperatorNameByID($currentRuleset['logicalOperatorID'])
					);
					$result[] = array(
						'type' => 'ruleset',
						'id' => 'set' . $currentRuleset['id'],
						'name' => $currentRuleset['name'],
						'priority' => $currentRuleset['priority'],
						'rules' => $VendorStrategyRule->generateRulesDataByVendorStrategyRulesetID($currentRuleset['id'])
					);
				}
			}

			$prevRuleset = $currentRuleset;
		}
		return $result;
	}

	public function getLogicalOperatorNameByID($operatorID)
	{
		if (!$operatorID) {
			return null;
		}
		$sql = "SELECT
					*
				FROM
					LogicalOperators lo
				WHERE
					lo.id = $operatorID";

		$operator = $this->db->fetchRow($sql);
		return $operator['name'];
	}

	public function findByID($id) {
		$sql = $this->select()
			->where("id = " . $id);
		return $this->fetchRow($sql);
	}

	public function deleteByVendorStrategyID($vendorStrategyID)
	{
		if ($this->hasRulesetsWithVendorStrategyID($vendorStrategyID)) {
			$this->delete('vendorStrategyID='. $vendorStrategyID);
		}
	}

	public function deleteByID($rulesetID)
	{
		$existingRow = $this->findByID($rulesetID);
		if ($existingRow) {
			$this->delete('id='. $rulesetID);
		}
	}

	/**
	 * Updates or inserts a row
	 */
	public function upsert($id,$vendorStrategyID ,$insertData)
	{
		//$existingRow = $this->findByID($id);

		$sql = $this->select()
		->where("id = ?",$id)
		->where("vendorStrategyID = ?",$vendorStrategyID);

		$existingRow = $this->fetchRow($sql);

		if($existingRow) {
			$this->update($insertData, $this->_db->quoteInto("id = ?", $existingRow['id']));
			return $id;
		}
		else {
			return $this->insert($insertData);
		}
	}



	public function hasRulesetsWithVendorStrategyID($vendorStrategyID) {
		$sql = $this->select()
			->from($this->_name, array("count(*) AS amount"))
			->where($this->_db->quoteInto($this->_name . ".vendorStrategyID = ?", $vendorStrategyID));

		$result = $this->_db->fetchRow($sql);
		if ($result['amount'] < 1) {
			return FALSE;
		}
		return TRUE;
	}

	public function getAllByVendorStrategyID($vendorStrategyID) {
		$sql = $this->select()
			->where("vendorStrategyID = " . $vendorStrategyID)
			->order('priority asc');
		return $this->fetchAll($sql);
	}

	/**
	 * This method deletes all old rulesets with their rules that we had before
	 * @param $rulesets - rulesets old and new
	 * @param $rulesetIds - new rulesets IDs that we should keep
	 */
	public function deleteOldRulesets($vendorStrategyID, $rulesetIds) {
		$rulesets = $this->getAllByVendorStrategyID($vendorStrategyID);
		if ($rulesets) {
			$rulesets = $rulesets->toArray();
			$VendorStrategyRule = new VendorStrategyRule();
			$size = count($rulesets);
			for ($i = 0; $i < $size; $i++) {
				if (!in_array($rulesets[$i]['id'], $rulesetIds)) {
					$VendorStrategyRule->deleteByRulesetID($rulesets[$i]['id']);
					$this->deleteByID($rulesets[$i]['id']);
				}
			}
		}
	}

	public function findOperatorValueByRulesetID($rulesetOperators, $id) {
		foreach ($rulesetOperators as $operator) {
			$expload = explode('-',$operator['id']);
			$rulesetID = $expload['0'];
			if ('set'.$id == $rulesetID) {
				return $operator['value'];
			}
		}
		return null;
	}


	/**
	 * @param $rulesets
	 * @param $strategyId
	 * @param $rulesetOperators
	 * @param $ruleIDs
	 * @param $ruleData
	 * @param $ruleOperators
	 */
	public function buildRuleset($rulesets, $strategyId, $rulesetOperators, $ruleIDs, $ruleData, $ruleOperators)
	{
		$upsertedRulesetIDs = array();
		$VendorStrategyRuleset = new VendorStrategyRuleset();
		$VendorStrategyRule = new VendorStrategyRule();
		if (!isset($rulesets)) {
			$VendorStrategyRule->deleteAllRulesByVendorStrategyID($strategyId);
			$VendorStrategyRuleset->deleteByVendorStrategyID($strategyId);
		} else {
			$prevRulesetID = 0;
			foreach ($rulesets AS $ruleset) {
				$rulesetID = $ruleset['id'];
				$name = $ruleset['name'];
				$priority = $ruleset['priority'];
				$extractedID = substr($rulesetID, strlen('set'));
				if ($priority == 1) {
					$rulesetDataForSave = array(
						'vendorStrategyID' => $strategyId,
						'name' => $name,
						'priority' => $priority);
				} else {
					$rulesetDataForSave = array(
						'vendorStrategyID' => $strategyId,
						'name' => $name,
						'priority' => $priority,
						'referrerVendorStrategyRulesetID' => $prevRulesetID,
						'logicalOperatorID' => $this->getRulesetOperatorValueByRulesetID($rulesetOperators, $rulesetID));
				}
				$rulesetIDFromDB = $VendorStrategyRuleset->upsert($extractedID,$strategyId,$rulesetDataForSave);
				if ($ruleIDs && $ruleData) {
					$this->saveRuleByRulesetID($ruleIDs, $ruleData, $ruleOperators, $rulesetID, $rulesetIDFromDB);
				} else {
					$VendorStrategyRule->deleteAllRulesByVendorStrategyID($strategyId);
				}
				$prevRulesetID = $rulesetIDFromDB;
				$upsertedRulesetIDs[] = $rulesetIDFromDB;
			}
		}
		$VendorStrategyRuleset->deleteOldRulesets($strategyId, $upsertedRulesetIDs);
	}

	function saveRuleByRulesetID($ruleIDs, $ruleData, $ruleOperators, $rulesetID, $createdByDBRulesetID) {
		$VendorStrategyRule = new VendorStrategyRule();
		$prevRuleID = null;
		$upsertedRuleIDs = array();
		foreach ($ruleIDs AS $rule) {
			$id = $rule['id'];
			$priority = $rule['priority'];

			$exploded = explode('-', $id);
			$extratectedRulesetID = $exploded[0];
			$extratectedRuleID = $exploded[1];

			$extractedID = substr($extratectedRuleID, strlen('rule'));
			if ($rulesetID == $extratectedRulesetID) {
				if ($priority == 1) {
					$ruleDataForSave = array(
						'vendorStrategyRulesetID' => $createdByDBRulesetID,
						'comparisonOperatorID' => $this->getParamValueByParamName($ruleData, 'operators', $extratectedRulesetID, $extratectedRuleID),
						'vendorResponseParameterID' => $this->getParamValueByParamName($ruleData, 'vendorparams', $extratectedRulesetID, $extratectedRuleID),
						'value' => $this->getParamValueByParamName($ruleData, 'paramvalue', $extratectedRulesetID, $extratectedRuleID),
						'priority' => $priority);
				} else {
					$ruleDataForSave = array(
						'vendorStrategyRulesetID' => $createdByDBRulesetID,
						'comparisonOperatorID' => $this->getParamValueByParamName($ruleData, 'operators', $extratectedRulesetID, $extratectedRuleID),
						'vendorResponseParameterID' => $this->getParamValueByParamName($ruleData, 'vendorparams', $extratectedRulesetID, $extratectedRuleID),
						'value' => $this->getParamValueByParamName($ruleData, 'paramvalue', $extratectedRulesetID, $extratectedRuleID),
						'priority' => $priority,
						'referrerVendorStrategyRuleID'=>$prevRuleID,
						'logicalOperatorID' => $this->getRuleOperatorValueByRulesetIDAndRuleID($ruleOperators, $extratectedRulesetID, $extratectedRuleID));
				}

				$ruleIDFromDB = $ruleIDFromDB = $VendorStrategyRule->upsert($extractedID,$rulesetID,$ruleDataForSave);
				$prevRuleID = $ruleIDFromDB;
				$upsertedRuleIDs[] = $ruleIDFromDB;
			}
		}
		$VendorStrategyRule->deleteOldRules($createdByDBRulesetID, $upsertedRuleIDs);
	}

	function getParamValueByParamName($ruleData, $paramName, $rulesetID, $ruleID) {
		foreach ($ruleData AS $data) {
			$id = $data['id'];
			$value = $data['value'];

			$result = explode('-', $id);
			$currentRulesetID = $result[0];
			$currentRuleID = $result[1];
			$currentRuleParamName = $result[2];

			if (($currentRulesetID == $rulesetID) AND
				($currentRuleID == $ruleID) AND
				($currentRuleParamName == $paramName)) {
				return $value;
			}
		}
		return null;
	}


	function getRuleOperatorValueByRulesetIDAndRuleID($ruleOperators, $rulesetID, $ruleID) {
		foreach ($ruleOperators AS $ruleOperator) {
			$ruleOperatorID = $ruleOperator['id'];
			$value = $ruleOperator['value'];

			$result = explode('-', $ruleOperatorID);
			$rulesetIDOne = $result[0];
			$ruleseIDOne = $result[1];
			$rulesetIDTwo = $result[2];
			$ruleIDTwo = $result[3];

			if ($rulesetIDTwo == $rulesetID AND $ruleIDTwo == $ruleID) {
				return $value;
			}
		}
		return null;
	}


	function getRulesetOperatorValueByRulesetID($rulesetOperators, $rulesetID) {
		foreach ($rulesetOperators AS $rulesetOperator) {
			$rulesetOperatorID = $rulesetOperator['id'];
			$value = $rulesetOperator['value'];

			$result = explode('-', $rulesetOperatorID);
			$rulsetIDOne = $result[0];
			$rulsetIDTwo = $result[1];

			if ($rulsetIDTwo == $rulesetID) {
				return $value;
			}
		}
		return null;
	}
}
