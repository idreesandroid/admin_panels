<?php

class TimeblockController extends Zend_Controller_Action 
{

	public function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if(!$AdminNameSpace->userid)
		{
			$this->_redirect('index/login');	
		}
		$this->baseurl = $this->_request->getBaseUrl();

		$this->PostDelivery = new PostDelivery();
		$this->ClientPostSetupTimeBlockCap = new ClientPostSetupTimeBlockCap();

	}
		
	public function editAction()
	{

		$postSetupID = $this->_request->postSetupID;

		$deliveryDays = $this->PostDelivery->getDeliveryTimesForPostSetup($postSetupID);

		$timeBlocks = $this->ClientPostSetupTimeBlockCap->getFullDayBlocksForPostSetup($postSetupID);

		$this->view->postSetupID = $postSetupID;
		$this->view->daysOfWeek = DateUtility::getDaysOfWeek();
		$this->view->deliveryDays = $deliveryDays;
		$this->view->timeBlocks = $timeBlocks;	
		$this->view->messages = $this->_helper->flashMessenger->getMessages();
	}

	public function updateAction()
	{

          if ($this->_request->isPost()) {

			$postSetupID = $this->_request->postSetupID;

			$deliveryDays = $this->_request->deliveryDays;

			$timeBlocks = $this->_request->timeBlocks;

			foreach($deliveryDays as $day => $dayTimes) { 
				if($dayTimes['checked'] && $dayTimes['startTime'] >= $dayTimes['endTime']) {
					$this->_helper->flashMessenger->addMessage("day: " . $day . " start time can't be greater than or equal to the end time");
					$this->_redirect("timeblock/edit?postSetupID=" . $postSetupID);
				}
			}

			$this->PostDelivery->delete($this->PostDelivery->getAdapter()->quoteInto("postSetupID = ?", $postSetupID));
			$this->PostDelivery->saveDeliveryDays($postSetupID, $deliveryDays);
	
			$this->ClientPostSetupTimeBlockCap->delete($this->PostDelivery->getAdapter()->quoteInto("postSetupID = ?", $postSetupID));
			$this->ClientPostSetupTimeBlockCap->saveTimeBlocks($postSetupID, $timeBlocks);

			$this->_helper->flashMessenger->addMessage("Delivery Days saved successfully");

			$this->_redirect("timeblock/edit?postSetupID=" . $postSetupID);

		}
	}	
}
?>
