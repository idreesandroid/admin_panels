<?php
class ValidPostals extends BaseZendDbTable
{
	protected $_name = 'validpostals';

	public function getProvinces()
	{
		$select = $this->select()
			->distinct()
			->from($this,array("province" => "province"))
			->order("province");
		$result = $this->fetchAll($select);

		return $result;
	}
}
