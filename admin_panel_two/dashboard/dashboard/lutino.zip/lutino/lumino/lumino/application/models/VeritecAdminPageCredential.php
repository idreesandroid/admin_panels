<?php
/**
 * this table handles credentials for Veritec
 */
class VeritecAdminPageCredential extends Zend_Db_Table
{
	protected $_name = 'VeritecAdminPageCredentials';

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}

	/**
	 * Updates the row
	 * @param $username
	 * @param $password
	 * @return int
	 */

	public function save($username, $password)
	{
		$data = array('username' => $username, 'password' => $password);
		$result = $this->fetchAll();


		if (isset($result)) {
			if ($result->count() == 0) {
				$this->insert($data);
			} else {
				$where = array(
					'id = ?' => $result->current()->id
				);

				$this->update($data, $where);
			}
			return true;
		}

		return false;
	}

	/**
	 * @return bool|Zend_Db_Table_Row_Abstract
	 */
	public function getCurrentCredentials()
	{
		$result = $this->fetchAll();

		if (isset($result)) {
			if ($result->count() > 0) {
				return $result->current();
			}
		}

		return false;
	}


}

