<?php

class DecisionLogicStrategyRules extends Zend_Db_Table
{
	protected $_name = 'DecisionLogicStrategyRules';

}
?>