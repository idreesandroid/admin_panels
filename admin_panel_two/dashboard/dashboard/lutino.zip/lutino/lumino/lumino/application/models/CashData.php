<?php
class CashData extends Zend_Db_Table
{
	protected $_name = 'CashData';

}
