<?php
/**
 * this table handles credentials for FactorTrust
 */
class FTCredentials extends Zend_Db_Table 
{
	protected $_name = 'FTCredentials';
	const VENDOR_ID = 19;

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}

	public function getDefault()
	{
		$row = $this->fetchRow("isDefault = 1");
		if ($row)
			$row = $row->toArray();

		return($row);
	}

	/**
	 * Updates or inserts a row
	 */
	public function upsert($vendorStrategyID, $insertData)
	{
		$existingRow = $this->findByID($vendorStrategyID);

		if($existingRow) {
			$this->update($insertData, $this->_db->quoteInto("id = ?", $existingRow['id']));
			return $existingRow['id'];
		}
		else {
			return $this->insert($insertData);
		}
	}

	public function findByID($vendorStrategyID) {
		$FTCredentialsVendorStrategy = new FTCredentialsVendorStrategy();
		$result = $FTCredentialsVendorStrategy->findByVendorStrategyID($vendorStrategyID);
		if ($result['FTCredentialID']) {
			$sql = $this->select()
				->where("id = " . $result['FTCredentialID']);
			return $this->fetchRow($sql);
		}
	}
}

