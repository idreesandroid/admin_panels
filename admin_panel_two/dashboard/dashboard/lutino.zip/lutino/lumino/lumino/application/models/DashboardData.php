<?php

class DashboardData {


    public function __construct()
    {
        // we want to run all queries against slave db
        $bootstrap = Zend_Controller_Front::getInstance()->getParam("bootstrap");
        $resource = $bootstrap->getPluginResource('multidb');
        $this->slave = $resource->getDb('slave');
    }

    /**
     *
     * Gets total new customers originated
     *
     * @param	fromDate  date    start of date range
     * @param	toDate    date    end of date range
     *
     * @return	int	number of customers originated
     */
    public function getTotalNewCustomersOriginations($fromDate,$toDate,$affiliateID = "", $campaignID = "") {
	    if($affiliateID) {
		    $affiliateID = " AND l.affiliateID IN($affiliateID)";
	    }

	    if ($campaignID != "") {
		    $campaignID = " AND l.campaign IN($campaignID)";
	    }

        $sql = "SELECT
					count(1) total
				FROM
				Master m
				LEFT JOIN Leads l ON l.id = m.leadID
				LEFT JOIN ReturningCustomers rc ON l.id = rc.leadID
				WHERE
					m.Loan_Type = 'S'
				AND m.Loan_Status NOT IN ('I', 'V', 'W')
				AND LEFT(m.Loan_Date, 10) >= '" . $fromDate . "'
				AND LEFT(m.Loan_Date, 10) <= '" . $toDate . "'
				AND
					l.leadsold = 1
				{$affiliateID}
				{$campaignID}
				AND ISNULL(rc.leadID)";

        $result = $this->slave->fetchRow($sql);
        return $result['total'];
    }
}