<?php

class VariatesVendorStrategy extends Zend_Db_Table 
{
	protected $_name = 'VariatesVendorStrategies';

	public function findAllByVariateID($variateID)
	{
		$sql = $this->select()
			->where("variateID = " . $variateID)
			->order('id asc');
		return $this->fetchAll($sql);
	}
	
	
	public function getVariatesByVendorStrategy($vendorStrategyId)// retrives an array of variates containing a specific vendor strategy
	{
	   $select = $this->select()
		->from($this, 'variateID')
		->distinct()
		->where("vendorStrategyID = " . $vendorStrategyId);
	    $assocArray = $this->fetchAll($select)->toArray();
	    $returnArray = array();
	    foreach($assocArray as $a)
		array_push($returnArray, $a['variateID']);
	    return $returnArray;
	  
	}
}

	