<?php
/**
 * this table handles credentials for Brite Verify
 */
class BriteVerifyCredentials extends Zend_Db_Table 
{
	protected $_name = 'BriteVerifyCredentials';

	const BRITE_VERIFY_EMAIL_CHECK_VENDOR_ID = 11;

	public function init()
	{
	    $this->db = Zend_Registry::get('db');
	}

	public function getDefault()
	{
	    $row = $this->fetchRow("isDefault = 1");
	    if ($row)
		$row = $row->toArray();

	    return($row);
	}
	
	/**
	 * Updates or inserts a row
	 */
	public function upsert($vendorStrategyID, $insertData)
	{
		$existingRow = $this->findByVendorStrategyID($vendorStrategyID);

		if($existingRow) {
			$this->update($insertData, $this->_db->quoteInto("id = ?", $existingRow['id']));
			return $existingRow['id'];
		}
		else {
			return $this->insert($insertData);
		}
	}
	
	public function findByVendorStrategyID($vendorStrategyID) {
            
		$BriteVerifyCredentialsVendorStrategies = new BriteVerifyCredentialsVendorStrategies();
		$result = $BriteVerifyCredentialsVendorStrategies->findByVendorStrategyID($vendorStrategyID);
		if ($result['BriteVerifyCredentialID']) {
			$sql = $this->select()
				->where("id = " . $result['BriteVerifyCredentialID']);
			return $this->fetchRow($sql);
		}
	}
}

