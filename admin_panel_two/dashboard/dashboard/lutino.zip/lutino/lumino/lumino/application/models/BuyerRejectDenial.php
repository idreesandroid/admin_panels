<?php

class BuyerRejectDenial extends Zend_Db_Table
{
	protected $_name = 'BuyerRejectDenials';


	public function getClientNameDenyQuery()
	{

		$sql = $this->_db->select()
			->from("BuyerRejectDenials", array())
			->joinInner("PostLogs", "PostLogs.id = BuyerRejectDenials.postLogID", array())
			->joinInner("ClientPostSetups", "PostLogs.postSetupID = ClientPostSetups.postSetupID", array())
			->joinInner("Clients", "ClientPostSetups.clientID = Clients.id", array("vendorName" => "company"))
			->where('PostLogs.leadID = Leads.id')
			->where('PostLogs.productCode = "cash"')
			->where('PostLogs.postStatus = "no"')
			->limit(1);

		return $sql;
	}

	public function getClientDenyReasonQuery()
	{

		$sql = $this->_db->select()
			->from("BuyerRejectDenials", array("denyDescription" => "parsedDenialMessage"))
			->joinInner("PostLogs", "PostLogs.id = BuyerRejectDenials.postLogID", array())
			->where('PostLogs.leadID = Leads.id')
			->where('PostLogs.productCode = "cash"')
			->where('PostLogs.postStatus = "no"')
			->limit(1);

		return $sql;
	}
}
