<?php
/**
 * this table handles credentials for Clarity
 */
class ClarityCredentials extends Zend_Db_Table 
{
	protected $_name = 'ClarityCredentials';

	const VENDOR_ID = 22;

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}

	public function getDefault()
	{
		$row = $this->fetchRow("isDefault = 1");
		if ($row)
			$row = $row->toArray();

		return($row);
	}

	/**
	 * Updates or inserts a row
	 */
	public function upsert($vendorStrategyID, $insertData)
	{
		$existingRow = $this->findByID($vendorStrategyID);

		if($existingRow) {
			$this->update($insertData, $this->_db->quoteInto("id = ?", $existingRow['id']));
			return $existingRow['id'];
		}
		else {
			return $this->insert($insertData);
		}
	}

	public function findByID($vendorStrategyID) {
		$ClarityCredentialsVendorStrategy = new ClarityCredentialsVendorStrategy();
		$result = $ClarityCredentialsVendorStrategy->findByVendorStrategyID($vendorStrategyID);
		if ($result['clarityCredentialID']) {
			$sql = $this->select()
				->where("id = " . $result['clarityCredentialID']);
			return $this->fetchRow($sql);
		}
	}
}

