<?php
/**
 *
 */
class VendorScores extends Zend_Db_Table
{
	protected $_name = 'VendorScores';
}
?>