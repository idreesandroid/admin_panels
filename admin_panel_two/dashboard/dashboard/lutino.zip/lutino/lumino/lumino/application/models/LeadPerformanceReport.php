<?php

// Model class to get Lead performance report by store state and price

class LeadPerformanceReport {

    public function __construct($fromDate, $toDate, $timeStart, $timeEnd) {

        // we want to run all queries against slave db
        $bootstrap = Zend_Controller_Front::getInstance()->getParam("bootstrap");
        $resource = $bootstrap->getPluginResource('multidb');
        $this->slave = $resource->getDb('slave');

        $this->fromDate = $fromDate;
        $this->toDate = $toDate;
        $this->fromTime = $timeStart;
        $this->toTime = $timeEnd;
    }

    public function getReportData() {

        $sql = "select
                l.storeid,
                l.state,
                lsold.price price,
                lsold.sold as leadsPurchased,
                IFNULL(totalLoansOrigSameDayPurchased,0) totalLoansOrigSameDayPurchased,
                IFNULL(totalLoansOrig,0) totalLoansOrig,
                lsold.totalPrice,
                IFNULL(loanamountfunded,0) loanamountfunded,
                IFNULL(scrubbingcost,0) scrubbingcost,
                firstleadpurchased,
                lastleadpurchased,
				(totalLoansOrig/lsold.sold)*100 totalConversion,
				((lsold.totalPrice+scrubbingcost)/loanamountfunded)*100 costPerHundredFunded
                from Leads l
                left join
                (
                    select count(ls.id) as sold,storeid,state,price,
                    SUM(ls.price) as totalPrice
                    from Leads l left join LeadSold ls
                    on l.id = ls.leadID
                    where l.originalDate >= '$this->fromDate'
                    and l.originalDate <= '$this->toDate'
                    group by l.storeid, l.state, price
                ) lsold on l.state = lsold.state and l.storeid = lsold.storeid
                left join
                (
                    select count(*) as totalLoansOrigSameDayPurchased, storeid,state,ls.price
                   from InfinityApprovedLoansScrape inf
                   inner join Leads l on l.id = inf.leadID
                   inner join LeadSold ls on ls.leadid = l.id
                   and l.originaldate >= '$this->fromDate'
                   and l.originaldate <= '$this->toDate'
                   and l.originaldate = inf.approveDate
                   and inf.leadID is not null
                   group by l.storeid, l.state,ls.price
                ) inf on l.state = inf.state and l.storeid = inf.storeid and lsold.price = inf.price
                left join
                (
                    select count(*) as totalLoansOrig, storeid,state,ls.price
                   from InfinityApprovedLoansScrape inf
                   inner join Leads l on l.id = inf.leadID
                   inner join LeadSold ls on ls.leadid = l.id
                   and l.originaldate >= '$this->fromDate'
                   and l.originaldate <= '$this->toDate'
                   and inf.leadID is not null
                   group by l.storeid, l.state,ls.price
                ) inforg on l.state = inforg.state and l.storeid = inforg.storeid and lsold.price = inforg.price

                left join
                (
                    select sum(inf.loanAmount) as loanamountfunded,storeid,state,ls.price
                    from InfinityApprovedLoansScrape inf
                    inner join Leads l on l.id = inf.leadID
                    inner join LeadSold ls on ls.leadid = l.id
                    where
                    inf.createdDate >= '$this->fromDate'
                    and inf.createdDate <= '$this->toDate'
                    and inf.leadID is not null
                    group by l.storeid, l.state,ls.price
                ) infamtfun on l.state = infamtfun.state and l.storeid = infamtfun.storeid and lsold.price = infamtfun.price
                left join
                (
                    select sum(pl.cost) as scrubbingcost, storeid,state,ls.price
                   from PostLogs  pl
                   inner join Leads l on l.id = pl.leadID
                   left join LeadSold ls on ls.leadid = l.id
                   where pl.productCode = 'scoring'
                   and pl.postDate >= '$this->fromDate'
                   and pl.postDate <= '$this->toDate'
                   group by l.storeid, l.state, ls.price

                ) plogs on l.state = plogs.state and l.storeid = plogs.storeid and lsold.price <=> plogs.price
                left join
                (
                    select MIN(originaltime) firstleadpurchased,MAX(originaltime) lastleadpurchased,storeid,state,ls.price
                    FROM
                    Leads l inner join LeadSold ls on ls.leadid = l.id
                    where l.leadsold = 1
                    and l.originaldate >= '$this->fromDate'
                    and l.originaldate <= '$this->toDate'
                    group by l.storeid, l.state,ls.price
                ) lpurchased on l.state = lpurchased.state and l.storeid = lpurchased.storeid and lsold.price = lpurchased.price
                where originaldate >= '$this->fromDate'
                and originaldate <= '$this->toDate'
                group by l.storeid, l.state, lsold.price";

        return $this->slave->fetchAll($sql);
    }

    public function getPaginationTotals() {

        $sql = "SELECT count(*) as total FROM
        (
            select
                l.storeid,
                l.state,
                ls.price
                from Leads l
                left join LeadSold ls on ls.leadid = l.id
                where originaldate >= '$this->fromDate'
                and originaldate <= '$this->toDate'
                group by l.storeid, l.state, ls.price
        ) t";

        return $this->slave->fetchRow($sql);
    }
}
