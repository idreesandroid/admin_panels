<?php
/**
 * facade class that handles getting all data for building 
 * Denial Report subID breakdown for a specific Campaign
 */
class DenialReportCampaignSubID extends DenialReportCampaignSubIDAbstract
{
    public function __construct($fromDate, $toDate, $campaignID, $timeStart, $timeEnd)
	{
		// we want to run all queries against slave db
	    $bootstrap = Zend_Controller_Front::getInstance()->getParam("bootstrap");
		$resource = $bootstrap->getPluginResource('multidb');
		$this->slave = $resource->getDb('slave');

		$this->fromDate = $fromDate;
		$this->toDate = $toDate;
		$this->campaignID = $campaignID;
		$this->fromTime = $timeStart;
		$this->toTime = $timeEnd;
		$this->fromDateTime = $fromDate .' ' .$timeStart;
		$this->toDateTime = $toDate .' ' .$timeEnd;
    }

	/**
	 * this is the main interface to this class
	 * @return array
	 */
	public function execute()
	{
		$reports = array();

		$subIDs = $this->getSubIDs();

		$internals = $this->getInternalRejects();
		$clientCriterias = $this->getClientCriteriaRejects();
		$vendors = $this->getVendorRejects();
		$clients = $this->getClientRejects();
		$campaignRejects = $this->getCampaignRejects();
		$leads = $this->getLeadAttempts();
		$leadSold = $this->getLeadSold();
		$preCheckedVendorRejects = $this->getVendorRejectsByRejectCode(VendorRejectCode::CUST_DENIED_IN_THE_PAST);
		$timeoutVendorRejects = $this->getVendorRejectsByRejectCode(VendorRejectCode::API_TIMEOUT);
		$vendorstrategyVendorRejects = $this->getVendorRejectsByRejectCode(VendorRejectCode::VENDORSTRATEGY_RULE_FAILED);

		// adding to final report array
		foreach ($internals as $k => $v) {
			if (in_array($v['subid'], $subIDs)) {
				$reports[$v['subid']]['internalRejects'][] = $internals[$k];
			}
		}
		foreach ($clientCriterias as $k => $v) {
			if (in_array($v['subid'], $subIDs)) {
				$reports[$v['subid']]['clientCriteriaRejects'][] = $clientCriterias[$k];
			}
		}
		foreach ($campaignRejects as $k => $v) {
			if (in_array($v['subid'], $subIDs)) {
				$reports[$v['subid']]['campaignRejects'][] = $campaignRejects[$k];
			}
		}

		foreach ($vendors as $k => $v) {
			$reports[$v['subid']]['vendorRejects'][$v['postSetupID']] = $v['total'];
		}
		foreach ($clients as $k => $v) {
			$reports[$v['subid']]['clientRejects'][$v['postSetupID']] = $v['total'];
		}
		foreach ($leads as $k => $v) {
			$reports[$v['subid']]['leadAttempts'] = $v['total'];
		}
		foreach ($leadSold as $k => $v) {
			$reports[$v['subid']]['leadSold'] = $v['total'];
		}

		foreach ($preCheckedVendorRejects as $k => $v) {
			$reports[$v['subid']]['preCheckedVendorRejects'] = $v['total'];
		}

		foreach ($timeoutVendorRejects as $k => $v) {
			$reports[$v['subid']]['timeoutVendorRejects'] = $v['total'];
		}

		foreach ($vendorstrategyVendorRejects as $k => $v) {
			$reports[$v['subid']]['vendorstrategyVendorRejects'] = $v['total'];
		}

		$reports = $this->restructureForView($reports);

		return $reports;
	}

	/**
	 * NOTE: maybe make this a view helper.
	 * It reformats the array so we can plug it right into the view.
	 * (each array key is the html table column)
	 *
	 * format: [['xxxx'] => ['subid'] => 'xxxx', [100] => NULL, [101] => 4,... [10] => NULL]]
	 *
	 * @param array $reports organized by campaign
	 * @return array
	 */
	public function restructureForView($reports)
	{
		$restructured = array();

		// all internal reject codes
		$InternalRejectCode = new InternalRejectCode();
		$internalResults = $InternalRejectCode->fetchAll(array('id'))->toArray();
		$internalCodes = array_map(function($v) { return $v['id']; }, $internalResults);

		// all criteria reject codes
		$ClientRejectCode = new ClientRejectCode();
		$criteriaResults = $ClientRejectCode->fetchAll(array('id'))->toArray();
		$criteriaCodes = array_map(function($v) { return $v['id']; }, $criteriaResults);

		// all campaign reject codes
		$CampaignRejectCode = new CampaignRejectCode();
		$campaignRejectCodeResults = $CampaignRejectCode->fetchAll(array('id'))->toArray();
		$campaignCodes = array_map(function($v) { return $v['id']; }, $campaignRejectCodeResults);

		foreach ($reports as $k => $report) 
		{
			$restructured[$k]['subid'] = $k;

			// internal rejects
			if (array_key_exists('internalRejects', $report)) {
				foreach ($internalCodes as $code) {
					foreach ($report['internalRejects'] as $reject) {
						if ($reject['rejectCode'] == $code) {
							$restructured[$k][$code] = $reject['total'];
						}
					}
				}
			}

			// clientCriteria rejects
			if (array_key_exists('clientCriteriaRejects', $report)) {
				foreach ($criteriaCodes as $code) {
					foreach ($report['clientCriteriaRejects'] as $reject) {
						if ($reject['rejectCode'] == $code) {
							$restructured[$k][$code] = $reject['total'];
						}
					}
				}
			}

			// campaign rejects
			if (array_key_exists('campaignRejects', $report)) {
				foreach ($campaignCodes as $code) {
					foreach ($report['campaignRejects'] as $reject) {
						if ($reject['rejectCode'] == $code) {
							$restructured[$k]['campaign_' . $code] = $reject['total'];
						}
					}
				}
			}

			// vendor rejects
			if (array_key_exists('vendorRejects', $report)) {
				foreach ($report['vendorRejects'] as $vendorKey => $reject) {
					$restructured[$k]['vendor_' . $vendorKey] = $reject;
				}
			}

			// client rejects
			if (array_key_exists('clientRejects', $report)) {
				foreach ($report['clientRejects'] as $clientKey => $reject) {
					$restructured[$k]['client_' . $clientKey] = $reject;
				}
			}

			// lead attempts
			if (array_key_exists('leadAttempts', $report)) {
				$restructured[$k]['leadAttempts'] = $report['leadAttempts'];
			}

			// lead sold
			if (array_key_exists('leadSold', $report)) {
				$restructured[$k]['leadSold'] = $report['leadSold'];
			}

			if (array_key_exists('preCheckedVendorRejects', $report)) {
				$restructured[$k]['preCheckedVendorRejects'] = $report['preCheckedVendorRejects'];
			}

			if (array_key_exists('timeoutVendorRejects', $report)) {
				$restructured[$k]['timeoutVendorRejects'] = $report['timeoutVendorRejects'];
			}

			if (array_key_exists('vendorstrategyVendorRejects', $report)) {
				$restructured[$k]['vendorstrategyVendorRejects'] = $report['vendorstrategyVendorRejects'];
			}
		}
		return $restructured;
	}

	public function getVendorRejects()
	{
		// first get all vendor postsetupIDs
		$sqlVendors = "select postSetupID 
			from VendorPostSetups";
		$vendors = $this->slave->fetchAll($sqlVendors);

		// flatten array for sql query
		$vendorPostSetupIDs = array_map(function($v) { return $v['postSetupID']; }, $vendors);

		$sql = "select count(1) total,
			postSetupID,
			subid 
			from PostLogs pl 
			join Leads l on l.id = pl.leadID 
			where pl.postdate >= '" . $this->fromDate . "' 
			and pl.postdate <= '" . $this->toDate . "'
			and pl.startTime >= '" . $this->fromTime . "'
			and pl.startTime <= '" . $this->toTime . "'
			and postsetupid IN (" . implode(',', $vendorPostSetupIDs) . ") 
			and poststatus='no' 
			and pl.campaign = " . $this->campaignID . " 
			group by l.subid, postSetupID";

		return $this->slave->fetchAll($sql);
	}

	/**
	 * Format Denial report data as it has missing array elements if there's no data
	 * @param array $vendorsHeaders
	 * @param array $clientHeaders
	 * @param array $reports
	 * @return array
	 */
	public function prepareReportForTableView($vendorsHeaders, $clientHeaders, $reports)
	{
		$reportsFormatted = array();
		$result = array();

		// If we don't have any data, we set empty fields to default empty
		if (empty($reports)) {
			foreach ($vendorsHeaders as $headerVal) {
				$header = 'vendor_' . $headerVal['postSetupID'];
				$result['empty'][$header] = '';
			}
			foreach ($clientHeaders as $headerVal) {
				$header = 'client_' . $headerVal['postSetupID'];
				$result['empty'][$header] = '';
			}

			return $result;
		}

		// prepare Vendor Rejects
		foreach ($reports as $reportKey => $reportValue) {
			foreach ($reportValue as $v) {
				foreach ($vendorsHeaders as $headerVal) {
					$header = 'vendor_' . $headerVal['postSetupID'];
					if (array_key_exists($header, $reportValue)) {
						$reportsFormatted[$reportKey][$header] = $reportValue[$header];
					} else {
						$reportsFormatted[$reportKey][$header] = '';
					}
				}
			}
			$result[$reportKey] = $reportValue + $reportsFormatted[$reportKey];
		}

		// prepare Client Rejects
		foreach ($reports as $reportKey => $reportValue) {
			foreach ($reportValue as $v) {
				foreach ($clientHeaders as $headerVal) {
					$header = 'client_' . $headerVal['postSetupID'];
					if (array_key_exists($header, $reportValue)) {
						$reportsFormatted[$reportKey][$header] = $reportValue[$header];
					} else {
						$reportsFormatted[$reportKey][$header] = '';
					}
				}
			}
			$result[$reportKey] = $reportValue + $reportsFormatted[$reportKey];
		}

		return $result;
	}
}
