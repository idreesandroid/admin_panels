<?php

class VendorStrategyRule extends Zend_Db_Table
{
	protected $_name = 'VendorStrategyRules';

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}


	public function generateRulesDataByVendorStrategyRulesetID($rulesetID)
	{
		$sql = $this->select()
			->where("vendorStrategyRulesetID = " . $rulesetID)
			->order('priority asc');
		$rules = $this->fetchAll($sql)->toArray();

		$result = array();
		$iRowCounter = 0;

		$firstRule = array();
		$prevRule = array();
		foreach ($rules as $currentRule) {
			$iRowCounter++;

			if (sizeof($rules) == 1 && $iRowCounter == 1) {
				$result[] = array(
					'type' => 'rule',
					'id' => 'set' . $rulesetID .'-rule'. $currentRule['id'],
					'params' => $this->generateRuleParams($currentRule, $rulesetID),
					'priority' => $currentRule['priority']
				);
			}

			if (sizeof($rules) > 1) {
				if ($iRowCounter == 1) {
					$firstRule = $currentRule;
					continue;
				}
				if ($iRowCounter == 2) {
					$result[] = array(
						'type' => 'rule',
						'id' => 'set' . $rulesetID .'-rule'. $firstRule['id'],
						'params' => $this->generateRuleParams($firstRule, $rulesetID),
						'priority' => $firstRule['priority'],
					);
					$result[] = array(
						'type' => 'operator',
						'id' => 'set' . $rulesetID .'-rule'. $firstRule['id'] . '-set' . $rulesetID .'-rule'. $currentRule['id'] . '-ruleoperator',
						'operatorID' => $currentRule['logicalOperatorID'],
						'operatorName' => $this->getLogicalOperatorNameByID($currentRule['logicalOperatorID'])
					);
					$result[] = array(
						'type' => 'rule',
						'id' => 'set' . $rulesetID .'-rule'. $currentRule['id'],
						'params' => $this->generateRuleParams($currentRule, $rulesetID),
						'priority' => $currentRule['priority']
					);
				} else {
					$result[] = array(
						'type' => 'operator',
						'id' => 'set' . $rulesetID .'-rule'. $prevRule['id'] . '-set' . $rulesetID .'-rule'. $currentRule['id'] . '-ruleoperator',
						'operatorID' => $currentRule['logicalOperatorID'],
						'operatorName' => $this->getLogicalOperatorNameByID($currentRule['logicalOperatorID'])
					);
					$result[] = array(
						'type' => 'rule',
						'id' => 'set' . $rulesetID .'-rule'. $currentRule['id'],
						'params' => $this->generateRuleParams($currentRule, $rulesetID),
						'priority' => $currentRule['priority']
					);
				}
			}

			$prevRule = $currentRule;
		}
		return $result;
	}

	private function generateRuleParams($rule, $rulesetID) {
		$ruleID = $rule['id'];
		$params[] = array(
			'id'=>"set$rulesetID-rule$ruleID-vendorparams",
			'name' => 'vendorResponseParameter',
			'vendorResponseParameterID' => $rule['vendorResponseParameterID'],
			'vendorResponseParameterName' => $this->getGetVendorResponseParameterNameByID($rule['vendorResponseParameterID'])
		);

		$params[] = array(
			'id'=>"set$rulesetID-rule$ruleID-operators",
			'name' => 'comparisonOperator',
			'comparisonOperatorID' => $rule['comparisonOperatorID'],
			'comparisonOperatorName' => $this->getComparisonOperatorNameByID($rule['comparisonOperatorID'])
		);

		$params[] = array(
			'id'=>"set$rulesetID-rule$ruleID-paramvalue",
			'name' => 'value',
			'valueName' => "set$rulesetID-rule$ruleID-paramValue",
			'value' => $rule['value']
		);


		return $params;
	}

	public function getComparisonOperatorNameByID($operatorID)
	{
		if (!$operatorID) {
			return null;
		}
		$sql = "SELECT
					*
				FROM
					ComparisonOperators co
				WHERE
					co.id = $operatorID";

		$operator = $this->db->fetchRow($sql);

		return $operator['name'];
	}

	public function getLogicalOperatorNameByID($operatorID)
	{
		if (!$operatorID) {
			return null;
		}

		$sql = "SELECT
					*
				FROM
					LogicalOperators lo
				WHERE
					lo.id = $operatorID";

		$operator = $this->db->fetchRow($sql);
		return $operator['name'];
	}

	public function getGetVendorResponseParameterNameByID($responseParamID)
	{
		if (!$responseParamID) {
			return null;
		}
		$sql = "SELECT
					*
				FROM
					VendorResponseParameters vrp
				WHERE
					vrp.id = $responseParamID";

		$parameter = $this->db->fetchRow($sql);
		return $parameter['name'];
	}

	/**
	 * Updates or inserts a row
	 */
	public function upsert($id,$vendorStrategyRuleSetID, $insertData)
	{
		$sql = $this->select()
		->where("id = ?",$id)
		->where("vendorStrategyRulesetID = ?",$vendorStrategyRuleSetID);

		$existingRow =  $this->fetchRow($sql);

		if($existingRow) {
			$this->update($insertData, $this->_db->quoteInto("id = ?", $existingRow['id']));
			return $id;
		}
		else {
			return $this->insert($insertData);
		}
	}

	public function deleteByID($ruleID)
	{
		$existingRow = $this->findByID($ruleID);
		if ($existingRow) {
			$this->delete('id='. $ruleID);
		}
	}

	public function deleteByRulesetID($rulesetId)
	{
		$existingRow = $this->findByRulesetID($rulesetId);
		if ($existingRow) {
			$this->delete('vendorStrategyRulesetID='. $rulesetId);
		}
	}

	public function findByRulesetID($rulesetId) {
		$sql = $this->select()
			->where("vendorStrategyRulesetID = " . $rulesetId);
		return $this->fetchRow($sql);
	}

	public function findByID($id) {
		$sql = $this->select()
			->where("id = " . $id);
		return $this->fetchRow($sql);
	}

	public function deleteAllRulesByVendorStrategyID($vendorStrategyID) {
		$VendorStrategyRuleset = new VendorStrategyRuleset();
		$rulesets = $VendorStrategyRuleset->getAllByVendorStrategyID($vendorStrategyID);

		if ($rulesets) {
			foreach ($rulesets->toArray() as $ruleset) {
				if ($this->hasRulesWithVendorStrategyRulesetID($ruleset['id'])) {
					$this->delete('vendorStrategyRulesetID='. $ruleset['id']);
				}
			}
		}
	}

	public function hasRulesWithVendorStrategyRulesetID($vendorStrategyRulesetID) {
		$sql = $this->select()
			->from($this->_name, array("count(*) AS amount"))
			->where($this->_db->quoteInto($this->_name . ".vendorStrategyRulesetID = ?", $vendorStrategyRulesetID));

		$result = $this->_db->fetchRow($sql);
		if ($result['amount'] < 1) {
			return FALSE;
		}
		return TRUE;

	}

	public function getAllByVendorStrategyRulesetID($rulesetID) {
		$sql = $this->select()
			->where("vendorStrategyRulesetID = " . $rulesetID)
			->order('priority asc');
		return $this->fetchAll($sql);
	}

	/**
	 * This method deletes all old rulesets with their rules that we had before
	 * @param $rulesets - rulesets old and new
	 * @param $rulesetIds - new rulesets IDs that we should keep
	 */
	public function deleteOldRules($rulesetID, $ruleIds) {
		$rulesets = $this->getAllByVendorStrategyRulesetID($rulesetID);
		if ($rulesets) {
			$rulesets = $rulesets->toArray();
			$VendorStrategyRule = new VendorStrategyRule();
			$size = count($rulesets);
			for ($i = 0; $i < $size; $i++) {
				if (!in_array($rulesets[$i]['id'], $ruleIds)) {
					$VendorStrategyRule->deleteByRulesetID($rulesets[$i]['id']);
					$this->deleteByID($rulesets[$i]['id']);
				}
			}
		}
	}

	public function findOperatorValueByRuleID($rulesetOperators, $id) {
		foreach ($rulesetOperators as $operator) {
			$result = explode('-', $operator['id']);
			$rulesetIDOne = $result[0];
			$ruleseIDOne = $result[1];
			$rulesetIDTwo = $result[2];
			$ruleIDTwo = $result[3];

			if ('rule'.$id == $ruleseIDOne) {
				return $operator['value'];
			}
		}
		return null;
	}
}
