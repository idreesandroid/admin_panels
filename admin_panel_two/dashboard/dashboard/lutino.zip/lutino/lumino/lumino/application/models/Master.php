<?php

/**
 * Master Model
 *
 * model for TRAN Master table
 *
 */
class Master extends TranAbstract
{

	const STANDARD_LOAN_TYPE = "S";

	protected $_name = 'Master';
		
	public function init()
	{

		$this->fileName = "Master";
		// db columns that are dates, used to format the date from scrape
		$this->dateFields = array(18, 26, 30, 34, 37);
		// scrape file type
		$this->cboFileType = "M";

		$this->fieldNames = array("Merchant_ID",
				"Store_number",
				"Loan_Number",
				"Cust_ID",
				"Cust_SSN",
				"Cust_Name",
				"Cust_Suffix",
				"Cust_Add1",
				"Cust_Add2",
				"Cust_Add3",
				"Cust_Add4",
				"Cust_Add5",
				"Cust_City",
				"Cust_Location",
				"Cust_PostalCode",
				"Cust_PostalExt",
				"Cust_Country",
				"Cust_HPhone",
				"Loan_Date",
				"Disb_Mode",
				"ABA_No",
				"Acct_No",
				"Acct_Type",
				"Loan_Type",
				"Loan_Amount",
				"Loan_Fees",
				"Loan_Due_Date",
				"Loan_Status",
				"Withdraw_Reason",
				"Loan_Check_No",
				"Date_Paid_Off",
				"Total_Prin_To_Date",
				"Current_Renewal_Count",
				"Days_Past_Due",
				"ApplicationDate",
				"DenialCode",
				"MASID",
				"Last_Modified"
				);

		$this->CustFile = new CustFile();

	}

	/**
	 * Updates or inserts a row
	 */
	public function upsert($insertData)
	{

		$existingRow = $this->find($insertData['Loan_Number'], $insertData['Cust_ID']);

		if(count($existingRow) > 0) {
			$updateKeys = $this->_db->quoteInto("Loan_Number = ?", $insertData['Loan_Number']);
			$updateKeys .= " AND " . $this->_db->quoteInto("Cust_ID = ?", $insertData['Cust_ID']);

			$this->update($insertData, $updateKeys);
		}
		else {
			$this->insert($insertData);
		}
	}

	/** 
 	 * Builds the insert array from the table field names and an array of values
	 *
	 */
	public function buildInsertArray($fieldData)
	{
	
		$insertData = array();
	
		foreach($this->fieldNames as $key =>$name) {
			$insertData[$name] = trim($fieldData[$key]);
		}

		$AppDate = new DateTime($insertData['ApplicationDate']);

		// new search algorithm for leadID lookup
		$LeadMatch = new LeadMatchMaster($insertData['Loan_Number']);
		$insertData['leadID'] = $LeadMatch->execute();

		return $insertData;
	}
}
