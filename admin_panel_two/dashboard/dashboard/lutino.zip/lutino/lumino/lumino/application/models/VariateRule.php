<?php

class VariateRule extends Zend_Db_Table
{
	protected $_name = 'VariateRules';

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}


	public function generateRulesDataByVariateRulesetID($rulesetID)
	{
		$sql = $this->select()
			->where("variateRulesetID = " . $rulesetID)
			->order('priority asc');
		$rules = $this->fetchAll($sql)->toArray();

		$result = array();
		$iRowCounter = 0;

		$firstRule = array();
		$prevRule = array();
		foreach ($rules as $currentRule) {
			$iRowCounter++;

			if (sizeof($rules) == 1 && $iRowCounter == 1) {
				$result[] = array(
					'type' => 'rule',
					'id' => 'set' . $rulesetID .'-rule'. $currentRule['id'],
					'params' => $this->generateRuleParams($currentRule, $rulesetID),
					'priority' => $currentRule['priority']
				);
			}

			if (sizeof($rules) > 1) {
				if ($iRowCounter == 1) {
					$firstRule = $currentRule;
					continue;
				}
				if ($iRowCounter == 2) {
					$result[] = array(
						'type' => 'rule',
						'id' => 'set' . $rulesetID .'-rule'. $firstRule['id'],
						'params' => $this->generateRuleParams($firstRule, $rulesetID),
						'priority' => $firstRule['priority'],
					);
					$result[] = array(
						'type' => 'operator',
						'id' => 'set' . $rulesetID .'-rule'. $firstRule['id'] . '-set' . $rulesetID .'-rule'. $currentRule['id'] . '-ruleoperator',
						'operatorID' => $currentRule['logicalOperatorID'],
						'operatorName' => $this->getLogicalOperatorNameByID($currentRule['logicalOperatorID'])
					);
					$result[] = array(
						'type' => 'rule',
						'id' => 'set' . $rulesetID .'-rule'. $currentRule['id'],
						'params' => $this->generateRuleParams($currentRule, $rulesetID),
						'priority' => $currentRule['priority']
					);
				} else {
					$result[] = array(
						'type' => 'operator',
						'id' => 'set' . $rulesetID .'-rule'. $prevRule['id'] . '-set' . $rulesetID .'-rule'. $currentRule['id'] . '-ruleoperator',
						'operatorID' => $currentRule['logicalOperatorID'],
						'operatorName' => $this->getLogicalOperatorNameByID($currentRule['logicalOperatorID'])
					);
					$result[] = array(
						'type' => 'rule',
						'id' => 'set' . $rulesetID .'-rule'. $currentRule['id'],
						'params' => $this->generateRuleParams($currentRule, $rulesetID),
						'priority' => $currentRule['priority']
					);
				}
			}

			$prevRule = $currentRule;
		}
		return $result;
	}

	private function generateRuleParams($rule, $rulesetID) {
		$ruleID = $rule['id'];
		$params[] = array(
			'id'=>"set$rulesetID-rule$ruleID-vendorparams",
			'name' => 'vendorResponseParameter',
			'vendorResponseParameterID' => $rule['vendorResponseParameterID'],
			'vendorResponseParameterName' => $this->getGetVendorResponseParameterNameByID($rule['vendorResponseParameterID'])
		);

		$params[] = array(
			'id'=>"set$rulesetID-rule$ruleID-operators",
			'name' => 'comparisonOperator',
			'comparisonOperatorID' => $rule['comparisonOperatorID'],
			'comparisonOperatorName' => $this->getComparisonOperatorNameByID($rule['comparisonOperatorID'])
		);

		$params[] = array(
			'id'=>"set$rulesetID-rule$ruleID-paramvalue",
			'name' => 'value',
			'valueName' => "set$rulesetID-rule$ruleID-paramValue",
			'value' => $rule['value']
		);


		return $params;
	}

	public function getComparisonOperatorNameByID($operatorID)
	{
		if (!$operatorID) {
			return null;
		}
		$sql = "SELECT
					*
				FROM
					ComparisonOperators co
				WHERE
					co.id = $operatorID";

		$operator = $this->db->fetchRow($sql);

		return $operator['name'];
	}

	public function getLogicalOperatorNameByID($operatorID)
	{
		if (!$operatorID) {
			return null;
		}

		$sql = "SELECT
					*
				FROM
					LogicalOperators lo
				WHERE
					lo.id = $operatorID";

		$operator = $this->db->fetchRow($sql);
		return $operator['name'];
	}

	public function getGetVendorResponseParameterNameByID($responseParamID)
	{
		if (!$responseParamID) {
			return null;
		}
		$sql = "SELECT
					*
				FROM
					VendorResponseParameters vrp
				WHERE
					vrp.id = $responseParamID";

		$parameter = $this->db->fetchRow($sql);
		return $parameter['name'];
	}

	/**
	 * Updates or inserts a row
	 */
	public function upsert($id,$ruleSetID,$insertData)
	{
		$sql = $this->select()
		->where("id = ?",$id)
		->where("variateRulesetID = ?",$ruleSetID);

		$existingRow =  $this->fetchRow($sql);

		if($existingRow) {
			$this->update($insertData, $this->_db->quoteInto("id = ?", $existingRow['id']));
			return $id;
		}
		else {
		    $insertID = $this->insert($insertData);
			return $insertID;
		}
	}

	public function deleteByID($ruleID)
	{
		$existingRow = $this->findByID($ruleID);
		if ($existingRow) {
			$this->delete('id='. $ruleID);
		}
	}

	public function deleteByRulesetID($rulesetId)
	{
		$existingRow = $this->findByRulesetID($rulesetId);
		if ($existingRow) {
			$this->delete('variateRulesetID='. $rulesetId);
		}
	}

	public function findByRulesetID($rulesetId) {
		$sql = $this->select()
			->where("variateRulesetID = " . $rulesetId);
		return $this->fetchRow($sql);
	}

	public function findByID($id) {
		$sql = $this->select()
			->where("id = " . $id);
		return $this->fetchRow($sql);
	}

	public function deleteAllRulesByVariateID($variateID) {
		$VariateRuleset = new VariateRuleset();
		$rulesets = $VariateRuleset->getAllByVariateID($variateID);

		if ($rulesets) {
			foreach ($rulesets->toArray() as $ruleset) {
				if ($this->hasRulesWithVariateRulesetID($ruleset['id'])) {
					$this->delete('variateRulesetID='. $ruleset['id']);
				}
			}
		}
	}

	public function hasRulesWithVariateRulesetID($variateRulesetID) {
		$sql = $this->select()
			->from($this->_name, array("count(*) AS amount"))
			->where($this->_db->quoteInto($this->_name . ".variateRulesetID = ?", $variateRulesetID));

		$result = $this->_db->fetchRow($sql);
		if ($result['amount'] < 1) {
			return FALSE;
		}
		return TRUE;

	}

	public function getAllByVariateRulesetID($rulesetID) {
		$sql = $this->select()
			->where("variateRulesetID = " . $rulesetID)
			->order('priority asc');
		return $this->fetchAll($sql);
	}

	public function deleteRemovedRules($rulesetID, $ruleIds, $rulesOperators) {

	    $rules = $this->getAllByVariateRulesetID($rulesetID);

		$firstRowDeleted = false;
		if ($rules) {
			$rules = $rules->toArray();

			for ($i = 0; $i < count($rules); $i++) {
				if (!in_array($rules[$i]['id'], $ruleIds)) {
					if ($i==0) {
						$firstRowDeleted = true;
					}

					$this->deleteByID($rules[$i]['id']);
				}
			}
		}
	}

	public function findOperatorValueByRuleID($rulesetOperators, $id) {
		foreach ($rulesetOperators as $operator) {
			$result = explode('-', $operator['id']);
			$rulesetIDOne = $result[0];
			$ruleseIDOne = $result[1];
			$rulesetIDTwo = $result[2];
			$ruleIDTwo = $result[3];

			if ('rule'.$id == $ruleseIDOne) {
				return $operator['value'];
			}
		}
		return null;
	}
}
