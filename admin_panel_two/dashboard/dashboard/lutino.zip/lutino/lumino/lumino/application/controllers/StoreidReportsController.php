<?php

class StoreidReportsController extends Zend_Controller_Action
{
	public function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if(!$AdminNameSpace->userid)
		{
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();

		$this->config = Zend_Registry::get('config');
	}

	public function indexAction() {

		$reportData = array();

		if($_POST['submit']) {

			$fromDate = ($this->_request->fromDate) ? $this->_request->fromDate : date('Y-m-d');
			$toDate = ($this->_request->toDate) ? $this->_request->toDate : date('Y-m-d');

			$timeStart =  ($this->_request->timeStart) ? $this->_request->timeStart : date("H:i:s", strtotime("Today"));
			$timeEnd =($this->_request->timeEnd) ? $this->_request->timeEnd : date("H:i:s", strtotime("Today last second"));
			$affiliateID = ($this->_request->affiliateID) ? $this->_request->affiliateID : "";
			$campaignID = ($this->_request->campaigns) ? $this->_request->campaigns : "";

			$fromDate = date('Y-m-d', strtotime($fromDate));
			$toDate = date('Y-m-d', strtotime($toDate));
		}
		else {
			$fromDate = date('Y-m-d');
			$toDate =  date('Y-m-d');
			$timeStart =  date("H:i:s", strtotime("Today"));
			$timeEnd = date("H:i:s", strtotime("Today last second"));
			$affiliateID = "";
			$campaignID = "";
		}

		$ReportsDataModel = new StoreIDReportsDataModel();
		$ReportsDataModel->initSettingsForSlaveDB();
		$reportData = $ReportsDataModel->getReportData($fromDate,$toDate,$timeStart,$timeEnd,$affiliateID,$campaignID);

		$Campaigns = new Campaigns();
		$campaignsData = $Campaigns->getCampaignsByAffiliateID($affiliateID);

		$this->view->fromDate = $fromDate;
		$this->view->toDate = $toDate;
		$this->view->timeStart = $timeStart;
		$this->view->timeEnd = $timeEnd;
		$this->view->reportsData = $reportData;

		$this->view->affiliates = $ReportsDataModel->getAllAffiliates();
		$affiliateId = $this->_request->affiliateID;
		$this->view->affiliateID = $affiliateId;
		$this->view->campaignID = $campaignID;
		$this->view->campaigns = $campaignsData;
	}

        /*
        *   Get subid reports data
        */
        public function reportsdataAction() {

            $fromDate = ($this->_request->fromDate) ? $this->_request->fromDate : date('Y-m-d');
            $toDate = ($this->_request->toDate) ? $this->_request->toDate : date('Y-m-d');

            $timeStart =  ($this->_request->timeStart) ? $this->_request->timeStart : date("H:i:s", strtotime("Today"));
            $timeEnd =($this->_request->timeEnd) ? $this->_request->timeEnd : date("H:i:s", strtotime("Today last second"));

            $fromDate = date('Y-m-d', strtotime($fromDate));
            $toDate = date('Y-m-d', strtotime($toDate));

            $affiliateID =($this->_request->affiliateID) ? $this->_request->affiliateID : "";
            $campaignID = ($this->_request->campaignID) ? $this->_request->campaignID : "";

            $ReportsDataModel = new StoreIDReportsDataModel();
            $ReportsDataModel->initSettingsForSlaveDB();
            $reportData = $ReportsDataModel->getReportData($fromDate,$toDate,$timeStart,$timeEnd, $affiliateID,$campaignID);

            echo json_encode($reportData);
            exit;
        }

        /*
        *   Get subid reports data broken down by storeid
        */
        public function reportsdatabystoreidAction() {

            $fromDate = ($this->_request->fromDate) ? $this->_request->fromDate : date('Y-m-d');
            $toDate = ($this->_request->toDate) ? $this->_request->toDate : date('Y-m-d');

            $timeStart =  ($this->_request->timeStart) ? $this->_request->timeStart : date("H:i:s", strtotime("Today"));
            $timeEnd =($this->_request->timeEnd) ? $this->_request->timeEnd : date("H:i:s", strtotime("Today last second"));

            $fromDate = date('Y-m-d', strtotime($fromDate));
            $toDate = date('Y-m-d', strtotime($toDate));

	        $affiliateID =($this->_request->affiliateID) ? $this->_request->affiliateID : "";
	        $campaignID = ($this->_request->campaignID) ? $this->_request->campaignID : "";
            $storeID = $this->_request->storeid;

            $ReportsDataModel = new StoreIDReportsDataModel();
            $ReportsDataModel->initSettingsForSlaveDB();
            $reportData = $ReportsDataModel->getReportDataByStoreID($storeID,$fromDate,$toDate,$timeStart,$timeEnd,$affiliateID,$campaignID);

            echo json_encode($reportData);
            exit;

        }

        public function getcampaignsbyaffiliateAction()
        {
            $affiliateID = ($this->_request->affiliateID) ? $this->_request->affiliateID : "";
            $Campaigns = new Campaigns();
            $campaignsData = $Campaigns->getCampaignsByAffiliateID($affiliateID);

            echo json_encode($campaignsData);
            exit;
        }
}