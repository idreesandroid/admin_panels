<?php
class CampaignController extends Zend_Controller_Action
{
	private $baseurl;

	/**
	 * TODO: refactor this once we get more cash clients
	 */
	public $coverMeCashClientIDs = array(74, 78);

	function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if (!$AdminNameSpace->userid) {
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();
		$this->config = Zend_Registry::get("config");
	}

	public function addAction()
	{
		$message = "";
		$error = 0;
		$success = 0;
		$lockedClientPostSetupIDs = array();
		$autoSellToGoodCustomers = 1;
		$isPricerejectEnabled = 0;

		if ($this->_request->isPost()) {
			$commonobj = new Commonfunctions();

			$f = new Zend_Filter_StripTags();

			$campaigntitle = $this->_request->getPost('title');
			$masteraffilaite = $this->_request->getPost('maffiliate');
			$productcode = $this->_request->getPost('pcode');
			$campaigntype = $this->_request->getPost('campaigntype');
			$checkdirectmailwhitelist = $this->_request->getPost('checkdirectmailwhitelist');
			$revenushare = $this->_request->getPost('revenueshare');
			$patialpixel = $this->_request->getPost('ppixel');
			$costperlead = $this->_request->getPost('costperlead');
			$markupprice = $this->_request->getPost('markupprice');
			$ppixelper = $this->_request->getPost('ppixelprec');
			$pixelcode = $this->_request->getPost('pixelcode');
			$blacklistedsubids = ($this->_request->blacklistedsubids) ? trim($this->_request->blacklistedsubids) : NULL;
			$maxleadsperday = ($this->_request->maxleadsperday) ? $this->_request->maxleadsperday : NULL;
			$maxLeadsSoldPerDay = ($this->_request->maxLeadsSoldPerDay) ? $this->_request->maxLeadsSoldPerDay : NULL;
			$maxLeadsSoldPerWeek = ($this->_request->maxLeadsSoldPerWeek) ? $this->_request->maxLeadsSoldPerWeek : NULL;
			$maxLeadsSoldPerMonth = ($this->_request->maxLeadsSoldPerMonth) ? $this->_request->maxLeadsSoldPerMonth : NULL;
			$maxOriginations = ($this->_request->maxOriginations) ? $this->_request->maxOriginations : NULL;
			$chosenClientPostSetupIDs = $this->_request->chosenClientPostSetupIDs;
			$defaultTranStore = $this->_request->defaultTranStore;
			$skipVendorVerification = ($this->_request->skipVendorVerification == 1) ? 1 : 0;
			$lockedClientPostSetupIDsOrder = $this->_request->lockedClientPostSetupIDs;
			$leadDistroPurchasingType = $this->_request->getPost('leadDistroPurchasingType');
			$campaignNotes = $this->_request->getPost('campaignNotes');
			$autoSellToGoodCustomers = $this->_request->getPost('autoselltogoodcustomers');
			$isPricerejectEnabled = $this->_request->getPost('ispricerejectenabled');
            $byPassGlobalDupeRule = ($this->_request->getPost('byPassGlobalDupeRule') == 1) ? 1 : 0;

			$lockedClientPostSetupOrder = array();
			foreach($lockedClientPostSetupIDsOrder as $value) {
				$setupId = explode("_",$value);
				if (count($setupId)>0) {
					$lockedClientPostSetupIDs[] = $setupId[0];
					$lockedClientPostSetupOrder[] = $setupId[1];
				}
			}

			if (empty($campaigntitle)) {
				$message .= "Please provide campaign title.<br>";
				$error = 1;
			}
			if (empty($masteraffilaite)) {
				$message .= "Please choose master affilaite.<br>";
				$error = 1;
			}

			if (!empty($revenushare)) {
				if (!is_numeric($revenushare)) {
					$message .= "Revenue share must be numeric value.<br>";
					$error = 1;
				}
			}

			if ($costperlead) {
				if (!is_numeric($costperlead)) {
					$message .= "Cost per lead must be numeric value.<br>";
					$error = 1;
				}
			}

			if (empty($defaultTranStore)) {
				$message .= "Default LMS Store can not be empty <br />";
				$error = 1;
			}
			else {
			    if (strpos($defaultTranStore,' ') !== FALSE) {
			        $message .= "Default LMS Store must not contain any spaces<br />";
			        $error = 1;
			    }
			}

			if ($error == 0) {
				if (!$revenushare) $revenushare = 0;
				$Form_Data = array(
					'masteraff' => $masteraffilaite,
					'costPerLead' => $costperlead,
					'markupPrice' => $markupprice,
					'revShare' => $revenushare,
					'pixelCode' => $pixelcode,
					'partialPixel' => $patialpixel,
					'partialPixelPercentage' => $ppixelper,
					'productCode' => $productcode,
					'campaignType' => $campaigntype,
					'checkDirectMailWhitelist' => $checkdirectmailwhitelist,
					'title' => $campaigntitle,
					'blacklistedsubids' => $blacklistedsubids,
					'isHotTransfer' => $this->_request->hottransfer,
					'maxLeadsPerDay' => $maxleadsperday,
					'maxLeadsSoldPerDay' => $maxLeadsSoldPerDay,
					'maxLeadsSoldPerWeek' => $maxLeadsSoldPerWeek,
					'maxLeadsSoldPerMonth' => $maxLeadsSoldPerMonth,
					'maxOriginations' => $maxOriginations,
					'defaultTranStore' => $defaultTranStore,
					'skipVendorVerification' => $skipVendorVerification,
				    'notes' => $campaignNotes,
				    'autoSellToGoodCustomers' => $autoSellToGoodCustomers,
				    'isPriceRejectEnabled' => $isPricerejectEnabled
				);

				// custom save method so we can update campaign 'name' to match id
				$cmp = new Campaigns();
				if (!$newCampaignID = $cmp->trySave($Form_Data)) {
					$error = 1;
					$message = "Some error occurred please try later.";
				} else {
					// save multivariate
					$CampaignsMultiVariate = new CampaignsMultiVariate();
					if ($this->_request->multivariate > 0) {
						if (!$CampaignsMultiVariate->saveNew($newCampaignID, $this->_request->multivariate)) {
							$error = 1;
							$message = "Error occurred while saving multivariate.";
						}
					}

					$chosenClientPostSetupWithOrder = array();
					foreach($chosenClientPostSetupIDs as $id) {
						$key = array_search($id,$lockedClientPostSetupIDs);
						if ($key!== FALSE) {
							$chosenClientPostSetupWithOrder[] = array('id' => $id, 'position' => $lockedClientPostSetupOrder[$key]);
						}
						else {
							$chosenClientPostSetupWithOrder[] = array('id' => $id, 'position' => '');
						}
					}

					// save custom cash clients
					$CashClient = new CampaignCashPostSetups($newCampaignID);
					$CashClient->save($chosenClientPostSetupWithOrder, $defaultTranStore);

					$cmp->saveLeadDistroPurchasingType($newCampaignID, $leadDistroPurchasingType);
					$message = "Campaign successfully added.";
				}
				return $this->_helper->redirector('view');
			}
			if ($error == 1) {
				$this->view->title = $campaigntitle;
				$this->view->masteraff = $masteraffilaite;
				$this->view->pcode = $productcode;
				$this->view->campaigntype = $campaigntype;
				$this->view->checkdirectmailwhitelist = $checkdirectmailwhitelist;
				$this->view->revshare = $revenushare;
				$this->view->ppixel = $patialpixel;
				$this->view->cpl = $costperlead;
				$this->view->markupprice = $markupprice;
				$this->view->pixelcode = $pixelcode;
				$this->view->ppixelperc = $ppixelper;
				$this->view->blacklistedsubids = $blacklistedsubids;
				$this->view->hottransfer = $this->_request->hottransfer;
				$this->view->maxleadsperday = $maxleadsperday;
				$this->view->maxLeadsSoldPerDay = $maxLeadsSoldPerDay;
				$this->view->maxLeadsSoldPerWeek = $maxLeadsSoldPerWeek;
				$this->view->maxLeadsSoldPerMonth = $maxLeadsSoldPerMonth;
				$this->view->maxOriginations = $maxOriginations;
				$this->view->defaultTranStore = $defaultTranStore;
				$this->view->chosenClientPostSetupIDs = $chosenClientPostSetupIDs;
				$this->view->skipVendorVerification = $skipVendorVerification;
				$this->view->selClientPostSetupIDs = $chosenClientPostSetupIDs;
				$this->view->campaignNotes = $campaignNotes;
				$this->view->ispricerejectenabled = $isPricerejectEnabled;
			}
		}

		$Products = new Products();
		$productdata = $Products->fetchAll(NULL, "productcode");

		$CampaignType = new CampaignType();
		$campaigntypedata = $CampaignType->fetchAll(NULL, "campaignType");

		$Affiliates = new Affiliates();
		$affdata = $Affiliates->fetchAll(NULL, "masteraff");

		$MultiVariate = new MultiVariate();
		$multiVariates = $MultiVariate->getUnHiddenActiveVariates();

		$Campaigns = new Campaigns();
		$leadDistroPurchasingTypes = $Campaigns->getLeadDistroPurchasingTypes();

		// checkboxes for mapping to client(s)
		$ClientPostSetup = new ClientPostSetups();
		$clientPostSetups = $ClientPostSetup->findAllActive();

		$allsetups = array();
		foreach($clientPostSetups as $setup) {
			$allsetups[] = $setup['postSetupID'];
		}

		$selectedClientPostSetupIDs =array();

		foreach($chosenClientPostSetupIDs as $id) {
			$key = array_search($id,$allsetups);
			if ($key!== FALSE) {
				$tuple = array();
				$tuple['postSetupID'] = $clientPostSetups[$key]['postSetupID'];
				$tuple['company']     = $clientPostSetups[$key]['company'];
				if (in_array($id,$lockedClientPostSetupIDs)) {
					$tuple['islocked'] = TRUE;
				}
				else {
					$tuple['islocked'] = FALSE;
				}
				$selectedClientPostSetupIDs[] = $tuple;
			}
		}


		$this->view->chosenClientPostSetupIDs = $selectedClientPostSetupIDs;
		$this->view->baseurl = $this->baseurl;
		$this->view->message = $message;
		$this->view->error = $error;
		$this->view->success = $success;
		$this->view->affdata = $affdata;
		$this->view->pdata = $productdata;
		$this->view->campaigntypedata = $campaigntypedata;
		$this->view->multivariates = $multiVariates;
		$this->view->leadDistroPurchasingTypes = $leadDistroPurchasingTypes;
		$this->view->clientPostSetups = $clientPostSetups;
		$this->view->autoselltogoodcustomers = $autoSellToGoodCustomers;
	}

	public function editAction()
	{
		$id = $_REQUEST['id'];

		$message = "";
		$error = 0;
		$success = 0;
		$lockedClientPostSetupIDs = array();
		$lockedClientPostSetupOrder = array();
		$chosenClientPostSetupIDs = array();
		$chosenClientPostSetupLockPos = array();

		if ($this->_request->isPost()) {
			$commonobj = new Commonfunctions();

			$f = new Zend_Filter_StripTags();

			$campaigntitle = $this->_request->getPost('title');
			$masteraffilaite = $this->_request->getPost('maffiliate');
			$productcode = $this->_request->getPost('pcode');
			$campaigntype = $this->_request->getPost('campaigntype');
			$checkdirectmailwhitelist = $this->_request->getPost('checkdirectmailwhitelist');
			$revenushare = $this->_request->getPost('revenueshare');
			$patialpixel = $this->_request->getPost('ppixel');
			$costperlead = $this->_request->getPost('costperlead');
			$markupprice = $this->_request->getPost('markupprice');
			$ppixelper = $this->_request->getPost('ppixelprec');
			$pixelcode = $this->_request->getPost('pixelcode');
			$active = ($this->_request->active == 1) ? 1 : 0;
			$blacklistedsubids = ($this->_request->blacklistedsubids) ? trim($this->_request->blacklistedsubids) : NULL;
			$maxleadsperday = ($this->_request->maxleadsperday) ? $this->_request->maxleadsperday : NULL;
			$maxLeadsSoldPerDay = ($this->_request->maxLeadsSoldPerDay) ? $this->_request->maxLeadsSoldPerDay : NULL;
			$maxLeadsSoldPerWeek = ($this->_request->maxLeadsSoldPerWeek) ? $this->_request->maxLeadsSoldPerWeek : NULL;
			$maxLeadsSoldPerMonth = ($this->_request->maxLeadsSoldPerMonth) ? $this->_request->maxLeadsSoldPerMonth : NULL;
			$maxOriginations = ($this->_request->maxOriginations) ? $this->_request->maxOriginations : NULL;
			$defaultTranStore = $this->_request->defaultTranStore;
			$multivariate = $this->_request->multivariate;
			$chosenClientPostSetupIDs = $this->_request->chosenClientPostSetupIDs;
			$skipVendorVerification = ($this->_request->skipVendorVerification == 1) ? 1 : 0;
			$lockedClientPostSetupIDsOrder = $this->_request->lockedClientPostSetupIDs;
			$leadDistroPurchasingType = $this->_request->getPost('leadDistroPurchasingType');
			$campaignNotes = $this->_request->getPost('campaignNotes');
			$autoSellToGoodCustomers = $this->_request->getPost('autoselltogoodcustomers');
			$decisionLogicRuleSetsData = $this->_request->getPost('decisionlogicrulesets');
			$isPricerejectEnabled = $this->_request->getPost('ispricerejectenabled');
            $byPassGlobalDupeRule = ($this->_request->getPost('byPassGlobalDupeRule') == 1) ? 1 : 0;

			// As data is in format of "setupid_order" i.e. 23567_1, 65786_2
			// So we need to explode it and store values in different arrays
			if (count($lockedClientPostSetupIDsOrder)) {
				foreach($lockedClientPostSetupIDsOrder as $value) {
					$setupId = explode("_",$value);
					if (count($setupId)>0) {
						$lockedClientPostSetupIDs[] = $setupId[0];
						$lockedClientPostSetupOrder[] = $setupId[1];
						$chosenClientPostSetupLockPos[$setupId[0]] = $setupId[1];
					}
				}
			}

			if (empty($campaigntitle)) {
				$message .= "Please provide campaign title.<br>";
				$error = 1;
			}
			if (empty($masteraffilaite)) {
				$message .= "Please choose master affilaite.<br>";
				$error = 1;
			}

			if (!empty($revenushare)) {
				if (!is_numeric($revenushare)) {
					$message .= "Revenue share must be numeric value.<br>";
					$error = 1;
				}
			}

			if ($costperlead) {
				if (!is_numeric($costperlead)) {
					$message .= "Cost per lead must be numeric value.<br>";
					$error = 1;
				}
			}

			if (empty($defaultTranStore)) {
				$message .= "Default LMS Store can not be empty <br />";
				$error = 1;
			}
			else {
			    if (strpos($defaultTranStore,' ') !== FALSE) {
			        $message .= "Default LMS Store must not contain any spaces<br />";
			        $error = 1;
			    }
			}


			if ($error == 0) {
				if (!$revenushare) $revenushare = 0;

				$Form_Data = array(
					'masteraff' => $masteraffilaite,
					'costPerlead' => $costperlead,
					'markupPrice' => $markupprice,
					'revShare' => $revenushare,
					'pixelCode' => $pixelcode,
					'partialPixel' => $patialpixel,
					'partialPixelPercentage' => $ppixelper,
					'productCode' => $productcode,
					'campaignType' => $campaigntype,
					'checkDirectMailWhitelist' => $checkdirectmailwhitelist,
					'title' => $campaigntitle,
					'active' => $active,
					'blacklistedSubIDs' => $blacklistedsubids,
					'isHotTransfer' => $this->_request->hottransfer,
					'maxLeadsPerDay' => $maxleadsperday,
					'maxLeadsSoldPerDay' => $maxLeadsSoldPerDay,
					'maxLeadsSoldPerWeek' => $maxLeadsSoldPerWeek,
					'maxLeadsSoldPerMonth' => $maxLeadsSoldPerMonth,
					'maxOriginations' => $maxOriginations,
					'defaultTranStore' => $defaultTranStore,
					'skipVendorVerification' => $skipVendorVerification,
				    'notes' => $campaignNotes,
				    'autoSellToGoodCustomers' => $autoSellToGoodCustomers,
				    'isPriceRejectEnabled' => $isPricerejectEnabled
				);

				$cmp = new Campaigns();

				try {
					$where = "id=$id";
					$cmp->update($Form_Data, $where);
					$message = "Campaign successfully updated.";
					$success = 1;

					// save multivariate
					$CampaignsMultiVariate = new CampaignsMultiVariate();
					if ($this->_request->multivariate > 0) {
						if (!$CampaignsMultiVariate->saveNew($id, $this->_request->multivariate)) {
							$error = 1;
							$message = "Error occurred while saving multivariate.";
						}
					} else {
						$CampaignsMultiVariate->delete('campaignID = ' . $id);
					}

					$chosenClientPostSetupWithOrder = array();
					foreach($chosenClientPostSetupIDs as $postSetupid) {
						$key = array_search($postSetupid,$lockedClientPostSetupIDs);
						if ($key!== FALSE) {
							$chosenClientPostSetupWithOrder[] = array('id' => $postSetupid, 'position' => $lockedClientPostSetupOrder[$key]);
						}
						else {
							$chosenClientPostSetupWithOrder[] = array('id' => $postSetupid, 'position' => '');
						}
					}

					// save custom cash clients
					$CashClient = new CampaignCashPostSetups($id);
					$CashClient->save($chosenClientPostSetupWithOrder, $defaultTranStore);

					$cmp->saveLeadDistroPurchasingType($id, $leadDistroPurchasingType);

					if ($this->config->decisionLogicEnabled == 1) {
					    // Save decisionlogic rulesets to DB
					    $DecisionLogicStrategyRulesets = new DecisionLogicStrategyRulesets();
					    // first delete all previous rules and then insert new
					    $DecisionLogicStrategyRulesets->deleteDecisionLogicRuleSetsDataByCampaignID($id);
					    $DecisionLogicStrategyRulesets->buildRuleset($id,$decisionLogicRuleSetsData);
					}

					return $this->_helper->redirector('view');
				} catch (Zend_Exception $e) {
					$error = 1;
					$message = "Some error occurred please try later.";
				}
			}
			if ($error == 1) {
				$this->view->fname = $fname;
				$this->view->lname = $lname;
				$this->view->email = $email;
				$this->view->company = $company;
				$this->view->phone = $phone;
				$this->view->markupprice = $markupprice;
				$this->view->leadprice = $leadprice;
				$this->view->leadsperday = $ledsperday;
				$this->view->leadspermonth = $leadspermonth;
				$this->view->totalleads = $totalleads;
				$this->view->deleiverydays = $deliverydays;
				$this->view->status = $status;
				$this->view->pcode = $pcode;
				$this->view->campaigntype = $campaigntype;
				$this->view->checkdirectmailwhitelist = $checkdirectmailwhitelist;
				$this->view->aeid = $aeid;
				$this->view->id = $id;
				$this->view->active = $active;
				$this->view->maxleadsperday = $maxleadsperday;
				$this->view->maxLeadsSoldPerDay = $maxLeadsSoldPerDay;
				$this->view->maxLeadsSoldPerWeek = $maxLeadsSoldPerWeek;
				$this->view->maxLeadsSoldPerMonth = $maxLeadsSoldPerMonth;
				$this->view->maxOriginations = $maxOriginations;
				$this->view->defaultTranStore = $defaultTranStore;
				$this->view->skipVendorVerification = $skipVendorVerification;
				$this->view->selClientPostSetupIDs = $chosenClientPostSetupIDs;
				$this->view->campaignNotes = $campaignNotes;
				$this->view->autoselltogoodcustomers = $autoSellToGoodCustomers;
				$this->view->ispricerejectenabled = $isPricerejectEnabled;
			}
		}

		$Campaigns = new Campaigns();
		$data = $Campaigns->fetchRow("id = $id");
		$this->view->title = $data['title'];
		$this->view->masteraff = $data['masteraff'];
		$this->view->pcode = $data['productCode'];
		$this->view->campaigntype = $data['campaignType'];
		$this->view->checkdirectmailwhitelist = $data['checkDirectMailWhitelist'];
		$this->view->campaign = $data['campaign'];
		$this->view->revshare = $data['revShare'];
		$this->view->ppixel = $data['partialPixel'];
		$this->view->cpl = $data['costPerLead'];
		$this->view->markupprice = $data['markupPrice'];
		$this->view->pixelcode = $data['pixelCode'];
		$this->view->ppixelperc = $data['partialPixelPercentage'];
		$this->view->id = $id;
		$this->view->active = $data['active'];
		$this->view->blacklistedsubids = $data['blacklistedSubIDs'];
		$this->view->hottransfer = $data['isHotTransfer'];
		$this->view->maxleadsperday = $data['maxLeadsPerDay'];
		$this->view->maxLeadsSoldPerDay = $data['maxLeadsSoldPerDay'];
		$this->view->maxLeadsSoldPerWeek = $data['maxLeadsSoldPerWeek'];
		$this->view->maxLeadsSoldPerMonth = $data['maxLeadsSoldPerMonth'];
		$this->view->maxOriginations = $data['maxOriginations'];
		$this->view->skipVendorVerification = $data['skipVendorVerification'];
		$this->view->campaignNotes = $data['notes'];


		if (!$this->_request->isPost()) {
		    $this->view->autoselltogoodcustomers = $data['autoSellToGoodCustomers'];
		    $this->view->ispricerejectenabled = $data['isPriceRejectEnabled'];
		}

		$Products = new Products();
		$productdata = $Products->fetchAll(NULL, "productcode");

		$CampaignType = new CampaignType();
		$campaigntypedata = $CampaignType->fetchAll(NULL, "campaignType");

		$Affiliates = new Affiliates();
		$affdata = $Affiliates->fetchAll(NULL, "company");

		$CampaignsMultiVariate = new CampaignsMultiVariate();
		$campaignMultiVariate = $CampaignsMultiVariate->getActiveByCampaignID($id);

		$MultiVariate = new MultiVariate();
		$multiVariates = $MultiVariate->getUnHiddenActiveVariates();

		$Campaigns = new Campaigns();
		$leadDistroPurchasingTypes = $Campaigns->getLeadDistroPurchasingTypes($id);


		// checkboxes for selling only to specific client(s)
		$ClientPostSetup = new ClientPostSetups();
		$clientPostSetups = $ClientPostSetup->findAllActive();

		$CampaignsClientPostSetup = new CampaignsClientPostSetup();
		$chosenClientPostSetups = $CampaignsClientPostSetup->filterByCampaignId($id);

		if (!$this->_request->isPost()) {
			foreach ($chosenClientPostSetups as $v) {
				$chosenClientPostSetupIDs[] = $v->postSetupID;
				$chosenClientPostSetupLockPos[$v->postSetupID] = $v->lockPosition;
			}
		}

		$allsetups = array();
		foreach($clientPostSetups as $setup) {
			$allsetups[] = $setup['postSetupID'];
		}

		$selectedClientPostSetupIDs =array();
		$filteredPostSetupIDs = array();

		foreach($chosenClientPostSetupIDs as $id) {
			$key = array_search($id,$allsetups);
			if ($key!== FALSE) {
				$tuple = array();
				$tuple['postSetupID'] = $clientPostSetups[$key]['postSetupID'];
				$tuple['company']     = $clientPostSetups[$key]['company'];
				$tuple['title']     = $clientPostSetups[$key]['title'];
				$tuple['qualifyingTierPrice'] = $clientPostSetups[$key]['qualifyingTierPrice'];

				if ($chosenClientPostSetupLockPos[$id]>0) {
					$tuple['islocked'] = TRUE;
				}
				else {
					$tuple['islocked'] = FALSE;
				}
				$selectedClientPostSetupIDs[] = $tuple;
				$filteredPostSetupIDs[] = $tuple['postSetupID'];
			}
		}

		$DLogicResponseParams = new DecisionLogicResponseParameters();

		$this->view->chosenClientPostSetupIDs = $selectedClientPostSetupIDs;
		$this->view->selClientPostSetupIDs = $filteredPostSetupIDs;
		$this->view->baseurl = $this->baseurl;
		$this->view->message = $message;
		$this->view->error = $error;
		$this->view->success = $success;
		$this->view->affdata = $affdata;
		$this->view->pdata = $productdata;
		$this->view->campaigntypedata = $campaigntypedata;
		$this->view->multivariates = $multiVariates;
		$this->view->leadDistroPurchasingTypes = $leadDistroPurchasingTypes;
		$this->view->multivariate = $campaignMultiVariate['multiVariateID'];
		$this->view->clientPostSetups = $clientPostSetups;
		$this->view->decisionLogicEnabled = $this->config->decisionLogicEnabled;

		$vendorResponseParams = $DLogicResponseParams->getDecesionLogicResponseParameters();
		$dlResponseParams = array();
		foreach ($vendorResponseParams as $param) {
		    $dlResponseParams[$param['id']] = $param['name'];
		}
		$this->view->dlResponseParams = $dlResponseParams;

		if ($this->config->decisionLogicEnabled == 1) {
    		if ($error == 1) {
    		    $this->view->decisionLogicRuleSetsData =  $decisionLogicRuleSetsData;
    		}
    		else {
    		    $DecisionLogicStrategyRulesets = new DecisionLogicStrategyRulesets();
    		    $this->view->decisionLogicRuleSetsData =  $DecisionLogicStrategyRulesets->getRuleSetsDataAsJSON($id);
    		}
		}
		// TODO: we will need individual storeID form fields for each postsetup	soon
		$this->view->defaultTranStore = (!empty($chosenClientPostSetupIDs)) ?
			$chosenClientPostSetups[0]['storeID'] : $data['defaultTranStore'];
	}

	function viewAction()
	{
		$activeCampaigns = array();
		$inactiveCampaigns = array();
		$Campaigns = new Campaigns();
		$campaignsData = $Campaigns->fetchAll(NULL, array("masteraff", "campaign"));
		$campaignsData = $campaignsData ? $campaignsData->toArray() : $campaignsData;

		$CampaignsMultiVariate = new CampaignsMultiVariate();
		foreach($campaignsData as $key=>$data) {
			$campaignMultiVariate = $CampaignsMultiVariate->getActiveByCampaignID($data['id']);
			if ($campaignMultiVariate) {
				$data['scorecardName'] = $campaignMultiVariate['name'];
				$campaignsData[$key] = $data;
			}

			if ($data['active'] == 1) {
				$activeCampaigns[] = $data;
			}
			else {
				$inactiveCampaigns[] = $data;
			}
		}
		$this->view->baseurl = $this->baseurl;
		$this->view->data = $campaignsData;
		$this->view->activecampigns = $activeCampaigns;
		$this->view->inactivecampigns = $inactiveCampaigns;
	}

	function deleteAction()
	{
		$id = $_GET['id'];
		if ($id > 0) {
			$where = "id=$id";
			$cmp = new Campaigns();
			$cmp->delete($where);
		}

		$this->_redirect('campaign/view');
	}

	function pauseresumeAction() {

	    $this->_helper->viewRenderer->setNoRender(TRUE);

	    $campaignID = $this->_request->getPost('id');
	    $status = $this->_request->getPost('status');

	    $AdminSnoozeLogs = new AdminSnoozeLogs();
	    $campaign = new Campaigns();

	    $AdminSnoozeLogs->upsertCampaignLogAndEmail($campaignID, $status);
	    $row = $campaign->fetchRow($campaign->select()->where('id = ?', $campaignID));

	    if ($status == "P") {
	        $row->paused = 1;
	    }
	    else if ($status == "R") {
	         $row->paused = 0;
	    }
	    $row->save();

	    echo '{"status": "OK"}';
	}

	function getvendorresparamsAction() {

	    $this->_helper->viewRenderer->setNoRender(TRUE);

	    $DLogicResponseParams = new DecisionLogicResponseParameters();
	    $responseParams = $DLogicResponseParams->getDecesionLogicResponseParameters();

	    $vendorParams = array();
	    foreach ($responseParams as $param) {
	        $tuple = array('value' => $param['id'],'text' => $param['name']);
	        $vendorParams[] = $tuple;
	    }
	    echo json_encode($vendorParams);
	}

	public function downloadExcelAction()
	{
		$this->_helper->viewRenderer->setNoRender();
		$campaignstatus = $this->_request->campaignstatus ? $this->_request->campaignstatus : "";

		$Campaigns = new Campaigns();
		$campaignsData = $Campaigns->fetchAll(NULL, array("masteraff", "campaign"));
		$campaignsData = $campaignsData ? $campaignsData->toArray() : $campaignsData;
		$CampaignsMultiVariate = new CampaignsMultiVariate();

		header("Content-Disposition: attachment; filename=campaigns_$campaignstatus.csv");

		$statusColumnTitle = $campaignstatus == "all" ? ",\"Status\"" : "";

		echo '"Campaign","Affiliate","Title","Price","Rev Share","Scorecard Name"' . $statusColumnTitle .',"Product Code","Campaign Type"';
		echo "\n";


		foreach($campaignsData as $key=>$data) {
			$campaignMultiVariate = $CampaignsMultiVariate->getActiveByCampaignID($data['id']);
			if ($campaignMultiVariate) {
				$data['scorecardName'] = $campaignMultiVariate['name'];
				$campaignsData[$key] = $data;
			}

			$row = array();
			if ($campaignstatus == "active") {
				if ($data['active'] == 1) {
					$row = $data;
				}
			} else if ($campaignstatus == "inactive") {
				if ($data['active'] == 0) {
					$row = $data;
				}
			} else if ($campaignstatus == "all") {
				$row = $data;
			}
			$scorecardName = $row['scorecardName'] ? $row['scorecardName'] : 'N/A';
			$status = $data['active'] == 1 ? 'active' : 'inactive';

			if (!empty($row)) {
				echo '"' . $row['campaign'] . '",';
				echo '"' . $row['masteraff'] . '",';
				echo '"' . $row['title'] . '",';
				echo '"' . $row['costPerLead'] . '",';
				echo '"' . $row['revShare'] . '",';
				echo '"' . $scorecardName . '",';
				if ($campaignstatus == "all") {
					echo '"' . $status . '",';
				}
				echo '"' . $row['productCode'] . '",';
				echo '"' . $row['campaignType'] . '"';
				echo "\n";
			}
		}
	}
}

?>
