<?php

/**
 * LoanApp Model
 *
 * model for TRAN Loan_App table
 *
 */
class CMCLoanApp extends TranAbstract
{

	protected $_name = 'CMCLoan_App';

	public function init()
	{

		$this->fileName = "Loan_App";
		// db columns that are dates, used to format the date from data file
		$this->dateFields = array(6, 7, 19, 21, 29, 31);
		// file type
		$this->cboFileType = "L";

		$this->fieldNames = array("Appl_No",
				"Cust_ID",
				"Cust_SSN",
				"Merch_Store_ID",
				"User_ID",
				"Req_Loan_Amt",
				"Req_Due_Date",
				"Loan_Eff_Date",
				"Cr_Bureau_Score",
				"Loan_Type",
				"Incomplete_App",
				"APR",
				"Fin_Charge",
				"Fee_Charge",
				"Appl_Status",
				"Loan_Status",
				"IsOriginated",
				"PrintedCheckNo",
				"Cust_Check_Amt",
				"Date_Created",
				"MerchantRefID",
				"ApplicationDate",
				"ActionID",
				"PDLoan_Rcvd",
				"Mkt_Code",
				"MarketingCodeDesc",
				"Cur_Ren_No",
				"MASID",
				"QuickID",
				"ESig_Date",
				"ESignature",
				"Last_Modified"
					);

		$this->Master = new Master();
		$this->CustFile = new CustFile();

	}

	/**
	 * Updates or inserts a row
	 */
	public function upsert($insertData)
	{

		$existingRow = $this->find($insertData['Appl_No'], $insertData['Cust_ID']);

		if(count($existingRow) > 0) {
			$this->update($insertData, $this->_db->quoteInto("Appl_No = ?", $insertData['Appl_No']) . " AND " . $this->_db->quoteInto("Cust_ID = ?", $insertData['Cust_ID']));
		}
		else {
			$this->insert($insertData);
		}

	}

	/** 
	 * Builds the insert array from the table field names and an array of values
	 *
	 */
	public function buildInsertArray($fieldData)
	{

		$insertData = array();

		foreach($this->fieldNames as $key =>$name) {
			$insertData[$name] = trim($fieldData[$key]);
		}

		$insertData['leadID'] = $this->findLeadID($insertData['PDLoan_Rcvd']);

		return $insertData;
	}

	/**
	 * Find the leadID
	 *
	 * @param               PDLoan_Rcvd     string	PDLoan_Rcvd field (sometimes has the leadID) 
	 *
	 * @return                              leadID  id of lead
	 */
	public function findLeadID($PDLoan_Rcvd)
	{
		if(is_numeric($PDLoan_Rcvd) && !empty($PDLoan_Rcvd)) { 
			$Leads = new Leads();
			$result = $Leads->find($PDLoan_Rcvd);
				
			if($result) {
				return $PDLoan_Rcvd;
			}
			else {
				return 0;
			}
		}
		else {
			return 0;
		}
	}

}
