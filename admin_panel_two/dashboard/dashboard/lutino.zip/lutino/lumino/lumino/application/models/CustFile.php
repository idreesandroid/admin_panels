<?php

/**
 * CustFile Model
 *
 * model for TRAN Cust_File table
 *
 */
class CustFile extends TranAbstract 
{

	protected $_name = 'Cust_File';
		
	public function init()
	{

		$this->fileName = "Cust_File";
		// db columns that are dates, used to format the date from scrape
		$this->dateFields = array(31, 80, 97, 101, 102, 114, 115);
		// scrape file type
		$this->cboFileType = "C";

		$this->fieldNames = array("Cust_MerchantID",
				"Merch_Store_ID",
				"Cust_ID",
				"Cust_SSN",
				"Cust_Name",
				"Cust_Suffix",
				"Cust_Add1",
				"Cust_Add2",
				"Cust_Add3",
				"Cust_Add4",
				"Cust_Add5",
				"Cust_City",
				"Cust_Location",
				"Cust_PostalCode",
				"Cust_PostalExt",
				"Cust_Country",
				"Cust_PrevAdd1",
				"Cust_PrevAdd2",
				"Cust_PrevAdd3",
				"Cust_PrevAdd4",
				"Cust_PrevAdd5",
				"Cust_PrevCity",
				"Cust_PrevLocation",
				"Cust_PrevPostalCode",
				"Cust_PrevPostalExt",
				"Cust_HPhone",
				"Cust_CellPhone",
				"Cust_WorkPhone",
				"Cust_WorkPhoneExt",
				"Cust_AltPhone",
				"Cust_Mom_MName",
				"Cust_DOB",
				"Cust_18YrsOld",
				"ID_Country",
				"IdentificationType",
				"Cust_DL_State",
				"Cust_DL_No",
				"IsMilitary",
				"MaritalStatus",
				"IsSpouseMilitary",
				"IsDependent",
				"IsClaimantMilitary",
				"CollateralType",
				"Cust_Auto_Year",
				"Cust_Auto_Make",
				"Cust_Auto_Model",
				"Cust_Auto_Color",
				"Cust_Auto_Tag",
				"Cust_Auto_VIN",
				"Cust_Auto_Note",
				"Cust_Utility_Bill",
				"Cust_Proper_ID",
				"Curr_Add_Dur",
				"Prev_Add_Dur",
				"Mortage_Comp",
				"Comp_Phone",
				"Home_Status",
				"Dist_Frm_Store",
				"Cust_Education",
				"Total_Income",
				"MerchantRefID",
				"Mkt_Codes",
				"PDLoan_Rcvd",
				"Email",
				"Ref_FName",
				"Ref_MName",
				"Ref_LName",
				"Ref_Add1",
				"Ref_Add2",
				"Ref_City",
				"Ref_State",
				"Ref_ZIP",
				"Ref_ZIP4",
				"Ref_HPhone",
				"Ref_WPhone",
				"Ref_Relation",
				"ABA_No",
				"Cust_Acct_No",
				"Cust_Acct_Type",
				"Voided_Check_No",
				"Acct_Open_Date",
				"Acct_Old",
				"Rec_Bank_Stmt",
				"NSF",
				"No_Of_Tran",
				"Ending_Stmt_Bal",
				"Emp_Name",
				"Country",
				"Emp_Add1",
				"Emp_Add2",
				"Emp_City",
				"Emp_State",
				"Emp_ZIP",
				"Emp_ZIP4",
				"Emp_Phone",
				"Type_Of_Income",
				"Emp_Type",
				"Emp_Date",
				"Work_Shift",
				"Type_Of_Payroll",
				"Avg_Salary",
				"Last_Pay_Date",
				"Next_Pay_Date",
				"Periodicity",
				"Frequency",
				"BizDays",
				"AWhichDay",
				"PayWeek1",
				"SemiDate1",
				"PayWeek2",
				"SemiDate2",
				"Income_Verified",
				"Pay_Garnishment",
				"Pay_Bankruptcy",
				"Date_Created",
				"Last_Modified"
				);
	}

	/**
	 * Updates or inserts a row
	 */
	public function upsert($insertData)
	{

		$existingRow = $this->find($insertData['Cust_MerchantID'], $insertData['Cust_ID']);

		if(count($existingRow) > 0) {
			$this->update($insertData, $this->_db->quoteInto("Cust_MerchantID = ?", $insertData['Cust_MerchantID']) . " AND " . $this->_db->quoteInto("Cust_ID = ?", $insertData['Cust_ID']));
		}
		else {
			$this->insert($insertData);
		}

	}
}
