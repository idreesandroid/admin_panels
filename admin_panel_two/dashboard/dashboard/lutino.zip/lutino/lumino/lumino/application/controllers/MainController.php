<?php
class MainController extends Zend_Controller_Action
{
    private   $baseurl;
    private   $userid;

	function init()
    {
    	$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if(!$AdminNameSpace->userid)
		{
    		$this->_redirect('index/login');
		}
    	$this->baseurl = $this->_request->getBaseUrl();
	    $this->userid = $AdminNameSpace->userid;
    }

    function indexAction()
    {
        $this->view->baseurl =$this->baseurl;
    	$this->view->userid =$this->userid;

    	$DashBoardFaceory = new DashBoardFactory();
    	$DashBoard = $DashBoardFaceory->create();

    	$hourlyAvgs  = $DashBoard->hourlyAvgForThePastWeek();
    	$todayTotals = $DashBoard->totalTodayPerHour();
    	$today 	= date('l');

    	// past 6 weekdays. e.g. past 6 Mondays
    	$DateUtil = new DateUtility();
    	$dates = $DateUtil->getWeekdayDates($today, 6);

    	// creating quoted comma-delim of dates
    	foreach ($dates as $date) {
    		$datesFormatted .= "'$date',";
    	}
    	$datesFormatted = rtrim($datesFormatted, ',');
    	$specificDayAvgs = $DashBoard->hourlyAvgForSpecificDay($datesFormatted);

    	// combine for easier output
    	$graphDatas = array();
    	foreach ($hourlyAvgs as $k => $v) {
    		$graphDatas[$k]['prettyHour'] = $v['prettyHour'];
    		$graphDatas[$k]['averageLeads'] = $v['averageLeads'];
    		$graphDatas[$k]['specificDayAvgs'] = $specificDayAvgs[$k]['averageLeads'];

    		// some hours might not exist yet. ie too early in the day
    		if (array_key_exists($k, $todayTotals)) {
    			$graphDatas[$k]['todayTotals'] = $todayTotals[$k]['total'];
    		} else {
    			$graphDatas[$k]['todayTotals'] = 0;
    		}
    	}

    	$fromDate = ($this->_request->fromDate) ?
    		$this->_request->fromDate : date('Y-m-d');
    	$toDate = ($this->_request->toDate) ?
    		$this->_request->toDate : date('Y-m-d');

    	$fromTime = '00:00:00';
    	$toTime = '23:59:59';

    	$this->view->fromDate = date('m/d/Y', strtotime($fromDate));
    	$this->view->toDate = date('m/d/Y', strtotime($toDate));

    	$this->view->graphDatas = $graphDatas;
    	$this->view->today 		= $today;

    	$main = new Main();
    	$adminUserNameByID = $main->getAdminUserNameByID($this->userid);
    	$fname = $adminUserNameByID[0]['fname'];
    	$lname = $adminUserNameByID[0]['lname'];
    	$this->view->fname = $fname;
    	$this->view->lname = $lname;


	    $charttype = $this->_request->charttype ? $this->_request->charttype : "hourly";
	    $this->view->charttype = $charttype;

	    $fromDate = ($this->_request->fromDate) ?
		    date('Y-m-d', strtotime($this->_request->fromDate)) : date('Y-m-d');
	    $toDate = ($this->_request->toDate) ?
		    date('Y-m-d', strtotime($this->_request->toDate)) : date('Y-m-d');
	    $selectedCampaignIDs = $this->_request->selectedCampaignIDs ? $this->_request->selectedCampaignIDs : "";

	    $DashBoard->setChartType('hourly', $fromDate, $toDate, 'false', $this->_request->affiliateID, $selectedCampaignIDs);

	    $dashboardData = $DashBoard->getDashboardData();
	    $this->view->totalAttemptsToday = $dashboardData['totalAttemptsToday'];
	    $this->view->totalActiveCampaigns = $dashboardData['totalActiveCampaigns'];
	    $this->view->totalCostToday = $dashboardData['totalCostToday'];
	    $this->view->totalSoldToday = $dashboardData['totalSoldToday'];
	    $this->view->acceptRate = number_format(ReportCalc::percentBoughtvsAttempted($dashboardData['totalSoldToday'], str_replace(",","",$dashboardData['totalAttemptsToday'])),2);

	    $this->view->totalNewCustomers = $dashboardData['totalNewCustomers'];
	    $this->view->totalNewCustomersPercentage = $dashboardData['totalNewCustomersPercentage'];
	    $this->view->totalReturningCustomers = $dashboardData['totalReturningCustomers'];
	    $this->view->totalReturningCustomersPercentage = $dashboardData['totalReturningCustomersPercentage'];
	    $this->view->totalNewCustomersOriginations = $dashboardData['totalNewCustomersOriginations'];
	    $this->view->totalReturningCustomersOriginations = $dashboardData['totalReturningCustomersOriginations'];
	    $this->view->barchart = $dashboardData['barchart'];

		if ($charttype == "hourly") {
			$this->view->chartLabels = $dashboardData['chartHours'];
			$this->view->chartLeadsAttempts = $dashboardData['chartLeadsAttemptsHourly'];
			$this->view->chartLeadsPurchase = $dashboardData['chartLeadsPurchaseHourly'];
		}

	    $UserSession = new Zend_Session_Namespace('UserSession');
	    if ($UserSession->role != 'affiliate') {
		    $affiliateId = $this->_request->affiliateID;
		    $this->view->affiliates = $DashBoard->getAllAffiliates();
		    $this->view->affiliateID = $affiliateId;
		    $this->view->campaignNames = json_decode($dashboardData['campaignNames']);
		    $this->view->selectedCampaignIDs = $selectedCampaignIDs;

	    }
    }

	function checksessionAction() {
		$result = array();
		$userIdleTimeMin = $this->_request->userIdleTimeMin;
		if ($userIdleTimeMin == 0) {
			$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
			$AdminNameSpace->setExpirationSeconds( 1200 );
		}

		$sessionTimeLeft = $_SESSION['__ZF']['AdminUser']['ENT'] - time();
		$result['sessiontime'] = $sessionTimeLeft;

		echo Zend_Json::encode($result);
		$this->_helper->viewRenderer->setnoRender();
	}

	function updatetabchartAction() {

		$charttype = $this->_request->charttype ? $this->_request->charttype : "hourly";
		$isCurrentTimeSnapshot = $this->_request->isCurrentTimeSnapshot ? $this->_request->isCurrentTimeSnapshot : "false";
		$affiliateID = $this->_request->affiliateID ? $this->_request->affiliateID : "";
		$campaignName = $this->_request->campaignName ? $this->_request->campaignName : "";

		$affiliateID = $affiliateID ? "'" . implode("','", $affiliateID) . "'" : "";
		$campaignName = $campaignName ? "'" . implode("','", $campaignName) . "'" : "";

		$fromDate = ($this->_request->fromDate) ?
			date('Y-m-d', strtotime($this->_request->fromDate)) : date('Y-m-d');
		$toDate = ($this->_request->toDate) ?
			date('Y-m-d', strtotime($this->_request->toDate)) : date('Y-m-d');

		$DashBoardFaceory = new DashBoardFactory();
		$DashBoard = $DashBoardFaceory->create();
		$DashBoard->setChartType($charttype, $fromDate, $toDate, $isCurrentTimeSnapshot, $affiliateID, $campaignName);
		$dashboardData = $DashBoard->getDashboardData();

		if ($charttype == "hourly") {
			$data['totalAttemptsToday'] = $dashboardData['totalAttemptsToday'];
			$data['totalActiveCampaigns'] = $dashboardData['totalActiveCampaigns'];
			$data['totalCostToday'] = $dashboardData['totalCostToday'];
			$data['totalSoldToday'] = $dashboardData['totalSoldToday'];
			$data['totalNewCustomers'] = $dashboardData['totalNewCustomers'];
			$data['totalNewCustomersPercentage'] = $dashboardData['totalNewCustomersPercentage'];
			$data['totalReturningCustomers'] = $dashboardData['totalReturningCustomers'];
			$data['totalReturningCustomersPercentage'] = $dashboardData['totalReturningCustomersPercentage'];
			$data['totalNewCustomersOriginations'] = $dashboardData['totalNewCustomersOriginations'];
			$data['totalReturningCustomersOriginations'] = $dashboardData['totalReturningCustomersOriginations'];
			$data['acceptRate'] = number_format(ReportCalc::percentBoughtvsAttempted($dashboardData['totalSoldToday'], str_replace(",","",$dashboardData['totalAttemptsToday'])),2);
			$data['chartLeadsAttempts'] = $dashboardData['chartLeadsAttemptsHourly'];
			$data['chartLeadsPurchase'] = $dashboardData['chartLeadsPurchaseHourly'];
			$data['chartLabels'] = $dashboardData['chartHours'];
			$data['charttype'] = $charttype;
		} else if ($charttype == "sevendays") {
			$data['chartLeadsAttempts'] = $dashboardData['chartLeadsAttemptsForLastSevenDays'];
			$data['chartLeadsPurchase'] = $dashboardData['chartLeadsPurchaseForLastSevenDays'];
			$data['chartLabels'] = $dashboardData['chartDays'];
			$data['charttype'] = $charttype;
		} else if ($charttype == "fiveweeks") {
			$data['chartLeadsAttempts'] = $dashboardData['chartLeadAttemptsCurrentDayForLastFiveWeeksData'];
			$data['chartLeadsPurchase'] = $dashboardData['chartLeadPurchasedCurrentDayForLastFiveWeeksData'];
			$data['chartLabels'] = $dashboardData['chartDays'];
			$data['charttype'] = $charttype;
		}

		$data['campaignNames'] = $dashboardData['campaignNames'];
		$data['selectedCampaignName'] = $campaignName;

		echo json_encode($data);

		$this->_helper->viewRenderer->setnoRender();
	}


	function getcampaignnamesAction() {
		$selectedAffiliates = $this->_request->selectedAffiliates ? $this->_request->selectedAffiliates : array();

		$DashBoardFactory = new DashBoardFactory();
		$DashBoard = $DashBoardFactory->create();

		$Affiliates = new Affiliates();

		$campaignIDs = array();
		foreach ($selectedAffiliates as $affiliateID) {
			$affiliateName = $Affiliates->getAffiliateNameByID($Affiliates->fetchAll(), $affiliateID);
			$campaignIDs += $DashBoard->getCampaignsByAffiliateName($affiliateName);
		}

		echo json_encode($campaignIDs);

		$this->_helper->viewRenderer->setnoRender();
	}

	/**
	 * format array so we can easily plug into piechart
	 *
	 * @param array $data
	 * @return array
	 */
	private function prepareData($data)
	{
		$formatted = array();

		foreach ($data as $k => $v) {
			$formatted[$v['campaign']."-".$v['masteraff']] = $v['total'];
		}
		return $formatted;
	}
}
?>
