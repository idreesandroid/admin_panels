<?php

class SearchCustomersController extends Zend_Controller_Action
{
	private $SearchCustomers;
	private $baseurl;

	public function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if(!$AdminNameSpace->userid)
		{
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();

		$this->SearchCustomers = new SearchCustomers();
		$this->Leads = new Leads();
	}

	public function indexAction()
	{
		$this->view->fromDate = date("Y-m-d");
		$this->view->toDate = date("Y-m-d");
		$this->view->searchtype = ($this->_request->searchtype) ? $this->_request->searchtype : 'ssntype';
	}

	public function searchDataAction()
	{

		$returnArray = array();

		if($_POST['submit']) {

			$searchtype = ($this->_request->searchtype) ? $this->_request->searchtype : 'ssntype';

			$fromDate = ($this->_request->fromDate) ? $this->_request->fromDate : "";
			$this->view->fromDate = $fromDate;
			$Date = new DateTime($fromDate);
			$fromDate = $Date->format("Y-m-d");

			$toDate = ($this->_request->fromDate) ? $this->_request->toDate : "";
			$this->view->toDate = $toDate;
			$Date = new DateTime($toDate);
			$toDate = $Date->format("Y-m-d");

			$searchvalue = ($this->_request->searchvalue) ? $this->_request->searchvalue : "";

			if($searchvalue && $searchtype) {
				// search either on ssn or email for dupes
				$ssn = '';
				$email = '';
				if ($searchtype == "emailtype") {
					$email = $searchvalue;
				} else if ($searchtype == "ssntype") {
					$ssn = $searchvalue;
				} else if ($searchtype == "leadidtype") {
                    $leadID = $searchvalue;
                }

				$page = 0;
				$limit = 50;

				if ($searchtype == "leadidtype") {
                    $reportData = $this->SearchCustomers->getCustomerDataByLeadID($fromDate, $toDate,$leadID);
                }
                else {
                    // data for current page
                    $reportData = $this->SearchCustomers->getCustomerData($fromDate, $toDate, $email, $ssn, $page, $limit, $columns[$sortColNum], "ASC");
                }


				foreach($reportData as $row) {

					$dataRow = array();

					$dataRow[] = $row['datetime'];
					$dataRow[] = $row['id'];
					$dataRow[] = $row['storeID'];
					$dataRow[] = $row['masteraff'];
					$dataRow[] = $row['campaign'];
					$dataRow[] = $row['leadsold'];
					$dataRow[] = $row['ip'];
					$dataRow[] = ((!empty($row['city'])) ? $row['city'] . ", " : "") . $row['state'];
					$dataRow[] = $row['fname'];
					$dataRow[] = $row['lname'];
					$dataRow[] = $row['email'];
					$dataRow[] = (isset($row['ssn']) && !empty($row['ssn'])) ? substr_replace($row['ssn'], "xxx-xx-", 0, 5) : "";
					$dataRow[] = isset($row['mphone']) ? $row['mphone'] : "";

					if(!empty($row['dob'])) {
						$DOB = new DateTime($row['dob']);
						$Date = new DateTime();
						$dobInterval = $Date->diff($DOB);
						$dataRow[] = $row['dob'] . " (" . $dobInterval->y . ")";
					}
					else {
						$dataRow[] = "";
					}

					$dataRow[] = $row['monthlyincome'];

					$returnArray[] = $dataRow;
				}
			}
			$this->view->searchtype = $searchtype;
			$this->view->searchvalue = $searchvalue;
			$this->view->data = $returnArray;

		} else if($this->_request->leadid) {

			$fromDate = ($this->_request->fromDate) ? $this->_request->fromDate : "";
			$this->view->fromDate = $fromDate;
			$Date = new DateTime($fromDate);
			$fromDate = $Date->format("Y-m-d");

			$toDate = ($this->_request->fromDate) ? $this->_request->toDate : "";
			$this->view->toDate = $toDate;
			$Date = new DateTime($toDate);
			$toDate = $Date->format("Y-m-d");

			// data for current page
			$reportData = $this->SearchCustomers->getCustomerDataByLeadID($fromDate, $toDate, $this->_request->leadid);

			foreach($reportData as $row) {

				$dataRow = array();

				$dataRow[] = $row['datetime'];
				$dataRow[] = $row['id'];
				$dataRow[] = $row['storeID'];
				$dataRow[] = $row['masteraff'];
				$dataRow[] = $row['campaign'];
				$dataRow[] = $row['leadsold'];
				$dataRow[] = $row['ip'];
				$dataRow[] = ((!empty($row['city'])) ? $row['city'] . ", " : "") . $row['state'];
				$dataRow[] = $row['fname'];
				$dataRow[] = $row['lname'];
				$dataRow[] = $row['email'];
				$dataRow[] = (isset($row['ssn']) && !empty($row['ssn'])) ? substr_replace($row['ssn'], "xxx-xx-", 0, 5) : "";
				$dataRow[] = isset($row['mphone']) ? $row['mphone'] : "";

				if(!empty($row['dob'])) {
					$DOB = new DateTime($row['dob']);
					$Date = new DateTime();
					$dobInterval = $Date->diff($DOB);
					$dataRow[] = $row['dob'] . " (" . $dobInterval->y . ")";
				}
				else {
					$dataRow[] = "";
				}

				$dataRow[] = $row['monthlyincome'];

				$returnArray[] = $dataRow;
			}

			$this->view->searchtype = '';
			$this->view->searchvalue = '';
			$this->view->data = $returnArray;
		}
		else {
			$this->view->fromDate = date("Y-m-d");
			$this->view->toDate = date("Y-m-d");
			$this->view->searchtype = ($this->_request->searchtype) ? $this->_request->searchtype : 'emailtype';
			$this->view->data = array();
		}
	}

	public function searchPostlogsAction()
	{
		$PostLogs = new PostLogs();
		$reportData = $PostLogs->getDataByLeadID($this->_request->leadID);

		$vendorsClientsResult = $this->SearchCustomers->getAllVendorsAndClients();

		$returnArray = array();
		foreach($reportData as $row) {
			$dataRow = array();

			$dataRow["postDate"] = $row['postDate'] . ' ' . $row['startTime'];
			$dataRow["postSetupID"] = $row['postSetupID'];

			$clientVendorName = "";
			foreach ($vendorsClientsResult as $value) {
				if ($value['postSetupID'] == $row['postSetupID']) {
					$clientVendorName = $value['company'];
				}
			}

            // for clarity. as we need to show clarity report link
			$reportLink = "";
			if ($row['clientID'] == 22) {
                if (preg_match("/<tracking\-number>(.*?)<\/tracking\-number>/i",$row['postResponse'],$matches)) {
                    $trackingNumber = $matches[1];
                    $reportLink = '<a style="color:#30a5ff;text-decoration:underline;" href="https://login.clarityservices.com/xml_responses/'.$trackingNumber.'" target="_blank">View Clarity Report</a>';
                }
            }
            else if($row['clientID'] == 19) {
                $postResponse = $row['postResponse'];
                if (preg_match('/<ReportLink>(.*?)<\/ReportLink>/i',$postResponse,$matches)) {
                    $reportLink = '<a style="color:#30a5ff;" href="'.$matches[1].'" target="_blank">View FactorTrust Report</a>';
                }
            }

			$dataRow["clientVendorName"] = $clientVendorName;
			$dataRow["postStatus"] = $row['postStatus'];
			$dataRow["postResponse"] = '<button onclick="showPostRespose('.$row['id'].', '.$this->_request->leadID.', '.$row['postSetupID'].')" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#post_response">
													<span class="glyphicon glyphicon-search"></span>
												</button>&nbsp;&nbsp;'.$reportLink;
			$dataRow["type"] = $row['productCode'];

			$returnArray[] = $dataRow;
		}

		echo json_encode($returnArray);

		$this->_helper->viewRenderer->setnoRender();
	}

	public function showPostResponseAction()
	{
		$PostLogs = new PostLogs();
		$reportData = $PostLogs->getDataByLeadIDAndPostSetupID($this->_request->postLogID, $this->_request->leadID, $this->_request->postSetupID);

		if ($reportData) {
			$dataRow['postResponse'] = $reportData['postResponse'];
			$dataRow['postQueryString'] = $reportData['postQueryString'];
			echo json_encode($dataRow);
		}

		$this->_helper->viewRenderer->setnoRender();
	}
}
