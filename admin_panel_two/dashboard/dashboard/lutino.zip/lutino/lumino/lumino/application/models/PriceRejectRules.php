<?php
class PriceRejectRules extends Zend_Db_Table
{
	protected $_name = 'PriceRejectRules';

	public function init()
	{
	    $this->db = Zend_Registry::get('db');
	}

	public function getRulesByPriceRejectRulesetID($ruleSetID)
	{
	    $sql = $this->select()
	    ->where("priceRejectRulesetID = ?", $ruleSetID)
	    ->order('id asc');

	    $rulesData = array();
	    $priceRejectRules =  $this->fetchAll($sql);

	    if (count($priceRejectRules) > 0) {
	        foreach ($priceRejectRules as $rule) {
	            $tuple = array();
	            $tuple['rulePassingValue'] = $rule['value'];
	            $tuple['comparisonOperator'] = $this->getComparisonOperatorNameByID($rule['comparisonOperatorID']);
	            $tuple['vendorResponseParam'] = $this->getGetVendorResponseParameterNameByID($rule['vendorResponseParameterID']);
	            $tuple['logicalOperator'] = $this->getLogicalOperatorNameByID($rule['logicalOperatorID']);
	            $rulesData[] = $tuple;
	        }
	    }
	    return $rulesData;
	}

	public function getComparisonOperatorNameByID($operatorID)
	{
	    if (!$operatorID) {
	        return null;
	    }
	    $sql = "SELECT id,name FROM ComparisonOperators co WHERE co.id = $operatorID";
	    $operator = $this->db->fetchRow($sql);
	    return $operator;
	}

    public function getLogicalOperatorNameByID($operatorID)
	{
		if (!$operatorID) {
			return null;
		}
		$sql = "SELECT id,name FROM LogicalOperators lo WHERE lo.id = $operatorID";
		$operator = $this->db->fetchRow($sql);
		return $operator;
	}

	public function getGetVendorResponseParameterNameByID($responseParamID)
	{
		if (!$responseParamID) {
			return null;
		}
		$sql = "SELECT id,name FROM VendorResponseParameters vrp WHERE vrp.id = $responseParamID";
		$parameter = $this->db->fetchRow($sql);
		return $parameter;
	}
}
?>