<?php
class RandomScorecardController extends Zend_Controller_Action
{
	function init()
	{

	}

	function indexAction()
	{
		$MultiVariate = new MultiVariate();
		$randomvariates = $MultiVariate->getAllRandomMultivariates();

		$this->view->randomvariates = $randomvariates;
	}

	function editAction()
	{
		$multivariateID = $this->getRequest()->getParam('multivariateID');
		if ($multivariateID) {
			$Variate = new Variate();
			$staticvariates = $Variate->fetchAll(NULL, "id");
			$this->view->staticvariates = $staticvariates;

			$MultiVariatesVariate = new MultiVariatesVariate();
			$multiVariatesVariates = $MultiVariatesVariate->getDataByMultivariateID($multivariateID);
			$this->view->multivariatesvariates = $multiVariatesVariates;

			$MultiVariate = new MultiVariate();
			$multiVariates = $MultiVariate->getDataByMultivariateID($multivariateID);
			$this->view->randomvariates = $multiVariates;

			$this->view->scorecardname = $multiVariates['name'];
			$this->view->scorecarddesc = $multiVariates['description'];

			$this->view->multivariateID = $multivariateID;

			$MultiVariateLeadRuleset = new MultiVariateLeadRuleset();
			$variateRulesets = $MultiVariateLeadRuleset->generateRulesetsDataByMultiVariateID($multivariateID);
			$this->view->variateRulesets = $variateRulesets;

			$MultiVariate = new MultiVariate();
			$this->view->multivariates = $MultiVariate->getAllRandomMultivariatesWithExceptionMultivariates($multivariateID);

		}
	}

	function deleteAction()
	{
		$multivariateID = $this->getRequest()->getParam('multivariateID');
		$response = array();

		if ($multivariateID) {
			$MultiVariate = new MultiVariate();
			if ($MultiVariate->checkIfSafeToDelete($multivariateID)) {
				$MultiVariateLeadRule = new MultiVariateLeadRule();
				$MultiVariateLeadRule->deleteAllRulesByMultiVariateID($multivariateID);
				$MultiVariateLeadRuleset = new MultiVariateLeadRuleset();
				$MultiVariateLeadRuleset->deleteBymMultiVariateID($multivariateID);

				$where = "id=$multivariateID";
				$MultiVariate->delete($where);

				$where = "multiVariateID=$multivariateID";
				$MultiVariatesVariate = new MultiVariatesVariate();
				$MultiVariatesVariate->delete($where);

				$MultiVariateLeadExceptionMultiVariate = new MultiVariateLeadExceptionMultiVariate();
				$MultiVariateLeadExceptionMultiVariate->deleteByMultivariateID($multivariateID);
			} else {
				$response['status'] = 'error';
			}
		} else {
			$response['status'] = 'error';
		}

		echo Zend_Json::encode($response);
		$this->_helper->viewRenderer->setnoRender();
	}

	function cancelAction()
	{
		$this->_redirect('/random-scorecard');
	}

	function saveAction()
	{
		if ($this->_request->isPost()) {
			$scorecardName = $this->getRequest()->getParam('scorecardname');
			$scorecardDesc = $this->getRequest()->getParam('scorecarddesc');
			$multivariateID = $this->getRequest()->getParam('multivariateID');
			$type = $this->getRequest()->getParam('type');
			$randomScorecardData = $this->getRequest()->getParam('randomScorecardData');
			$exceptionMultivariate = $this->getRequest()->getParam('exceptionMultivariate');

			// parameters for rulesets and rules
			$rulesets = Zend_Json::decode($this->getRequest()->getParam('rulesets'));
			$rulesetOperators = Zend_Json::decode($this->getRequest()->getParam('rulesetOperators'));
			$ruleData = Zend_Json::decode($this->getRequest()->getParam('rules'));
			$ruleOperators = Zend_Json::decode($this->getRequest()->getParam('ruleOperators'));
			$ruleIDs = Zend_Json::decode($this->getRequest()->getParam('ruleIDs'));


			if ($randomScorecardData) {
				$MultiVariate = new MultiVariate();
				$MultiVariatesVariate = new MultiVariatesVariate();
				if ($type == "edit") {
					$dataForUpdate = array(
						'name' => $scorecardName,
						'description' => $scorecardDesc);

					$multivariateID = $MultiVariate->upsert($multivariateID, $dataForUpdate);

					$where = "multivariateID=$multivariateID";
					$MultiVariatesVariate->delete($where);

				} else if ($type == "new") {
					$dataForSave = array(
						'name' => $scorecardName,
						'description' => $scorecardDesc);

					$multivariateID = $MultiVariate->insert($dataForSave);
				}

				foreach ($randomScorecardData AS $scorecard) {
					$min = $scorecard['minPercent'];
					$max = $scorecard['maxPercent'];
					$variateID = $scorecard['variate'];

					$data = array(
						'minPercent' => $min,
						'maxPercent' => $max,
						'multiVariateID' => $multivariateID,
						'variateID' => $variateID
					);

					$MultiVariatesVariate->saveData($data);
				}
			}


			$MultiVariateLeadRuleset = new MultiVariateLeadRuleset();
			$MultiVariateLeadRuleset->buildRuleset($rulesets, $multivariateID, $rulesetOperators, $ruleIDs, $ruleData, $ruleOperators);


			$MultiVariateLeadExceptionMultiVariate = new MultiVariateLeadExceptionMultiVariate();

			if (!$rulesets) {
				$MultiVariateLeadExceptionMultiVariate->deleteByMultivariateID($multivariateID);
			} else {
				if ($exceptionMultivariate != 0) {
					$data = array(
						'multiVariateID' => $multivariateID,
						'exceptionMultiVariateID' => $exceptionMultivariate
					);
					$MultiVariateLeadExceptionMultiVariate->upsert($multivariateID, $data);
				} else {
					$MultiVariateLeadExceptionMultiVariate->deleteByMultivariateID($multivariateID);
				}
			}
		}

		$this->_redirect('/random-scorecard');
	}

	function newAction()
	{
		$Variate = new Variate();
		$staticvariates = $Variate->fetchAll(NULL, "id");
		$this->view->staticvariates = $staticvariates;

		$MultiVariate = new MultiVariate();
		$this->view->multivariates = $MultiVariate->getAllMultivariates();
	}

	public function searchAction()
	{
		$this->_helper->viewRenderer->setnoRender();
		$paramName = $this->getRequest()->getParam('query');
		$LeadRequestParameter = new LeadRequestParameter();
		$data = $LeadRequestParameter->findParameterByName($paramName);

		$result = array();
		$parameters = array();
		foreach ($data as $v) {
			$result['id'] = $v['id'];
			$result['name'] = $v['name'];
			$parameters[] = $result;
		}

		echo Zend_Json::encode($parameters);
	}

}

?>
