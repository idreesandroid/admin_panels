<?php
class ListController extends Zend_Controller_Action 
{
    private $baseurl;
	
	function init()
    {
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if(!$AdminNameSpace->userid)
		{
	    		$this->_redirect('index/login');	
		}
	    $this->baseurl = $this->_request->getBaseUrl();
    }
    
    
    function createsetupAction()
    {
    	global $db;
    	$message = "";
    	$error = 0;
    	$success = 0;
    	$testbutton = 0;
    	
    	if ($this->_request->isPost()) {
    		
    		$test = @($_POST['test']);
    		
    		$clientid = $this->_request->getPost('clientid');
    		$status = $this->_request->getPost('status');
    		$deliverytype = $this->_request->getPost('deliverytype');
    		$testurl = $this->_request->getPost('testurl');
    		$posturl = $this->_request->getPost('posturl');
    		$postheader = $this->_request->getPost('postheader');
    		$blaffiliate = $this->_request->getPost('blaffiliate');
    		$blacampaigns = $this->_request->getPost('blacampaigns');
    		$translation = $this->_request->getPost('translation');
    		$poststring = $this->_request->getPost('poststring');
    		$priority = $this->_request->getPost('priority');
    		
			if(empty($clientid)){
    			$message.="Please select client.<br>";
    			$error = 1;
    		}
    		if(empty($priority)){
    			$message.="Please provide priority.<br>";
    			$error = 1;
    		}
			if(empty($posturl)){
    			$message.="Please provide post url.<br>";
    			$error = 1;
    		}
    		if(empty($poststring)){	
    			$message.="Please provide post string.<br>";
    			$error = 1;
    		}
    		
    			
    		if($error==0)
    		{
    			if($test)
    			{
    				require_once("TestPostSubmitter.class.php");
					$post_submitter  = new TestPostSubmitter();	
					$result_array = $post_submitter->Translate_Postdata($testurl,$postheader,$translation,$poststring,$deliverytype);
					$this->view->response = "Query String:\n".$result_array[0]."\n\nResult:\n".$result_array[1];
					$testbutton = 1;
					$error = 1;
					
    			}
    			else {
	    			$Form_Data = array('clientid'=>$clientid,'active'=>$status,'priority'=>$priority,'postdeliverytype'=>$deliverytype,'postheader'=>$postheader,'posturl'=>$posturl
	    			,'posttesturl'=>$testurl,'postquerystring'=>$poststring,'posttranslation'=>$translation,'blacklist_campaigns'=>$blacampaigns,'blacklist_masteraff'=>$blaffiliate);
	
	    			Zend_Loader::loadClass('Listmanagers');
				    $lm  = new Listmanagers();
				    try 
				    { 
				   		$lm->insert($Form_Data);	
				   		$message = "List manager setup successfully created.";	
				   		$success = 1;		   		
				    }
				    catch (Zend_Exception $e)
				    {
				   		$error = 1;
				    	$message = "Some error occurred please try latter.";
				    	
				    }
    			}
    		}
    		if ($error==1 || $testbutton==1){
    			
    			$this->view->clientid = $clientid;
    			$this->view->status = $status;
    			$this->view->postmethod = $deliverytype;
    			$this->view->priority = $priority;
    			$this->view->testurl = $testurl;
    			$this->view->postingurl = $posturl;
    			$this->view->postheader = $postheader;
    			$this->view->blacklistaffiliate = $blaffiliate;
    			$this->view->blacklistcampaigns = $blacampaigns;
    			$this->view->translation = $translation;
    			$this->view->poststring = $poststring;
    		}
    		
    		
    	}
    	
    	$query = "select * from clients where productcode='list' order by fname ";
    	$listmangers = $db->fetchAll($query);
    	
    	$this->view->baseurl = $this->baseurl;
    	$this->view->message = $message;
    	$this->view->error = $error;
    	$this->view->success = $success;
    	$this->view->lmdata = $listmangers;
    	
    }
    
    function editsetupAction()
    {
    	global $db;
    	$id = $_REQUEST['id'];
    	
    	$message = "";
    	$error = 0;
    	$success = 0;
    	$testbutton = 0;
    	
    	if ($this->_request->isPost()) {
    		
    		$test = @($_POST['test']);
    		
    		$clientid = $this->_request->getPost('clientid');
    		$status = $this->_request->getPost('status');
    		$deliverytype = $this->_request->getPost('deliverytype');
    		$testurl = $this->_request->getPost('testurl');
    		$posturl = $this->_request->getPost('posturl');
    		$postheader = $this->_request->getPost('postheader');
    		$blaffiliate = $this->_request->getPost('blaffiliate');
    		$blacampaigns = $this->_request->getPost('blacampaigns');
    		$translation = $this->_request->getPost('translation');
    		$poststring = $this->_request->getPost('poststring');
    		$priority = $this->_request->getPost('priority');
    		
			if(empty($clientid)){
    			$message.="Please select client.<br>";
    			$error = 1;
    		}
    		if(empty($priority)){
    			$message.="Please provide priority.<br>";
    			$error = 1;
    		}
			if(empty($posturl)){
    			$message.="Please provide post url.<br>";
    			$error = 1;
    		}
    		if(empty($poststring)){	
    			$message.="Please provide post string.<br>";
    			$error = 1;
    		}
    		
    		if($error==0)
    		{
    			if($test)
    			{
    				require_once("TestPostSubmitter.class.php");
					$post_submitter  = new TestPostSubmitter();	
					$result_array = $post_submitter->Translate_Postdata($testurl,$postheader,$translation,$poststring,$deliverytype);
					$this->view->response = "Query String:\n".$result_array[0]."\n\nResult:\n".$result_array[1];
					$testbutton = 1;
					$error = 1;
					
    			}
    			else 
    			{
	    			$Form_Data = array('clientid'=>$clientid,'active'=>$status,'priority'=>$priority,'postdeliverytype'=>$deliverytype,'postheader'=>$postheader,'posturl'=>$posturl
	    			,'posttesturl'=>$testurl,'postquerystring'=>$poststring,'posttranslation'=>$translation,'blacklist_campaigns'=>$blacampaigns,'blacklist_masteraff'=>$blaffiliate);
	    			
	    			Zend_Loader::loadClass('Listmanagers');
				    $lm  = new Listmanagers();
				    try 
				    { 
				   		$where = "postsetupid=$id";
				    	$lm->update($Form_Data,$where);	
				   		$message = "List manager setup successfully updated.";	
				   		$success = 1;		   		
				    }
				    catch (Zend_Exception $e)
				    {
				   		$error = 1;
				    	$message = "Some error occurred please try latter.";
				    	
				    }
    			}
    		}
    		if ($error==1 || $testbutton==1){
    			
    		$this->view->clientid = $clientid;
    		$this->view->status = $status;
    		$this->view->postmethod = $deliverytype;
    		$this->view->priority = $priority;
    		$this->view->testurl = $testurl;
    		$this->view->postingurl = $posturl;
    		$this->view->postheader = $postheader;
    		$this->view->blacklistaffiliate = $blaffiliate;
    		$this->view->blacklistcampaigns = $blacampaigns;
    		$this->view->translation = $translation;
    		$this->view->poststring = $poststring;
    		$this->view->id    = $id;	
	    		
    			
    		}
    	}
    	
    	if($error==0) {
    		$query = "select * from postsetups where postsetupid = $id";
    		
    		$data = $db->fetchRow($query);
    		$this->view->clientid = $data['clientid'];
    		$this->view->status = $data['active'];
    		$this->view->postmethod = $data['postdeliverytype'];
    		$this->view->priority = $data['priority'];
    		$this->view->testurl = $data['posttesturl'];
    		$this->view->postingurl = $data['posturl'];
    		$this->view->postheader = $data['postheader'];
    		$this->view->blacklistaffiliate = $data['blacklist_masteraff'];
    		$this->view->blacklistcampaigns = $data['blacklist_campaigns'];
    		$this->view->translation = $data['posttranslation'];
    		$this->view->poststring = $data['postquerystring'];
    		$this->view->response = "";
    		$this->view->id    = $data['postsetupid'];	
    	}
    	
    	$query = "select * from clients where productcode='list' order by fname ";
    	$listmangers = $db->fetchAll($query);
    	
    	$this->view->baseurl = $this->baseurl;
    	$this->view->message = $message;
    	$this->view->error = $error;
    	$this->view->success = $success;
    	$this->view->lmdata = $listmangers;
    }
    
    function viewAction()
    {
    	global $db;
    	$query = "select * from postsetups inner join clients on clients.clientid = postsetups.clientid and clients.productcode='list' order by company";
    	$clients = $db->fetchAll($query);
    	$this->view->baseurl = $this->baseurl;
    	$this->view->data = $clients;
    }
    
    function deleteAction()
    {
    	$id= $_GET['id'];
    	$where = "postsetupid='$id'";
    	Zend_Loader::loadClass('Listmanagers');
		$lm  = new Listmanagers();
	    $lm->delete($where);
	    
	    $this->_redirect('list/view');	
    }
}
?>