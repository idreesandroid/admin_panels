<?php

class TdcDailyCampaignReport extends DailyCampaignReportAbstract {

    public function getCampaignReports($customerType, $campaignID, $startDate, $endDate, $originalTimeStart, $originalTimeEnd, $storeIds)
    {
        $leadData = $this->getCampaignReportData($customerType,$campaignID,$startDate, $endDate, $originalTimeStart, $originalTimeEnd, $storeIds);
        $reportData	= $this->calculateValues($leadData);
        $reportData	= $this->totalCalculatedValues($reportData);

        return $reportData;
    }

    public function getCampaignReportData($customerType,$campaign,$startDateReport, $endDateReport, $originalTimeStart, $originalTimeEnd, $storeIds)
    {
        $startDateTimeReport = $startDateReport . " " . $originalTimeStart;
		$endDateTimeReport = $endDateReport . " " . $originalTimeEnd;

		$dateAndTimeWithoutStoreIDs = "2013-03-11 22:02:30";
		if(strtotime($startDateTimeReport) > strtotime($dateAndTimeWithoutStoreIDs)){
			$qMasterStoresIDs = "";
			$qLeadsStoresIDs = "";
			if (strlen($storeIds) == 0) {
				$storeIds = "''";
			}
			$qMasterStoresIDs = "AND Master.Store_number IN ($storeIds)";
			$qLeadsStoresIDs = "AND storeID IN ($storeIds)";
		}

		$inSql = "SELECT l.id FROM Leads l
		INNER JOIN ReturningCustomers rc ON l.id = rc.leadID
		WHERE
		l.campaign = '$campaign' AND
		l.originaldate >= '$startDateReport' AND l.originaldate <= '$endDateReport'
		AND
		l.originaltime >= '$originalTimeStart' AND l.originaltime <= '$originalTimeEnd'
		";

		if ($customerType == "new") {
		    $filter = " NOT IN (".$inSql.") ";
		}
		else if ($customerType == 'returning') {
		     $filter = " IN (".$inSql.") ";
		}

        $sql = "SELECT IFNULL(Leads.campaign, 1) campaign,
                COUNT(1) AS leads,
                IFNULL(totalSold, 0) AS bought,
                IFNULL(TotalPrice, 0) AS TotalPrice,
                IFNULL(TotalOriginated, 0) AS TotalLoansOriginated,
                IFNULL(TodaysOriginated, 0) AS LoansOriginated,
                COUNT(DISTINCT Loan_App.Cust_ID) AS esigs,
                COUNT(DISTINCT PixelFires.leadID) AS redirects,
                IFNULL(leadPrice, 0) AS cost
                FROM Leads
                LEFT JOIN (
					SELECT
						campaign,
						SUM(totalSold) totalSold,
						SUM(TotalPrice) TotalPrice,
						IFNULL(FORMAT(TotalPrice / totalSold,2),0) AS leadPrice
					FROM
						(
							SELECT
								ls.campaign,
								price,
								count(1) AS totalSold,
								COALESCE (price * count(1), 0) AS TotalPrice
							FROM
							LeadSold ls
							INNER JOIN Leads ON Leads.id = ls.leadID
							WHERE
							Leads.originaldate >= '$startDateReport' AND Leads.originaldate <= '$endDateReport'
							AND
							Leads.originaltime >= '$originalTimeStart' AND Leads.originaltime <= '$originalTimeEnd'
							".$qLeadsStoresIDs."
							AND Leads.id $filter
							AND Leads.campaign = '$campaign'
						) S
				) AS LeadSold ON LeadSold.campaign = Leads.campaign
				LEFT JOIN (
					SELECT
						campaign ocampaign,
						count(1) totalOriginated
					FROM
					Master
					LEFT OUTER JOIN Leads ON Leads.id = Master.leadID
					WHERE
					Master.Loan_Type = 'S'
					AND Loan_Status NOT IN ('I', 'V', 'W')
					AND Loan_Date >= '$startDateTimeReport'
					AND Loan_Date <= '$endDateTimeReport'
                    ".$qMasterStoresIDs."
					AND Leads.id $filter
					AND Leads.campaign = '$campaign'
				) AS Originations ON ocampaign = Leads.campaign
				LEFT JOIN (
				    SELECT
						campaign tcampaign,
						count(1) todaysOriginated
					FROM
					Master
					LEFT OUTER JOIN Leads ON Leads.id = Master.leadID
					WHERE
					Master.Loan_Type = 'S'
					AND Loan_Status NOT IN ('I', 'V', 'W')
					AND ApplicationDate >= '$startDateTimeReport'
					AND ApplicationDate <= '$endDateTimeReport'
					".$qMasterStoresIDs."
					AND Leads.id $filter
					AND Leads.campaign = '$campaign'
				) AS TodaysOriginated ON tcampaign = Leads.campaign
				LEFT JOIN Loan_App ON Leads.id = Loan_App.leadID
				AND
					TIMESTAMPDIFF(MINUTE,Loan_App.ApplicationDate,Loan_App.ESig_Date) <= 20
				AND
					Loan_App.ESig_Date != '1900-01-01 00:00:00'
				LEFT JOIN PixelFires ON Leads.id = PixelFires.leadID
				AND PixelFires.createdAt >= '$startDateTimeReport'
				AND PixelFires.createdAt <= '$endDateTimeReport'
				LEFT JOIN Campaigns camp ON Leads.campaign = camp.campaign
				WHERE Leads.id $filter
				AND Leads.campaign = '$campaign'
				AND Leads.originaldate >= '$startDateReport' AND Leads.originaldate <= '$endDateReport'
				AND
				Leads.originaltime >= '$originalTimeStart' AND Leads.originaltime <= '$originalTimeEnd' ".$qLeadsStoresIDs."
				";

        $result = $this->db_slave->fetchAll($sql);
        return $result;
    }
}