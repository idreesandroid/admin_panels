<?php

class EngineConfigSetting extends Zend_Db_Table
{
	protected $_name = 'EngineConfigSettings';

	/**
	 * Updates or inserts a row
	 */
	public function upsert($insertData)
	{
		$existingRow = $this->fetchRow();

		if ($existingRow) {
			$id = $this->update($insertData, $this->_db->quoteInto("id = ?", $existingRow['id']));
			return $id;
		} else {
			return $this->insert($insertData);
		}
	}
}
