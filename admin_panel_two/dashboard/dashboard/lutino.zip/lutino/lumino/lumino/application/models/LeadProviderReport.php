<?php

/**
 * Lead Provider Report class
 * pulls report data for these reports
 *
 * @category    Model
 * @package     none
 * @subpackage  LeadProviderReport
 * @author      Andrew Ahn <andrewa@mediaenvy.com>
 */
class LeadProviderReport
{

	public function __construct()
	{
		$bootstrap = Zend_Controller_Front::getInstance()->getParam("bootstrap");
		$resource = $bootstrap->getPluginResource('multidb');
		$this->db_slave = $resource->getDb('slave');

		$this->Campaigns = new Campaigns();
		$this->ClarityResponse = new ClarityResponse();
		$this->RelianceResponse = new RelianceResponse();
		$this->PreScrubLog = new PreScrubLog();
		$this->BuyerRejectError = new BuyerRejectErrors();
		$this->BuyerRejectDenial = new BuyerRejectDenial();
	}

	/**
	 * Gets the total attempts
	 *
	 * @param	date	$fromDate	start of date range
	 * @param	time	$fromTime	start time
	 * @param	date	$toDate		end of date range
	 * @param	time	$toTime		end time
	 * @param	int	$affiliateID	id of affiliate
	 * @param	int	$campaignID	id of campaign
	 * @param	array	$storeIDs	id of stores
	 *
	 * @return	int			total attempts
	 */
	public function getTotalAttempts($fromDate, $fromTime, $toDate, $toTime, $affiliateID = "", $campaignID = "", $storeIDs = "")
	{


		$dateWhere = $this->db_slave->quoteInto("originaldate > ?", $fromDate) . " AND " .
				$this->db_slave->quoteInto("originaldate < ?", $toDate) . " OR " .
				"(" . $this->db_slave->quoteInto("originaldate = ?", $fromDate) . " AND " . $this->db_slave->quoteInto("originaltime >= ?", $fromTime) . ") OR " .
				"(" . $this->db_slave->quoteInto("originaldate = ?", $toDate) . " AND " . $this->db_slave->quoteInto("originaltime <= ?", $toTime) . ")";

		$sql = $this->db_slave->select()
					->from("Leads", array("total" => "COUNT(1)"))
					->where($dateWhere);

		if(!empty($affiliateID)) {
			$sql->where($this->db_slave->quoteInto("Leads.affiliateID = ?", $affiliateID));
		}

                if(!empty($campaignID)) {
                        $sql->where($this->db_slave->quoteInto("Leads.campaign = ?", $campaignID));
                }

		if(!empty($storeIDs)) {
			$storeIDIN = implode(",", $storeIDs);
			$sql->where("storeID IN (" . $storeIDIN . ")");
		}

		$result = $this->db_slave->fetchRow($sql);

		if(count($result) > 0) {
			return $result['total'];
		}
		else {
			return 0;
		}

	}

	/**
	 * Get the attempts data
	 *
 	 * GeoIP calculations are to convert ip address to integers to do a faster search
	 * as they are in ip blocks
	 *
	 * @param	date	$fromDate	start of date range
	 * @param	time	$fromTime	start time
	 * @param	date	$toDate		end of date range
	 * @param	time	$toTime		end time
	 * @param	int	$page		page for pagination
	 * @param	int	$limit		limit of rows per page
	 * @param	int	$affiliateID	id of affiliate
	 * @param	int	$campaignID	id of campaign
	 * @param	string	$sortCol	column to sort on
	 * @param	string	$sortOrder	sort order
	 * @param	array	$storeIDs	id of stores
	 */
	public function getAttemptsData($fromDate, $fromTime, $toDate, $toTime, $page, $limit, $affiliateID = "", $campaignID = "", $sortCol = "", $sortOrder = "DESC", $storeIDs = "")
	{

		if(empty($page)) {
			$page = 0;
		}

		if(empty($limit)) {
			$limit = 50;
		}

		if(!empty($fromTime)) {
			$fromTime = "00:00:00";
		}

		if(!empty($toTime)) {
			$toTime = "23:59:59";
		}

		$dateWhere = $this->db_slave->quoteInto("originaldate > ?", $fromDate) . " AND " .
				$this->db_slave->quoteInto("originaldate < ?", $toDate) . " OR " .
				"(" . $this->db_slave->quoteInto("originaldate = ?", $fromDate) . " AND " . $this->db_slave->quoteInto("originaltime >= ?", $fromTime) . ") OR " .
				"(" . $this->db_slave->quoteInto("originaldate = ?", $toDate) . " AND " . $this->db_slave->quoteInto("originaltime <= ?", $toTime) . ")";


		$clarityVendorNameDenyQuery = $this->ClarityResponse->getVendorNameDenyQuery();
		$clarityVendorDenyReasonQuery = $this->ClarityResponse->getVendorDenyReasonQuery();

		$relianceVendorNameDenyQuery = $this->RelianceResponse->getVendorNameDenyQuery();
		$relianceVendorDenyReasonQuery = $this->RelianceResponse->getVendorDenyReasonQuery();

		$prescreenVendorNameDenyQuery = $this->PreScrubLog->getVendorNameDenyQuery();
		$prescreenVendorDenyReasonQuery = $this->PreScrubLog->getVendorDenyReasonQuery();

		$clientNameErrorQuery = $this->BuyerRejectError->getClientNameErrorQuery();
		$clientErrorReasonQuery = $this->BuyerRejectError->getClientErrorReasonQuery();

		$clientNameDenyQuery = $this->BuyerRejectDenial->getClientNameDenyQuery();
		$clientDenyReasonQuery = $this->BuyerRejectDenial->getClientDenyReasonQuery();

		$sql = $this->db_slave->select()
					->from("Leads", array("originaldate",
						"originaltime",
						"datetime" => new Zend_Db_Expr("CONCAT(originaldate, ' ', originaltime)"),
						"id",
						"storeID",
						"campaign",
						"leadsold",
						"email",
						"fname",
						"lname",
						"ip",
						"mphone",
						"city",
						"state",
						"address",
						"address2",
						"zip",
						"hphone",
						"wphone",
						"wphone_ext",
						"dob",
						"title",
						"campaign",
						"sourceurl",
						"subid",
						"subid2",
						"subid3",
						"subid3",
						"multiVarTestNum",
						"vendorName" => new Zend_Db_Expr(
								'('.$clarityVendorNameDenyQuery.' UNION '.$relianceVendorNameDenyQuery.' UNION '.$prescreenVendorNameDenyQuery.' UNION '.$clientNameDenyQuery.' UNION '.$clientNameErrorQuery.')' ),
						"denyDescription" => new Zend_Db_Expr(
								'('.$clarityVendorDenyReasonQuery.' UNION '.$relianceVendorDenyReasonQuery.' UNION '.$prescreenVendorDenyReasonQuery.' UNION '.$clientDenyReasonQuery.' UNION '.$clientErrorReasonQuery.')' )
					))
					->joinLeft("CashData", "Leads.id = CashData.leadID", array("loanamount", "ssn","employer","monthlyincome","military","paymethod","payperiod",
					"paydate1","paydate2","aba","ownrent","timetocall","licensenumber","licensestate","citizen","incomesource","timeatjob","occupation","empaddress","empcity","empstate","empzip","bank","accountnumber","accounttype"
					,"bankphone","loanamount","ref1name","ref2name","ref1phone","ref2phone","ref1relation","ref2relation","bankruptcy","yearsatresidence","monthsatresidence","bankinstitutionnumber","bankbranchnumber"))
					->joinLeft("Campaigns", "Leads.campaign = Campaigns.id", array("costPerLead", "title"))
					->joinLeft("GeoIPBlocks", "GeoIPBlocks.indexGeo = (INET_ATON(Leads.ip) - INET_ATON(Leads.ip)%65536) AND INET_ATON(Leads.ip) >= GeoIPBlocks.startIpNum AND INET_ATON(Leads.ip) <= GeoIPBlocks.endIpNum", array())
					->joinLeft("GeoIPLocations", "GeoIPBlocks.locId = GeoIPLocations.locId", array("ipCity" => "city", "ipState" => "region"))
					->joinLeft("LeadDupes", "Leads.id = LeadDupes.leadID", array("numDiffLeadProviders"))
					->joinLeft("LeadStrategies", "Leads.id = LeadStrategies.leadID", array())
					->joinLeft("Variates", "Variates.id = LeadStrategies.variateID", array("variatename" => "name"))
					->joinLeft("MultiVariates", "MultiVariates.id = LeadStrategies.multiVariateID", array("multivariatename" => "MultiVariates.name"))
					->joinLeft("LeadDupes", "Leads.id = LeadDupes.leadID", array("numDiffLeadProviders"))

					->where($dateWhere)
					->limit($limit,$page);

		if(!empty($affiliateID)) {
			$sql->where($this->db_slave->quoteInto("Leads.affiliateID = ?", $affiliateID));
		}

		if(!empty($campaignID)) {
			$sql->where($this->db_slave->quoteInto("Leads.campaign = ?", $campaignID));
		}

		if(!empty($storeIDs)) {
			$storeIDIN = implode(",", $storeIDs);
			$sql->where("storeID IN (" . $storeIDIN . ")");
		}

		if(empty($sortCol) || $sortCol == "datetime") {
			$sql->order("originaldate $sortOrder");
			$sql->order("originaltime $sortOrder");
		}
		else if($sortCol == "citystate") {
			$sql->order("city $sortOrder");
			$sql->order("state $sortOrder");
		}
		else if($sortCol == "geolocation")
		{
			$sql->order("ipCity $sortOrder");
			$sql->order("ipState $sortOrder");
		}
		else if ($sortCol == "variate")
		{
		    $sql->order("variatename $sortOrder");
		}
		else if ($sortCol == "multivariate")
		{
		    $sql->order("multivariatename $sortOrder");
		}
		else if ($sortCol == "status")
        {
            $sql->order("leadsold $sortOrder");
        }
        else if ($sortCol == "vendor" || $sortCol == "vendor_deny_description") {
			if ($sortCol == "vendor") {
				$sortCol = "vendorName";
			} else if ($sortCol == "vendor_deny_description") {
				$sortCol = "denyDescription";
			}
			$sql->order($sortCol . " " . $sortOrder);
		}
		else {
			$sql->order($sortCol . " " . $sortOrder);
		}

		$result = $this->db_slave->fetchAll($sql);
		return $result;
	}

	/**
	 * Gets total lead dupes
	 * NOTE: This method DOES NOT query LeadDupes table.
	 *
	 * @param	date	$fromDate	start date
	 * @param	time	$fromTime	start time
	 * @param	date	$toDate		end date
	 * @param	time	$toTime		end time
	 * @param	string	$email		email
	 * @param	string	$ssn		ssn
	 *
	 * @return	int			number of total dupes
	 */
	public function getTotalLeadDupes($fromDate, $fromTime, $toDate, $toTime, $email, $ssn)
	{

		$dateWhere = $this->db_slave->quoteInto("originaldate > ?", $fromDate) . " AND " .
				$this->db_slave->quoteInto("originaldate < ?", $toDate) . " OR " .
				"(" . $this->db_slave->quoteInto("originaldate = ?", $fromDate) . " AND " . $this->db_slave->quoteInto("originaltime >= ?", $fromTime) . ") OR " .
				"(" . $this->db_slave->quoteInto("originaldate = ?", $toDate) . " AND " . $this->db_slave->quoteInto("originaltime <= ?", $toTime) . ")";

		$sql = $this->db_slave->select()
					->from("Leads", array("total" => "COUNT(1)"))
					->join("CashData", "Leads.id = CashData.leadID", array())
					->where($dateWhere);

		if(!empty($email)) {
			$sql->where($this->db_slave->quoteInto("Leads.email = ?", $email));
		}
		else if(!empty($ssn)) {
			$sql->where($this->db_slave->quoteInto("CashData.ssn = ?", $ssn));
		}

		$result = $this->db_slave->fetchRow($sql);

		if(count($result) > 0) {
			return $result['total'];
		}
		else {
			return 0;
		}
	}

	/**
	 * Gets lead dupe data
	 * NOTE: this method DOES NOT query the LeadDupes table
	 *
 	 * GeoIP calculations are to convert ip address to integers to do a faster search
	 * as they are in ip blocks
	 *
	 * @param	date	$fromDate	start date
	 * @param	time	$fromTime	start time
	 * @param	date	$toDate		end date
	 * @param	time	$toTime		end time
	 * @param	string	$email		email
	 * @param	string	$ssn		ssn
	 * @param	int	$page		page for pagination
	 * @param	int	$limit		limit of rows per page
	 * @param	string	$sortCol	column to sort on
	 * @param	string	$sortOrder	sort order
	 *
	 * @return	array			array of lead dupe data
	 */
	public function getLeadDupes($fromDate, $fromTime, $toDate, $toTime, $email, $ssn, $page = 0, $limit = 50, $sortCol = "datetime", $sortOrder = "ASC")
	{

		$dateWhere = $this->db_slave->quoteInto("originaldate > ?", $fromDate) . " AND " .
				$this->db_slave->quoteInto("originaldate < ?", $toDate) . " OR " .
				"(" . $this->db_slave->quoteInto("originaldate = ?", $fromDate) . " AND " . $this->db_slave->quoteInto("originaltime >= ?", $fromTime) . ") OR " .
				"(" . $this->db_slave->quoteInto("originaldate = ?", $toDate) . " AND " . $this->db_slave->quoteInto("originaltime <= ?", $toTime) . ")";

		$sql = $this->db_slave->select()
					->from("Leads", array("originaldate", "originaltime", "datetime" => new Zend_Db_Expr("CONCAT(originaldate, ' ', originaltime)"), "id", "storeID", "affiliateID", "campaign", "leadsold", "ip", "fname", "lname", "email", "dob", "city", "state", "mphone"))
					->joinLeft("CashData", "Leads.id = CashData.leadID", array("ssn", "monthlyincome"))
					->joinLeft("Affiliates", "Leads.affiliateID = Affiliates.id", array("masteraff"))
					->joinLeft("GeoIPBlocks", "GeoIPBlocks.indexGeo = (INET_ATON(Leads.ip) - INET_ATON(Leads.ip)%65536) AND INET_ATON(Leads.ip) >= GeoIPBlocks.startIpNum AND INET_ATON(Leads.ip) <= GeoIPBlocks.endIpNum", array())
					->joinLeft("GeoIPLocations", "GeoIPBlocks.locId = GeoIPLocations.locId", array("ipCity" => "city", "ipState" => "region"))
					->where($dateWhere)
					->limitPage($page, $limit);

		if(!empty($email)) {
			$sql->where($this->db_slave->quoteInto("Leads.email = ?", $email));
		}
		else if(!empty($ssn)) {
			$sql->where($this->db_slave->quoteInto("CashData.ssn = ?", $ssn));
		}

		if(empty($sortCol) || $sortCol == "datetime") {
			$sql->order("originaldate $sortOrder");
			$sql->order("originaltime $sortOrder");
		}
		else if($sortCol == "citystate") {
			$sql->order("city $sortOrder");
			$sql->order("state $sortOrder");
		}
		else if($sortCol == "geolocation")
		{
			$sql->order("ipCity $sortOrder");
			$sql->order("ipState $sortOrder");
		}
		else {
			if ($sortCol != "vendor" && $sortCol != "vendor_deny_description") {
				$sql->order($sortCol . " " . $sortOrder);
			}
		}


		$result = $this->db_slave->fetchAll($sql);

		return $result;

	}

	/**
	 * Gets lead dupe grouped by affiliate total
	 *
	 * @param	date	$fromDate	start date
	 * @param	time	$fromTime	start time
	 * @param	date	$toDate		end date
	 * @param	time	$toTime		end time
	 *
	 * @return	array			array of lead dupe data
	 */

	public function getTotalDupesByAffiliate($fromDate, $fromTime, $toDate, $toTime)
	{

		$dateWhere = $this->db_slave->quoteInto("originaldate > ?", $fromDate) . " AND " .
				$this->db_slave->quoteInto("originaldate < ?", $toDate) . " OR " .
				"(" . $this->db_slave->quoteInto("originaldate = ?", $fromDate) . " AND " . $this->db_slave->quoteInto("originaltime >= ?", $fromTime) . ") OR " .
				"(" . $this->db_slave->quoteInto("originaldate = ?", $toDate) . " AND " . $this->db_slave->quoteInto("originaltime <= ?", $toTime) . ")";

		$sql = $this->db_slave->select()
					->from("Leads", array("total" => "COUNT(DISTINCT(affiliateID))"))
					->where($dateWhere);

		$result = $this->db_slave->fetchRow($sql);

		if(count($result) > 0) {
			return $result['total'];
		}
		else {
			return 0;
		}
	}

	/**
	 * Gets lead dupe data grouped by affiliate
	 *
	 * @param	date	$fromDate	start date
	 * @param	time	$fromTime	start time
	 * @param	date	$toDate		end date
	 * @param	time	$toTime		end time
	 * @param	int	$page		page for pagination
	 * @param	int	$limit		limit of rows per page
	 * @param	string	$sortCol	column to sort on
	 * @param	string	$sortOrder	sort order
	 *
	 * @return	array			array of lead dupe data
	 */

	public function getDupesByAffiliate($fromDate, $fromTime, $toDate, $toTime, $page, $limit, $sortCol, $sortOrder = "ASC")
	{

		$dateWhere = $this->db_slave->quoteInto("originaldate > ?", $fromDate) . " AND " .
				$this->db_slave->quoteInto("originaldate < ?", $toDate) . " OR " .
				"(" . $this->db_slave->quoteInto("originaldate = ?", $fromDate) . " AND " . $this->db_slave->quoteInto("originaltime >= ?", $fromTime) . ") OR " .
				"(" . $this->db_slave->quoteInto("originaldate = ?", $toDate) . " AND " . $this->db_slave->quoteInto("originaltime <= ?", $toTime) . ")";

		$sql = $this->db_slave->select()
					->from("Leads", array("affiliateID", "attempts" => "COUNT(1)"))
					->join("CashData", "Leads.id = CashData.leadID", array("ssn"))
					->join("Affiliates", "Leads.affiliateID = Affiliates.id", array("affiliate" => "masteraff"))
					->joinLeft("LeadDupes", "Leads.id = LeadDupes.leadID", array("uniques" => "SUM(isUnique)", "dupes" => new Zend_Db_Expr("COUNT(1) - SUM(isUnique)"), "uniquesPercentage" => new Zend_Db_Expr("100 * (SUM(isUnique)/COUNT(1))"), "dupesPercentage" => new Zend_Db_Expr("100 * ((COUNT(1) - SUM(isUnique)) / COUNT(1))")))
					->where($dateWhere)
					->group("affiliateID")
					->limitPage($page, $limit);

		if(empty($sortCol) || $sortCol == "datetime") {
			$sql->order("originaldate $sortOrder");
			$sql->order("originaltime $sortOrder");
		}
		else {
			if ($sortCol != "vendor" && $sortCol != "vendor_deny_description") {
				$sql->order($sortCol . " " . $sortOrder);
			}
		}

		$result = $this->db_slave->fetchAll($sql);

		return $result;
	}

	/**
	 * Gets Score columns of leads
	 *
	 * @param	array	$leadIds	Array containing leadid

	 * @return	array			array of Lead score columns
	 */
	public function getLeadsScores($leadIds) {

		$result = array();
		if(count($leadIds)) {
			$dataWhere = $this->db_slave->quoteInto("Vendors.active=1 and LeadScores.leadID in (?)",$leadIds);
			$sql = $this->db_slave->select()
			->from("LeadScores",array("score","leadID"))
			->join("LeadScoreTypes","LeadScores.leadScoreTypeID = LeadScoreTypes.id",array("name"))
			->join("Vendors","LeadScoreTypes.vendorID = Vendors.id",array())
			->where($dataWhere)
			->order("leadID");

			$result = $this->db_slave->fetchAll($sql);
		}
		return $result;
	}

	/**
	 * Gets Veritec's Score columns
	 *
	 * @param	array	$leadIds	Array containing leadid

	 * @return	array			array of Veritec scores
	 */
	public function getVeritecScores($leadIds) {

		$result = array();
		if(count($leadIds)) {
			$dataWhere = $this->db_slave->quoteInto("VeritecResponses.leadID in (?)",$leadIds);
			$sql = $this->db_slave->select()
				->from("VeritecResponses",array("leadID","responseother","responsedescription"))
				->where($dataWhere)
				->order("leadID");

			$result = $this->db_slave->fetchAll($sql);
		}
		return $result;
	}

	/**
	 * Gets All lead Score type Columns

	 * @return	array	array of Lead score columns
	 *
	 */
	public function getScoreColumns() {

		$dataWhere = $this->db_slave->quoteInto("Vendors.active=?",1);
		$sql = $this->db_slave->select()
		->from("LeadScoreTypes",array("name"))
		->join("Vendors","LeadScoreTypes.vendorID = Vendors.id",array())
		->where($dataWhere)
		->order("name");

		$result = $this->db_slave->fetchAll($sql);
		return $result;
	}


	/**
	 * Gets Internal Reject Names
	 *
	 * @param	array	$leadIds	Array containing leadid

	 * @return	array result
	 */
	public function getInternalRejectReasons($leadIds) {
		$leadIds = implode(',', $leadIds);

		$sql = "SELECT
						Leads.id AS leadID,
						IF(irc.name IS NOT NULL, irc.name, '') AS denyReason
					FROM
						Leads
					LEFT JOIN InternalRejects ir ON ir.leadid = Leads.id
					LEFT JOIN InternalRejectCodes irc ON irc.id = ir.rejectcode
					WHERE
						Leads.id IN ({$leadIds})";

		$result = $this->db_slave->fetchAll($sql);

		return $result;
	}

	/**
	 * Gets Client Reject Names
	 *
	 * @param	array	$leadIds	Array containing leadid

	 * @return	array result
	 */
	public function getClientRejectReasons($leadIds) {
		$leadIds = implode(',', $leadIds);

		$sql = "SELECT
						Leads.id AS leadID,
						IF(crc.name IS NOT NULL, crc.name, '') AS denyReason
					FROM
						Leads
					LEFT JOIN ClientRejects cr ON cr.leadid = Leads.id
					LEFT JOIN ClientRejectCodes crc ON crc.id = cr.rejectcode
					WHERE
						Leads.id IN ({$leadIds})";

		$result = $this->db_slave->fetchAll($sql);

		return $result;
	}

	/**
	 * Gets Campaign Reject Names
	 *
	 * @param	array	$leadIds	Array containing leadid

	 * @return	array result
	 */
	public function getCampaignRejectReasons($leadIds) {
		$leadIds = implode(',', $leadIds);

		$sql = "SELECT
						Leads.id AS leadID,
						IF(crc.name IS NOT NULL, crc.name, '') AS denyReason
					FROM
						Leads
					LEFT JOIN CampaignRejects cr ON cr.leadid = Leads.id
					LEFT JOIN CampaignRejectCodes crc ON crc.id = cr.rejectcode
					WHERE
						Leads.id IN ({$leadIds})";

		$result = $this->db_slave->fetchAll($sql);

		return $result;
	}


	/**
	 * Gets Reject Names for Clients or Vendors
	 *
	 * @param	array	$leadIds	Array containing leadid

	 * @return	array result
	 */
	public function getClientOrVendorRejects($leadIds) {
		$leadIds = implode(',', $leadIds);

		$sql = "SELECT
					PostLogs.leadID,
					IF (PostLogs.productCode = 'cash','Denied by LMS','Denied by Vendor') AS denyReason
				FROM
					PostLogs
				WHERE
					PostLogs.leadID IN ({$leadIds})
				AND PostLogs.postStatus = 'no'";

		$result = $this->db_slave->fetchAll($sql);

		return $result;
	}

	public function getVendorTimeOutsRejects($leadIds) {

        $leadIds = implode(',', $leadIds);

        $sql = "SELECT
					vr.leadID,
					vrc.name AS denyReason
				FROM
					VendorRejects as vr
				LEFT JOIN VendorRejectCodes vrc on vrc.id = vr.rejectCode 	
				WHERE
					vr.leadID IN ({$leadIds})
				AND vr.rejectCode = 1001";

        $result = $this->db_slave->fetchAll($sql);

        return $result;
    }
}
