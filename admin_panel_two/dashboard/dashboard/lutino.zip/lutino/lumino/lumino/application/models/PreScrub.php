<?php
class PreScrub extends Zend_Db_Table
{
	protected $_name = 'PreScrub';
}
?>