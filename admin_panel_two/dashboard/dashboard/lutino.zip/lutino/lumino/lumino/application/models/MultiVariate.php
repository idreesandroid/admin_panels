<?php

class MultiVariate extends Zend_Db_Table
{
	protected $_name = 'MultiVariates';

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}

	public function getUnHiddenActiveVariates()
	{
	    $sql = "SELECT
	        mv.id,mv.name,mv.description
	        FROM
	        Variates v,
	        MultiVariatesVariates mvv,
	        MultiVariates mv
	        WHERE
	        mvv.variateID = v.id AND mv.id = mvv.multiVariateID
	        AND hideInAdmin = 0
	        AND active = 1
	        GROUP BY mv.id";

	    $result = $this->db->fetchAll($sql);
	    return $result;
	}

	public function getHiddenActiveVariates()
	{
		$sql = "SELECT
          v.name, active, hideInAdmin
        FROM
          Variates v,
    	 MultiVariatesVariates mvv,
          MultiVariates mv
        WHERE
   mvv.variateID = v.id AND mv.id = mvv.multiVariateID
        AND hideInAdmin = 1
        AND active = 1
        GROUP BY v.name, active";

		$result = $this->db->fetchAll($sql);

		return $result;
	}

	public function findByID($id) {
		$sql = $this->select()
			->where("id = " . $id);
		return $this->fetchRow($sql);
	}

	/**
	 * Updates or inserts a row
	 */
	public function upsert($id, $insertData)
	{
		$existingRow = $this->findByID($id);

		if($existingRow) {
			$this->update($insertData, $this->_db->quoteInto("id = ?", $existingRow['id']));
			return $id;
		}
		else {
			return $this->insert($insertData);
		}
	}


	public function updateData($insertData, $multivariateID)
	{
		$this->update($insertData, $this->_db->quoteInto("id = ?", $multivariateID));
		return $multivariateID;
	}

	public function updateNameByVariateID($insertData, $variateID)
	{
		$MultiVariatesVariate = new MultiVariatesVariate();
		$result = $MultiVariatesVariate->getDataByVariateID($variateID);

		foreach ($result as $v) {
			$countVariatesInMultivariate = $this->countVariatesInMultivariateByMultivariateID($v['multiVariateID']);
			if ($countVariatesInMultivariate > 1) {
				continue;
			}
			$insertData['description'] = $insertData['name'] . " 0-99 - Static Scorecard";
			$this->updateData($insertData, $v['multiVariateID']);
		}

		return true;
	}

	public function getDataByMultivariateID($multivariateID)
	{
		$sql = $this->select()
			->where("id = " . $multivariateID)
			->order('id asc');
		return $this->fetchRow($sql);
	}

	public function getAllRandomMultivariatesWithExceptionMultivariates($multivariateID)
	{
		$MultiVariateLeadExceptionMultiVariate = new MultiVariateLeadExceptionMultiVariate();

		$sql = $this->select();
		$randomvariates =  $this->fetchAll($sql);
		if ($randomvariates) {
			$data = array();
			$variates = $randomvariates->toArray();

			foreach ($variates AS $variate) {
				if ($variate['id'] == $multivariateID)
					continue;

				$ExceptionMultivariate = $MultiVariateLeadExceptionMultiVariate->findByMultivariateID($multivariateID);
				if ($ExceptionMultivariate) {
					if ($ExceptionMultivariate->exceptionMultiVariateID == $variate['id']) {
						$variate['isExceptionMultivariate'] = TRUE;
					} else {
						$variate['isExceptionMultivariate'] = FALSE;
					}
				}

				$data[] = $variate;
			}
			return $data;
		}
	}

	/**
	 * Random multivariate should contains at least two variates.
	 * @return array
	 */
	public function getAllRandomMultivariates()
	{
		$sql = $this->select()
			->order('createdAt');
		$randomvariates =  $this->fetchAll($sql);

		$data = array();
		foreach($randomvariates AS $variate) {
			$count = $this->countVariatesInMultivariateByMultivariateID($variate['id']);
			if ($count <= 1)
				continue;
			$data[] = $variate;
		}
		return $data;
	}

	/**
	 * Random multivariate should contains at least two variates.
	 * @return array
	 */
	public function getAllMultivariates()
	{
		$sql = $this->select()
			->order('createdAt');
		$randomvariates =  $this->fetchAll($sql);

		$data = array();
		foreach($randomvariates AS $variate) {
			$data[] = $variate;
		}
		return $data;
	}

	public function countVariatesInMultivariateByMultivariateID($multivariateID)
	{

		$sql = $this->_db->select()
			->from($this->_name, array("count(*) AS amount"))
			->join("MultiVariatesVariates", "MultiVariatesVariates.multiVariateID = " . $this->_name . ".id", array())
			->join("Variates", "Variates.id = MultiVariatesVariates.variateID", array())
			->where($this->_db->quoteInto($this->_name . ".id = ?", $multivariateID));

		$result = $this->_db->fetchRow($sql);
		return ($result['amount']);
	}

	public function isMultivariateInUseByAnyCampaign($multivariateID)
	{
		$CampaignsMultiVariate = new CampaignsMultiVariate();
		return ($CampaignsMultiVariate->findByMultivariateID($multivariateID));
	}

	public function isMultivariateWasInUse($multivariateID)
	{

		$sql = $this->_db->select()
			->from($this->_name, array("count(*) AS amount"))
			->join("MultiVariatesVariates", "MultiVariatesVariates.multiVariateID = " . $this->_name . ".id", array())
			->join("LeadStrategies", "LeadStrategies.variateID = MultiVariatesVariates.variateID", array())
			->where($this->_db->quoteInto($this->_name . ".id = ?", $multivariateID));

		$result = $this->_db->fetchRow($sql);
		return ($result['amount'] > 0);
	}

	public function checkIfSafeToDelete($multivariateID) {
		if ($this->isMultivariateInUseByAnyCampaign($multivariateID))
			return FALSE;
		if ($this->isMultivariateWasInUse($multivariateID))
			return FALSE;

		return TRUE;
	}
}
?>
