<?php
/**
 * this table handles credentials for Clarity
 */
class ClarityCredentialsVendorStrategy extends Zend_Db_Table
{
	protected $_name = 'ClarityCredentialsVendorStrategies';

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}

	/**
	 * Updates or inserts a row
	 */
	public function upsert($vendorStrategyID, $insertData)
	{
		$existingRow = $this->findByVendorStrategyID($vendorStrategyID);

		if($existingRow) {
			$updatedID = $this->update($insertData, $this->_db->quoteInto("id = ?", $existingRow['id']));
			return $updatedID;
		}
		else {
			return $this->insert($insertData);
		}
	}

	public function findByVendorStrategyID($vendorStrategyID) {
		$sql = $this->select()
			->where("vendorStrategyID = " . $vendorStrategyID);
		return $this->fetchRow($sql);
	}
}

