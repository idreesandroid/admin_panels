<?php

class AffiliateStoresReportsController extends Zend_Controller_Action
{
	public function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if(!$AdminNameSpace->userid)
		{
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();

		$this->config = Zend_Registry::get('config');
	}

	public function indexAction()
	{
		$fromDate = ($this->_request->fromDate) ? $this->_request->fromDate : date('Y-m-d');
		$toDate =  ($this->_request->toDate) ? $this->_request->toDate : date('Y-m-d');

		$timeStart =  date("H:i:s", strtotime("Today"));
		$timeEnd = date("H:i:s", strtotime("Today last second"));

		$fromDate = date('Y-m-d', strtotime($fromDate));
		$toDate = date('Y-m-d', strtotime($toDate));

		$Report = new AffiliateStoreReport();
		$reports = $Report->execute($fromDate, $toDate, $timeStart, $timeEnd);

		$this->view->fromDate = $fromDate;
		$this->view->toDate = $toDate;
		$this->view->timeStart = $timeStart;
		$this->view->timeEnd = $timeEnd;
		$this->view->reports = $reports;
	}
}
