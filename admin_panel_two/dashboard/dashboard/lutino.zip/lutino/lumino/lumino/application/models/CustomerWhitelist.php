<?php
/* Customer Whitelist Model      

   pulls data from Tran Good Customer list

*/ 
class CustomerWhitelist  extends TranAbstract
{
	protected $_name = 'CustomerWhitelist';
	public $storeID = "13420000001";

	public function init() 
	{
		$this->fileName = "CustomerWhitelist";
		$this->dateFields = array(18);
		// file type G from the report type dropdown
		$this->cboFileType = "G";
		$this->fieldNames = array(
					"MerchantIdKey",
					"CustSSN",
					"CustFName",
					"CustMName",
					"CustLName",
					"CustAddress1",
					"CustAddress2",
					"CustAddress3",
					"CustAddress4",
					"CustAddress5",
					"CustCity",
					"CustLocationCode",
					"CustPostalCode",
					"CustHomePhone",
					"CustCellPhone",
					"CustWorkPhone",
					"CustWorkPhoneExt",
					"CustEmail",
					"CustDateCreated", 
					"ValidStandardLoanCount",
					"Revenue",
					);

	}

	/**
	 * Finds by storeID / ssn
	 *
	 * @param	int	$storeID	id of store
	 * @param	int	$ssn		ssn of customer
	 *
	 * @return	array			array of CustomerWhitelist data
	 */
	public function findByStoreIDSSN($storeID, $ssn)
	{

		$sql = $this->select()
				->from($this->_name)
				->where($this->getAdapter()->quoteInto("CustSSN = ?", $ssn))
				->where($this->getAdapter()->quoteInto("StoreID = ?", $storeID));
	
		$result = $this->fetchRow($sql);

		return $result;
		
	}

	/**
	 * inserts the prepared data
	 */
	public function upsert($insertData)
	{

		$insertData['StoreID'] = $this->storeID;

		$result = $this->findByStoreIDSSN($insertData['StoreID'], $insertData['CustSSN']);

		if(count($result) > 0) { 
			$this->update($insertData, $this->getAdapter()->quoteInto("id = ?", $result['id']));
		}
		else {
                        $this->insert($insertData);
                }

	}
	

	/**
	 * builds the isnert array from the table field names
	 */
	public function buildInsertArray($fieldData)
	{
		$insertData = array();
		
		foreach($this->fieldNames as $key=>$name)
		{
			$insertData[$name] = trim($fieldData[$key]);
		}	
		
		return $insertData;
		
	}
}
?>
