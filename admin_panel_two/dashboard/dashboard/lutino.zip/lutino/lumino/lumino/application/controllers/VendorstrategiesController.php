<?php
class VendorstrategiesController extends Zend_Controller_Action
{
	private $baseurl;

	function init()
	{
		if ($this->_helper->flashMessenger->hasMessages()) {
			$this->view->flashMessages = $this->_helper->flashMessenger->getMessages();
		}

		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if (!$AdminNameSpace->userid)
		{
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();

		$this->view->headLink()->appendStylesheet($this->_request->getBaseUrl() .  '/public/styles/older/mediaEnvy/jquery-ui-1.10.3.custom.css');
		$this->view->headLink()->appendStylesheet($this->_request->getBaseUrl() . '/public/styles/older/new/styles.css');
		$this->view->headLink()->appendStylesheet($this->_request->getBaseUrl() . '/public/styles/older/gradientButtons.css');
	}

	public function indexAction()
	{
		$VendorStrategies = new VendorStrategies();
		$this->view->data = $VendorStrategies->getStrategies();

		// accordian headers
		$Vendor = new Vendors();
		$this->view->vendors = $Vendor->findAll();

		if(isset($this->_request->vendorId))
		    $this->view->vendorId = $this->_request->vendorId;
		else
		    $this->view->vendorId = 'false';
	}

	public function addAction()
	{

		$VendorStrategies = new VendorStrategies();
		$Vendors = new Vendors();
		if ($this->getRequest()->isPost() && $this->_request->strategyName!="")
		{
			// NOTE: this method DOES NOT actually do a db update
			// it returns a string
			$strategyName = $VendorStrategies->updateStrategyNameByCurrentState(
				$this->_request->strategyName,
				$this->_request->ignorefailresponse);

			$savedStrategyID = $VendorStrategies->saveStrategy($this->_request->vendorId,
				$strategyName,
				$this->_request->ignorefailresponse,$this->_request->strategyCost);

			if (!$savedStrategyID)
			{
				// flash message here
				$this->_helper->flashMessenger->addMessage(array(
					'errors' => array(
						"This Data Provider's PostSetup does not exist. Please create the PostSetup first." => 'fail')));
			}
			else
			{
				$this->_helper->flashMessenger->clearMessages();

				$credentialtype = $this->getRequest()->getParam('credentialtype');

				$ClarityCredentials = new ClarityCredentials();
				$ClarityCredentialsVendorStrategy = new ClarityCredentialsVendorStrategy();

				$FTCredentials = new FTCredentials();
				$FTCredentialsVendorStrategy = new FTCredentialsVendorStrategy;

				$TrueScoreCredentials = new TrueScoreCredentials();
				$TrueScoreCredentialsVendorStrategy = new TrueScoreCredentialsVendorStrategy();

				$vendorId = $this->_request->vendorId;

				if ($credentialtype == "customtype") {
					if ($vendorId == FTCredentials::VENDOR_ID) {
						$formData = array(
							'username'=>$this->getRequest()->getParam('username'),
							'password'=>$this->getRequest()->getParam('password'),
							'merchantID' => $this->getRequest()->getParam('merchantID'),
							'storeID' => $this->getRequest()->getParam('storeID'),
							'lenderID' => $this->getRequest()->getParam('lenderID'),
							'isDefault' => 0);
						$insertedID = $FTCredentials->upsert($savedStrategyID, $formData);

						$data = array('vendorStrategyID' => $savedStrategyID,
							'FTCredentialID' => $insertedID);

						$FTCredentialsVendorStrategy->upsert($savedStrategyID, $data);

					} else if ($vendorId == ClarityCredentials::VENDOR_ID) {
						$formData = array(
							'username'=>$this->getRequest()->getParam('username'),
							'password'=>$this->getRequest()->getParam('password'),
							'groupID' => $this->getRequest()->getParam('groupID'),
							'accountID' => $this->getRequest()->getParam('accountID'),
							'locationID' => $this->getRequest()->getParam('locationID'),
							'controlFileName' => $this->getRequest()->getParam('controlFileName'),
						    'inquiryTradelineType' => $this->getRequest()->getParam('inquiryTradelineType'),
							'isDefault' => 0);

						$insertedID = $ClarityCredentials->upsert($savedStrategyID, $formData);

						$data = array('vendorStrategyID' => $savedStrategyID,
							'clarityCredentialID' => $insertedID);

						$ClarityCredentialsVendorStrategy->upsert($savedStrategyID, $data);
					} else if ($vendorId == TrueScoreCredentials::VENDOR_ID) {
						$formData = array(
							'accountID' => $this->getRequest()->getParam('accountID'),
							'apiKey' => $this->getRequest()->getParam('apiKey'),
							'isDefault' => 0);

						$insertedID = $TrueScoreCredentials->upsert($savedStrategyID, $formData);

						$data = array('vendorStrategyID' => $savedStrategyID,
							'truescoreCredentialID' => $insertedID);

						$TrueScoreCredentialsVendorStrategy->upsert($savedStrategyID, $data);
					} else if ($vendorId == DataXCredentials::VENDOR_ID) {

						$DataXCredentials = new DataXCredentials();
						$DataXCredentialsVendorStrategies = new DataXCredentialsVendorStrategies();

						$formData = array('key' => $this->getRequest()->getParam('dataxkey'),
							'password' => $this->getRequest()->getParam('dataxpassword'),
							'inquiryType' => $this->getRequest()->getParam('dataxinquiryType'));

						$insertedID = $DataXCredentials->upsert($savedStrategyID, $formData);
						$data = array('vendorStrategyID' => $savedStrategyID,
							'DataXCredentialID' => $insertedID);

						$DataXCredentialsVendorStrategies->upsert($savedStrategyID, $data);

					} else if ($vendorId == MBCredentials::VENDOR_ID) {

						$MBCredentials = new MBCredentials();
						$MBCredentialsVendorStrategies = new MBCredentialsVendorStrategies();

						$formData = array('username' => $this->getRequest()->getParam('mbUsername'),
							'password' => $this->getRequest()->getParam('mbPassword'),
							'useTestUrl' => $this->getRequest()->getParam('mbUseTestUrl'));

						$insertedID = $MBCredentials->upsert($savedStrategyID, $formData);
						$data = array('vendorStrategyID' => $savedStrategyID,
							'MBCredentialID' => $insertedID);

						$MBCredentialsVendorStrategies->upsert($savedStrategyID, $data);

					} else if ($vendorId == GVerifyCredentials::VENDOR_ID) {

						$GVerifyCredentials = new GVerifyCredentials();
						$GVerifyCredentialsVendorStrategies = new GVerifyCredentialsVendorStrategies();

						$formData = array('username' => $this->getRequest()->getParam('gverifyusername'),
							'password' => $this->getRequest()->getParam('gverifypassword'));

						$insertedID = $GVerifyCredentials->upsert($savedStrategyID, $formData);
						$data = array('vendorStrategyID' => $savedStrategyID,
							'GVerifyCredentialsID' => $insertedID);

						$GVerifyCredentialsVendorStrategies->upsert($savedStrategyID, $data);

					} else if ($vendorId == CPADetectiveCredentials::VENDOR_ID) {

						$CPADetectiveCredentials = new CPADetectiveCredentials();
						$CPADetectiveCredentialsVendorStrategies = new CPADetectiveCredentialsVendorStrategies();

						$formData = array('key' => $this->getRequest()->getParam('cpadectivekey'));

						$insertedID = $CPADetectiveCredentials->upsert($savedStrategyID, $formData);
						$data = array('vendorStrategyID' => $savedStrategyID,
							'CPADetectiveCredentialID' => $insertedID);

						$CPADetectiveCredentialsVendorStrategies->upsert($savedStrategyID, $data);

					} else if ($vendorId == RelianceMarkCredentials::VENDOR_ID) {

						$RelianceMarkCredentials = new RelianceMarkCredentials();
						$RelianceMarkCredentialsVendorStrategies = new RelianceMarkCredentialsVendorStrategies();

						$formData = array('key' => $this->getRequest()->getParam('reliancemarkkey'));

						$insertedID = $RelianceMarkCredentials->upsert($savedStrategyID, $formData);
						$data = array('vendorStrategyID' => $savedStrategyID,
							'RelianceMarkCredentialID' => $insertedID);

						$RelianceMarkCredentialsVendorStrategies->upsert($savedStrategyID, $data);
					} else if ($vendorId == DecisionLogicCredentials::VENDOR_ID) {

						$DecisionLogicCredentials = new DecisionLogicCredentials();
						$DecisionLogicCredentialsVendorStrategies = new DecisionLogicCredentialsVendorStrategies();

						$formData = array('key' => $this->getRequest()->getParam('decisionlogickey'),
											'guid' => $this->getRequest()->getParam('decisionlogicguid'));

						$insertedID = $DecisionLogicCredentials->upsert($savedStrategyID, $formData);
						$data = array('vendorStrategyID' => $savedStrategyID,
							'decisionLogicCredentialID' => $insertedID);

						$DecisionLogicCredentialsVendorStrategies->upsert($savedStrategyID, $data);

					} else if ($vendorId == EbureauCredentials::VENDOR_ID) {

						$EbureauCredentials = new EbureauCredentials();
						$EbureauCredentialsVendorStrategies = new EbureauCredentialsVendorStrategies();

						$formData = array('username' => $this->getRequest()->getParam('ebUsername'),
								'password' => $this->getRequest()->getParam('ebPassword'),
								'fraudScore' => $this->getRequest()->getParam('ebFraudScore'),
								'marketScore' => $this->getRequest()->getParam('ebMarketScore'),
								'useTestUrl' => $this->getRequest()->getParam('ebUseTestUrl'));

						$insertedID = $EbureauCredentials->upsert($savedStrategyID, $formData);
						$data = array('vendorStrategyID' => $savedStrategyID,
							'EbureauCredentialID' => $insertedID);

						$EbureauCredentialsVendorStrategies->upsert($savedStrategyID, $data);

					} else if ($vendorId == EbureauCredentials::VENDOR_ID_FINANCE) {

						$EbureauCredentials = new EbureauCredentials();
						$EbureauCredentialsVendorStrategies = new EbureauCredentialsVendorStrategies();

						$formData = array('username' => $this->getRequest()->getParam('ebUsername'),
								'password' => $this->getRequest()->getParam('ebPassword'),
								'fraudScore' => $this->getRequest()->getParam('ebFraudScore'),
								'marketScore' => $this->getRequest()->getParam('ebMarketScore'),
								'fraudScoreName' => $this->getRequest()->getParam('ebFraudScoreName'),
								'marketScoreName' => $this->getRequest()->getParam('ebMarketScoreName'),
								'useTestUrl' => $this->getRequest()->getParam('ebUseTestUrl'));

						$insertedID = $EbureauCredentials->upsert($savedStrategyID, $formData);
						$data = array('vendorStrategyID' => $savedStrategyID,
							'EbureauCredentialID' => $insertedID);

						$EbureauCredentialsVendorStrategies->upsert($savedStrategyID, $data);

					} else if ($vendorId == BriteVerifyCredentials::BRITE_VERIFY_EMAIL_CHECK_VENDOR_ID ) {

						$BriteVerifyCredentials = new BriteVerifyCredentials();
						$BriteVerifyCredentialsVendorStrategies = new BriteVerifyCredentialsVendorStrategies();

						$formData = array('key' => $this->getRequest()->getParam('briteVerifyKey'));
						$insertedID = $BriteVerifyCredentials->upsert($savedStrategyID, $formData);

						$data = array('vendorStrategyID' => $savedStrategyID,
							'BriteVerifyCredentialID' => $insertedID);

						$BriteVerifyCredentialsVendorStrategies->upsert($savedStrategyID, $data);

					} else if ($vendorId == PDSPaymentCredential::VENDOR_ID) {

						$PDSPaymentCredential = new PDSPaymentCredential();
						$PDSPaymentCredentialVendorStrategy = new PDSPaymentCredentialVendorStrategy();

						$formData = array(
							'login'=>$this->getRequest()->getParam('pdspaymentLogin'),
							'password'=>$this->getRequest()->getParam('pdspaymentPassword'),
							'merchantid' => $this->getRequest()->getParam('pdspaymentMerchantid'),
							'trancode' => $this->getRequest()->getParam('pdspaymentTrancode'),
							'sec' => $this->getRequest()->getParam('pdspaymentSec'),
							'description' => $this->getRequest()->getParam('pdspaymentDescription'),
							'isDefault' => 0);

						$insertedID = $PDSPaymentCredential->upsert($savedStrategyID, $formData);

						$data = array('vendorStrategyID' => $savedStrategyID,
							'PDSPaymentCredentialsID' => $insertedID);

						$PDSPaymentCredentialVendorStrategy->upsert($savedStrategyID, $data);

					} else if ($vendorId == DataTwentyFourSevenCredentials::VENDOR_ID) {

						$DataTwentyFourSevenCredentials = new DataTwentyFourSevenCredentials();
						$DataTwentyFourSevenCredentialsVendorStrategy = new DataTwentyFourSevenCredentialsVendorStrategy();

						$formData = array(
							'username'=>$this->getRequest()->getParam('dataTwentyFourSevenUsername'),
							'password'=>$this->getRequest()->getParam('dataTwentyFourSevenPassword'),
							'isDefault' => 0);

						$insertedID = $DataTwentyFourSevenCredentials->upsert($savedStrategyID, $formData);

						$data = array('vendorStrategyID' => $savedStrategyID,
							'dataTwentyFourSevenCredentialID' => $insertedID);

						$DataTwentyFourSevenCredentialsVendorStrategy->upsert($savedStrategyID, $data);

					} else if ($vendorId == VeritecCredentials::VENDOR_ID) {
						$VeritecCredentials = new VeritecCredentials();
						$VeritecCredentialsVendorStrategy = new VeritecCredentialsVendorStrategy();

						$formData = array(
							'username'=>$this->getRequest()->getParam('veritecUsername'),
							'password'=>$this->getRequest()->getParam('veritecPassword'),
							'actioncode' => $this->getRequest()->getParam('veritecActioncode'),
							'reglicnum' => $this->getRequest()->getParam('veritecReglicnum'),
							'isDefault' => 0);

						$insertedID = $VeritecCredentials->upsert($savedStrategyID, $formData);

						$data = array('vendorStrategyID' => $savedStrategyID,
							'VeritecCredentialsID' => $insertedID);

						$VeritecCredentialsVendorStrategy->upsert($savedStrategyID, $data);

					}
					else if ($vendorId == WhitePagesCredentials::VENDOR_ID) {

					    $WhitePagesCredentials = new WhitePagesCredentials();
					    $WhitePagesCredentialsVendorStrategy = new WhitePagesCredentialsVendorStrategy();

					    $formData = array(
					        'apiKey' => $this->getRequest()->getParam('apiKey'),
					        'products' => implode(",",$this->getRequest()->getParam('products')),
					        'isDefault' => 0);

					    $insertedID = $WhitePagesCredentials->upsert($savedStrategyID, $formData);

					    $data = array('vendorStrategyID' => $savedStrategyID,
					        'whitePagesCredentialsID' => $insertedID);
					    $WhitePagesCredentialsVendorStrategy->upsert($savedStrategyID, $data);
					}


				} else if ($credentialtype == "defaulttype") {
					if ($vendorId == FTCredentials::VENDOR_ID) {
						$FTCredentialsVendorStrategy->delete("vendorStrategyID=$savedStrategyID");
					} else if ($vendorId == ClarityCredentials::VENDOR_ID) {
						$ClarityCredentialsVendorStrategy->delete("vendorStrategyID=$savedStrategyID");
					} else if ($vendorId == TrueScoreCredentials::VENDOR_ID) {
						$TrueScoreCredentialsVendorStrategy->delete("vendorStrategyID=$savedStrategyID");
					} else if ($vendorId == DataXCredentials::VENDOR_ID) {
						$DataXCredentialsVendorStrategies = new DataXCredentialsVendorStrategies();
						$DataXCredentialsVendorStrategies->delete("vendorStrategyID=$savedStrategyID");
					} else if ($vendorId == MBCredentials::VENDOR_ID) {
						$MBCredentialsVendorStrategies = new MBCredentialsVendorStrategies();
						$MBCredentialsVendorStrategies->delete("vendorStrategyID=$savedStrategyID");
					} else if ($vendorId == GVerifyCredentials::VENDOR_ID) {
						$GVerifyCredentialsVendorStrategies = new GVerifyCredentialsVendorStrategies();
						$GVerifyCredentialsVendorStrategies->delete("vendorStrategyID=$savedStrategyID");
					} else if ($vendorId == CPADetectiveCredentials::VENDOR_ID) {
						$CPADetectiveCredentialsVendorStrategies = new CPADetectiveCredentialsVendorStrategies();
						$CPADetectiveCredentialsVendorStrategies->delete("vendorStrategyID=$savedStrategyID");
					} else if ($vendorId == RelianceMarkCredentials::VENDOR_ID) {
						$RelianceMarkCredentialsVendorStrategies = new RelianceMarkCredentialsVendorStrategies();
						$RelianceMarkCredentialsVendorStrategies->delete("vendorStrategyID=$savedStrategyID");
					} else if ($vendorId == DecisionLogicCredentials::VENDOR_ID) {
						$DecisionLogicCredentialsVendorStrategies = new DecisionLogicCredentialsVendorStrategies();
						$DecisionLogicCredentialsVendorStrategies->delete("vendorStrategyID=$savedStrategyID");
					} else if ($vendorId == EbureauCredentials::VENDOR_ID) {
						$EbureauCredentialsVendorStrategies = new EbureauCredentialsVendorStrategies();
						$EbureauCredentialsVendorStrategies->delete("vendorStrategyID=$savedStrategyID");
					} else if ($vendorId == EbureauCredentials::VENDOR_ID_FINANCE) {
						$EbureauCredentialsVendorStrategies = new EbureauCredentialsVendorStrategies();
						$EbureauCredentialsVendorStrategies->delete("vendorStrategyID=$savedStrategyID");
					} else if ($vendorId == BriteVerifyCredentials::BRITE_VERIFY_EMAIL_CHECK_VENDOR_ID) {
						$BriteVerifyCredentialsVendorStrategies = new BriteVerifyCredentialsVendorStrategies();
						$BriteVerifyCredentialsVendorStrategies->delete("vendorStrategyID=$savedStrategyID");
					} else if ($vendorId == PDSPaymentCredential::VENDOR_ID) {
						$PDSPaymentCredentialVendorStrategy = new PDSPaymentCredentialVendorStrategy();
						$PDSPaymentCredentialVendorStrategy->delete("vendorStrategyID=$savedStrategyID");
					} else if ($vendorId == DataTwentyFourSevenCredentials::VENDOR_ID) {
						$DataTwentyFourSevenCredentialsVendorStrategy = new DataTwentyFourSevenCredentialsVendorStrategy();
						$DataTwentyFourSevenCredentialsVendorStrategy->delete("vendorStrategyID=$savedStrategyID");
					} else if ($vendorId == VeritecCredentials::VENDOR_ID) {
						$VeritecCredentialsVendorStrategy = new VeritecCredentialsVendorStrategy();
						$VeritecCredentialsVendorStrategy->delete("vendorStrategyID=$savedStrategyID");
					} else if ($vendorId == WhitePagesCredentials::VENDOR_ID) {
						$WhitePagesCredentialsVendorStrategy = new WhitePagesCredentialsVendorStrategy();
						$WhitePagesCredentialsVendorStrategy->delete("vendorStrategyID=$savedStrategyID");
					}
				}
			}

			$this->_helper->redirector->gotoUrlAndExit('vendorstrategies?vendorId=' .$this->_request->vendorId );
		}

		$Vendors = new Vendors();
		$vendorData = $Vendors->getDataById($this->_request->vendorId);
		$this->view->pageTitle = 'Create Data Provider Strategy for ' . $vendorData['company'];
		$this->view->vendorId = $this->_request->vendorId;

		$this->view->clarityVendorID = ClarityCredentials::VENDOR_ID;
		$this->view->factortrustVendorID = FTCredentials::VENDOR_ID;
		$this->view->truescoreVendorID = TrueScoreCredentials::VENDOR_ID;

		$this->view->dataxVendorID = DataXCredentials::VENDOR_ID;
		$this->view->mbVendorID = MBCredentials::VENDOR_ID;
		$this->view->gverifyVendorID = GVerifyCredentials::VENDOR_ID;
		$this->view->cpadetectiveVendorID = CPADetectiveCredentials::VENDOR_ID;
		$this->view->relmarVendorID = RelianceMarkCredentials::VENDOR_ID;
		$this->view->decisionlogicVendorID = DecisionLogicCredentials::VENDOR_ID;
		$this->view->ebureauVendorID = EbureauCredentials::VENDOR_ID;
		$this->view->ebureauFinanceVendorID = EbureauCredentials::VENDOR_ID_FINANCE;
		$this->view->briteverifyemailcheckVendorID  = BriteVerifyCredentials::BRITE_VERIFY_EMAIL_CHECK_VENDOR_ID;
		$this->view->pdsPaymentVendorID = PDSPaymentCredential::VENDOR_ID;
		$this->view->dataTwentyFourSevenVendorID = DataTwentyFourSevenCredentials::VENDOR_ID;
		$this->view->veritecVendorID = VeritecCredentials::VENDOR_ID;
		$this->view->whitePapersVendorID = WhitePagesCredentials::VENDOR_ID;

		$this->view->isdefaultcredentials = true;
	}

	public function saveAction()
	{
		$this->_helper->viewRenderer->setnoRender();

		$rulesets = Zend_Json::decode($this->getRequest()->getParam('rulesets'));
		$rulesetOperators = Zend_Json::decode($this->getRequest()->getParam('rulesetOperators'));

		$ruleData = Zend_Json::decode($this->getRequest()->getParam('rules'));
		$ruleOperators = Zend_Json::decode($this->getRequest()->getParam('ruleOperators'));

		$ruleIDs = Zend_Json::decode($this->getRequest()->getParam('ruleIDs'));
		$strategyId = $this->getRequest()->getParam('strategyId');
		$vendorId = $this->getRequest()->getParam('vendorId');

		$VendorStrategies = new VendorStrategies();
		$strategyName = $VendorStrategies->updateStrategyNameByCurrentState($this->getRequest()->getParam('strategyName'), $this->getRequest()->getParam('ignorefailresponse'));
		$VendorStrategies->updateStrategy($this->getRequest()->getParam('vendorId'), $strategyId, $strategyName, $this->getRequest()->getParam('ignorefailresponse'),$this->getRequest()->getParam('strategyCost'));

		$vendorStrategyRuleset = new VendorStrategyRuleset();
		$vendorStrategyRuleset->buildRuleset($rulesets, $strategyId, $rulesetOperators, $ruleIDs, $ruleData, $ruleOperators);

		$credentialtype = $this->getRequest()->getParam('credentialtype');

		$ClarityCredentials = new ClarityCredentials();
		$ClarityCredentialsVendorStrategy = new ClarityCredentialsVendorStrategy();

		$FTCredentials = new FTCredentials();
		$FTCredentialsVendorStrategy = new FTCredentialsVendorStrategy;

		$TrueScoreCredentials = new TrueScoreCredentials();
		$TrueScoreCredentialsVendorStrategy = new TrueScoreCredentialsVendorStrategy();

		if ($credentialtype == "customtype") {
			if ($vendorId == FTCredentials::VENDOR_ID) {
				$formData = array(
					'username'=>$this->getRequest()->getParam('username'),
					'password'=>$this->getRequest()->getParam('password'),
					'merchantID' => $this->getRequest()->getParam('merchantID'),
					'storeID' => $this->getRequest()->getParam('storeID'),
					'lenderID' => $this->getRequest()->getParam('lenderID'),
					'isDefault' => 0);
				$insertedID = $FTCredentials->upsert($strategyId, $formData);

				$data = array('vendorStrategyID' => $strategyId,
					'FTCredentialID' => $insertedID);

				$FTCredentialsVendorStrategy->upsert($strategyId, $data);

			} else if ($vendorId == ClarityCredentials::VENDOR_ID) {
				$formData = array(
					'username'=>$this->getRequest()->getParam('username'),
					'password'=>$this->getRequest()->getParam('password'),
					'groupID' => $this->getRequest()->getParam('groupID'),
					'accountID' => $this->getRequest()->getParam('accountID'),
					'locationID' => $this->getRequest()->getParam('locationID'),
					'controlFileName' => $this->getRequest()->getParam('controlFileName'),
				    'inquiryTradelineType' => $this->getRequest()->getParam('inquiryTradelineType'),
					'isDefault' => 0);

				$insertedID = $ClarityCredentials->upsert($strategyId, $formData);

				$data = array('vendorStrategyID' => $strategyId,
					'clarityCredentialID' => $insertedID);

				$ClarityCredentialsVendorStrategy->upsert($strategyId, $data);
			} else if ($vendorId == TrueScoreCredentials::VENDOR_ID) {
				$formData = array(
					'accountID' => $this->getRequest()->getParam('accountID'),
					'apiKey' => $this->getRequest()->getParam('apiKey'),
					'isDefault' => 0);

				$insertedID = $TrueScoreCredentials->upsert($strategyId, $formData);

				$data = array('vendorStrategyID' => $strategyId,
					'truescoreCredentialID' => $insertedID);

				$TrueScoreCredentialsVendorStrategy->upsert($strategyId, $data);
			} else if ($vendorId == DataXCredentials::VENDOR_ID) {

				$DataXCredentials = new DataXCredentials();
				$DataXCredentialsVendorStrategies = new DataXCredentialsVendorStrategies();

				$formData = array('key' => $this->getRequest()->getParam('dataxkey'),
					'password' => $this->getRequest()->getParam('dataxpassword'),
					'inquiryType' => $this->getRequest()->getParam('dataxinquiryType'));

				$insertedID = $DataXCredentials->upsert($strategyId, $formData);
				$data = array('vendorStrategyID' => $strategyId,
					'DataXCredentialID' => $insertedID);

				$DataXCredentialsVendorStrategies->upsert($strategyId, $data);

			} else if ($vendorId == MBCredentials::VENDOR_ID) {

				$MBCredentials = new MBCredentials();
				$MBCredentialsVendorStrategies = new MBCredentialsVendorStrategies();

				$formData = array('username' => $this->getRequest()->getParam('mbUsername'),
					'password' => $this->getRequest()->getParam('mbPassword'),
					'useTestUrl' => $this->getRequest()->getParam('mbUseTestUrl'));

				$insertedID = $MBCredentials->upsert($strategyId, $formData);
				$data = array('vendorStrategyID' => $strategyId,
					'MBCredentialID' => $insertedID);

				$MBCredentialsVendorStrategies->upsert($strategyId, $data);

			} else if ($vendorId == GVerifyCredentials::VENDOR_ID) {

				$GVerifyCredentials = new GVerifyCredentials();
				$GVerifyCredentialsVendorStrategies = new GVerifyCredentialsVendorStrategies();

				$formData = array('username' => $this->getRequest()->getParam('gverifyusername'),
					'password' => $this->getRequest()->getParam('gverifypassword'));

				$insertedID = $GVerifyCredentials->upsert($strategyId, $formData);
				$data = array('vendorStrategyID' => $strategyId,
					'GVerifyCredentialsID' => $insertedID);

				$GVerifyCredentialsVendorStrategies->upsert($strategyId, $data);

			} else if ($vendorId == CPADetectiveCredentials::VENDOR_ID) {

				$CPADetectiveCredentials = new CPADetectiveCredentials();
				$CPADetectiveCredentialsVendorStrategies = new CPADetectiveCredentialsVendorStrategies();

				$formData = array('key' => $this->getRequest()->getParam('cpadectivekey'));

				$insertedID = $CPADetectiveCredentials->upsert($strategyId, $formData);
				$data = array('vendorStrategyID' => $strategyId,
					'CPADetectiveCredentialID' => $insertedID);

				$CPADetectiveCredentialsVendorStrategies->upsert($strategyId, $data);

			} else if ($vendorId == RelianceMarkCredentials::VENDOR_ID) {

				$RelianceMarkCredentials = new RelianceMarkCredentials();
				$RelianceMarkCredentialsVendorStrategies = new RelianceMarkCredentialsVendorStrategies();

				$formData = array('key' => $this->getRequest()->getParam('reliancemarkkey'));

				$insertedID = $RelianceMarkCredentials->upsert($strategyId, $formData);
				$data = array('vendorStrategyID' => $strategyId,
					'RelianceMarkCredentialID' => $insertedID);

				$RelianceMarkCredentialsVendorStrategies->upsert($strategyId, $data);

			} else if ($vendorId == DecisionLogicCredentials::VENDOR_ID) {

				$DecisionLogicCredentials = new DecisionLogicCredentials();
				$DecisionLogicCredentialsVendorStrategies = new DecisionLogicCredentialsVendorStrategies();

				$formData = array('key' => $this->getRequest()->getParam('decisionlogickey'),
					'guid' => $this->getRequest()->getParam('decisionlogicguid'));

				$insertedID = $DecisionLogicCredentials->upsert($strategyId, $formData);
				$data = array('vendorStrategyID' => $strategyId,
					'decisionLogicCredentialID' => $insertedID);

				$DecisionLogicCredentialsVendorStrategies->upsert($strategyId, $data);

			} else if ($vendorId == EbureauCredentials::VENDOR_ID) {

				$EbureauCredentials = new EbureauCredentials();
				$EbureauCredentialsVendorStrategies = new EbureauCredentialsVendorStrategies();

				$formData = array(
				'username'=>$this->getRequest()->getParam('ebUsername'),
				'password'=>$this->getRequest()->getParam('ebPassword'),
				'marketScore' => $this->getRequest()->getParam('ebMarketScore'),
				'fraudScore' => $this->getRequest()->getParam('ebFraudScore'),
				'useTestUrl' => $this->getRequest()->getParam('ebUseTestUrl'),
				'isDefault' => 0);

				$insertedID = $EbureauCredentials->upsert($strategyId, $formData);

				$data = array('vendorStrategyID' => $strategyId,
					'EbureauCredentialID' => $insertedID);

				$EbureauCredentialsVendorStrategies->upsert($strategyId, $data);

			} else if ($vendorId == EbureauCredentials::VENDOR_ID_FINANCE) {

				$EbureauCredentials = new EbureauCredentials();
				$EbureauCredentialsVendorStrategies = new EbureauCredentialsVendorStrategies();

				$formData = array(
					'username'=>$this->getRequest()->getParam('ebUsername'),
					'password'=>$this->getRequest()->getParam('ebPassword'),
					'marketScore' => $this->getRequest()->getParam('ebMarketScore'),
					'fraudScore' => $this->getRequest()->getParam('ebFraudScore'),
					'fraudScoreName' => $this->getRequest()->getParam('ebFraudScoreName'),
					'marketScoreName' => $this->getRequest()->getParam('ebMarketScoreName'),
					'useTestUrl' => $this->getRequest()->getParam('ebUseTestUrl'),
					'isDefault' => 0);

				$insertedID = $EbureauCredentials->upsert($strategyId, $formData);

				$data = array('vendorStrategyID' => $strategyId,
					'EbureauCredentialID' => $insertedID);

				$EbureauCredentialsVendorStrategies->upsert($strategyId, $data);

			} else if ($vendorId == BriteVerifyCredentials::BRITE_VERIFY_EMAIL_CHECK_VENDOR_ID) {

				$BriteVerifyCredentials = new BriteVerifyCredentials();
				$BriteVerifyCredentialsVendorStrategies = new BriteVerifyCredentialsVendorStrategies();

				$formData = array(
				'key'=>$this->getRequest()->getParam('briteVerifyKey'),
				'isDefault' => 0);

				$insertedID = $BriteVerifyCredentials->upsert($strategyId, $formData);

				$data = array('vendorStrategyID' => $strategyId,
					'BriteVerifyCredentialID' => $insertedID);

				$BriteVerifyCredentialsVendorStrategies->upsert($strategyId, $data);

			} else if ($vendorId == PDSPaymentCredential::VENDOR_ID) {

				$PDSPaymentCredential = new PDSPaymentCredential();
				$PDSPaymentCredentialVendorStrategy = new PDSPaymentCredentialVendorStrategy();

				$formData = array(
					'login'=>$this->getRequest()->getParam('pdspaymentLogin'),
					'password'=>$this->getRequest()->getParam('pdspaymentPassword'),
					'merchantid' => $this->getRequest()->getParam('pdspaymentMerchantid'),
					'trancode' => $this->getRequest()->getParam('pdspaymentTrancode'),
					'sec' => $this->getRequest()->getParam('pdspaymentSec'),
					'description' => $this->getRequest()->getParam('pdspaymentDescription'),
					'isDefault' => 0);

				$insertedID = $PDSPaymentCredential->upsert($strategyId, $formData);

				$data = array('vendorStrategyID' => $strategyId,
					'PDSPaymentCredentialsID' => $insertedID);

				$PDSPaymentCredentialVendorStrategy->upsert($strategyId, $data);

			} else if ($vendorId == DataTwentyFourSevenCredentials::VENDOR_ID) {


				$DataTwentyFourSevenCredentialsVendorStrategy = new DataTwentyFourSevenCredentialsVendorStrategy();

				$formData = array(
					'username'=>$this->getRequest()->getParam('dataTwentyFourSevenUsername'),
					'password'=>$this->getRequest()->getParam('dataTwentyFourSevenPassword'),
					'isDefault' => 0);

				$DataTwentyFourSevenCredentials = new DataTwentyFourSevenCredentials();
				$insertedID = $DataTwentyFourSevenCredentials->upsert($strategyId, $formData);

				$data = array('vendorStrategyID' => $strategyId,
					'dataTwentyFourSevenCredentialID' => $insertedID);

				$DataTwentyFourSevenCredentialsVendorStrategy->upsert($strategyId, $data);

			} else if ($vendorId == VeritecCredentials::VENDOR_ID) {
				$VeritecCredentials = new VeritecCredentials();
				$VeritecCredentialsVendorStrategy = new VeritecCredentialsVendorStrategy();

				$formData = array(
					'username'=>$this->getRequest()->getParam('veritecUsername'),
					'password'=>$this->getRequest()->getParam('veritecPassword'),
					'actioncode' => $this->getRequest()->getParam('veritecActioncode'),
					'reglicnum' => $this->getRequest()->getParam('veritecReglicnum'),
					'isDefault' => 0);

				$insertedID = $VeritecCredentials->upsert($strategyId, $formData);

				$data = array('vendorStrategyID' => $strategyId,
					'VeritecCredentialsID' => $insertedID);

				$VeritecCredentialsVendorStrategy->upsert($strategyId, $data);

			} else if ($vendorId == WhitePagesCredentials::VENDOR_ID) {

				$WhitePagesCredentials = new WhitePagesCredentials();
				$WhitePagesCredentialsVendorStrategy = new WhitePagesCredentialsVendorStrategy();

				$formData = array(
					'apiKey' => $this->getRequest()->getParam('apiKey'),
				    'products' => implode(",",$this->getRequest()->getParam('products')),
					'isDefault' => 0);

				$insertedID = $WhitePagesCredentials->upsert($strategyId, $formData);

				$data = array('vendorStrategyID' => $strategyId,
					'whitePagesCredentialsID' => $insertedID);

				$WhitePagesCredentialsVendorStrategy->upsert($strategyId, $data);

			}
		}
		else if ($credentialtype == "defaulttype") {

			if ($vendorId == FTCredentials::VENDOR_ID) {
				$FTCredentialsVendorStrategy->delete("vendorStrategyID=$strategyId");
			} else if ($vendorId == ClarityCredentials::VENDOR_ID) {
				$ClarityCredentialsVendorStrategy->delete("vendorStrategyID=$strategyId");
			} else if ($vendorId == TrueScoreCredentials::VENDOR_ID) {
				$TrueScoreCredentialsVendorStrategy->delete("vendorStrategyID=$strategyId");
			} else if ($vendorId == DataXCredentials::VENDOR_ID) {
				$DataXCredentialsVendorStrategies = new DataXCredentialsVendorStrategies();
				$DataXCredentialsVendorStrategies->delete("vendorStrategyID=$strategyId");

			} else if ($vendorId == MBCredentials::VENDOR_ID) {
				$MBCredentialsVendorStrategies = new MBCredentialsVendorStrategies();
				$MBCredentialsVendorStrategies->delete("vendorStrategyID=$strategyId");

			} else if ($vendorId == GVerifyCredentials::VENDOR_ID) {
				$GVerifyCredentialsVendorStrategies = new GVerifyCredentialsVendorStrategies();
				$GVerifyCredentialsVendorStrategies->delete("vendorStrategyID=$strategyId");
			} else if ($vendorId == CPADetectiveCredentials::VENDOR_ID) {
				$CPADetectiveCredentialsVendorStrategies = new CPADetectiveCredentialsVendorStrategies();
				$CPADetectiveCredentialsVendorStrategies->delete("vendorStrategyID=$strategyId");
			} else if ($vendorId == RelianceMarkCredentials::VENDOR_ID) {
				$RelianceMarkCredentialsVendorStrategies = new RelianceMarkCredentialsVendorStrategies();
				$RelianceMarkCredentialsVendorStrategies->delete("vendorStrategyID=$strategyId");
			} else if ($vendorId == DecisionLogicCredentials::VENDOR_ID) {
				$DecisionLogicCredentialsVendorStrategies = new DecisionLogicCredentialsVendorStrategies();
				$DecisionLogicCredentialsVendorStrategies->delete("vendorStrategyID=$strategyId");
			} else if ($vendorId == EbureauCredentials::VENDOR_ID) {
				$EbureauCredentialsVendorStrategies = new EbureauCredentialsVendorStrategies();
				$EbureauCredentialsVendorStrategies->delete("vendorStrategyID=$strategyId");
			} else if ($vendorId == EbureauCredentials::VENDOR_ID_FINANCE) {
				$EbureauCredentialsVendorStrategies = new EbureauCredentialsVendorStrategies();
				$EbureauCredentialsVendorStrategies->delete("vendorStrategyID=$strategyId");
			} else if ($vendorId == BriteVerifyCredentials::BRITE_VERIFY_EMAIL_CHECK_VENDOR_ID) {
				$BriteVerifyCredentialsVendorStrategies = new BriteVerifyCredentialsVendorStrategies();
				$BriteVerifyCredentialsVendorStrategies->delete("vendorStrategyID=$strategyId");
			} else if ($vendorId == PDSPaymentCredential::VENDOR_ID) {
				$PDSPaymentCredentialVendorStrategy = new PDSPaymentCredentialVendorStrategy();
				$PDSPaymentCredentialVendorStrategy->delete("vendorStrategyID=$strategyId");
			} else if ($vendorId == DataTwentyFourSevenCredentials::VENDOR_ID) {
				$DataTwentyFourSevenCredentialsVendorStrategy = new DataTwentyFourSevenCredentialsVendorStrategy();
				$DataTwentyFourSevenCredentialsVendorStrategy->delete("vendorStrategyID=$strategyId");
			} else if ($vendorId == VeritecCredentials::VENDOR_ID) {
				$VeritecCredentialsVendorStrategy = new VeritecCredentialsVendorStrategy();
				$VeritecCredentialsVendorStrategy->delete("vendorStrategyID=$strategyId");
			} else if ($vendorId == WhitePagesCredentials::VENDOR_ID) {
				$WhitePagesCredentialsVendorStrategy = new WhitePagesCredentialsVendorStrategy();
				$WhitePagesCredentialsVendorStrategy->delete("vendorStrategyID=$strategyId");
			}
		}
	}

	public function deleteAction()
	{
		$this->_helper->viewRenderer->setnoRender();
		$strategyId = $this->_request->strategyId;
		$VendorStrategies = new VendorStrategies();
		if ($VendorStrategies->checkIfSafeToDelete($strategyId))
			$VendorStrategies->delete('id=' . $strategyId);
		else
			echo 'fail';


		// we also need to delete all credentials for the strategy
		$ClarityCredentialsVendorStrategy = new ClarityCredentialsVendorStrategy();
		$FTCredentialsVendorStrategy = new FTCredentialsVendorStrategy;
		$TrueScoreCredentialsVendorStrategy = new TrueScoreCredentialsVendorStrategy();
		$GVerifyCredentialsVendorStrategies = new GVerifyCredentialsVendorStrategies();
		$CPADetectiveCredentialsVendorStrategies = new CPADetectiveCredentialsVendorStrategies();
		$DataXCredentialsVendorStrategies = new DataXCredentialsVendorStrategies();
		$RelianceMarkCredentialsVendorStrategies = new RelianceMarkCredentialsVendorStrategies();
		$DecisionLogicCredentialsVendorStrategies = new DecisionLogicCredentialsVendorStrategies();
		$EbureauCredentialsVendorStrategies = new EbureauCredentialsVendorStrategies();
		$BriteVerifyCredentialsVendorStrategies = new BriteVerifyCredentialsVendorStrategies();
		$PDSPaymentCredentialVendorStrategy = new PDSPaymentCredentialVendorStrategy();
		$DataTwentyFourSevenCredentialsVendorStrategy = new DataTwentyFourSevenCredentialsVendorStrategy();
		$VeritecCredentialsVendorStrategy = new VeritecCredentialsVendorStrategy();
		$WhitePagesCredentialsVendorStrategy= new WhitePagesCredentialsVendorStrategy();

		$vendorId = $this->getRequest()->getParam('vendorId');
		if ($vendorId == FTCredentials::VENDOR_ID) {
			$FTCredentialsVendorStrategy->delete("vendorStrategyID=$strategyId");
		} else if ($vendorId == ClarityCredentials::VENDOR_ID) {
			$ClarityCredentialsVendorStrategy->delete("vendorStrategyID=$strategyId");
		} else if ($vendorId == TrueScoreCredentials::VENDOR_ID) {
			$TrueScoreCredentialsVendorStrategy->delete("vendorStrategyID=$strategyId");
		} else if ($vendorId == GVerifyCredentials::VENDOR_ID) {
			$GVerifyCredentialsVendorStrategies->delete("vendorStrategyID=$strategyId");
		} else if ($vendorId == CPADetectiveCredentials::VENDOR_ID) {
			$CPADetectiveCredentialsVendorStrategies->delete("vendorStrategyID=$strategyId");
		} else if ($vendorId == DataXCredentials::VENDOR_ID) {
			$DataXCredentialsVendorStrategies->delete("vendorStrategyID=$strategyId");
		} else if ($vendorId == RelianceMarkCredentials::VENDOR_ID) {
			$RelianceMarkCredentialsVendorStrategies->delete("vendorStrategyID=$strategyId");
		} else if ($vendorId == DecisionLogicCredentials::VENDOR_ID) {
			$DecisionLogicCredentialsVendorStrategies->delete("vendorStrategyID=$strategyId");
		} else if ($vendorId == EbureauCredentials::VENDOR_ID) {
			$EbureauCredentialsVendorStrategies->delete("vendorStrategyID=$strategyId");
		} else if ($vendorId == EbureauCredentials::VENDOR_ID_FINANCE) {
			$EbureauCredentialsVendorStrategies->delete("vendorStrategyID=$strategyId");
		} else if ($vendorId == BriteVerifyCredentials::BRITE_VERIFY_EMAIL_CHECK_VENDOR_ID) {
			$BriteVerifyCredentialsVendorStrategies->delete("vendorStrategyID=$strategyId");
		} else if ($vendorId == PDSPaymentCredential::VENDOR_ID) {
			$PDSPaymentCredentialVendorStrategy->delete("vendorStrategyID=$strategyId");
		} else if ($vendorId == DataTwentyFourSevenCredentials::VENDOR_ID) {
			$DataTwentyFourSevenCredentialsVendorStrategy->delete("vendorStrategyID=$strategyId");
		} else if ($vendorId == VeritecCredentials::VENDOR_ID) {
			$VeritecCredentialsVendorStrategy->delete("vendorStrategyID=$strategyId");
		} else if ($vendorId == WhitePagesCredentials::VENDOR_ID) {
			$WhitePagesCredentialsVendorStrategy->delete("vendorStrategyID=$strategyId");
		}
	}

	public function editAction()
	{
		$VendorStrategies = new VendorStrategies();
		$Vendors = new Vendors();
		if ($_POST)
		{
			$strategyName = $VendorStrategies->updateStrategyNameByCurrentState($this->_request->strategyName, $this->_request->ignorefailresponse);
			$VendorStrategies->updateStrategy($this->_request->vendorId, $this->_request->strategyId, $strategyName, $this->_request->ignorefailresponse);
			$this->_helper->redirector->gotoUrlAndExit('Vendorstrategies?vendorId=' .$this->_request->vendorId );
		}
		$vendorId = $this->_request->vendorId;
		$vendorStrategyId = $this->_request->strategyId;
		// get vendor Data
		$vendorData = $Vendors->getDataById($vendorId);
		// get strategy Name
		$select = $VendorStrategies->select()->where('id=' . $vendorStrategyId);
		$result = $VendorStrategies->fetchRow($select);
		// passing as an array in anticipation of more things being added down the road
		$data['strategyName'] = $VendorStrategies->updateStrategyNameByCurrentState($result['description'], "0");
		$this->view->pageTitle = 'Update ' . $result['description'] . ' Strategy for ' . $vendorData['company'];
		$this->view->data = $data;
		$this->view->ignorefailresponse = $result['ignoreFailResponse'] == "1" ? "checked" : "";
		$this->view->edit = TRUE;
		$this->view->vendorId = $vendorId;
		$this->view->strategyId = $vendorStrategyId;
		$this->view->clarityVendorID = ClarityCredentials::VENDOR_ID;
		$this->view->factortrustVendorID = FTCredentials::VENDOR_ID;
		$this->view->truescoreVendorID = TrueScoreCredentials::VENDOR_ID;
		$this->view->dataxVendorID = DataXCredentials::VENDOR_ID;
		$this->view->mbVendorID = MBCredentials::VENDOR_ID;
		$this->view->gverifyVendorID = GVerifyCredentials::VENDOR_ID;
		$this->view->cpadetectiveVendorID = CPADetectiveCredentials::VENDOR_ID;
		$this->view->relmarVendorID = RelianceMarkCredentials::VENDOR_ID;
		$this->view->decisionlogicVendorID = DecisionLogicCredentials::VENDOR_ID;
		$this->view->ebureauVendorID = EbureauCredentials::VENDOR_ID;
		$this->view->ebureauFinanceVendorID = EbureauCredentials::VENDOR_ID_FINANCE;
		$this->view->briteverifyemailcheckVendorID  = BriteVerifyCredentials::BRITE_VERIFY_EMAIL_CHECK_VENDOR_ID;
		$this->view->pdsPaymentVendorID = PDSPaymentCredential::VENDOR_ID;
		$this->view->dataTwentyFourSevenVendorID = DataTwentyFourSevenCredentials::VENDOR_ID;
		$this->view->veritecVendorID = VeritecCredentials::VENDOR_ID;
		$this->view->whitePapersVendorID = WhitePagesCredentials::VENDOR_ID;
		$this->view->cost = $result['cost'];

		$vendorStrategies = new VendorStrategies();


		if ($vendorId == FTCredentials::VENDOR_ID) {
			$FTdata = $vendorStrategies->getFactorTrustCredentialsByStrategyID($vendorStrategyId);

			$this->view->username = $FTdata[0]['username'];
			$this->view->password = $FTdata[0]['password'];
			$this->view->merchantID = $FTdata[0]['merchantID'];
			$this->view->storeID = $FTdata[0]['storeID'];
			$this->view->lenderID = $FTdata[0]['lenderID'];
			$this->view->isdefaultcredentials = $FTdata[0]['username'] && $FTdata[0]['isDefault'] == 0 ? false : true;

		} else if ($vendorId == ClarityCredentials::VENDOR_ID) {
			$CLdata = $vendorStrategies->getClarityCredentialsByStrategyID($vendorStrategyId);

			$this->view->username = $CLdata[0]['username'];
			$this->view->password = $CLdata[0]['password'];
			$this->view->groupID = $CLdata[0]['groupID'];
			$this->view->accountID = $CLdata[0]['accountID'];
			$this->view->locationID = $CLdata[0]['locationID'];
			$this->view->controlFileName = $CLdata[0]['controlFileName'];
			$this->view->inquiryTradelineType = $CLdata[0]['inquiryTradelineType'];
			$this->view->isdefaultcredentials = $CLdata[0]['username'] && $CLdata[0]['isDefault'] == 0 ? false : true;
		} else if ($vendorId == TrueScoreCredentials::VENDOR_ID) {
			$TSdata = $vendorStrategies->getTrueScoreCredentialsByStrategyID($vendorStrategyId);

			$this->view->accountID = $TSdata[0]['accountID'];
			$this->view->apiKey = $TSdata[0]['apiKey'];
			$this->view->isdefaultcredentials = $TSdata[0]['accountID'] && $TSdata[0]['isDefault'] == 0 ? false : true;

		} else if ($vendorId == DataXCredentials::VENDOR_ID) {

			$dxdata = $vendorStrategies->getDataXCredentialsByStrategyID($vendorStrategyId);
			$this->view->key = $dxdata[0]['key'];
			$this->view->password = $dxdata[0]['password'];
			$this->view->inquiryType = $dxdata[0]['inquiryType'];
			$this->view->isdefaultcredentials = $dxdata[0]['key'] && $dxdata[0]['isDefault'] == 0 ? false : true;
		} else if ($vendorId == MBCredentials::VENDOR_ID) {

			$mbdata = $vendorStrategies->getmbCredentialsByStrategyID($vendorStrategyId);
			$this->view->mbUsername = $mbdata[0]['username'];
			$this->view->mbPassword = $mbdata[0]['password'];
			$this->view->mbUseTestUrl = $mbdata[0]['useTestUrl'];
			$this->view->isdefaultcredentials = $mbdata[0]['username'] && $mbdata[0]['isDefault'] == 0 ? false : true;
		} else if ($vendorId == GVerifyCredentials::VENDOR_ID) {

			$Gverifydata = $vendorStrategies->getGverifyCredentialsByStrategyID($vendorStrategyId);
			$this->view->username = $Gverifydata[0]['username'];
			$this->view->password = $Gverifydata[0]['password'];
			$this->view->isdefaultcredentials = $Gverifydata[0]['username'] && $Gverifydata[0]['isDefault'] == 0 ? false : true;

		} else if ($vendorId == CPADetectiveCredentials::VENDOR_ID) {

			$CPADectivedata = $vendorStrategies->getCPADectiveCredentialsByStrategyID($vendorStrategyId);
			$this->view->cpadectivekey = $CPADectivedata[0]['key'];
			$this->view->isdefaultcredentials = $CPADectivedata[0]['key'] && $CPADectivedata[0]['isDefault'] == 0 ? false : true;

		} else if ($vendorId == RelianceMarkCredentials::VENDOR_ID) {

			$RelMardata = $vendorStrategies->getRelianceMarkCredentialsByStrategyID($vendorStrategyId);
			$this->view->reliancemarkkey = $RelMardata[0]['key'];
			$this->view->isdefaultcredentials = $RelMardata[0]['key'] && $RelMardata[0]['isDefault'] == 0 ? false : true;

		} else if ($vendorId == DecisionLogicCredentials::VENDOR_ID) {

			$decisionlogicdata = $vendorStrategies->getDecisionLogicCredentialsByStrategyID($vendorStrategyId);
			$this->view->decisionlogickey = $decisionlogicdata[0]['key'];
			$this->view->decisionlogicguid = $decisionlogicdata[0]['guid'];
			$this->view->isdefaultcredentials = $decisionlogicdata[0]['key'] && $decisionlogicdata[0]['isDefault'] == 0 ? false : true;

		} else if ($vendorId == EbureauCredentials::VENDOR_ID) {

			$ebureaudata = $vendorStrategies->getEbureauCredentialsByStrategyID($vendorStrategyId);
			$this->view->ebUsername = $ebureaudata[0]['username'];
			$this->view->ebPassword = $ebureaudata[0]['password'];
			$this->view->ebMarketScore = $ebureaudata[0]['marketScore'];
			$this->view->ebFraudScore = $ebureaudata[0]['fraudScore'];
			$this->view->ebUseTestUrl = $ebureaudata[0]['useTestUrl'];
			$this->view->isdefaultcredentials = $ebureaudata[0]['username'] && $ebureaudata[0]['isDefault'] == 0 ? false : true;

		} else if ($vendorId == EbureauCredentials::VENDOR_ID_FINANCE) {

			$ebureaudata = $vendorStrategies->getEbureauCredentialsByStrategyID($vendorStrategyId);
			$this->view->ebUsername = $ebureaudata[0]['username'];
			$this->view->ebPassword = $ebureaudata[0]['password'];
			$this->view->ebMarketScore = $ebureaudata[0]['marketScore'];
			$this->view->ebFraudScore = $ebureaudata[0]['fraudScore'];
			$this->view->ebMarketScoreName = $ebureaudata[0]['fraudScoreName'];
			$this->view->ebFraudScoreName = $ebureaudata[0]['marketScoreName'];
			$this->view->ebUseTestUrl = $ebureaudata[0]['useTestUrl'];
			$this->view->isdefaultcredentials = $ebureaudata[0]['username'] && $ebureaudata[0]['isDefault'] == 0 ? false : true;

		} else if ($vendorId == BriteVerifyCredentials::BRITE_VERIFY_EMAIL_CHECK_VENDOR_ID) {

			$briteVerifyData = $vendorStrategies->getBriteVerifyCredentialsByStrategyID($vendorStrategyId);
			$this->view->briteVerifyKey = $briteVerifyData[0]['key'];
			$this->view->isdefaultcredentials = $briteVerifyData[0]['key'] && $briteVerifyData[0]['isDefault'] == 0 ? false : true;
		} else if ($vendorId == PDSPaymentCredential::VENDOR_ID) {

			$pdsPaymentData = $vendorStrategies->getPDSPaymentCredentialsByStrategyID($vendorStrategyId);
			$this->view->pdspaymentLogin = $pdsPaymentData[0]['login'];
			$this->view->pdspaymentPassword = $pdsPaymentData[0]['password'];
			$this->view->pdspaymentMerchantid = $pdsPaymentData[0]['merchantid'];
			$this->view->pdspaymentTrancode = $pdsPaymentData[0]['trancode'];
			$this->view->pdspaymentSec = $pdsPaymentData[0]['sec'];
			$this->view->pdspaymentDescription = $pdsPaymentData[0]['description'];

			$this->view->isdefaultcredentials = $pdsPaymentData[0]['login'] && $pdsPaymentData[0]['isDefault'] == 0 ? false : true;
		} else if ($vendorId == DataTwentyFourSevenCredentials::VENDOR_ID) {

			$dataTwentyFourSevenData = $vendorStrategies->getDataTwentyFourSevenCredentialsByStrategyID($vendorStrategyId);
			$this->view->dataTwentyFourSevenUsername = $dataTwentyFourSevenData[0]['username'];
			$this->view->dataTwentyFourSevenPassword = $dataTwentyFourSevenData[0]['password'];

			$this->view->isdefaultcredentials = $dataTwentyFourSevenData[0]['username'] && $dataTwentyFourSevenData[0]['isDefault'] == 0 ? false : true;
		} else if ($vendorId == VeritecCredentials::VENDOR_ID) {

			$veritecData = $vendorStrategies->getVeritecCredentialsByStrategyID($vendorStrategyId);
			$this->view->veritecUsername = $veritecData[0]['username'];
			$this->view->veritecPassword = $veritecData[0]['password'];
			$this->view->veritecReglicnum = $veritecData[0]['reglicnum'];
			$this->view->veritecActioncode = $veritecData[0]['actioncode'];

			$this->view->isdefaultcredentials = $veritecData[0]['username'] && $veritecData[0]['isDefault'] == 0 ? false : true;

		} else if ($vendorId == WhitePagesCredentials::VENDOR_ID) {
		    $whitePaperscData = $vendorStrategies->getWhitePapersCredentialsByStrategyID($vendorStrategyId);
		    $this->view->whitePapersApiKey = $whitePaperscData[0]['apiKey'];
		    $this->view->products = $whitePaperscData[0]['products'];
		    $this->view->isdefaultcredentials = $whitePaperscData[0]['apiKey'] && $whitePaperscData[0]['isDefault'] == 0 ? false : true;
		}

		$VendorStrategyRuleset = new VendorStrategyRuleset();
		$vendorStrategyRulesets = $VendorStrategyRuleset->generateRulesetsDataByVendorStrategyID($vendorStrategyId);
		$this->view->vendorStrategyRulesets = $vendorStrategyRulesets;

		echo "";
	}

	public function searchAction()
	{
		$this->_helper->viewRenderer->setnoRender();
		$paramName = $this->getRequest()->getParam('query');
		$vendorID = $this->getRequest()->getParam('vendorId');
		$VendorResponseParameter = new VendorResponseParameter();
		$data = $VendorResponseParameter->findParameterByVendorIDandName($vendorID, $paramName);

		$result = array();
		$parameters = array();
		foreach ($data as $v) {
			$result['id'] = $v['id'];
			$result['name'] = $v['name'];
			$result['description'] = $v['description'];
			$parameters[] = $result;
		}

		echo Zend_Json::encode($parameters);
	}
}
?>
