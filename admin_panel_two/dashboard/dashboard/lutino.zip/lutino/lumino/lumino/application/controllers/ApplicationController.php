<?php
/**
 * Base Class where we can share things amongst all Controllers
 *
 * @package Admin
 */
abstract class ApplicationController extends Zend_Controller_Action
{
	public function __construct((Zend_Controller_Request_Abstract $request, 
																Zend_Controller_Response_Abstract $response, 
																array $invokeArgs = array()) 
	{
		parent::_construct($request, $response, $invokeArgs);

		// initialize session
		$this->adminNameSpace = new Zend_Session_Namespace('AdminUserID');

		// initialize flash messenger
		$this->flash = $this->_helper->getHeler('FlashMessenger');
		$this->view->flash = $this->flash;
	}

	public function connectToDatabase($serverName)
	{
		$config = new Zend_Config_Ini('./application/config.ini', $serverName);

		try {
			$db = Zend_Db::factory($config->db->adapter, $config->db->config->toArray());
		}
		catch (PDOException $e) { }
		catch (Exception $e) { }

		if (!$db) {
			return false;
		}

		return $db;
	}

