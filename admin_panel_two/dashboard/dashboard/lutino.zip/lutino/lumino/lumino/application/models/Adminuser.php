<?php
class Adminuser extends Zend_Db_Table
{
	protected $_name = 'adminusers';
}
?>