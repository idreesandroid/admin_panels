<?php
$decisonLogicRuleSetsData = json_decode($this->decisionLogicRuleSetsData);
$ruleSetsCount = count($decisonLogicRuleSetsData);
$strategyName = "";
if ($ruleSetsCount > 0) {
    $strategyName = $decisonLogicRuleSetsData[0];
    $strategyName = $strategyName->strategyName;
}
$ruleComparisionOperators = array(
    '1' => 'equals',
    '2' => 'is greater than',
    '3'=> 'is greater than or equal to',
    '4'=> 'is less than',
    '5'=> 'is less than or equal to',
    '6'=> 'like',
    '9'=> 'not equals'
);
$ruleOperators = array('1' => 'AND','2' => 'OR');
?>
<div class="row">
<div class="col-lg-12">
<label style="margin-bottom: 1px;">Decision logic rule sets</label>
</div>
</div>
<div class="row">
		<div class="col-lg-12">
		    <div class="ruleset-panel ruleset-panel-default">
    		    <div class="panel-body">
    		        <div class="col-lg-11">
    		        <div class="row">
    		            <div class="col-lg-5">
    		            <div class="form-group-dl">
								<label style="margin-bottom: 1px;">Strategy Name</label>
								<input type="text" value="<?php echo $strategyName;?>" id="dlstrategyname" class="form-control-dl">
							</div>
    		            </div>
    		        </div>

    		        <div id="decisionLogicRulesSpawnArea">
    		            <?php
    		            if ($ruleSetsCount > 0) {
    		                $counter = 1;
    		                foreach ($decisonLogicRuleSetsData as $data)
    		                {
    		            ?>
    		            <div class="DecisionLogicExtraRuleset">
                        <div class="row">
                            <div class="ruleset-panel ruleset-panel-default">
                        		<div class="panel-body">
                        		    <div class="row" class="rulesinputfields">
                        		    <div class="col-lg-1" style="width:4%;">
                        		    <div class="decisionLogicRuleSetPriority" style="float:left">
                        		    [<?php echo $counter;?>]
                        		    </div>
                        		    </div>
                        		    <div class="col-lg-4">
                        		        <div class="form-group-dl">
                        				<label style="margin-bottom: 1px;">Ruleset Name</label>
                        				<input type="text" value="<?php echo $data->ruleSetName;?>" class="dlrulesetname form-control-dl">
                        				</div>
                        		    </div>
                        		    <div class="col-lg-3">
                        		    <div class="form-group-dl">
                        				<label style="margin-bottom: 1px;">StoreID</label>
                        				<input type="text" value="<?php echo $data->ruleSetStoreID;?>" name="markupprice" class="dlrulesetstoreid form-control-dl">
                        				</div>
                        		    </div>
                        		    <div class="col-lg-2">
                        		    <div class="form-group-dl">
                        				<label style="margin-bottom: 1px;">Priority</label>
                        				<input type="text" value="<?php echo $data->ruleSetPriority;?>" name="markupprice" class="dlrulesetpriority form-control-dl">
                        				</div>
                        		    </div>
                        		    <div class="col-lg-2">
                        		    <div style="float:right">
                        		    <a href="#" class="decisionLogicRemoveRuleSet" style="color:red; text-decoration:none;">[x] Delete Rule Set</a>
                        		    </div>
                        		    </div>
                        		    </div>

                        		    <div class="row">
                        		    <div class="col-lg-12">

                        		        <div class="ruleSpawnArea">

                        		            <?php for ($a=0;$a<count($data->rulesVendorParams);$a++) {?>
                        		            <div class="extraRuleDecisionLogic">
                                                <div class="row">
                                                    <div class="col-lg-11" style="border-radius: 5px;width:98%;background-color: #1ab0f0; margin-left:10px;line-height:20px;">
                                                	    <div class="col-lg-1" style="color:white;width:4.333%;margin-top: 4px; margin-bottom: 5px;"><strong><span class="rulePriority">[<?php echo $a+1;?>]</span></strong></div>
                                                	    <div class="col-lg-3" style="width:32%;margin-top: 4px; margin-bottom: 5px;"><a class="dlogicresponseparam" data-value="<?php echo $data->rulesVendorParams[$a];?>" href="#"><?php echo $this->dlResponseParams[$data->rulesVendorParams[$a]];?></a></div>
                                                	    <div class="col-lg-3" style="width:23%;margin-top: 4px; margin-bottom: 5px;"><a  class="operators" data-value="<?php echo $data->rulesVendorParamsOperator[$a];?>" href="#"><?php echo $ruleComparisionOperators[$data->rulesVendorParamsOperator[$a]];?></a></div>
                                                	    <div class="col-lg-3" style="width:26%;margin-top: 4px; margin-bottom: 5px;"><a class="paramValue" data-value="<?php echo $data->rulesVendorParamsValues[$a];?>" href="#"><?php echo $data->rulesVendorParamsValues[$a];?></a></div>
                                                	    <div class="col-lg-2" style="width:14%;margin-top: 4px; margin-bottom: 5px;">
                                                	        <div style="float:right">
                                                	        <a href="#" class="decisionLogicRemoveRule" style="color:red; text-decoration:none;">[x] Delete Rule</a>
                                                	        </div>
                                                	    </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php if (isset($data->ruleOperators[$a])) {?>
                                            <div class="col-lg-12" style="">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <a href="#" class="decisionLogicRuleOperator" data-value="<?php echo $data->ruleOperators[$a];?>" style="color:black"><?php echo $ruleOperators[$data->ruleOperators[$a]];?></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php }?>
                                            <?php }?>

                        		        </div>
                        		    </div>
                        		    </div>

                        		    <div class="row">
                        		    <div class="col-lg-2" style="margin-top: 3px;">
                        		    <div style="cursor:pointer;" id="decisionLogicaddRule">[+] Add new rule</div>
                        		    </div>
                        		    </div>
                        		</div>
                            </div>
                        </div>
                    </div>
                    <?php
    		                $counter++;
    		                }
    		        }?>
    		        </div>

    		        </div>
    		        <div class="col-lg-3">
    		        <div style="cursor:pointer;" id="addDecisionLogicRuleset">[+] Add new decision logic ruleset</div>
                    </div>
                </div>
		    </div>
		</div>
</div>

<div class="decisionLogicRuleSetTemplate" style="display: none;">
    <div class="row">
        <div class="ruleset-panel ruleset-panel-default">
    		<div class="panel-body">
    		    <div class="row" class="rulesinputfields">
    		    <div class="col-lg-1" style="width:4%;">
    		    <div class="decisionLogicRuleSetPriority" style="float:left">
    		    </div>
    		    </div>
    		    <div class="col-lg-4">
    		        <div class="form-group-dl">
    				<label style="margin-bottom: 1px;">Ruleset Name</label>
    				<input type="text" value="" class="dlrulesetname form-control-dl">
    				</div>
    		    </div>
    		    <div class="col-lg-3">
    		    <div class="form-group-dl">
    				<label style="margin-bottom: 1px;">StoreID</label>
    				<input type="text" name="markupprice" class="dlrulesetstoreid form-control-dl">
    				</div>
    		    </div>
    		    <div class="col-lg-2">
    		    <div class="form-group-dl">
    				<label style="margin-bottom: 1px;">Priority</label>
    				<input type="text" name="markupprice" class="dlrulesetpriority form-control-dl">
    				</div>
    		    </div>
    		    <div class="col-lg-2">
    		    <div style="float:right">
    		    <a href="#" class="decisionLogicRemoveRuleSet" style="color:red; text-decoration:none;">[x] Delete Rule Set</a>
    		    </div>
    		    </div>
    		    </div>

    		    <div class="row">
    		    <div class="col-lg-12">
    		        <div class="ruleSpawnArea"></div>
    		    </div>
    		    </div>

    		    <div class="row">
    		    <div class="col-lg-2" style="margin-top: 3px;">
    		    <div style="cursor:pointer;" id="decisionLogicaddRule">[+] Add new rule</div>
    		    </div>
    		    </div>
    		</div>
        </div>
    </div>
</div>

<div class="decisionLogicRuleTemplate" style="display: none;">
    <div class="row">
        <div class="col-lg-11" style="border-radius: 5px;width:98%;background-color: #1ab0f0; margin-left:10px;line-height:20px;">
    	    <div class="col-lg-1" style="color:white;width:4.333%;margin-top: 4px; margin-bottom: 5px;"><strong><span class="rulePriority"></span></strong></div>
    	    <div class="col-lg-3" style="width:32%;margin-top: 4px; margin-bottom: 5px;"><a class="dlogicresponseparam" href="#">decision logic operator</a></div>
    	    <div class="col-lg-3" style="width:23%;margin-top: 4px; margin-bottom: 5px;"><a  class="operators" href="#">comparision</a></div>
    	    <div class="col-lg-3" style="width:26%;margin-top: 4px; margin-bottom: 5px;"><a class="paramValue" href="#">passing value</a></div>
    	    <div class="col-lg-2" style="width:14%;margin-top: 4px; margin-bottom: 5px;">
    	        <div style="float:right">
    	        <a href="#" class="decisionLogicRemoveRule" style="color:red; text-decoration:none;">[x] Delete Rule</a>
    	        </div>
    	    </div>
        </div>
    </div>
</div>
<input type="hidden" id="baseurl" value="<?php echo $this->baseurl; ?>/campaign/getvendorresparams">