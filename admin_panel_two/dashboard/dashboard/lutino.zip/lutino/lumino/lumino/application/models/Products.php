<?php

class Products extends Zend_Db_Table
{
	protected $_name = 'products';
}
?>
