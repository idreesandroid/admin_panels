<?php
/**
 * facade class that handles getting all data for building Pie charts
 */
class PieChartReport extends ReportAbstract
{
	
}
