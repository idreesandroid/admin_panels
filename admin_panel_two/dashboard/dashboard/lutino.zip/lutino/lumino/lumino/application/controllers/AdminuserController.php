<?php
class AdminuserController extends Zend_Controller_Action 
{
    private $baseurl;
	
	function init()
    {
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if(!$AdminNameSpace->userid)
		{
	    		$this->_redirect('index/login');	
		}
	    $this->baseurl = $this->_request->getBaseUrl();
    }
    
    function viewAction()
    {
    	global $db;
    	$query = "select * from adminusers order by fname";
    	$accountexecutives = $db->fetchAll($query);
    	$this->view->baseurl = $this->baseurl;
    	$this->view->data = $accountexecutives;
    }
    
    function addAction()
    {
    	$message = "";
    	$error = 0;
    	$success = 0;
    	
    	if ($this->_request->isPost()) {
    		
    		include("Commonfunctions.php");
    		$commonobj = new Commonfunctions();
    		
    		Zend_Loader::loadClass('Zend_Filter_StripTags');
			$f = new Zend_Filter_StripTags();
			
    		$firstname = $f->filter($this->_request->getPost('fname'));
    		$lastname = $f->filter($this->_request->getPost('lname'));	
    		$email    = $f->filter($this->_request->getPost('email'));	
    		$username = $this->_request->getPost('username');	
    		$password = $this->_request->getPost('password');	
    		
    		if(empty($firstname)){
    			$message.="Please provide first name.<br>";
    			$error = 1;
    		}
    		if(empty($lastname)){
    			$message.="Please provide last name.<br>";
    			$error = 1;
    		}
    		if(empty($email)){
    			$message.="Please provide email.<br>";
    			$error = 1;
    		}
    		if(!empty($email)){
    			if($commonobj->isvalidemail($email)==0){
    			$message.="Invalid email.<br>";
    			$error = 1;
    			}
    		}
    		if(empty($username)){
    			$message.="Please provide username.<br>";
    			$error = 1;
    		}
    		if(empty($password)){
    			$message.="Please provide password.<br>";
    			$error = 1;
    		}

    		if($error==0)
    		{

    			$Form_Data = array('username'=>$username,'password'=>$password,'fname'=>$firstname,'lname'=>$lastname,'email'=>$email);
		    	Zend_Loader::loadClass('Adminuser');
			    $ae_Data  = new Adminuser();
			    try 
			    { 
			   		$ae_Data->insert($Form_Data);	
			   		$message = "New user successfully added.";	
			   		$success = 1;		   		
			    }
			    catch (Zend_Exception $e)
			    {
			   		$error = 1;
			    	$message = "Some error occurred please try latter.";
			    	
			    }
    		}
    		
    		if($error==1){
    			
    		$this->view->firstname = $firstname;
    		$this->view->lastname = $lastname;
    		$this->view->email = $email;
    		$this->view->username = $username;
    		$this->view->password = $password;
    		
    		}
    		else {
    			
    			$this->view->firstname = "";
    			$this->view->lastname = "";
    			$this->view->email = "";
    			$this->view->phone = "";
    		}
    		
    		
    	}
    	else {
    		$this->view->firstname = "";
    		$this->view->lastname = "";
    		$this->view->email = "";
    		$this->view->phone = "";
    	}
    	   	
    	$this->view->baseurl = $this->baseurl;
    	$this->view->message = $message;
    	$this->view->error = $error;
    	$this->view->success = $success;
    }
    
    function editAction()
    {
    	global $db;
    	$id = $_REQUEST['id'];
    	
    	$message = "";
    	$error = 0;
    	$success = 0;
    	
    	if ($this->_request->isPost()) {
    		
    		include("Commonfunctions.php");
    		$commonobj = new Commonfunctions();
    		
    		Zend_Loader::loadClass('Zend_Filter_StripTags');
			$f = new Zend_Filter_StripTags();
			
    		$firstname = $f->filter($this->_request->getPost('fname'));
    		$lastname = $f->filter($this->_request->getPost('lname'));	
    		$email    = $f->filter($this->_request->getPost('email'));	
    		$username = $this->_request->getPost('username');	
    		$password = $this->_request->getPost('password');	
    		
    		if(empty($firstname)){
    			$message.="Please provide first name.<br>";
    			$error = 1;
    		}
    		if(empty($lastname)){
    			$message.="Please provide last name.<br>";
    			$error = 1;
    		}
    		if(empty($email)){
    			$message.="Please provide email.<br>";
    			$error = 1;
    		}
    		if(!empty($email)){
    			if($commonobj->isvalidemail($email)==0){
    			$message.="Invalid email.<br>";
    			$error = 1;
    			}
    		}
    		if(empty($username)){
    			$message.="Please provide username.<br>";
    			$error = 1;
    		}
    		if(empty($password)){
    			$message.="Please provide password.<br>";
    			$error = 1;
    		}

    		if($error==0)
    		{

    			$Form_Data = array('username'=>$username,'password'=>$password,'fname'=>$firstname,'lname'=>$lastname,'email'=>$email);
		    	Zend_Loader::loadClass('Adminuser');
			    $ae_Data  = new Adminuser();
			    try 
			    { 
			   	   $where = "adminuserid = $id";
			    	$ae_Data->update($Form_Data,$where);	
			   		$message = "User successfully updated.";	
			   		$success = 1;		   		
			    }
			    catch (Zend_Exception $e)
			    {
			   		$error = 1;
			    	$message = "Some error occurred please try latter.";
			    	
			    }
    		}
    		
    		if($error==1){
    			
    		$this->view->firstname = $firstname;
    		$this->view->lastname = $lastname;
    		$this->view->email = $email;
    		$this->view->username = $username;
    		$this->view->password = $password;
    		
    		}
    		
    	}
    	
    	if($error==0) 
    	{
    		$query = "select * from adminusers where adminuserid=".$id;
    		$data = $db->fetchRow($query);
    		$this->view->firstname = $data['fname'];
    		$this->view->lastname = $data['lname'];
    		$this->view->email = $data['email'];
    		$this->view->username = $data['username'];
    		$this->view->password = $data['password'];
    		$this->view->id    = $data['adminuserid'];	
    	}
    	
    	$this->view->baseurl = $this->baseurl;
    	$this->view->message = $message;
    	$this->view->error = $error;
    	$this->view->success = $success;
    }
    
    function deleteAction()
    {
    	$id= $_GET['id'];
    	$where = "adminuserid='$id'";
    	Zend_Loader::loadClass('Adminuser');
		$ae_Data  = new Adminuser();
	    $ae_Data->delete($where);
	    
	    $this->_redirect('adminuser/view');	
    }
}
?>