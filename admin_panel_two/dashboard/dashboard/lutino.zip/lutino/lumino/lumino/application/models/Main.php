<?php

class Main {
	public function __construct()
	{
//		$this->_db = Zend_Registry::get('db');

		$bootstrap = Zend_Controller_Front::getInstance()->getParam("bootstrap");
		$resource = $bootstrap->getPluginResource('multidb');
		$this->db_slave = $resource->getDb('slave');

	}

	public function getAdminUserNameByID($userID)
	{
		$sql = "SELECT
					au.fname,
					au.lname
				FROM
					adminusers au
				WHERE
					au.adminuserid = $userID";

		$result = $this->db_slave->fetchAll($sql);

		return $result;
	}

}
