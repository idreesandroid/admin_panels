<?php
class ThankyouController extends Zend_Controller_Action
{
	private $baseurl; 
	function init()
  {
  	$this->baseurl = $this->_request->getBaseUrl();
  }
  
  function indexAction()
  {
  		global $db;
  		$aNamespace = new Zend_Session_Namespace('Default');
		$pixelcode = "";
		$redirecturl = "";
		
		$campaign    = $_GET['campaign'];  /*Campaignd code*/
		$postsetupid = $_GET['psid'];  /* Post setupid */
		$clientid    = $_GET['clid'];  /* clientid */
		$masteraff   = $_GET['masteraff'];  /* Master aff*/
		$success     = $_GET['success']; /* lead posted successfully */
		$leadid      = $_GET['leadid'];
		
		$passthru   = $leadid."|".$campaign;
		
	  if($success==md5("1")){
	  		   
  	   $res = $db->fetchRow("select campaignid from campaigns where campaign = '".$campaign."'");
  	   
		if(count($res) > 0)
		{
			$row = $db->fetchRow("select partialpixel,partialpixelpercentage,pixelcode from campaigns where campaignid='".$res['campaignid']."'");
			
			$campaignpixelcode = $row['pixelcode'];
			
			$percantage = $row['partialpixelpercentage'];
			$percantage = intval($percantage);
			if($percantage==25)
			$percantage = 4;
			elseif ($percantage==50)
			$percantage = 2;
			elseif ($percantage==33)
			$percantage = 3;
			
			if($row['partialpixel']==1)   /// it is a partial pixel campaign so fire 50% pixels ////
			{				
				$row = $db->fetchRow("select count(*) as totalsold from leadsold where 	campaign='".$campaign."' and masteraff='".$masteraff."'
				and solddate=curdate()");
				
				if($row['totalsold']%$percantage==0){
					
				 $campaignpixelcode = str_replace('{campaign}', $campaign,$campaignpixelcode);
				 $campaignpixelcode = str_replace('{passthru}', $passthru, $campaignpixelcode);
				 $campaignpixelcode = str_replace('{leadid}', $leadid, $campaignpixelcode);
				 $campaignpixelcode = str_replace('{rand}', rand(), $campaignpixelcode);
				 $pixelcode = $campaignpixelcode;

				}				
		   }
		   else {	
		   		 /* As it is not partial pixel campaign so fire 100% pixel*/			
				 $campaignpixelcode = str_replace('{campaign}', $campaign,$campaignpixelcode);
				 $campaignpixelcode = str_replace('{passthru}', $passthru, $campaignpixelcode);
				 $campaignpixelcode = str_replace('{leadid}', $leadid, $campaignpixelcode);
				 $campaignpixelcode = str_replace('{rand}', rand(), $campaignpixelcode);
				 $pixelcode = $campaignpixelcode;
		   }
		   
		  /* Insert new record into esigtracking table*/ 
		  if($aNamespace->url&&$success==md5("1")){	
		  	
		  Zend_Loader::loadClass('Esigtracking');
	   		$esigtracking = new Esigtracking();
	   		
	   		$esigdata = array(
	   		'postsetupid' =>$postsetupid,
	   		'clientid' =>$clientid,
	   		'redirectdate' => date("Y-m-d H:i:s"));
	   		$esigtracking->insert($esigdata);
		  }
		}
		}

	$this->view->baseurl = $this->baseurl;	
	$this->view->pixelcode = $pixelcode;
	$this->view->url = $aNamespace->url;	
  }
}
?>