<?php

class CampaignVendorStrategyPostAcquisition extends Zend_Db_Table_Abstract
{
	protected $_name = 'CampaignVendorStrategyPostAcquisitions';

	/**
	 * Finds the data by campaignID
	 */
	public function getVendorStrategyIDByCampaignIDAndVendorID($campaignID, $vendorID)
	{

		$sql = $this->select()
			->from($this->_name)
			->where($this->getAdapter()->quoteInto("campaignID = ?", $campaignID))
			->where($this->getAdapter()->quoteInto("vendorID = ?", $vendorID));

		$result = $this->fetchRow($sql);

		return $result > 0 ? $result['vendorStrategyID'] : FALSE;
	}
}
