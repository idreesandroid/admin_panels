<?php
/**
 * this class gets the leadID from Loan_App table using loan_number
 * NOTE: this class can now be renamed as it can be used by any table with
 * a valid loan_number. e.g. CallNotes
 */
class LeadMatchMaster
{
	/**
	 * @param integer  $loanNumber unique key for Loan_App table
	 */
	public function __construct($loanNumber)
	{
		$this->db = Zend_Registry::get('db');

		$this->loanNumber = $loanNumber;
	}

	/**
	 * main interface to this class
	 *
	 * @return integer
	 */
	public function execute()
	{
		if ($leadID = $this->getLeadIDFromLoanApp($this->loanNumber)) {
			return $leadID;
		}
		return 0;
	}

	/**
	 * @param string $loanNumber
	 * @return integer
	 */
	public function getLeadIDFromLoanApp($loanNumber)
	{
		$sql = "select leadID 
			FROM Loan_App 
			WHERE Appl_No = '" . $loanNumber . "' 
			LIMIT 1";
		$result = $this->db->fetchRow($sql);

		if ($result) {
			return $result['leadID'];
		}
		return FALSE;
	}
}
