<?php

class MultiVariateLeadRule extends Zend_Db_Table
{
	protected $_name = 'MultiVariateLeadRules';

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}


	public function generateRulesDataByMultiVariateLeadRulesetID($rulesetID)
	{
		$sql = $this->select()
			->where("multiVariateLeadRulesetID = " . $rulesetID)
			->order('priority asc');
		$rules = $this->fetchAll($sql)->toArray();

		$result = array();
		$iRowCounter = 0;

		$firstRule = array();
		$prevRule = array();
		foreach ($rules as $currentRule) {
			$iRowCounter++;

			if (sizeof($rules) == 1 && $iRowCounter == 1) {
				$result[] = array(
					'type' => 'rule',
					'id' => 'set' . $rulesetID .'-rule'. $currentRule['id'],
					'params' => $this->generateRuleParams($currentRule, $rulesetID),
					'priority' => $currentRule['priority']
				);
			}

			if (sizeof($rules) > 1) {
				if ($iRowCounter == 1) {
					$firstRule = $currentRule;
					continue;
				}
				if ($iRowCounter == 2) {
					$result[] = array(
						'type' => 'rule',
						'id' => 'set' . $rulesetID .'-rule'. $firstRule['id'],
						'params' => $this->generateRuleParams($firstRule, $rulesetID),
						'priority' => $firstRule['priority'],
					);
					$result[] = array(
						'type' => 'operator',
						'id' => 'set' . $rulesetID .'-rule'. $firstRule['id'] . '-set' . $rulesetID .'-rule'. $currentRule['id'] . '-ruleoperator',
						'operatorID' => $currentRule['logicalOperatorID'],
						'operatorName' => $this->getLogicalOperatorNameByID($currentRule['logicalOperatorID'])
					);
					$result[] = array(
						'type' => 'rule',
						'id' => 'set' . $rulesetID .'-rule'. $currentRule['id'],
						'params' => $this->generateRuleParams($currentRule, $rulesetID),
						'priority' => $currentRule['priority']
					);
				} else {
					$result[] = array(
						'type' => 'operator',
						'id' => 'set' . $rulesetID .'-rule'. $prevRule['id'] . '-set' . $rulesetID .'-rule'. $currentRule['id'] . '-ruleoperator',
						'operatorID' => $currentRule['logicalOperatorID'],
						'operatorName' => $this->getLogicalOperatorNameByID($currentRule['logicalOperatorID'])
					);
					$result[] = array(
						'type' => 'rule',
						'id' => 'set' . $rulesetID .'-rule'. $currentRule['id'],
						'params' => $this->generateRuleParams($currentRule, $rulesetID),
						'priority' => $currentRule['priority']
					);
				}
			}

			$prevRule = $currentRule;
		}
		return $result;
	}

	private function generateRuleParams($rule, $rulesetID) {
		$ruleID = $rule['id'];
		$params[] = array(
			'id'=>"set$rulesetID-rule$ruleID-vendorparams",
			'name' => 'leadRequestParameter',
			'leadRequestParameterID' => $rule['leadRequestParameterID'],
			'leadRequestParameterName' => $this->getGetVendorResponseParameterNameByID($rule['leadRequestParameterID'])
		);

		$params[] = array(
			'id'=>"set$rulesetID-rule$ruleID-operators",
			'name' => 'comparisonOperator',
			'comparisonOperatorID' => $rule['comparisonOperatorID'],
			'comparisonOperatorName' => $this->getComparisonOperatorNameByID($rule['comparisonOperatorID'])
		);

		$params[] = array(
			'id'=>"set$rulesetID-rule$ruleID-paramvalue",
			'name' => 'value',
			'valueName' => "set$rulesetID-rule$ruleID-paramValue",
			'value' => $rule['value']
		);


		return $params;
	}

	public function getComparisonOperatorNameByID($operatorID)
	{
		if (!$operatorID) {
			return null;
		}
		$sql = "SELECT
					*
				FROM
					ComparisonOperators co
				WHERE
					co.id = $operatorID";

		$operator = $this->db->fetchRow($sql);

		return $operator['name'];
	}

	public function getLogicalOperatorNameByID($operatorID)
	{
		if (!$operatorID) {
			return null;
		}

		$sql = "SELECT
					*
				FROM
					LogicalOperators lo
				WHERE
					lo.id = $operatorID";

		$operator = $this->db->fetchRow($sql);
		return $operator['name'];
	}

	public function getGetVendorResponseParameterNameByID($responseParamID)
	{
		if (!$responseParamID) {
			return null;
		}
		$sql = "SELECT
					*
				FROM
					LeadRequestParameters vrp
				WHERE
					vrp.id = $responseParamID";

		$parameter = $this->db->fetchRow($sql);
		return $parameter['name'];
	}

	/**
	 * Updates or inserts a row
	 */
	public function upsert($id, $insertData)
	{
		$existingRow = $this->findByID($id);

		if($existingRow) {
			$this->update($insertData, $this->_db->quoteInto("id = ?", $existingRow['id']));
			return $id;
		}
		else {
			return $this->insert($insertData);
		}
	}

	public function deleteByID($ruleID)
	{
		$existingRow = $this->findByID($ruleID);
		if ($existingRow) {
			$this->delete('id='. $ruleID);
		}
	}

	public function deleteByRulesetID($rulesetId)
	{
		$existingRow = $this->findByRulesetID($rulesetId);
		if ($existingRow) {
			$this->delete('multiVariateLeadRulesetID='. $rulesetId);
		}
	}

	public function findByRulesetID($rulesetId) {
		$sql = $this->select()
			->where("multiVariateLeadRulesetID = " . $rulesetId);
		return $this->fetchRow($sql);
	}

	public function findByID($id) {
		$sql = $this->select()
			->where("id = " . $id);
		return $this->fetchRow($sql);
	}

	public function deleteAllRulesByMultiVariateID($multiVariateID) {
		$MultiVariateLeadRuleset = new MultiVariateLeadRuleset();
		$rulesets = $MultiVariateLeadRuleset->getAllByMultiVariateID($multiVariateID);

		if ($rulesets) {
			foreach ($rulesets->toArray() as $ruleset) {
				if ($this->hasRulesWithMultiVariateLeadRulesetID($ruleset['id'])) {
					$this->delete('multiVariateLeadRulesetID='. $ruleset['id']);
				}
			}
		}
	}

	public function hasRulesWithMultiVariateLeadRulesetID($multiVariateLeadRulesetID) {
		$sql = $this->select()
			->from($this->_name, array("count(*) AS amount"))
			->where($this->_db->quoteInto($this->_name . ".multiVariateLeadRulesetID = ?", $multiVariateLeadRulesetID));

		$result = $this->_db->fetchRow($sql);
		if ($result['amount'] < 1) {
			return FALSE;
		}
		return TRUE;

	}

	public function getAllByMultiVariateLeadRulesetID($rulesetID) {
		$sql = $this->select()
			->where("multiVariateLeadRulesetID = " . $rulesetID)
			->order('priority asc');
		return $this->fetchAll($sql);
	}

	public function deleteRemovedRules($rulesetID, $ruleIds, $rulesOperators) {
		$rules = $this->getAllByMultiVariateLeadRulesetID($rulesetID);
		$firstRowDeleted = false;
		if ($rules) {
			$rules = $rules->toArray();
			for ($i = 0; $i < count($rules); $i++) {
				if (!in_array($rules[$i]['id'], $ruleIds)) {
					if ($i==0) {
						$firstRowDeleted = true;
					}

					$this->deleteByID($rules[$i]['id']);

					if (!$firstRowDeleted && isset($rules[$i + 1])) {
						$nextID = $rules[$i + 1]['id'];
						if (isset($rules[$i - 1])) {
							$prevID = $rules[$i - 1]['id'];
							$value = $this->findOperatorValueByRuleID($rulesOperators, $prevID);
							$updateData = array('logicalOperatorID' => $value);
							$this->update($updateData, $this->_db->quoteInto("id = ?", $nextID));
						}
					}

					if ($firstRowDeleted && isset($rules[$i + 1])) {
						$updateData = array('logicalOperatorID' => null,
							'referrerVariateRuleID' => null);
						$this->update($updateData, $this->_db->quoteInto("id = ?", $rules[$i + 1]['id']));
					}
				}
			}
		}
	}

	public function findOperatorValueByRuleID($rulesetOperators, $id) {
		foreach ($rulesetOperators as $operator) {
			$result = explode('-', $operator['id']);
			$rulesetIDOne = $result[0];
			$ruleseIDOne = $result[1];
			$rulesetIDTwo = $result[2];
			$ruleIDTwo = $result[3];

			if ('rule'.$id == $ruleseIDOne) {
				return $operator['value'];
			}
		}
		return null;
	}
}
