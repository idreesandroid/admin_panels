<?php

class StoreIDReportsDataModel {

    private $db_slave;

	public function initSettingsForSlaveDB () {

		$config = Zend_Registry::get("config");

		$this->db_slave = Zend_Db::factory($config->resources->multidb->slave->adapter, $config->resources->multidb->slave->toArray());
	}

    /**
    *
    * Gets subid report data
    *
    * @param	startDate	date	start of date range
    * @param	endDate		date	end of date range
    * @param	startTime	date	start time of date range
    * @param	endTime	date	start   end time of date range
    * @param	$affiliateID	string	affiliate id to filter data for
    * @param	$campaignID	string	start campaign id to filter data for
    *
    * @return	array	array of report data
    */
    public function getReportData($startDate, $endDate, $startTime, $endTime, $affiliateID, $campaignID) {

        if ($affiliateID != "") {
            $affiliateIDStatement = "AND affiliateID = '$affiliateID'";
        }
        if ($campaignID != "") {
            $campaignIDStatement = "AND campaign = '$campaignID'";
        }

        $sql = "Select count(1) attempted,Leads.storeID,IFNULL(LP.purchased,0) purchased,
                FORMAT((IFNULL(LP.purchased,0)/count(1))*100,2) purchaserate
                FROM Leads
                LEFT JOIN
                (
                      Select count(*) purchased,storeID
                      FROM Leads
                      where originaldate >= '$startDate' AND originaldate <= '$endDate'
                      AND originaltime >= '$startTime' AND originaltime <= '$endTime'
                      AND leadsold = 1
                      {$affiliateIDStatement}
                      {$campaignIDStatement}
                      group by storeID
                ) LP
                ON Leads.storeID = LP.storeID
                where originaldate >= '$startDate' AND originaldate <= '$endDate'
                AND originaltime >= '$startTime' AND originaltime <= '$endTime'
                {$affiliateIDStatement}
                {$campaignIDStatement}
                group by Leads.storeID";

        $result = $this->db_slave->fetchAll($sql);

        $reportDataArray = array();
        $reportDataArray['data'] = array();
        foreach($result as $data) {

    	    $tuple = array('storeid' => $data['storeID'],'attempted' => $data['attempted'],
    			   'purchased' => $data['purchased'],'purchaserate' => $data['purchaserate']);
    	    $reportDataArray['data'][] = $tuple;
        }

        return $reportDataArray;
    }

    /**
    *
    * Gets data fro a storeid
    *
    * @param	storeID		string	storeid to get data for
    * @param	startDate	date	start of date range
    * @param	endDate		date	end of date range
    * @param	startTime	date	start time of date range
    * @param	endTime	date	date   end time of date range
    *
    * @return	array	array of report data
    */
    public function getReportDataByStoreID($storeID, $startDate, $endDate, $startTime, $endTime, $affiliateID, $campaignID) {

        if ($affiliateID != "") {
            $affiliateIDStatement = "AND affiliateID = '$affiliateID'";
        }
        if ($campaignID != "") {
            $campaignIDStatement = "AND campaign = '$campaignID'";
        }

    	$sql = "Select count(*) attempted,Leads.state, IFNULL(LP.purchased,0) purchased,
    	    FORMAT((IFNULL(LP.purchased,0)/count(*))*100,2) purchaserate
    	    FROM Leads
    	    LEFT JOIN (Select count(*) purchased,state
    		    FROM Leads
    		    where originaldate >= '$startDate' AND originaldate <= '$endDate'
    		    AND originaltime >= '$startTime' AND originaltime <= '$endTime'
    		    AND storeID = '$storeID'
    		    AND leadsold = 1
    		    {$affiliateIDStatement}
    		    {$campaignIDStatement}
    		    group by state ) LP
    	    on Leads.state = LP.state
    	    where originaldate >= '$startDate' AND originaldate <= '$endDate'
    	    AND originaltime >= '$startTime' AND originaltime <= '$endTime'
    	    AND Leads.storeID = '$storeID'
    	    {$affiliateIDStatement}
    	    {$campaignIDStatement}
    	    group by state";

        $result = $this->db_slave->fetchAll($sql);

    	$reportDataArray = array();
    	$reportDataArray['data'] = array();
    	foreach($result as $data) {

    	    $tuple = array('attempted' => $data['attempted'], 'state' => $data['state'], 'purchased' => $data['purchased'],
    			   'purchaserate' => $data['purchaserate']);
    	    $reportDataArray['data'][] = $tuple;
    	}

        return $reportDataArray;
    }


    /**
     * Gets campaigns list of all affiliates
     *
     * @return  array	array of all affiliates
     */
    public function getAllAffiliates()
    {
        $sql = "SELECT
					a.id,
					a.masteraff,
					a.company
				FROM
					Affiliates a
				WHERE
					a.active = 1";

        $result = $this->db_slave->fetchAll($sql);
        if ($result) {
            $affiliates = array();
            foreach ($result as $value) {
                $affiliates[$value['id']] = $value['masteraff'];
            }
            return $affiliates;
        }
        return array();
    }
}