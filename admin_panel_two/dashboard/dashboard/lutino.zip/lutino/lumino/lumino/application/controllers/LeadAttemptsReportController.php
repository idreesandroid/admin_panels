<?php

class LeadAttemptsReportController extends Zend_Controller_Action
{
	private $baseurl;

	function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if (!$AdminNameSpace->userid) {
			$this->_redirect('index/login');
		}
		$config = Zend_Registry::get('config');

		if (isset($config->leftMenu)) {
		    $customMenus = $config->leftMenu->toArray();
		}
		else {
		    $customMenus = array();
		}

		if (!in_array("showLeadAttemptsReport", $customMenus)) {
		    $this->_redirect('main/index');
		}
		$this->baseurl = $this->_request->getBaseUrl();
	}

	public function indexAction()
	{
		$customerType = ($this->_request->customertype) ? $this->_request->customertype : "returning";
		$this->view->fromDate = date('m/d/Y');
		$this->view->toDate = date('m/d/Y');
		$this->view->timeStart = "00:00:00";
		$this->view->timeEnd = "23:59:59";
		$leadDispositionCodes = new LeadDispositionCodes();
		$this->view->dispositionCodes = $leadDispositionCodes->fetchAll();
		$this->view->customerType = $customerType;
	}

	public function updateLeadDispositionAction() {

	    $this->_helper->viewRenderer->setNoRender();

	    $email = $this->_request->getPost('email');
	    $dispositionCode = $this->_request->getPost('code');

	    $leadDispositionCodes = new LeadDispositionCodes();
	    $codeID = $leadDispositionCodes->getIDByCode($dispositionCode);

	    // Check if valid code is posted?
	    if ($codeID != NULL) {
    		$LECustomerDisposition = new LECustomerDisposition();
    		$LECustomerDisposition->insert(array('email' => $email, 'dispositionCodeID' => $codeID));
    		echo '{"status":"ok"}';
	    }
	    else {
	        echo '{"status":"error"}';
	    }
	}

	public function getdataAction()
	{
		$this->_helper->viewRenderer->setNoRender();

		$offset = ($this->_request->offset) ? $this->_request->offset : 0;
		$limit  = ($this->_request->limit) ? $this->_request->limit : 100;
		$sortBy = ($this->_request->sort) ? $this->_request->sort : "email";
		$sortOrder = ($this->_request->order) ? $this->_request->order : "ASC";

		$customerType = ($this->_request->customertype) ? $this->_request->customertype : 'new';

		$fromDate = ($this->_request->fromDate) ?
			date('Y-m-d', strtotime($this->_request->fromDate)) : date('Y-m-d');
		$toDate = ($this->_request->toDate) ?
			date('Y-m-d', strtotime($this->_request->toDate)) : date('Y-m-d');

		$fromTime = ($this->_request->fromTime) ?
			date('Y-m-d', strtotime($this->_request->fromTime)) : "00:00:00";

		$toTime = ($this->_request->toTime) ?
			date('Y-m-d', strtotime($this->_request->toTime)) : "23:59:59";

		$leadsAttempts = new LeadsAttempts();

		$leadsCount = 	$leadsAttempts->getTotalLeadsAttempts($customerType,$fromDate,$toDate,$fromTime,$toTime);
		$leadsData = $leadsAttempts->getLatestUniqueLeadAttemptsByEmail($customerType,$fromDate,$toDate,$fromTime,$toTime,$sortBy,$sortOrder,$offset,$limit);

		$data = array('total' => $leadsCount['total']);
		$data['rows'] = array();

		foreach($leadsData as $leadData) {

			$totalTime = "";
			if (!empty($leadData['endTime'])) {

				$endTime = new DateTime($leadData['endTime']);
				$originalTime = new DateTime($leadData['originaltime']);
				$interval = $endTime->diff($originalTime);
				$totalTime = $interval->format('%H:%I:%S');
			}
			$tuple = array();
			$tuple['id'] = $leadData['id'];
			$tuple['datetime'] = $leadData['originaldate']." ".$leadData['originaltime'];
			$tuple['storeID'] = $leadData['storeID'];
			$tuple['campaign'] = $leadData['campaign'];
			$tuple['email'] = $leadData['email'];
			$tuple['state'] = $leadData['state'];
			$tuple['hphone'] = $leadData['hphone'];
			$tuple['endtime'] = $leadData['endTime'];
			$tuple['postsetup'] = (empty($leadData['postsetupid'])) ? "" : $leadData['postSetupTitle']."(".$leadData['postsetupid'].")";
			$tuple['cost'] = $leadData['cost'];
			$tuple['price'] = $leadData['price'];
			$tuple['originated'] = $leadData['originated'];
			$tuple['totaltime'] = $totalTime;
			$tuple['sold'] = ($leadData['leadsold'] == 1) ? 'Yes' : 'No';
			$tuple['dispositioncode'] = $leadData['code'];
 			$data['rows'][] = $tuple;
		}

		echo json_encode($data);
	}
}

?>
