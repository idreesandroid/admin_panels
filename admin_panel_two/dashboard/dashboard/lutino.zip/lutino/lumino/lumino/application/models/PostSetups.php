<?php

class PostSetups extends BaseZendDbTable
{
	protected $_name = 'PostSetups';

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}

	// TODO: move this to a facade as it joins multiple tables
	public function findByActive()
	{
		$sql = "select * from PostSetups ps
			join ClientPostSetups cps on cps.postSetupID = ps.id
			left join Clients c on c.id = cps.clientID
			where ps.active = 1 AND c.active = 1";
		$results = $this->db->fetchAll($sql);
		return $results;
	}

	public function getPostSetupType($postSetupID)
	{
		$postSetupData = $this->getClientPostSetupByID($postSetupID);
		if($postSetupData)
			return "Client";
		$postSetupData = $this->isVendorPostSetup($postSetupID);
		if($postSetupData)
			return "Vendor";
		return;
	}
	public function getPostSetupData($postSetupID)
	{
		$postSetupData = $this->getClientPostSetupByID($postSetupID);
		if($postSetupData)
		{
			return $postSetupData;
		}

		$postSetupData = $this->getVendorPostSetupByID($postSetupID);
		if($postSetupData)
		{
			return $postSetupData;
		}
		return;
	}

	public function getAllClientPostSetups($productCode=NULL)
	{
		$select = $this->select();
		$select->setIntegrityCheck(false);
		$select->from("PostSetups",array("*","postSetupID"=>"id"));
		$select->join("ClientPostSetups","PostSetups.id = ClientPostSetups.postSetupID",
										array("monetaryValue"=>"markupValue","companyID"=>"clientID","productCode"));
		$select->join("Clients","ClientPostSetups.clientID = Clients.id","company");
		if (! is_null($productCode ))
		{
			$select->where("ClientPostSetups.productCode = '$productCode'");
		}
		return $this->fetchAll($select);
	}

	public function getClientPostSetupByID($postSetupID,$productCode=NULL)
	{
		if ( is_numeric($postSetupID ))
		{
			$select = $this->select();
			$select->setIntegrityCheck(false);
			$select->from("PostSetups",array("*","postSetupID"=>"id"));
			$select->join("ClientPostSetups","PostSetups.id = ClientPostSetups.postSetupID",
											array("monetaryValue"=>"markupValue","companyID"=>"clientID","markupvaluetype"=>"markupvaluetype","productCode"));
			$select->join("Clients","ClientPostSetups.clientID = Clients.id",array("company", "clientActive"=>"active"));
			$select->where("PostSetups.id = $postSetupID");
			if (! is_null($productCode ))
			{
				$select->where("ClientPostSetups.productCode = '$productCode'");
			}
			return $this->fetchRow($select);
		}
	}

	public function getClientPostSetupStatuses($productCode)
	{
		$select = $this->select();
		$select->setIntegrityCheck(false);
		$select->from("PostSetups",array("*","pactive"=>"active","postSetupID"=>"id"));
		$select->join("ClientPostSetups","ClientPostSetups.postSetupID = PostSetups.id",array("monetaryValue"=>"markupValue","productCode"));
		$select->join("Clients","ClientPostSetups.clientID = Clients.id",array("*","xactive"=>"active","companyID"=>"id"));
		$select->where("ClientPostSetups.productCode='$productCode'");
		$select->order("priority");
		return $this->fetchAll($select);
	}

	public function getAllVendorPostSetups($productCode=NULL)
	{
		$select = $this->select();
		$select->setIntegrityCheck(false);
		$select->from("PostSetups",array("*","postSetupID"=>"id"));
		$select->join("VendorPostSetups","PostSetups.id = VendorPostSetups.postSetupID",
										array("monetaryValue"=>"cost","companyID"=>"vendorID","productCode"));
		$select->join("Vendors","VendorPostSetups.vendorID = Vendors.id","company");
		if (! is_null($productCode ))
		{
			$select->where("ClientPostSetups.productCode = '$productCode'");
		}
		return $this->fetchAll($select);
	}

	public function getVendorPostSetupByID($postSetupID=NULL,$productCode=NULL)
	{
		if (is_numeric($postSetupID ))
		{
			$select = $this->select();
			$select->setIntegrityCheck(false);
			$select->from("PostSetups",array("*","postSetupID"=>"id"));
			$select->join("VendorPostSetups","PostSetups.id = VendorPostSetups.postSetupID",
										array("monetaryValue"=>"cost","companyID"=>"vendorID","productCode"));
			$select->join("Vendors","VendorPostSetups.vendorID = Vendors.id","company");
			$select->where("PostSetups.id = $postSetupID");
			if (! is_null($productCode ))
			{
				$select->where("ClientPostSetups.productCode = '$productCode'");
			}
			return $this->fetchRow($select);
		}
	}


	public function isVendorPostSetup($postSetupID=NULL,$productCode=NULL)
	{
		if (is_numeric($postSetupID ))
		{
			$select = $this->select();
			$select->setIntegrityCheck(false);
			$select->from("PostSetups",array("*","postSetupID"=>"id"));
			$select->join("VendorPostSetups","PostSetups.id = VendorPostSetups.postSetupID",
				array("monetaryValue"=>"cost","companyID"=>"vendorID","productCode"));
			$select->join("Vendors","VendorPostSetups.vendorID = Vendors.id","company");
			$select->where("PostSetups.id = $postSetupID");
			if (! is_null($productCode ))
			{
				$select->where("ClientPostSetups.productCode = '$productCode'");
			}
			return $this->fetchRow($select);
		}
	}

	public function getVendorPostSetupStatuses($productCode)
	{
		$select = $this->select();
		$select->setIntegrityCheck(false);
		$select->from("PostSetups",array("*","pactive"=>"active","postSetupID"=>"id"));
		$select->join("VendorPostSetups","VendorPostSetups.postSetupID = PostSetups.id",array("monetaryValue"=>"cost","productCode"));
		$select->join("Vendors","VendorPostSetups.vendorID = Vendors.id",array("*","xactive"=>"active","companyID"=>"id"));
		//$select->where("VendorPostSetups.productCode='$productCode'");
		$select->order("priority");
		return $this->fetchAll($select);
	}

	public function findById($id)
	{
		$result = $this->fetchRow($this->select()->where("id = $id"));
		return $result;
	}
}

?>
