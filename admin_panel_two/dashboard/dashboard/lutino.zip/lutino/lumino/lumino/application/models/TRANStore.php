<?php

/**
 * TRAN Store class 
 * processes a lead application and posts to the clients
 *
 * @category    Table 
 * @package     Zend_Db_Table      
 * @subpackage  TRANStore 
 * @author      Andrew Ahn <andrewa@mediaenvy.com>
 */
class TRANStore extends Zend_Db_table
{

	protected $_name = "TRANStores";

}
?>
