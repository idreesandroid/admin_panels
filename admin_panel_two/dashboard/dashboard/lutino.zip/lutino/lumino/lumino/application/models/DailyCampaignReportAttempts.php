<?php

class DailyCampaignReportAttempts extends Zend_Db_Table {

    private $db_slave;

    public function initSettingsForSlaveDB () {
        $config = Zend_Registry::get("config");
        $this->db_slave = Zend_Db::factory($config->resources->multidb->slave->adapter, $config->resources->multidb->slave->toArray());
    }

    public function getLeadsAttemtCampaigns($customerType,$startDate, $endDate, $startTime, $endTime) {

        if ($customerType == "new") {
            $filter = " (rc.leadID) IS NULL ";
        }
        else if ($customerType == 'returning') {
            $filter = " (rc.leadID) IS NOT NULL ";
        }

        $sql = "SELECT DISTINCT(l.campaign) FROM Leads l
        LEFT JOIN ReturningCustomers rc ON l.id = rc.leadID
        WHERE
        l.originaldate >= '$startDate' AND l.originaldate <= '$endDate'
        AND
        l.originaltime >= '$startTime' AND l.originaltime <= '$endTime'
        AND $filter";

        return $this->db_slave->fetchAll($sql);
    }
}