<?php

/**
 * this table handles credentials for DecisionLogic
 */
class DecisionLogicCredentials extends Zend_Db_Table
{
	protected $_name = 'DecisionLogicCredentials';

	const VENDOR_ID = 24;

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}

	public function getDefault()
	{
		$row = $this->fetchRow("isDefault = 1");
		if ($row)
			$row = $row->toArray();

		return($row);
	}

	/**
	 * Updates or inserts a row
	 */
	public function upsert($vendorStrategyID, $insertData)
	{
		$existingRow = $this->findByID($vendorStrategyID);

		if($existingRow) {
			$this->update($insertData, $this->_db->quoteInto("id = ?", $existingRow['id']));
			return $existingRow['id'];
		}
		else {
			return $this->insert($insertData);
		}
	}

	public function findByID($vendorStrategyID) {
		$DecisionLogicCredentialsVendorStrategies = new DecisionLogicCredentialsVendorStrategies();
		$result = $DecisionLogicCredentialsVendorStrategies->findByVendorStrategyID($vendorStrategyID);
		if ($result['decisionLogicCredentialID']) {
			$sql = $this->select()
				->where("id = " . $result['decisionLogicCredentialID']);
			return $this->fetchRow($sql);
		}
	}
}

