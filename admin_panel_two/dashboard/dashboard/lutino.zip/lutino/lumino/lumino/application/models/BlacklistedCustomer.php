<?php
class BlacklistedCustomer extends Zend_Db_Table
{
	protected $_name = 'BlacklistedCustomers';

	public function init()
    	{
        	$this->db = Zend_Registry::get('db');
    	}

	/**
	 * checks to see if this customer is already blacklisted
	 *
	 * @param integer $ssn
	 * @param string $email
	 * @return boolean
	 */
	public function exists($ssn = NULL, $email = NULL)
	{
		if (!$ssn) {
			$q = "email = '$email'";
		} elseif (!$email) {
			$q = "ssn = '$ssn'";
		} else {
			$q = "ssn = '$ssn' AND email = '$email'";
		}
		$result = $this->fetchRow($q);

		if (count($result) > 0) {
			return TRUE;
		}
		return FALSE;
	}

	public function getTotalCustomers($search = "") {
		
		$searchSql = "";
		if (!empty($search)) {
			$searchSql = " where email like '%$search%' OR ssn like '%$search%'";
		}
		$sql = "select count(*) as cnt from BlacklistedCustomers
		$searchSql";
		return $this->db->fetchRow($sql);
	}
	
	public function getCustomers($search = "", $offset = 0, $limit = 100, $sortBy = 'email', $sortOrder = 'ASC')
	{
		$searchSql = "";
		if (!empty($search)) {
			$searchSql = " where email like '%$search%' OR ssn like '%$search%'";
		}
		$sql = "select * from BlacklistedCustomers
		$searchSql
		order by $sortBy $sortOrder
		limit $offset,$limit";
		return $this->db->fetchAll($sql);
	}
	
	/**
	 * Updates or inserts a row
	 */
	public function upsert($insertData)
	{
		//$existingRow = $this->findBySSNAndEmail($insertData['ssn'], $insertData['email']);
		//if($existingRow) {
		//	return $existingRow['id'];
		//}
		//else {
			return $this->insert($insertData);
		//}
	}
	
	/**
	 * Finds record beased on ssn and email
	 *
	 * @param integer $ssn
	 * 
	 * @param string $email
	 * 
	 * @return matching record row
	 */
	public function findBySSNAndEmail($ssn = NULL, $email = NULL) {
		
		if (!$ssn) {
			$q = "email = '$email'";
		} elseif (!$email) {
			$q = "ssn = '$ssn'";
		} else {
			$q = "ssn = '$ssn' AND email = '$email'";
		}
		$result = $this->fetchRow($q);
		return $result;
	}
}
