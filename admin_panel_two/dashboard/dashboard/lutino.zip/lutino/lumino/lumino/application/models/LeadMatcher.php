<?php
/**
 * this class matches the most likely leadID, based off a custID and a date
 */
class LeadMatcher
{
	/**
	 * @array Sovereign advance clientIDs (used for joining on PostLogs table)
	 */
	protected $clientIDs = array(72,76);

	/**
	 * @param integer $custID
	 * @param string $dateTime e.g. '2013-05-01 09:30:00'
	 */
	public function __construct($custID, $dateTime)
	{
		$this->db = Zend_Registry::get('db');

		$this->custID = $custID;
		$this->dateTime = $dateTime;
	}

	/**
	 * main interface to this class
	 *
	 * @return integer the leadID or NULL
	 */
	public function execute()
	{
		// get all possible Loan Applications 
		// that are associated with this Cust_ID. 
		// (we need Loan Application date to match with the Lead date)
		if (!$loanApps = $this->getLoanAppsByCustID($this->custID)) {
			return NULL;
		}

		// lets choose the Loan_App.ApplicationDate closest to our dateTime
		if (!$loanApp = $this->chooseLoanApp($loanApps)) {
			return NULL;
		}

		// lets now get all possible leads via CashData.ssn
		if (!$leads = $this->getLeadsBySsn($loanApp['Cust_SSN'])) {
			return NULL;
		}

		// if multiple leads found, we must choose correct one 
		// using Leads.originaldate/originaltime and Loan_App.ApplicationDate
		$result = $this->chooseLead($leads, $loanApp['ApplicationDate']);

		return $result;
	}

	public function getLoanAppsByCustID($custID)
	{
		$sql = "select Cust_ID,
			Cust_SSN,
			ApplicationDate 
			FROM Loan_App 
			WHERE Cust_ID = '" . $custID . "'";
		$result = $this->db->fetchAll($sql);

		return $result;
	}

	/**
	 * NOTE: we will presume socketTimeouts were accepted by TRAN.
	 * ie postResponse = ''
	 * 
	 * @return array
	 */
	public function getLeadsBySsn($ssn)
	{
		$sql = "select l.id leadID,
			l.originaldate,
			l.originaltime,
			CONCAT_WS(' ', l.originaldate, l.originaltime) as leadDateTime,
			l.leadsold,
			cd.ssn 
			FROM Leads l 
			join PostLogs pl on l.id = pl.leadID 
			join CashData cd on l.id = cd.leadID 
			WHERE cd.ssn = '" . $ssn . "' 
			and (pl.postResponse = '' OR pl.postStatus = 'accept') 
			and pl.clientID IN (" . implode(",", $this->clientIDs) . ");";
		$result = $this->db->fetchAll($sql);

		return $result;
	}

	/**
	 * if multiple leads found, we must choose correct one 
	 * using Leads.originaldate/originaltime and Loan_App.ApplicationDate
	 *
	 * @param array $leads
	 * @param string $loanAppDate 'Y-m-d H:i:s'
	 *
	 * @return integer leadID
	 */
	public function chooseLead($leads, $loanAppDate)
	{
		$chosenDate = NULL;
		$chosenLeadID = NULL;

		foreach ($leads as $lead)
		{
			if (strtotime($lead['leadDateTime']) <= 
				strtotime($this->fixDate($loanAppDate)))
			{
				if (!$chosenDate)
				{
					$chosenDate 	= $lead['leadDateTime'];
					$chosenLeadID 	= $lead['leadID'];
					continue;
				}

				// we only care about largest date
				if (strtotime($lead['leadDateTime']) >= strtotime($chosenDate))
				{
					$chosenDate 	= $lead['leadDateTime'];
					$chosenLeadID 	= $lead['leadID'];
				}
			}
		}

		return $chosenLeadID;
	}

	/**
	 * if multiple Loan_Apps found, we must choose correct one 
	 * using dateTime
	 *
	 * @param array $loanApps
	 * @return array
	 */
	public function chooseLoanApp($loanApps)
	{
		// only one match found. this must be it!
		if (count($loanApps) == 1) {
			return $loanApps[0];
		}

		$chosenLoanApp = array();

		foreach ($loanApps as $loanApp)
		{
			// has to be a valid leadtime (earlier than dateTime)
			if (strtotime($loanApp['ApplicationDate']) <= 
				strtotime($this->fixDate($this->dateTime)))
			{
				if (empty($chosenLoanApp))
				{
					$chosenLoanApp = $loanApp;
					continue;
				}

				// we only care about largest date
				if (strtotime($loanApp['ApplicationDate']) > 
					strtotime($chosenLoanApp['ApplicationDate']))
				{
					$chosenLoanApp = $loanApp;
				}
			}
		}

		return $chosenLoanApp;
	}

	/**
	 * fastforward datetime 1min as we are finding small offsets in time (usually seconds)
	 *
	 * @param string $date 'Y-m-d H:i:s'
	 * @return string datetime
	 */
	public function fixDate($date)
	{
		$correctDate = $date;

		$correctDate = date('Y-m-d H:i:s', strtotime('+1 minutes', strtotime($correctDate)));	
		return $correctDate;
	}
}
