<?php

class PDSPaymentCredentialVendorStrategy extends Zend_Db_Table
{
	protected $_name = 'PDSPaymentCredentialsVendorStrategies';

	/**
	 * Updates or inserts a row
	 */
	public function upsert($vendorStrategyID, $insertData)
	{
		$existingRow = $this->findByVendorStrategyID($vendorStrategyID);

		if($existingRow) {
			$updatedID = $this->update($insertData, $this->_db->quoteInto("id = ?", $existingRow['id']));
			return $updatedID;
		}
		else {
			return $this->insert($insertData);
		}
	}

	public function findByVendorStrategyID($vendorStrategyID) {
		$sql = $this->select()
			->where("vendorStrategyID = " . $vendorStrategyID);
		return $this->fetchRow($sql);
	}
}
