<?php
class SnoozeLogsEmailer {

    public function __construct()
    {
        $this->config = Zend_Registry::get('config');
    }

    /**
     * @param string $body email body
     * return void
     */
    public function execute($body)
    {
        $mail= new Mail();
        $mail->setBody($body);
        $mail->setSubject('Snooze/Resume Alert For '.$_SERVER['HTTP_HOST']);
        $mail->setToEmail('tech@lead-envy.com', 'Snooze/Resume Alert');
        $mail->send();
    }
}
