<?php

class DecisionLogicStrategyRulesets extends Zend_Db_Table
{
	protected $_name = 'DecisionLogicStrategyRulesets';

	/* function buildRuleset Build ruleset and rules for each ruleset and insert to DB
	 * @param int $variateID
	 * @param string $ruleSets Json encoded rulesets string
	 */
	public function buildRuleset($campaignID,$ruleSets)
	{
	    $ruleSets = json_decode($ruleSets);
	    $prevRulesetID = null;

	    if (count($ruleSets) > 0) {

	        $DecisionLogicStrategies = new DecisionLogicStrategies();
	        $rule =  $ruleSets[0];
	        $strategyName = $rule->strategyName;

	        $insetData = array('campaignID' => $campaignID,'name' => $strategyName);
	        $strategyID = $DecisionLogicStrategies->insert($insetData);

    	    foreach ($ruleSets as $ruleSet) {

    	        $ruleSetName = $ruleSet->ruleSetName;
    	        $ruleSetStoreID = $ruleSet->ruleSetStoreID;
    	        $ruleSetPriority = $ruleSet->ruleSetPriority;

    	        $rulesVendorParams = $ruleSet->rulesVendorParams;
    	        $rulesVendorParamsValues = $ruleSet->rulesVendorParamsValues;
    	        $rulesVendorParamsOperator = $ruleSet->rulesVendorParamsOperator;
    	        $rulesOperators = $ruleSet->ruleOperators;

    	        $insertData = array(
    	            'DecisionLogicStrategyID' => $strategyID,
    	            'name' => $ruleSetName,
    	            'storeID' => $ruleSetStoreID,
    	            'priority' => $ruleSetPriority,
    	            'referrerDecisionLogicStrategyRulesetID' => $prevRulesetID
    	        );

    	        $rulesetIDFromDB = $this->insert($insertData);

    	        if ($rulesetIDFromDB) {
    	            $this->saveRuleByRulesetID($rulesetIDFromDB, $rulesVendorParams, $rulesVendorParamsOperator, $rulesVendorParamsValues, $rulesOperators);
    	        }
    	        $prevRulesetID = $rulesetIDFromDB;
    	    }
	    }
	}

	/* function saveRuleByRulesetID Save decision logic rules to DB
	 *
	 * @param int $ruleSetID
	 * @param array $rulesVendorParams  vendor parameters
	 * @param array $rulesVendorParamsOperator vendor param comparision operator
	 * @param array $rulesVendorParamsValues vendor rule passing value
	 * @param array $rulesOperators operators between rules
	 */
	public function saveRuleByRulesetID($ruleSetID,$rulesVendorParams,$rulesVendorParamsOperator,$rulesVendorParamsValues,$rulesOperators) {

	    $prevRuleID = null;
	    $priority = 1;
	    $DecisionLogicStrategyRules = new DecisionLogicStrategyRules();

	    // Lets process rules for this ruleset
	    for ($a=0;$a<count($rulesVendorParams);$a++) {
	        if($priority == 1) {
	            $insertData = array(
	                'DecisionLogicStrategyRulesetID' => $ruleSetID,
	                'comparisonOperatorID' => $rulesVendorParamsOperator[$a],
	                'DecisionLogicResponseParameterID' => $rulesVendorParams[$a],
	                'value' => $rulesVendorParamsValues[$a],
	                'priority' => $priority
	            );
	        }
	        else {
	            $insertData = array(
	                'DecisionLogicStrategyRulesetID' => $ruleSetID,
	                'comparisonOperatorID' => $rulesVendorParamsOperator[$a],
	                'DecisionLogicResponseParameterID' => $rulesVendorParams[$a],
	                'value' => $rulesVendorParamsValues[$a],
	                'priority' => $priority,
	                'referrerDecisionLogicStrategyRuleID' => $prevRuleID,
	                'logicalOperatorID' => $rulesOperators[$a-1]
	            );
	        }
	        // insert into DB
	        $ruleIDFromDB = $DecisionLogicStrategyRules->insert($insertData);
	        $prevRuleID = $ruleIDFromDB;
	        $priority++;
	    }
	}

	public function deleteDecisionLogicRuleSetsDataByCampaignID($campaignID) {

	    $DecisionLogicStrategies = new DecisionLogicStrategies();
	    $DecisionLogicStrategyRulesets = new DecisionLogicStrategyRulesets();
	    $DecisionLogicStrategyRules = new DecisionLogicStrategyRules();

	    $DecisionLogicStrategy = $DecisionLogicStrategies->fetchRow('campaignID = '.$campaignID);

	    if (isset($DecisionLogicStrategy) && count($DecisionLogicStrategy) > 0) {

	        $strategyID = $DecisionLogicStrategy['id'];
	        $ruleSets = $DecisionLogicStrategyRulesets->fetchAll('DecisionLogicStrategyID = '.$strategyID);

	        foreach ($ruleSets as $ruleSet) {
	            $ruleSetID = $ruleSet['id'];
	            $DecisionLogicStrategyRules->delete("DecisionLogicStrategyRulesetID = ".$ruleSetID);
	            $DecisionLogicStrategyRulesets->delete("DecisionLogicStrategyID = ".$strategyID);
	        }
	        $DecisionLogicStrategies->delete("id = ".$strategyID);
	    }
	}

	public function getRuleSetsDataAsJSON($campaignID) {

	    $DecisionLogicStrategies = new DecisionLogicStrategies();
	    $DecisionLogicStrategyRulesets = new DecisionLogicStrategyRulesets();
	    $DecisionLogicStrategyRules = new DecisionLogicStrategyRules();

	    $data = array();

	    $DecisionLogicStrategy = $DecisionLogicStrategies->fetchRow('campaignID = '.$campaignID);

	    if (isset($DecisionLogicStrategy) && count($DecisionLogicStrategy) > 0) {

	        $strategyID = $DecisionLogicStrategy['id'];
	        $ruleSets = $DecisionLogicStrategyRulesets->fetchAll('DecisionLogicStrategyID = '.$strategyID);

	        foreach ($ruleSets as $ruleSet) {

	            $tuple = array();
	            $tuple['ruleSetName'] = $ruleSet['name'];
	            $tuple['ruleSetStoreID'] = $ruleSet['storeID'];
	            $tuple['ruleSetPriority'] = $ruleSet['priority'];
	            $tuple['strategyName'] = $DecisionLogicStrategy['name'];
	            $tuple['ruleOperators'] = array();
	            $tuple['rulesVendorParams'] = array();
	            $tuple['rulesVendorParamsOperator'] = array();
	            $tuple['rulesVendorParamsValues'] = array();

	            $rules = $DecisionLogicStrategyRules->fetchAll("DecisionLogicStrategyRulesetID = ".$ruleSet['id']);
	            foreach ($rules as $rule) {
	                if (!empty($rule['logicalOperatorID'])) {
	                    $tuple['ruleOperators'][] = $rule['logicalOperatorID'];
	                }
	                if (!empty($rule['DecisionLogicResponseParameterID'])) {
	                    $tuple['rulesVendorParams'][] = $rule['DecisionLogicResponseParameterID'];
	                }
	                if (!empty($rule['comparisonOperatorID'])) {
	                    $tuple['rulesVendorParamsOperator'][] = $rule['comparisonOperatorID'];
	                }
	                if (!empty($rule['value'])) {
	                    $tuple['rulesVendorParamsValues'][] = $rule['value'];
	                }
	            }
	            $data[] = $tuple;
	        }
	    }
	    return json_encode($data);
	}
}
?>