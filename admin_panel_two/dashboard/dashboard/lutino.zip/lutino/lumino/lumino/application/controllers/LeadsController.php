<?php

class LeadsController extends Zend_Controller_Action 
{
	private $baseurl;

	public function init()
	{

		$this->baseurl = $this->_request->getBaseUrl();
	}

	public function chartAction()
	{
		$Lead = new LeadGraph();

		$hourlyAvgs 	= $Lead->hourlyAvgForThePastWeek();
		$todayTotals 	= $Lead->totalTodayPerHour();
		$today 			= date('l');

		// past 6 weekdays. e.g. past 6 Mondays
		$DateUtil = new DateUtility();
		$dates = $DateUtil->getWeekdayDates($today, 6);
		// creating quoted comma-delim of dates
		foreach ($dates as $date) {
			$datesFormatted .= "'$date',";
		}
		$datesFormatted = rtrim($datesFormatted, ',');
		$specificDayAvgs = $Lead->hourlyAvgForSpecificDay($datesFormatted);

		// combine for easier output
		$graphDatas = array();
		foreach ($hourlyAvgs as $k => $v) {
			$graphDatas[$k]['prettyHour'] = $v['prettyHour'];
			$graphDatas[$k]['averageLeads'] = $v['averageLeads'];
			$graphDatas[$k]['specificDayAvgs'] = $specificDayAvgs[$k]['averageLeads'];

			// some hours might not exist yet. ie too early in the day
			if (array_key_exists($k, $todayTotals)) {
				$graphDatas[$k]['todayTotals'] = $todayTotals[$k]['total'];
			} else {
				$graphDatas[$k]['todayTotals'] = 0;
			}
		}

		$this->view->graphDatas = $graphDatas;
		$this->view->today 		= $today;
	}
}
