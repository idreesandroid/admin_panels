<?php
/**
 * this class determines if any campaigns have hit their leadsold cap for the day.
 * If so, send an email alert
 */
class CampaignsLeadSoldCapPerDayAlert extends CampaignsAlertAbstract
{
	/**
	 * this is main interface to this class.
	 * it looks at leadsold grouped by campaign and sends an email alert
	 *
	 * @return array
	 */
	public function execute()
	{
		if ($totals = $this->getTotals()) {
			if (!$this->testMode) {
				$headers = 'From: tech@mediaenvy.com' . "\r\n" .
					    'Reply-To: tech@mediaenvy.com' . "\r\n" .
						    'X-Mailer: PHP/' . phpversion();
				$subj = 'Campaign Daily LeadSold Cap Alert';
				$body  = "=== These Campaigns have hit their Daily LeadSold Cap ===" . "\r\n\r\n";
				foreach ($totals as $total) {
					$body .= 'campaign ' . $total['campaign'] . ", total leadsold today:" . 
						$total['totalForToday'] . ", daily cap setting:" . 
						$total['maxLeadsSoldPerDay'] . "\r\n";
				}
				mail('oscarz@mediaenvy.com, rebecca@mediaenvy.com', $subj, $body, $headers);
			}
		}
		return $totals;
	}
	
	/**
	 * @return array
	 */
	public function getTotals()
	{
		$sql = "select IFNULL(l.campaign, 'other') campaign,
			count(1) totalForToday,
			c.maxLeadsSoldPerDay
			from Leads l
			join Campaigns c on c.id = l.campaign
			where l.originaldate = curdate() 
			and l.leadsold = 1 
			group by l.campaign
			having totalForToday >= c.maxLeadsSoldPerDay";

		return $this->db->fetchAll($sql);
	}
}
