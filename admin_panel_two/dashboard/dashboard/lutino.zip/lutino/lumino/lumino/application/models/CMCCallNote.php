<?php

/**
 * CallNotes Model
 *
 * model for TRAN Note File table
 *
 */
class CMCCallNote extends TranAbstract
{

	protected $_name = 'CMCCallNotes';
		
	public function init()
	{

		$this->fileName = "CallNotes";
		// db columns that are dates, used to format the date from data file
		$this->dateFields = array(8,11);
		// file type
		$this->cboFileType = "N";

		$this->fieldNames = array("StoreID",
				"ApplNo",
				"CustID",
				"NoteType",
				"NotePriority",
				"NoteText",
				"UserCreated",
				"CreatedUserName",
				"DateCreated",
				"UserModified",
				"ModifiedUserName",
				"DateModified",
				);

		$this->CustFile = new CustFile();

	}

	/**
	 * Updates or inserts a row
	 */
	public function upsert($insertData)
	{

		$existingRow = $this->findByKeyFields($insertData);

		if($existingRow) {
			$this->update($insertData, $this->_db->quoteInto("id = ?", $existingRow['id']));
		}
		else {
			$this->insert($insertData);
		}

	}

	/**
	 * Find row by the key fields
	 *
	 * @param		insertData	array	array of insertData
	 *
	 * @return				array 	array of Call Note row data
	 */
	public function findByKeyFields($insertData)
	{
	
		$sql = $this->_db->select()
				->from($this->_name)
				->where($this->_db->quoteInto("CustID = ?", $insertData['CustID']))
				->where($this->_db->quoteInto("ApplNo = ?", $insertData['ApplNo']))
				->where($this->_db->quoteInto("DateCreated = ?", $insertData['DateCreated']))
				->where($this->_db->quoteInto("DateCreatedMilliseconds = ?", $insertData['DateCreatedMilliseconds']));

		$result = $this->_db->fetchRow($sql);

		return $result;

	}

	/**
	 * Builds the insert array from the table field names and an array of values
	 *
	 */
	public function buildInsertArray($fieldData)
	{
		$insertData = array();

		foreach($this->fieldNames as $key =>$name) {
			$insertData[$name] = trim($fieldData[$key]);
		}

		// updated lookup algorithm
		$LeadMatch = new LeadMatchMaster($insertData['ApplNo']);
		$leadID = $LeadMatch->execute();

		$insertData['leadID'] = $leadID;
		$insertData['LeadID_Updated2'] = $leadID;

		$insertData['DateCreatedMilliseconds'] = $this->parseMilliseconds($insertData['DateCreated']);

		return $insertData;
	}

	/**
	 * Get milliseconds from a dateTime
	 *
	 * @param		dateTime	datetime	a date time field with the milliseconds
	 * 
	 * @return				int		the milliseconds
	 */
	public function parseMilliseconds($dateTime)
	{
		$dateTime = explode(" ", $dateTime);

		if(isset($dateTime[1])) { 
			$time = explode(":", $dateTime[1]);
			
			if(isset($time[3])) { 
				return $time[3];
			}
		}
			
		return '000';
	}
}
