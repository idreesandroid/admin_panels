<?php

class DenialReportsController extends Zend_Controller_Action
{
	public function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if(!$AdminNameSpace->userid)
		{
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();

		$this->config = Zend_Registry::get('config');
	}

	public function indexAction()
	{
		// for building column headers in table
		$InternalRejectCode = new InternalRejectCode();
		$internalCodeHeaders = $InternalRejectCode->getDenialReportHeaders();
		$CriteriaRejectCode = new ClientRejectCode();
		$clientCriteriaCodeHeaders = $CriteriaRejectCode->fetchAll()->toArray();
		$CampaignRejectCode = new CampaignRejectCode();
		$campaignRejectCodeHeaders = $CampaignRejectCode->fetchAll()->toArray();

		$fromDate = ($this->_request->fromDate) ? $this->_request->fromDate : date('Y-m-d');
		$toDate = ($this->_request->toDate) ? $this->_request->toDate : date('Y-m-d');

		$timeStart =  ($this->_request->timeStart) ? $this->_request->timeStart : date("H:i:s", strtotime("Today"));
		$timeEnd =
			($this->_request->timeEnd) ? $this->_request->timeEnd : date("H:i:s", strtotime("Today last second"));
		$selectedStrategy =  ($this->_request->selectedStrategy) ? $this->_request->selectedStrategy : 0;

		$affiliateId = $this->_request->affiliateId;
		$storeIDs = array();
		$storeIDparam = explode(',', $this->_request->storeIDParam);

		foreach ($storeIDparam AS $id) {
			$storeID = "storeID_" . $id;
			if ($this->_request->$storeID == "true") {
				$storeIDs[] = '"'.$id.'"';
			}
		}
		$DenialReport = new DenialReport($fromDate, $toDate, $timeStart, $timeEnd, $selectedStrategy,$affiliateId,$storeIDs);
		$reports = $DenialReport->execute();

		// Need to get affiliates to be shown in affiliate drop down
		$masteraffData = $DenialReport->getLeadProviders($fromDate, $toDate, $timeStart, $timeEnd);
		$this->view->masteraff =  $masteraffData;

		$storeIDs = array();
		$storeIDs[''] = '';

		$Factory = new CampaignReportLMSFactory();
		$CampaignReport	= $Factory->create($this->config->lmsName);
		foreach ($CampaignReport->getStoreIDs() as $store) {
			if ($store['storeID']) {
				$storeIDs[$store['storeID']] = $store['storeID'];
			}
		}

		$this->view->internalCodeHeaders = $internalCodeHeaders;
		$this->view->criteriaCodeHeaders = $clientCriteriaCodeHeaders;
		$this->view->campaignCodeHeaders = $campaignRejectCodeHeaders;

		$this->view->affiliateId = $affiliateId;
		// Prepare Vendor Reject headers
		$vendorsHeaders = $DenialReport->prepareVendorRejectHeader();
		$this->view->vendorsHeaders = $vendorsHeaders;

		// Prepare Client Reject headers
		$clientsHeaders = $DenialReport->prepareClientRejectHeader();
		$this->view->clientsHeaders = $clientsHeaders;
		$reports = $DenialReport->prepareReportForTableView($vendorsHeaders, $clientsHeaders, $reports);


		$this->view->reports = $reports;
		$this->view->storeid =  $storeIDs;
		$this->view->totalsRow = $DenialReport->totalsRow($reports, array('campaign'));
		$this->view->fromDate = $fromDate;
		$this->view->toDate = $toDate;

		$this->view->timeStart = $timeStart;
		$this->view->timeEnd = $timeEnd;

		$this->view->flashMessages = $this->_helper->flashMessenger->getMessages();

		$strategies = array();
		$strategies[''] = '';
		$select = "<option value=''></option>";
		foreach ($DenialReport->getVendorStrategies() as $strategy) {
			if ($strategy['id']) {
				$name = $strategy['name'];
				$id = $strategy['id'];

				$selected = "";
				if ($selectedStrategy == $id) {
					$selected = "selected='selected'";
				}

				if ($strategy['active'] == 1) {
					$select .= "<option value=$id class='activestrategy' $selected>$name</option>";
				} else if ($strategy['active'] == 0) {
					$select .= "<option value=$id class='noactivestrategy' $selected>$name</option>";
				}
			}
		}

		$this->view->strategies =  $select;

		if ($this->_request->format == 'csv') {
			header("Content-type: text/csv");
			header("Content-Disposition: attachment; filename=denial_report_" . $fromDate . "_" . $toDate . ".csv");
			header("Pragma: no-cache");
			header("Expires: 0");

			$this->_helper->viewRenderer->setNoRender();

			$csvHeaders = $DenialReport->prepareColumnHeadersForCsv($internalCodeHeaders,
				$clientCriteriaCodeHeaders, $campaignRejectCodeHeaders, $vendorsHeaders, $clientsHeaders);
			$totalsRow = $DenialReport->totalsRow($reports, array('campaign'));
			$reportsFormatted = $DenialReport->prepareReportForCsv($csvHeaders,
				$reports,
				$totalsRow,
				$vendorsHeaders,
				$clientsHeaders);
			$csvFile = $DenialReport->makeCsv($csvHeaders, $reportsFormatted);

			echo $csvFile;
		}
	}

	public function postsetupAction() {
		// for building column headers in table

		$CriteriaRejectCode = new ClientRejectCode();
		$clientCriteriaCodeHeaders = $CriteriaRejectCode->fetchAll()->toArray();

		$fromDate = ($this->_request->fromDate) ? 
			$this->_request->fromDate : date('Y-m-d');
		$toDate = ($this->_request->toDate) ? 
			$this->_request->toDate : date('Y-m-d');

		$timeStart =  ($this->_request->timeStart) ? $this->_request->timeStart : date("H:i:s", strtotime("Today"));
		$timeEnd =
			($this->_request->timeEnd) ? $this->_request->timeEnd : date("H:i:s", strtotime("Today last second"));

		$this->view->criteriaCodeHeaders = $clientCriteriaCodeHeaders;

		$DenialReportPostSetupID = new DenialReportCampaignPostSetupID($fromDate, 
			$toDate, 
			$this->_request->campaignID,
			$timeStart,
			$timeEnd);
		$reports = $DenialReportPostSetupID->execute();

		// Prepare Vendor Reject headers
		$vendorsHeaders = $DenialReportPostSetupID->prepareVendorRejectHeader();

		$this->view->vendorsHeaders = $vendorsHeaders;

		// Prepare Client Reject headers
		$clientsHeaders = $DenialReportPostSetupID->prepareClientRejectHeader();
		$this->view->clientsHeaders = $clientsHeaders;

		$reports = $DenialReportPostSetupID->prepareReportForTableView($vendorsHeaders, $clientsHeaders, $reports);


		$this->view->reports = $reports;
		$this->view->fromDate = $fromDate;
		$this->view->toDate = $toDate;
		$this->view->timeStart = $timeStart;
		$this->view->timeEnd = $timeEnd;
		$this->view->campaignID = $this->_request->campaignID;

		$this->view->flashMessages = $this->_helper->flashMessenger->getMessages();
	}

	public function subidAction()
	{
		// for building column headers in table
		$InternalRejectCode = new InternalRejectCode();
		$internalCodeHeaders = $InternalRejectCode->getDenialReportHeaders();
		$CriteriaRejectCode = new ClientRejectCode();
		$clientCriteriaCodeHeaders = $CriteriaRejectCode->fetchAll()->toArray();
		$CampaignRejectCode = new CampaignRejectCode();
		$campaignRejectCodeHeaders = $CampaignRejectCode->fetchAll()->toArray();

		$fromDate = ($this->_request->fromDate) ? 
			$this->_request->fromDate : date('Y-m-d');
		$toDate = ($this->_request->toDate) ? 
			$this->_request->toDate : date('Y-m-d');

		$timeStart =  ($this->_request->timeStart) ? $this->_request->timeStart : date("H:i:s", strtotime("Today"));
		$timeEnd =
			($this->_request->timeEnd) ? $this->_request->timeEnd : date("H:i:s", strtotime("Today last second"));

		$this->view->internalCodeHeaders = $internalCodeHeaders;
		$this->view->criteriaCodeHeaders = $clientCriteriaCodeHeaders;
		$this->view->campaignCodeHeaders = $campaignRejectCodeHeaders;

		$DenialReportSubID = new DenialReportCampaignSubID($fromDate, 
			$toDate, 
			$this->_request->campaignID,
			$timeStart,
			$timeEnd);
		$reports = $DenialReportSubID->execute();

		// Prepare Vendor Reject headers
		$vendorsHeaders = $DenialReportSubID->prepareVendorRejectHeader();
		$this->view->vendorsHeaders = $vendorsHeaders;

		// Prepare Client Reject headers
		$clientsHeaders = $DenialReportSubID->prepareClientRejectHeader();
		$this->view->clientsHeaders = $clientsHeaders;

		$reports = $DenialReportSubID->prepareReportForTableView($vendorsHeaders, $clientsHeaders, $reports);


		$this->view->reports = $reports;
		$this->view->fromDate = $fromDate;
		$this->view->toDate = $toDate;
		$this->view->timeStart = $timeStart;
		$this->view->timeEnd = $timeEnd;
		$this->view->campaignID = $this->_request->campaignID;
		$this->view->campaignTitle = $DenialReportSubID->getCampaignTitleByCampaignID($this->_request->campaignID);

		$this->view->flashMessages = $this->_helper->flashMessenger->getMessages();
	}

	/**
	 * returns the totals for vendorstrategy ruleset rejects by postsetupid
	 */
	public function vendorStrategyRulesetDenialDataAction()
	{
		// required request params
		$originalDateStart = date('Y-m-d', strtotime($this->_request->originalDateStart));
		$originalDateEnd = date('Y-m-d', strtotime($this->_request->originalDateEnd));
		$originalTimeStart = date("H:i:s", strtotime($this->_request->originalTimeStart));
		$originalTimeEnd = date("H:i:s", strtotime($this->_request->originalTimeEnd));
		$campaignID = $this->_request->campaignID;

		// lets retrieve data
		$DenialReport = new DenialReport($originalDateStart,
			$originalDateEnd,
			$originalTimeStart,
			$originalTimeEnd);

		$result = $DenialReport->getVendorStrategyRulesetRejectBreakdownByCampaignID($campaignID);

		$this->view->result = $result;
		$this->view->campaignID = $campaignID;
	}
}
