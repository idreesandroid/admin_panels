<?php

class RelianceResponse extends Zend_Db_Table
{
    protected $_name = 'ClarityResponses';

    public function init()
    {
        $bootstrap = Zend_Controller_Front::getInstance()->getParam("bootstrap");
        $resource = $bootstrap->getPluginResource('multidb');
        $this->db_slave = $resource->getDb('slave');
    }

    public function getVendorNameDenyQuery() {

        $sql = $this->db_slave->select()
            ->from("RelianceResponses", array())
            ->joinInner("PostLogs", "PostLogs.leadID = RelianceResponses.leadID", array())
            ->joinInner("VendorPostSetups", "PostLogs.postSetupID = VendorPostSetups.postSetupID", array())
            ->joinInner("Vendors", "VendorPostSetups.vendorID = Vendors.id", array("vendorName"=>"company"))
            ->where('RelianceResponses.leadID = Leads.id')
            ->where('Vendors.id = 20')
            ->where('PostLogs.postStatus = "no"')
            ->where('RelianceResponses.errorMessage is not null')
            ->where('RelianceResponses.errorMessage != ""')
            ->limit(1);

        return $sql;
    }

    public function getVendorDenyReasonQuery() {

        $sql = $this->db_slave->select()
            ->from("RelianceResponses", array('errorMessage'))
            ->joinInner("PostLogs", "PostLogs.leadID = RelianceResponses.leadID", array())
            ->where('RelianceResponses.leadID = Leads.id')
            ->where('RelianceResponses.errorMessage is not null')
            ->where('RelianceResponses.errorMessage != ""')
            ->where('PostLogs.postStatus = "no"')
            ->limit(1);

        return $sql;
    }
}