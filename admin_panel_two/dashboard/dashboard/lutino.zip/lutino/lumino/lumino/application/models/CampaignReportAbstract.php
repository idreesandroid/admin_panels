<?php
/**
 * abstract class for the different types of concrete campaign reports.
 * e.g. tdc, epic, etc.
 */
abstract class CampaignReportAbstract
{
	public function getCampaignList()
	{
		$db= Zend_Registry::get("db");
		$query = "SELECT id,campaign FROM Campaigns";
		return $campaigns = $db->fetchAll($query);
	}

	/**
	 * Gets all leadprovider masteraff names
	 */
	public function getLeadProviders($originalDateStart, $originalDateEnd, $originalTimeStart, $originalTimeEnd)
	{
		$masteraffData[''] = '';
		$Leads = new Leads();
		$Leads->initSettingsForSlaveDB();
		$originalDateStart = date("Y-m-d", strtotime($originalDateStart));
		$originalDateEnd = date("Y-m-d", strtotime($originalDateEnd));

		$leadProviders = $Leads->getAllLeadProviders($originalDateStart, $originalDateEnd, $originalTimeStart, $originalTimeEnd);
		foreach ($leadProviders as $masteraff) {
			$masteraffData[$masteraff['masteraff']] = $masteraff['masteraff'];
		}
		return $masteraffData;
	}

	public function getStoreIDs()
	{
		$Leads = new Leads();
		$Leads->initSettingsForSlaveDB();

		$storeIDs = $Leads->getStoreIDs();
		return $storeIDs;
	}

	/**
	 * NOTE: this method actually gets variate info, NOT vendorstrategy info
	 */
	public function getVendorStrategies()
	{
		$Leads = new Leads();
		$Leads->initSettingsForSlaveDB();

		$strategies = $Leads->getVendorStrategies();
		return $strategies;
	}

	/**
	 * returns report data with added calculated custom values. eg. CPF, etc.
	 *
	 * @param   reportData  array of report data
	 * @return  $finalReport array of report data with calculated fields
	 */
	public function calculateValues($reportData)
	{
		$finalReport = array();

		foreach($reportData as $value)
		{
			$calculatedRow = $value;

			$calculatedRow['costPerLead'] = ReportCalc::costPerLead($calculatedRow['TotalPrice'], $calculatedRow['bought']);
			$calculatedRow['cost'] = $calculatedRow['TotalPrice'] ? $calculatedRow['TotalPrice'] : 0;
			$calculatedRow['cpf'] = $calculatedRow['CPF'];
			$calculatedRow['perTodayOrigBought'] = ReportCalc::percentOriginatedvsBought($calculatedRow['TodaysOriginated'], $calculatedRow['bought']);
			$calculatedRow['perTotalOrigBought'] = ReportCalc::percentOriginatedvsBought($calculatedRow['TotalOriginated'], $calculatedRow['bought']);
			$calculatedRow['perBoughtAttempted'] = ReportCalc::percentBoughtvsAttempted($calculatedRow['bought'], $calculatedRow['leads']);
			$calculatedRow['esigRate'] = ReportCalc::esigRate($calculatedRow['esigs'], $calculatedRow['bought']);
			$calculatedRow['originated'] = $calculatedRow['TodaysOriginated'];
			$calculatedRow['totaloriginated'] = $calculatedRow['TotalOriginated'];
			$calculatedRow['date'] = $calculatedRow['odate'];
			$calculatedRow['redirectsRate'] = ReportCalc::redirectsRate($calculatedRow['bought'], $calculatedRow['redirects']);
			$calculatedRow['FPDRate'] = ReportCalc::fpdRate($calculatedRow['TotalOriginated'], $calculatedRow['FPD']);

			$finalReport[] = $calculatedRow;
		}

		return $finalReport;
	}

	/**
	 * adds a hasSubIDs element for each row of data
	 *
	 * @param $calculatedData array
	 * @param $campaignsWithNotSubIDs array of campaigns with no subIDs
	 * @return our passed in $calculatedData array with an added 'hasSubIDs' elem per row
	 */
	public function addHasSubIdsElement($calculatedData, $campaignsWithNotSubIDs)
	{
		foreach($calculatedData as $k => $v)
		{
			if ($this->hasSubId($campaignsWithNotSubIDs, $v['campaign'])) {
				$calculatedData[$k]['hasSubIDs'] = true;
			} else {
				$calculatedData[$k]['hasSubIDs'] = false;
			}
		}

		return $calculatedData;
	}

	/**
	 * call this method if you want to total all the data returned in calculateValues()
	 *
	 * @param  $calculatedValues the array returned from calculatedValues()
	 * @return our passed in $calculatedValues array with an added 'totals' array element
	 */
	public function totalCalculatedValues($calculatedData)
	{
		// prepare totals array with initial values
		$totals = array("leads" => 0, "bought" => 0, "totalCost" => 0, "originated" => 0, "totaloriginated" => 0);

		// iterate to build totals
		foreach ($calculatedData as $value)
		{
			$totals['leads'] += $value['leads'];
			$totals['bought'] += $value['bought'];
			$totals['cost'] += $value['cost'];
			$totals['originated'] += $value['TodaysOriginated'];
			$totals['totaloriginated'] += $value['TotalOriginated'];
			$totals['esigs'] += $value['esigs'];
			$totals['FPD'] += $value['FPD'];
			$totals['redirects'] += $value['redirects'];
		}

		$totals['costPerLead'] = ReportCalc::costPerLead($totals['cost'], $totals['bought']);
		$totals['cpf'] = ReportCalc::costPerOriginated($totals['cost'], $totals['totaloriginated']);
		$totals['perTodayOrigBought'] = ReportCalc::percentOriginatedvsBought($totals['originated'], $totals['bought']);
		$totals['perTotalOrigBought'] = ReportCalc::percentOriginatedvsBought($totals['totaloriginated'], $totals['bought']);
		$totals['perBoughtAttempted'] = ReportCalc::percentBoughtvsAttempted($totals['bought'], $totals['leads']);
		$totals['esigRate'] = ReportCalc::esigRate($totals['esigs'], $totals['bought']);
		$totals['FPDRate'] = ReportCalc::fpdRate($totals['TotalOriginated'], $totals['FPD']);
		$totals['redirectsRate'] = ReportCalc::redirectsRate($totals['bought'], $totals['redirects']);

		$calculatedData['totals'] = $totals;

		return $calculatedData;
	}

	public function hasSubId($campaignsWithNotSubIDs, $campaignID)
	{
		foreach ($campaignsWithNotSubIDs as $val) {
			if ($val['campaign'] == $campaignID)
				return false;
		}
		return true;
	}

	abstract public function getCampaignReports($isxml = false, $startDate, $endDate, $originalTimeStart, $originalTimeEnd, $storeIds, $multiVarStart=0, $multiVarEnd=0, $originationDate="", $selectedStrategyID=0, $selectedAffiliate="");

	abstract public function getSubIdReports($isxml = false, $startDate, $endDate, $originalTimeStart, $originalTimeEnd, $storeIds, $campaign = NULL, $multiVarStart=0, $multiVarEnd=0, $originationDate="", $selectedStrategyID=0);

	abstract public function getSubId2Reports($isxml = false, $startDate, $endDate, $originalTimeStart, $originalTimeEnd, $storeIds, $campaign = NULL, $multiVarStart=0, $multiVarEnd=0, $originationDate="", $selectedStrategyID=0);

	abstract public function getSubId3Reports($isxml = false, $startDate, $endDate, $originalTimeStart, $originalTimeEnd, $storeIds, $campaign = NULL, $multiVarStart=0, $multiVarEnd=0, $originationDate="", $selectedStrategyID=0);
}
