<?php

class PDSPaymentCredential extends Zend_Db_Table
{
	protected $_name = 'PDSPaymentCredentials';
	const VENDOR_ID = 1003;

	public function getDefault()
	{
		$row = $this->fetchRow("isDefault = 1");
		if ($row)
			$row = $row->toArray();

		return($row);
	}

	/**
	 * Updates or inserts a row
	 */
	public function upsert($vendorStrategyID, $insertData)
	{
		$existingRow = $this->findByID($vendorStrategyID);

		if($existingRow) {
			$this->update($insertData, $this->_db->quoteInto("id = ?", $existingRow['id']));
			return $existingRow['id'];
		}
		else {
			return $this->insert($insertData);
		}
	}

	public function findByID($vendorStrategyID) {

		$PDSPaymentCredentialVendorStrategy = new PDSPaymentCredentialVendorStrategy();
		$result = $PDSPaymentCredentialVendorStrategy->findByVendorStrategyID($vendorStrategyID);
		if ($result['PDSPaymentCredentialsID']) {
			$sql = $this->select()
				->where("id = " . $result['PDSPaymentCredentialsID']);
			return $this->fetchRow($sql);
		}
	}
}

