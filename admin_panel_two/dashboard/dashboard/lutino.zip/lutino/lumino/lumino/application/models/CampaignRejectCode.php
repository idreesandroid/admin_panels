<?php

class CampaignRejectCode extends Zend_Db_Table
{
	protected $_name = 'CampaignRejectCodes';
}

?>
