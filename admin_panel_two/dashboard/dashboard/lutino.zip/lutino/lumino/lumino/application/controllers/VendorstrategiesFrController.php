<?php
class VendorstrategiesFrController extends Zend_Controller_Action
{
	private $baseurl;

	function init()
	{
		if ($this->_helper->flashMessenger->hasMessages()) {
			$this->view->flashMessages = $this->_helper->flashMessenger->getMessages();
		}

		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if (!$AdminNameSpace->userid)
		{
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();
	}

	public function indexAction()
	{
		$this->view->baseurl = $this->baseurl;
	}
}
?>
