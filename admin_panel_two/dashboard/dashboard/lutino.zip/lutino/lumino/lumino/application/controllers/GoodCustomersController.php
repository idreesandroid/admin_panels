<?php

class GoodCustomersController extends Zend_Controller_Action
{
	// index names of array that contains csv column names
	const STORE_ID = 0;
	const SSN = 1;
	const EMAIL = 2;
	const TOTAL_VALID_LOANS = 3;
	const CUSTOMER_DATE_CREATED = 4;


	public function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if (!$AdminNameSpace->userid) {
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();
		$this->Logger = new DataLogger('GoodCustomersUpload', 'daily');
		$this->_flashMessenger = $this->_helper->getHelper('FlashMessenger');
	}

	public function indexAction()
	{
		$this->view->messages = $this->_flashMessenger->getMessages();
	}

	public function getdataAction() {

		$offset = ($this->_request->offset) ? $this->_request->offset : 0;
		$limit  = ($this->_request->limit) ? $this->_request->limit : 100;
		$sortBy = ($this->_request->sort) ? $this->_request->sort : "email";
		$sortOrder = ($this->_request->order) ? $this->_request->order : "ASC";
		$search = ($this->_request->search) ? $this->_request->search : "";

		$GoodCustomer = new GoodCustomer();
		$customersCount = $GoodCustomer->getTotalCustomers($search);
		$customers = $GoodCustomer->getCustomers($search,$offset,$limit,$sortBy,$sortOrder);

		$data = array('total' => $customersCount['cnt']);
		$data['rows'] = array();

		foreach($customers as $customer) {
			$tuple = array();
			$tuple['id'] = $customer['id'];
			$tuple['ssn'] = substr_replace($customer['ssn'], "xxx-xx-", 0, 5);
			$tuple['email'] = $customer['email'];
			$tuple['storeID'] = $customer['storeID'];
			$tuple['totalValidLoans'] = $customer['totalValidLoans'];
			$tuple['custDateCreated'] = $customer['custDateCreated'];
			$data['rows'][] = $tuple;
		}

		echo json_encode($data);
		exit;
	}

	public function uploadAction()
	{
		ini_set("auto_detect_line_endings", true);

		$isError = 0;
		$this->_helper->viewRenderer->setnoRender();
		if (isset($_POST['submit'])) {
			$GoodCustomer = new GoodCustomer();

			$file_handle = NULL;
			$data = NULL;
			$keys = NULL;
			$record = NULL;

			$this->Logger->logtofile("--- Start");

			$filename = $_FILES['filename']['tmp_name'];

			if (is_uploaded_file($filename)) {
				if (file_exists($filename)) {

					$filenameExt = explode(".", $_FILES['filename']['name']);

					if (strtolower($filenameExt[1]) == "csv") {
						// Limit fixe size to 50KB
						if ($_FILES['filename']['size']/1024 <= 50) {

							$file_handle = fopen($filename, "r");

							$this->Logger->logtofile(" Uploading " . $_FILES['filename']['name'] . " file");

							while ($row = fgetcsv($file_handle, 1024)) {

								$this->Logger->logtofile(" calling fgetcsv()..");

								$this->Logger->logtofile("fgetcsv() done. assembling data into array..");

								if (is_array($row)) {
									//set record array keys from csv header
									if ($keys == NULL) {
										$keys = array_flip($row);
									} //set record array values from csv row
									else if ($keys != NULL) {
										foreach ($keys as $key => $value) {
											// if ssn has length less than 9 characters let's insert leading zeroes in front
											if ($value == self::SSN) {
												$record[$key] = sprintf('%09d', $row[$value]);
											}

											if ($value == self::STORE_ID || $value == self::EMAIL || $value == self::TOTAL_VALID_LOANS) {
												$record[$key] = $row[$value];
											}
											// let's format date. From 4/10/15 to 2015-04-10
											if ($value == self::CUSTOMER_DATE_CREATED) {
												$explodedDate = explode('/', $row[$value]);
												$date = mktime(1, 0, 0, $explodedDate[0], $explodedDate[1], $explodedDate[2]);
												$record[$key] = date('Y-m-d', $date);
											}

										}
										$data[] = $record;
									}
								}
							}

							foreach ($data as $v) {
								try {
									$GoodCustomer->upsert($v);
								} catch (Exception $e) {
									$this->Logger->logtofile(" CSV Upload error: " . $e->getMessage());
								}
							}
						}
						else {
							$this->_flashMessenger->addMessage("Uploaded file " . $_FILES['filename']['name'] . " exceeds 50KB upload file size limit .");
							$isError = 1;
						}
					} else {
						$this->_flashMessenger->addMessage("File " . $_FILES['filename']['name'] . " has wrong format.");
						$isError = 1;
					}
				} else {
					$this->_flashMessenger->addMessage("File " . $_FILES['filename']['name'] . " not found.");
					$isError = 1;
				}

				$this->Logger->logtofile("--- End: File " . $_FILES['filename']['name']);
				if ($isError == 0) {
					$this->_flashMessenger->addMessage($_FILES['filename']['name'] . " uploaded successfully.");
				}

			}
			if ($file_handle) fclose($file_handle);
		}

		return $this->_helper->redirector('index');
	}


	public function deleteAction()
	{
		if ($this->_request->id) {
			$GoodCustomer = new GoodCustomer();
			$GoodCustomer->delete("id = " . $this->_request->id);

			$this->_helper->flashMessenger->addMessage(array(
				'message' => array('Customer has been removed from Good Customer list.' => 'success')));
		}
		return $this->_helper->redirector('index');
	}
}
