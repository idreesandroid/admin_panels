<?php
class WidgetsController extends Zend_Controller_Action
{
    private $baseurl;

    function init()
    {
        $AdminNameSpace = new Zend_Session_Namespace('AdminUser');
        if(!$AdminNameSpace->userid)
        {
            $this->_redirect('index/login');
        }
        $this->baseurl = $this->_request->getBaseUrl();
    }

    function indexAction()
    {
        $TodoLists = new TodoLists();
        $this->view->todos = $TodoLists->fetchAll();
    }

    function flagtodoAction()
    {
        $this->_helper->viewRenderer->setNoRender(true);
        $id = $this->_request->getPost('id');
        $TodoLists = new TodoLists();
        $row = $TodoLists->fetchRow($TodoLists->select()->where('id = ?', $id));

        try {
            $where = "id = $id";
            if ($row->flagged == 0) {
                $TodoLists->update(array('flagged' => 1),$where);
                echo '{"status": "ok","flagged": "1"}';
            }
            else {
                $TodoLists->update(array('flagged' => 0),$where);
                echo '{"status": "ok","flagged": "0"}';
            }
        }
        catch (Exception $e) {
            echo '{"status": "error","id": '.$id.'}';
        }
    }

    function deletetodoAction()
    {
        $this->_helper->viewRenderer->setNoRender(true);
        $id = $this->_request->getPost('id');
        $TodoLists = new TodoLists();
        $row = $TodoLists->fetchRow($TodoLists->select()->where('id = ?', $id));
        try {
            if ($row->id) {
                $row->delete();
                echo '{"status": "ok"}';
            }
        }
        catch (Exception $e) {
            echo '{"status": "error","id": '.$id.'}';
        }
    }

    function updatetostatusAction()
    {
        $this->_helper->viewRenderer->setNoRender(true);
        $id = $this->_request->getPost('id');
        $TodoLists = new TodoLists();
        $row = $TodoLists->fetchRow($TodoLists->select()->where('id = ?', $id));

        try {
            $where = "id = $id";
            if ($row->status == "incomplete") {
                $TodoLists->update(array('status' => "complete"),$where);
                echo '{"status": "ok","iscomplete": "complete"}';
            }
            else {
                $TodoLists->update(array('status' => 'incomplete'),$where);
                echo '{"status": "ok","iscomplete": "incomplete"}';
            }
        }
        catch (Exception $e) {
            echo '{"status": "error"}';
        }
    }

    function addtodoAction()
    {
        $this->_helper->viewRenderer->setNoRender(true);
        $title = $this->_request->getPost('title');

        if ($title) {
            try {
                $TodoLists = new TodoLists();
                $id = $TodoLists->insert(array('title' => $title, 'status' => 'incomplete', 'flagged' => 0));
                echo '{"status": "ok","id": "'.$id.'"}';
            }
            catch (Exception $e) {
                echo '{"status": "error","id": ""}';
            }
        }
        else {
            echo '{"status": "error","id": ""}';
        }
    }

    function edittodoAction()
    {
        $this->_helper->viewRenderer->setNoRender(true);
        $title = $this->_request->getPost('value');
        $id = $this->_request->getPost('pk');

        if ($title && $id) {
            try {
                $TodoLists = new TodoLists();
                $where = "id = $id";
                $TodoLists->update(array('title' => $title),$where);
                echo '{"status": "ok","id": "'.$id.'"}';
            }
            catch (Exception $e) {
                echo '{"status": "error","id": ""}';
            }
        }
        else {
            echo '{"status": "error","id": ""}';
        }
    }
}