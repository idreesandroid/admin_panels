<?php
/**
 * Zend db class for ClientCampaignLeadCaps table
 */
class ClientCampaignLeadCap extends Zend_Db_Table
{
	protected $_name = 'ClientCampaignLeadCaps';

	public function findByPostSetupIDCampaignID($postSetupID, $campaignID)
	{
		return $this->fetchRow("postSetupID = '" . $postSetupID . "' 
			AND campaignID = '" . $campaignID . "'");
	}
}
