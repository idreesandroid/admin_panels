<?php

class GeoReportsSummaryController extends Zend_Controller_Action
{
	private $baseurl;

	function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if (!$AdminNameSpace->userid) {
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();
	}

	function indexAction()
	{
		$this->view->baseurl = $this->baseurl;

		$this->view->baseurl = $this->baseurl;
		// Pie Chart on the main page
		$fromDate = ($this->_request->fromDate) ?
			date('Y-m-d', strtotime($this->_request->fromDate)) : date('Y-m-d');
		$toDate = ($this->_request->toDate) ?
			date('Y-m-d', strtotime($this->_request->toDate)) : date('Y-m-d');

		$fromTime = '00:00:00';
		$toTime = '23:59:59';

		$this->view->fromDate = date('m/d/Y', strtotime($fromDate));;
		$this->view->toDate = date('m/d/Y', strtotime($toDate));;

		$geocharttype = $this->_request->geocharttype ? $this->_request->geocharttype : "leadsattempts";

		$this->view->geocharttype = $geocharttype;

		$GeoChartReport = new GeoReportSummary($fromDate, $toDate, $fromTime, $toTime);

		if ($geocharttype == "leadsattempts") {
			$this->view->geochartDataByState = $this->prepareGeoChartData($GeoChartReport->getLeadAttemptsByState());
		} else {
			$this->view->geochartDataByState = $this->prepareGeoChartData($GeoChartReport->getLeadPurchasedByState());
		}

		echo "";
	}

	/**
	 * format array so we can easily plug into geo chart
	 *
	 * @param array $data
	 * @return array
	 */
	private function prepareGeoChartData($data)
	{
		$formatted = array();

		foreach ($data as $v) {
			$formatted[$v['state']] = $v['amount'];
		}
		return $formatted;
	}
}

?>
