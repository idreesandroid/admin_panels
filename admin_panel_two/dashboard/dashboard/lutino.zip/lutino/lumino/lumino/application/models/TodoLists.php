<?php

class TodoLists extends Zend_Db_Table
{
	protected $_name = 'TodoLists';
}

?>