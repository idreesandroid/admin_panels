<?php
class HelpcenterController extends Zend_Controller_Action
{
    private $baseurl;

    function init()
    {
        $AdminNameSpace = new Zend_Session_Namespace('AdminUser');
        if(!$AdminNameSpace->userid)
        {
            $this->_redirect('index/login');
        }
        $this->baseurl = $this->_request->getBaseUrl();
    }

    function indexAction(){}
}