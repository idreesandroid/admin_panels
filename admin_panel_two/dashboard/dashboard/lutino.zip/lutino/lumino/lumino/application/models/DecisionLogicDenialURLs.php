<?php

class DecisionLogicDenialURLs extends Zend_Db_Table
{
    protected $_name = 'DecisionLogicDenialURLs';

    public function upsert($url)
    {
        $data = array('url' => $url);
        $sql = "SELECT count(*) AS count FROM ".$this->_name;

        $result = $this->_db->fetchRow($sql);
        if ($result['count'] >= 1) {
            // Update record
            $this->update($data,"id = 1");
        }
        else {
            // insert record
            $this->insert($data);
        }
    }
}

