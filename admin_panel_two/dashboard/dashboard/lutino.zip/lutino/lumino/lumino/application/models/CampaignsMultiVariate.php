<?php

class CampaignsMultiVariate extends Zend_Db_Table_Abstract
{
	protected $_name = 'CampaignsMultiVariates';

	public function findByCampaignID($campaignID)
	{
		$sql = "select * 
			FROM " . $this->_name . " 
			WHERE campaignID = " . $campaignID . " 
			LIMIT 1";

		return $this->_db->fetchRow($sql);
	}

	public function getActiveByCampaignID($campaignID)
	{
		$sql = "select * 
			FROM " . $this->_name . " cmv 
			JOIN MultiVariates m ON m.id = cmv.multiVariateID 
			WHERE cmv.campaignID = " . $campaignID . " 
			AND m.active = 1";

		return $this->_db->fetchRow($sql);
	}

	/**
	 * remove any current multivariates for this campaign before saving,
	 * also make sure the chosen one is activated. ie active=1
	 *
	 * @param integer $campaignID
	 * @param integer $multiVariateID
	 * @return boolean
	 */
	public function saveNew($campaignID, $multiVariateID)
	{
		try {
			// first remove current campaign multivariate
			$this->delete("campaignID = " . $campaignID);

			$this->insert(array(
				'campaignID' => $campaignID, 
				'multiVariateID' => $multiVariateID));

			// make sure chosen MultiVariate is active
			$MultiVariate = new MultiVariate();
			$MultiVariate->update(array('active' => 1), "id = " . $multiVariateID);

			return TRUE;
		} catch (Exception $e) {
			return FALSE;
		}
	}

	public function findByMultivariateID($multivariateID)
	{
		$sql = $this->select()->where("multiVariateID = " . $multivariateID);
		return $this->fetchRow($sql);
	}
}
