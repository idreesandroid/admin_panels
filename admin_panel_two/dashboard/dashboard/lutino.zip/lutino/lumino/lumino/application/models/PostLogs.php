<?php
class PostLogs extends Zend_Db_Table_Abstract
{
	protected $_name = 'PostLogs';

	/**
	 * Methods returns data by leadID
	 * @param $leadID lead id
	 * @return array|bool
	 */
	public function getDataByLeadID($leadID)
	{
		if (!$leadID) {
			return FALSE;
		}
		$sql = "SELECT
					*
				FROM
					PostLogs pl
				WHERE
					pl.leadID = '$leadID'";

		if ($result = $this->_db->fetchAll($sql)) {
			return $result;
		}
		return FALSE;
	}

	/**
	 * Methods returns data by leadID and postSetupID
	 * @param $leadID lead id, $postSetupID postSetup id
	 * @return array|bool
	 */
	public function getDataByLeadIDAndPostSetupID($postLogID, $leadID, $postSetupID)
	{
		if (!$leadID && !$postSetupID) {
			return FALSE;
		}

		$sql = "SELECT
					*
				FROM
					PostLogs pl
				WHERE
					pl.id = '$postLogID'
					AND
					pl.leadID = '$leadID'
					AND
					pl.postSetupID = '$postSetupID'";

		if ($result = $this->_db->fetchRow($sql)) {
			return $result;
		}
		return FALSE;
	}
}
