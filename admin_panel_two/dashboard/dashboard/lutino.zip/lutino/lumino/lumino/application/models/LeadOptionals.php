<?php

class LeadOptionals extends Zend_Db_Table
{
	protected $_name = 'LeadOptionals';
}
