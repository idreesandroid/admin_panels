<?php
/**
 * this class contains methods for querying data
 * needed for Graphs/Charts
 */
class LeadGraph
{
	public function __construct()
	{
		$this->_db = Zend_Registry::get('db');
	}

	/**
	 * gets the leads per hour from 0900 - 1800 for today
	 * @return array
	 */
	public function totalTodayPerHour()
	{
		$sql = "select 
			count(1) as total, 
			LEFT(originaltime,2) as hour,
			CONCAT(LEFT(originaltime,2), ':00') as prettyHour 
			from Leads 
			where originaldate=curdate() 
			group by hour
			having hour >= 9 and hour <= 18";

		$results = $this->_db->fetchAll($sql);
		return $results;
	}

	/**
	 * gets the avg leads per hour from 0900 - 1800
	 * for the last 7 days
	 * @return array
	 */
	public function hourlyAvgForThePastWeek()
	{
		$sql = "SELECT 
				ROUND(AVG(hourly_totals.total),0) as averageLeads,
				hourly_totals.hour,
				CONCAT(hourly_totals.hour, ':00') as prettyHour
				FROM (
					select 
					count(1) as total,
						originaldate,
						LEFT(originaltime,2) as hour
						from Leads 
						where originaldate >= (curdate() - INTERVAL 7 DAY) and originaldate < curdate()
						GROUP BY originaldate,
						LEFT(originaltime,2)
					) as hourly_totals 
					GROUP BY hourly_totals.hour 
					having hourly_totals.hour >= 9 and hourly_totals.hour <= 18";

		$results = $this->_db->fetchAll($sql);
		return $results;
	}

	/**
	 * gets the avg leads per hour from 0900 - 1800 
	 * for a specific day, looking back 6 weeks.
	 * e.g. last 6 'Mondays', 2012-12-31, 2012-12-24, etc.
	 *
	 * @param string $dayOfWeekDates comma-delim string of 6 dates for a specific day
	 * @return array
	 */
	public function hourlyAvgForSpecificDay($dayOfWeekDates)
	{
		$sql = "SELECT 
			ROUND(AVG(hourly_totals.total),0) as averageLeads,
				hourly_totals.hour,
				CONCAT(hourly_totals.hour, ':00') as prettyHour
			FROM
			(
				select 
				count(1) as total,
				originaldate,
				LEFT(originaltime,2) as hour
				from Leads 
				where originaldate IN ($dayOfWeekDates)
				GROUP BY originaldate,
				LEFT(originaltime,2) 
			) as hourly_totals 
			GROUP BY hourly_totals.hour 
			having hourly_totals.hour >= 9 and hourly_totals.hour <= 18";

		$results = $this->_db->fetchAll($sql);
		return $results;
	}
}
