<?php

class PreScrubLog extends Zend_Db_Table
{
	protected $_name = 'PreScrubLogs';

	public function init()
	{
		$bootstrap = Zend_Controller_Front::getInstance()->getParam("bootstrap");
		$resource = $bootstrap->getPluginResource('multidb');
		$this->db_slave = $resource->getDb('slave');
	}

	public function getVendorNameDenyQuery() {

		$sql = $this->db_slave->select()
			->from("PreScrubLogs", array())
			->joinInner("PostLogs", "PostLogs.leadID = PreScrubLogs.leadID", array())
			->joinInner("VendorPostSetups", "PostLogs.postSetupID = VendorPostSetups.postSetupID", array())
			->joinInner("Vendors", "VendorPostSetups.vendorID = Vendors.id", array("vendorName"=>"company"))
			->where('PreScrubLogs.leadID = Leads.id')
			->where('Vendors.id = 1005 OR Vendors.id = 1006')
			->where('PostLogs.postStatus = "no"')
			->where('PreScrubLogs.denyDescription is not null')
			->where('PreScrubLogs.denyDescription != ""')
			->limit(1);

		return $sql;
	}

	public function getVendorDenyReasonQuery() {

		$sql = $this->db_slave->select()
			->from("PreScrubLogs", array('denyDescription'))
			->joinInner("PostLogs", "PostLogs.leadID = PreScrubLogs.leadID", array())
			->where('PreScrubLogs.leadID = Leads.id')
			->where('PreScrubLogs.denyDescription is not null')
			->where('PreScrubLogs.denyDescription != ""')
			->where('PostLogs.postStatus = "no"')
			->limit(1);

		return $sql;
	}
}
