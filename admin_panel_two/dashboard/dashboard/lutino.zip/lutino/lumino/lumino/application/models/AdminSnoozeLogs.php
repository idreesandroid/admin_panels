<?php
class AdminSnoozeLogs extends Zend_Db_Table
{
	protected $_name = 'AdminSnoozeLogs';

	public function upsertCampaignLogAndEmail($campaignID,$status)
	{
	    $startTime = $endTime = NULL;
	    $UserSession = new Zend_Session_Namespace('UserSession');
	    $SnoozeLogsEmailer = new SnoozeLogsEmailer();

	    $adminUserID = $UserSession->userid;

	    if($status == "P") {
	        $startTime = date("Y-m-d H:i:s");
	    }
	    else if ($status == "R"){
	        $endTime = date("Y-m-d H:i:s");
	    }
	    $sql = $this->_db->select()
			->from($this->_name)
			->join('Campaigns','Campaigns.id = '.$this->_name.".campaignID",array('title','masteraff'))
			->where('campaignID = ?',$campaignID)
			->Order("id desc")
			->limit(1);

	    $result = $this->_db->fetchRow($sql);

	    if($result) { // we have a matching row
	        if ($status == 'R') {
	            $endDate = new DateTime($endTime);
	            $diff =  $endDate->diff(new DateTime($result['startTime']));

	            $body = "Campaign ID:".$campaignID."\nTitle:".$result['title']."\nMaterAff:".$result['masteraff'].
	            "\nhas been resumed at:".$endTime." with Snooze time: ".$result['startTime']."\nhaving time interval\n".
	            $diff->days." days\n".$diff->i." minutes\n".$diff->s." seconds";

	            $this->update(array('endTime' => $endTime),"id = ".$result['id']." AND ".$this->_db->quoteInto("campaignID = ?", $campaignID));
	        }
	        else if ($status == 'P') {
	            $body = "Campaign ID:".$campaignID."\nTitle:".$result['title']."\nMaterAff:".$result['masteraff'].
	            "\nhas been paused at:".$startTime;
	            $this->insert(array('adminUserID' => $adminUserID,'campaignID' => $campaignID,'startTime' => $startTime,'postSetupID' => NULL));
	        }
	    }
	    else {
	        $campaigns = new Campaigns();
	        $campaignRow = $campaigns->fetchRow("id = $campaignID");

	        if ($status == 'R') {
	            $body = "Campaign ID:".$campaignID."\nTitle:".$campaignRow['title']."\nMaterAff:".$campaignRow['masteraff'].
	            "\nhas been resumed at:".$endTime. " with Snooze time unknown";
	            $this->insert(array('adminUserID' => $adminUserID,'campaignID' => $campaignID,'endTime' => $endTime,'postSetupID' => NULL));
	        }
	        else {
	            $body = "Campaign ID:".$campaignID."\nTitle:".$campaignRow['title']."\nMaterAff:".$campaignRow['masteraff'].
	            "\nhas been paused at:".$startTime;
	            $this->insert(array('adminUserID' => $adminUserID,'campaignID' => $campaignID,'startTime' => $startTime,'postSetupID' => NULL));
	        }
	    }

	    //$SnoozeLogsEmailer->execute($body);
	}

	public function upsertBuyerTierLogAndEmail($postsetupID,$status)
	{
	    $startTime = $endTime = NULL;
	    $UserSession = new Zend_Session_Namespace('UserSession');
	    $SnoozeLogsEmailer = new SnoozeLogsEmailer();

	    $adminUserID = $UserSession->userid;

	    if($status == "P") {
	        $startTime = date("Y-m-d H:i:s");
	    }
	    else if ($status == "R"){
	        $endTime = date("Y-m-d H:i:s");
	    }

	    $sql = $this->_db->select()
	    ->from($this->_name)
	    ->where($this->_name.'.postSetupID = ?',$postsetupID)
	    ->join('PostSetups','PostSetups.id = '.$this->_name.".postSetupID",array('title'))
	    ->join('ClientPostSetups','ClientPostSetups.postSetupID = PostSetups.id',array('clientID'))
	    ->Order("id desc")
	    ->limit(1);

	    $result = $this->_db->fetchRow($sql);

	    if($result) { // we have a matching row
	        if ($status == 'R') {
	            $endDate = new DateTime($endTime);
	            $diff =  $endDate->diff(new DateTime($result['startTime']));

	            $body = "PostSetupID:".$postsetupID."\nClientID:".$result['clientID']."\nTitle:".$result['title'].
	            "\nhas been resumed at:".$endTime." with Snooze time: ".$result['startTime']."\nhaving time interval\n".
	            $diff->days." days\n".$diff->i." minutes\n".$diff->s." seconds";

	            $this->update(array('endTime' => $endTime),"id = ".$result['id']." AND ".$this->_db->quoteInto("postSetupID = ?", $postsetupID));
	        }
	        else if ($status == 'P') {
	            $body = "PostSetupID:".$postsetupID."\nClientID:".$result['clientID']."\nTitle:".$result['title'].
	            "\nhas been paused at:".$startTime;
	            $this->insert(array('adminUserID' => $adminUserID,'postSetupID' => $postsetupID,'startTime' => $startTime,'campaignID' => NULL));
	        }
	    }
	    else {

	        $sql = $this->_db->select()
	        ->from('PostSetups',array('title'))
	        ->where('id = ?',$postsetupID)
	        ->join('ClientPostSetups','ClientPostSetups.postSetupID = PostSetups.id',array('clientID'))
	        ->Order("id desc")
	        ->limit(1);

	        $postsetupRow = $this->_db->fetchRow($sql);

	        if ($status == 'R') {
	            $body = "PostSetupID:".$postsetupID."\nClientID:".$postsetupRow['clientID']."\nTitle:".$postsetupRow['title']."\nhas been resumed at:".$endTime. " with Snooze time unknown";
	            $this->insert(array('adminUserID' => $adminUserID,'postSetupID' => $postsetupID,'endTime' => $endTime,'campaignID' => NULL));
	        }
	        else {
	            $body = "PostSetupID:".$postsetupID."\nClientID:".$postsetupRow['clientID']."\nTitle:".$postsetupRow['title']."\nhas been paused at:".$startTime;
	            $this->insert(array('adminUserID' => $adminUserID,'postSetupID' => $postsetupID,'startTime' => $startTime,'campaignID' => NULL));
	        }
	    }

	    //$SnoozeLogsEmailer->execute($body);
	}
}
?>
