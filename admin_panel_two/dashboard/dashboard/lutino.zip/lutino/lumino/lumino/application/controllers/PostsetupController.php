<?php
class PostsetupController extends Zend_Controller_Action
{
	private $baseurl;

	function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if(!$AdminNameSpace->userid)
		{
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();

		$this->PostDelivery = new PostDelivery();

	}

		function createAction()
		{
			global $db;
			$obj = new Commonfunctions();
			$message = "";
			$error = 0;
			$success = 0;
			$testbutton = 0;
			$indextodays = array(1=>"sunday",2=>"monday",3=>"tuesday",4=>"wednesday",5=>"thursday",6=>"friday",7=>"saturday");

			$post_submitter	= new TestPostSubmitter();

 		 	if ($this->_request->isPost())
			{
				$test = @($_POST['test_x']);

				$companyid = $this->_request->getPost('companyid');
				$postSetupType = $this->_request->getPost('postSetupType');
				$status = $this->_request->getPost('status');
				$deliverytype = $this->_request->getPost('deliverytype');
				$productCode = $this->_request->getPost('productcode');
				$clienttype = $this->_request->getPost('clienttype');
				$monetaryValue = $this->_request->getPost('monetaryValue');
				$priority = $this->_request->getPost('priority');
				$testurl = $this->_request->getPost('testurl');
				$posturl = $this->_request->getPost('posturl');
				$postheader = $this->_request->getPost('postheader');
				$classname = $this->_request->getPost('classname');
				$postingclassname = $this->_request->getPost('postingclassname');
				$translation = $this->_request->getPost('translation');
				$poststring = $this->_request->getPost('poststring');
				$days = $_POST['days'];
				$holiday = $this->_request->getPost('holidays');
				$skipdupecheck = $this->_request->getPost('skipdupecheck');
				$leadsperhour = $this->_request->getPost('leadsperhour');
				$leadsperday = $this->_request->getPost('leadsperday');
				$leadspermonth = $this->_request->getPost('leadspermonth');
				$leadsperlife = $this->_request->getPost('leadsperlife');
				$posttimout = $this->_request->getPost('posttimeout');
				$comments = $this->_request->getPost('comments');
				$title = $this->_request->getPost('title');
				$blackoutTitles = $this->_request->getPost('blackouttitle');
				$blackoutDates = $this->_request->getPost('blackoutdate');
				$blackoutFromTimes = $this->_request->getPost('blackoutfromtime');
				$blackoutToTime = $this->_request->getPost('blackouttotime');

				if(!$posttimout)
					$posttimout = null;

				if(!$monetaryValue) $monetaryValue = 0;


				if(empty($postSetupType)){
					$message.="Please select the post setup type.<br>";
					$error = 1;
				}

				if(empty($companyid)){
					$message.="Please select the company.<br>";
					$error = 1;
				}

				if(!is_numeric($monetaryValue)){
					$message.="Cost/Price must be numeric.<br>";
					$error = 1;
				}
				if(empty($productCode)){
					$message.="Please provide productcode.<br>";
					$error = 1;
				}
				if(!is_numeric($priority)){
					$message.="Priority must be numeric.<br>";
					$error = 1;
				}
				if(empty($posturl)){
					$message.="Please provide Post url.<br>";
					$error = 1;
				}
				if(empty($classname)){
					$message.="Please provide class name.<br>";
					$error = 1;
				}
				if(!is_numeric($leadsperhour)){
					$message.="Leads per hour must be numeric.<br>";
					$error = 1;
				}
				if(!is_numeric($leadsperday)){
					$message.="Leads per day must be numeric.<br>";
					$error = 1;
				}
				if(!is_numeric($leadspermonth)){
					$message.="Leads per month must be numeric.<br>";
					$error = 1;
				}
				if(!is_numeric($leadsperlife)){
					$message.="Leads per life must be numeric.<br>";
					$error = 1;
				}
				if(empty($poststring)){
					$message.="Please provide post string.<br>";
					$error = 1;
				}
				if(empty($title)){
					$message.="Please provide title.<br>";
					$error = 1;
				}

				if($error==0)
				{
					$Form_Data = array('active'=>$status,
						'static'=>$clienttype,
						'priority'=>$priority,
						'postDeliverytype'=>$deliverytype,
						'postHeader'=>$postheader,
						'postURL'=>$posturl,
						'postTestURL'=>$testurl,
						'postQueryString'=>$poststring,
						'postTranslation'=>$translation,
						'postTimeout'=>$posttimout,
						'className'=>$classname,
						'postingClassName'=>$postingclassname,
						'deliveryHolidays'=>$holiday,
						'skipDupeCheck'=>$skipdupecheck,
						'leadsPerDay'=>$leadsperday,
						'leadsPerHour' => $leadsperhour,
						'leadsPerMonth'=>$leadspermonth,
						'leadsPerLife'=>$leadsperlife,
						'comments'=>$comments,
						'title' => $title);

					$ps = new PostSetups();
					try
					{
				 		$postSetupID = $ps->insert($Form_Data);
				 		$message = "Post setup successfully created.";

						// populating join tables
						if($postSetupType == "Vendor")
						{
							$VendorPostSetups = new VendorPostSetups();
							$vendorPostData = array('vendorID'=>$companyid,
								'postSetupID'=>$postSetupID,
								'productCode'=>$productCode,
								'cost'=>$monetaryValue);
							$VendorPostSetups->insert($vendorPostData);
						}
						if($postSetupType == "Client")
						{
							$ClientPostSetups = new ClientPostSetups();
							$clientPostData = array('clientID'=>$companyid,
								'postSetupID'=>$postSetupID,
								'productCode'=>$productCode,
								'markupValue'=>$monetaryValue);
					 		$ClientPostSetups->insert($clientPostData);

					 		if (count($blackoutDates) > 0){

					 		    $BlackoutDays = new BlackoutDays();

					 		    for ($a=0;$a<count($blackoutDates);$a++) {

					 		        if (!empty($blackoutDates[$a]) && !empty($blackoutFromTimes[$a]) && !empty($blackoutToTime[$a])) {
					 		            $BlackoutDays->insert(array('title' => $blackoutTitles[$a], 'postSetupID' => $postSetupID,
					 		                'blackoutDate' => date("Y-m-d",strtotime($blackoutDates[$a])), 'blackoutStartTime' => $blackoutFromTimes[$a],
					 		                'blackoutEndTime' => $blackoutToTime[$a], 'createdAt' => date("Y-m-d") ));
					 		        }
					 		    }
					 		}
						}

					 	$success = 1;
						return $this->_helper->redirector('redirect','postsetup',NULL,array('setupid' => $postSetupID,'setuptype' => $postSetupType));
					 }
					 catch (Zend_Exception $e)
					 {
					 		$error = 1;
							$message = "Error: ".$e->getMessage().".";
					 }
				}

				if ($error==1)
				{
					$this->view->companyid = $companyid;
					//TODO pass this back and do an onLoad to display the client/vendor
					//drop down based on initial setting
					$this->view->status = $status;
					$this->view->postmethod = $deliverytype;
					$this->view->productcode = $productCode;
					$this->view->clienttype = $clienttype;
					$this->view->priority = $priority;
					$this->view->testurl = $testurl;
					$this->view->postingurl = $posturl;
					$this->view->postheader = $postheader;
					$this->view->classname = $classname;
					$this->view->postingclassname = $postingclassname;
					$this->view->translation = $translation;
					$this->view->poststring = $poststring;
					$this->view->posttimeout = $posttimout;

					$this->view->checkboxarray = $days;
					$this->view->rangevalues = $obj->setpostvalues($_POST,$days,$indextodays);
					$this->view->holiday = $holiday;
					$this->view->skipdupecheck = $skipdupecheck;
					$this->view->leadsperhour = $leadsperhour;
					$this->view->leadsperday = $leadsperday;
					$this->view->leadspermonth = $leadspermonth;
					$this->view->leadsperlife = $leadsperlife;
					$this->view->comments = $comments;
					$this->view->title = $title;
					$this->view->blackouttitle = $blackoutTitles;
					$this->view->blackoutdate = $blackoutDates;
					$this->view->blackoutfromtime = $blackoutFromTimes;
					$this->view->blackouttotime = $blackoutToTime;

				}
				if($success==1){
					$this->view->message = "Post Setup Created…";
					$this->view->checkboxarray = array("1","2","3","4","5","6","7");
					$this->view->rangevalues = $obj->setdefaultvalues($indextodays);
					$this->view->timeblocks = $timeBlocks;
				}
			}
			else {
				$this->view->checkboxarray = array("1","2","3","4","5","6","7");
				$this->view->rangevalues = $obj->setdefaultvalues($indextodays);
				$this->view->leadsperhour = 10;
				$this->view->leadsperday = 1000;
				$this->view->leadspermonth = 10000;
				$this->view->leadsperlife = 100000;
			}

			$Clients = new Clients();
			$clients = $Clients->fetchAll("productCode='$productCode'","company");

			$PostSetups = new PostSetups();
			$settings = $PostSetups->getAllClientPostSetups();

			$cashlegends = $post_submitter->getCashLegend();
			$legends = $post_submitter->prepareLegendsForView($cashlegends);

			$this->view->legends = $legends;
			$this->view->baseurl = $this->baseurl;
			$this->view->message = $message;
			$this->view->error = $error;
			$this->view->success = $success;
			$this->view->lmdata = $clients;
			$this->view->settings = $settings;
		}

	function redirectAction()
	{
	    $postsetupID = $this->_request->setupid;
	    $postsetupType = $this->_request->setuptype;

	    $this->view->postsetupID = $postsetupID;
	    $this->view->postsetupType = $postsetupType;
	}

	function editsetupAction()
		{
			$id = $_REQUEST['id'];

			$obj = new Commonfunctions();
			$message = "";
			$error = 0;
			$success = 0;
			$testbutton = 0;
			$indextodays = array(1=>"sunday",2=>"monday",3=>"tuesday",4=>"wednesday",5=>"thursday",6=>"friday",7=>"saturday");

			$PostSetups = new PostSetups();
			$postSetupType = $PostSetups->getPostSetupType($id);

			$post_submitter	= new TestPostSubmitter();

			// select box values
			$Campaign = new Campaigns();
			$campaigns = $Campaign->fetchAll();

 		 	if ($this->_request->isPost() && is_numeric($id))
			{

				$test = @($_POST['test']);

				// campaign caps
				$ClientCap = new ClientCampaignLeadCap();
				// easier to first delete whats there and then re-add
				$ClientCap->delete("postSetupID = '$id'");

				if(isset($this->_request->campaigncaps) && is_array($this->_request->campaigncaps)) {
					foreach ($this->_request->campaigncaps as $k => $v) {
						$row = array('postSetupID' => $id,
								'campaignID' => $v,
								'percentCap' => $this->_request->campaignpercents[$k]);
						$ClientCap->insert($row);
					}
				}

				$companyid = $this->_request->getPost('companyid');
				$status = $this->_request->getPost('status');
				$deliverytype = $this->_request->getPost('deliverytype');
				$productCode = $this->_request->getPost('productcode');
				$clienttype = $this->_request->getPost('clienttype');
				$monetaryvalue = $this->_request->getPost('monetaryvalue');
				$priority = $this->_request->getPost('priority');
				$testurl = $this->_request->getPost('testurl');
				$posturl = $this->_request->getPost('posturl');
				$postheader = $this->_request->getPost('postheader');
				$classname = $this->_request->getPost('classname');
				$postingclassname = $this->_request->getPost('postingclassname');
				$translation = $this->_request->getPost('translation');
				$poststring = $this->_request->getPost('poststring');
				$days = $_POST['days'];
				$holiday = $this->_request->getPost('holidays');
				$skipdupecheck = $this->_request->getPost('skipdupecheck');
				$leadsperday = $this->_request->getPost('leadsperday');
				$leadspermonth = $this->_request->getPost('leadspermonth');
				$leadsperlife = $this->_request->getPost('leadsperlife');
				$posttimout = $this->_request->getPost('posttimeout');
				$comments = $this->_request->getPost('comments');
 		 		$leadsperhour = $this->_request->getPost('leadsperhour');
 		 		$markupvaluetype = $this->_request->getPost('markupvaluetype');
 		 		$qualifyingTierPrice = $this->_request->getPost('qualifyingTierPrice');
				$title = $this->_request->getPost('title');
				$pauseleads = $this->_request->getPost('pauseleads');
				$blackoutTitles = $this->_request->getPost('blackouttitle');
				$blackoutDates = $this->_request->getPost('blackoutdate');
				$blackoutFromTimes = $this->_request->getPost('blackoutfromtime');
				$blackoutToTime = $this->_request->getPost('blackouttotime');
				$custompoststring = $this->_request->getPost('custompoststring');

				if(!$posttimout)
					$posttimout = null;

				if($postSetupType == "Client")
				{
					if(!is_numeric($qualifyingTierPrice) || empty($qualifyingTierPrice)){
						$message.="Please provide minimum price.<br>";
						$error = 1;
					}
				}

	 			if(empty($id)){
					$message.="Company ID not found.<br>";
					$error = 1;
				}

				if(empty($companyid)){
					$message.="Please select the company.<br>";
					$error = 1;
				}

				if(!is_numeric($monetaryvalue)){
					$message.="Cost/Price must be numeric.<br>";
					$error = 1;
				}
				if(empty($productCode)){
					$message.="Please provide productcode.<br>";
					$error = 1;
				}
				if(!is_numeric($priority)){
					$message.="Priority must be numeric.<br>";
					$error = 1;
				}
				if(empty($posturl)){
					$message.="Please provide Post url.<br>";
					$error = 1;
				}
				if(empty($classname)){
					$message.="Please provide class name.<br>";
					$error = 1;
				}
				if(!is_numeric($leadsperhour)){
					$message.="Leads per hour must be numeric.<br>";
					$error = 1;
				}
				if(!is_numeric($leadsperday)){
					$message.="Leads per day must be numeric.<br>";
					$error = 1;
				}
				if(!is_numeric($leadspermonth)){
					$message.="Leads per month must be numeric.<br>";
					$error = 1;
				}
				if(!is_numeric($leadsperlife)){
					$message.="Leads per life must be numeric.<br>";
					$error = 1;
				}
				if(empty($poststring)){
					$message.="Please provide post string.<br>";
					$error = 1;
				}
				if(empty($title)){
					$message.="Please provide title.<br>";
					$error = 1;
				}

				if($error==0)
				{
					if($test)
					{
						if (strlen($custompoststring) > 0) {
						    $result_array = $post_submitter->Translate_Postdata($testurl,$postheader,$translation,$custompoststring,$deliverytype);
						}
						else {
						    $result_array = $post_submitter->Translate_Postdata($testurl,$postheader,$translation,$poststring,$deliverytype);
						}

						$this->view->response = "Query String:\n".$result_array[0]."\n\nResult:\n".$result_array[1] ."\n\nApproved:\n". $result_array[2] ."\n\nResponse description:\n". $result_array[4];
						$testbutton = 1;
						$error = 1;
					}

					$Form_Data = array('active'=>$status,
										'static'=>$clienttype,
										'priority'=>$priority,
										'postDeliverytype'=>$deliverytype,
										'postHeader'=>$postheader,
										'postURL'=>$posturl,
										'postTestURL'=>$testurl,
										'postQueryString'=>$poststring,
										'postTranslation'=>$translation,
										'postTimeout'=>$posttimout,
										'className'=>$classname,
										'postingClassName' => $postingclassname,
										'deliveryHolidays'=>$holiday,
										'skipDupeCheck'=>$skipdupecheck,
										'leadsPerDay'=>$leadsperday,
										'leadsPerHour' => $leadsperhour,
										'leadsPerMonth'=>$leadspermonth,
										'leadsPerLife'=>$leadsperlife,
										'comments'=>$comments,
										'title' => $title,
										'paused' => $pauseleads);

					$ps = new PostSetups();

					try
					{
				 		$where = "id=$id";
						$ps->update($Form_Data,$where);
				 		$message = "Post setup successfully updated.";

						// TODO: this really needs to be extracted
						if($postSetupType == "Vendor")
						{
							$VendorPostSetups = new VendorPostSetups();
							$vendorPostData = array('vendorID'=>$companyid,'postSetupID'=>$id,
																			'productCode'=>$productCode,'cost'=>$monetaryvalue);
							$where = "postSetupID = $id AND vendorID = $companyid";
							$VendorPostSetups->update($vendorPostData,$where);

							// also updating VendorStrategies classname field
							$VendorStrategies = new VendorStrategies();
							$VendorStrategies->update(array('className' => $postingclassname), "vendorID = $companyid");
						}
						if($postSetupType == "Client")
						{
							$ClientPostSetups = new ClientPostSetups();
					 		$clientPostData = array('clientID'=>$companyid,
													'postSetupID'=>$id,
													'productCode'=>$productCode,
													'markupValue'=>$monetaryvalue,
													'markupvaluetype'=>$markupvaluetype,
													'qualifyingTierPrice'=>$qualifyingTierPrice);
							$where = "postSetupID = $id AND clientID = $companyid";
					 		$ClientPostSetups->update($clientPostData,$where);

					 		if (count($blackoutDates) > 0){

					 		    $BlackoutDays = new BlackoutDays();
					 		    $BlackoutDays->delete("postSetupID>=$id");

					 		    for ($a=0;$a<count($blackoutDates);$a++) {

					 		        if (!empty($blackoutDates[$a]) && !empty($blackoutFromTimes[$a]) && !empty($blackoutToTime[$a])) {
					 		            $BlackoutDays->insert(array('title' => $blackoutTitles[$a], 'postSetupID' => $id,
					 		                'blackoutDate' => date("Y-m-d",strtotime($blackoutDates[$a])), 'blackoutStartTime' => $blackoutFromTimes[$a],
					 		                'blackoutEndTime' => $blackoutToTime[$a], 'createdAt' => date("Y-m-d")));
					 		        }
					 		    }
					 		}
						}

					 	$success = 1;
					 }
					 catch (Zend_Exception $e)
					 {
					 		$error = 1;
							$message = "Error(s): ".$e->getMessage().".";
					 }
				}
				if ($error==1 || $testbutton==1)
				{
					$this->view->id = $id;
					$this->view->companyid = $companyid;
					$this->view->active = $status;
					$this->view->postdeliverytype = $deliverytype;
					$this->view->productcode = $productCode;
					$this->view->static = $clienttype;
					$this->view->priority = $priority;
					if($postSetupType == "Client") {
						$this->view->qualifyingTierPrice = $qualifyingTierPrice;
					}
					$this->view->monetaryvalue = $monetaryvalue;
					$this->view->testurl = $testurl;
					$this->view->postingurl = $posturl;
					$this->view->postheader = $postheader;
					$this->view->classname = $classname;
					$this->view->postingclassname = $postingclassname;
					$this->view->translation = $translation;
					$this->view->poststring = $poststring;
					$this->view->posttimeout = $posttimout;

					$this->view->checkboxarray = $days;
					$this->view->rangevalues = $obj->setpostvalues($_POST,$days,$indextodays);
					$this->view->holiday = $holiday;
					$this->view->skipdupecheck = $skipdupecheck;
					$this->view->leadsperhour = $leadsperhour;
					$this->view->leadsperday = $leadsperday;
					$this->view->leadspermonth = $leadspermonth;
					$this->view->leadsperlife = $leadsperlife;
					$this->view->comments = $comments;
					$this->view->timeblocks = $timeBlocks;
					$this->view->title = $title;
					$this->view->custompostquerystring = $custompoststring;

					error_log(__LINE__.'error==1 and testbutton==1');
				}
				if($success==1){
					if($postSetupType == "Client") {
						$this->view->qualifyingTierPrice = $qualifyingTierPrice;
					}
					$this->view->checkboxarray = array("1","2","3","4","5","6","7");
					$this->view->rangevalues = $obj->setdefaultvalues($indextodays);
					$this->view->timeblocks = $timeBlocks;
					$this->view->message = "Configuratiion saved";
					error_log(__LINE__."sucess==1");
				}

				$tuple = array();
				for ($a=0;$a<count($blackoutDates);$a++) {
				    $tuple[] = array('title' => $blackoutTitles[$a],'blackoutDate' => $blackoutDates[$a],
				        'blackoutStartTime' => $blackoutFromTimes[$a], 'blackoutEndTime' => $blackoutToTime[$a]);
				}
				$this->view->blackout = $tuple;
			}
			else
			{
				if($postSetupType == "Client") {
					$ClientPostSetups = new ClientPostSetups();
					$where = "postSetupID = $id";
					$result = $ClientPostSetups->fetchRow($where);
					$this->view->qualifyingTierPrice = $result->qualifyingTierPrice;
				}

				$this->view->checkboxarray = array("1","2","3","4","5","6","7");
				$this->view->rangevalues = $obj->setdefaultvalues($indextodays);
				$this->view->leadsperhour = 10;
				$this->view->leadsperday = 1000;
				$this->view->leadspermonth = 10000;
				$this->view->leadsperlife = 100000;
			}

			if (!$this->_request->isPost()) {

			    $BlackoutDays = new BlackoutDays();
			    $blackout = $BlackoutDays->fetchAll("postSetupID = $id");
			    $this->view->blackout = $blackout;
			}

			$PostDelivery = new PostDelivery();
			$rows = $PostDelivery->fetchAll("postSetupID = $id");

			$this->view->success = 1;
			$this->view->message = "Config Saved";

			$Clients = new Clients();
			$clients = $Clients->fetchAll("productCode='cash'","company");

			$settings = $PostSetups->getPostSetupData($id);

			if ($settings) {
				foreach ($settings as $key => $value) {
					$key = strtolower($key);
					$this->view->$key = $value;
				}
			}

			$cashlegends = $post_submitter->getCashLegend();
			$legends = $post_submitter->prepareLegendsForView($cashlegends);

			// current campaign caps
			$ClientCap = new ClientCampaignLeadCap();
			$currentCampaignCaps = $ClientCap->fetchAll("postSetupID = " . $id);

			$deliveryDays = $this->PostDelivery->getDeliveryTimesForPostSetup($id);

			$this->view->daysOfWeek = DateUtility::getDaysOfWeek();
			$this->view->deliveryDays = $deliveryDays;

			$this->view->postsetuptype = $postSetupType;
			$this->view->monetarylabel = ($postSetupType == "Vendor") ? "Cost" : "Price";
			$this->view->legends = $legends;
			$this->view->baseurl = $this->baseurl;
			$this->view->message = $message;
			$this->view->error = $error;
			$this->view->success = $success;
			$this->view->lmdata = $clients;
			if ($settings) {
				$this->view->settings = $settings;
			}
			$this->view->campaigns = $campaigns;
			$this->view->currentCampaignCaps = $currentCampaignCaps;
		}

	function viewAction()
	{
		$postSetupType = (isset($this->_request->type)) ? $this->_request->type : "Client";
		$this->view->type = $postSetupType;

		if($postSetupType =='Vendor')
			$this->view->type = 'Data Provider';

		$activePostSetups = array();
		$inactivePostSetups = array();

		$sortby = @$_REQUEST['sortby'];
		$sortorder = @$_REQUEST['order'];

		if($sortorder=="desc")
			$order = SORT_DESC;
		if($sortorder=="asc")
			$order = SORT_ASC;

		if ($postSetupType == 'Client')
		{
			$productCode = "cash";
			$PostSetups = new PostSetups();
			$postSetups = $PostSetups->getClientPostSetupStatuses($productCode);
			foreach($postSetups as $data) {
				if ($data['pactive'] == 1 && $data['xactive'] == 1) {
				    $activePostSetups[] = $data;
				}
				else {
				    $inactivePostSetups[] = $data;
				}
			}

		}
		elseif ($postSetupType == 'Vendor')
		{
			$productCode = "scoring";
			$PostSetups = new PostSetups();
			$postSetups = $PostSetups->getVendorPostSetupStatuses($productCode);
		}

		if($sortby&&$sortorder)
		{
			$sortedcolumn = array();
			foreach ($postSetups as $ind=> $data)
			{
				$sortedcolumn[$ind] = $data[$sortby];
			}
			array_multisort($sortedcolumn,$order,$postSetups);
		}

		if($sortorder=="asc")
			$sortorder = "desc";
		elseif ($sortorder == "desc")
			$sortorder = "asc";
		elseif(!$sortorder)
			$sortorder = "asc";
		$this->view->baseurl = $this->baseurl;
		$this->view->sortorder = $sortorder;
		$this->view->data = $postSetups;
		$this->view->inactivepostsetups = $inactivePostSetups;
		$this->view->activepostsetups = $activePostSetups;

	}

	function deleteAction()
	{
		$id= $_GET['id'];
		if ($id > 0)
		{
			$PostSetups	= new PostSetups();
			$postSetupType = $PostSetups->getPostSetupType($id);

			$where = "id=$id";
 			$PostSetups->delete($where);

			if($postSetupType == "Vendor")
			{
				$VendorPostSetups = new VendorPostSetups();
				$where = "postSetupID = $id";
				$VendorPostSetups->delete($where);
			}
			if($postSetupType == "Client")
			{
				$ClientPostSetups = new ClientPostSetups();
				$where = "postSetupID = $id";
		 		$ClientPostSetups->delete($where);

		 		$BlackoutDays = new BlackoutDays();
		 		$BlackoutDays->delete($where);
			}
		}

		$this->_redirect('postsetup/view?type='.$postSetupType);
	}

	function pauseresumeAction() {

	    $this->_helper->viewRenderer->setNoRender(TRUE);

	    $postsetupID = $this->_request->getPost('id');
	    $status = $this->_request->getPost('status');

	    $PostSetups = new PostSetups();
	    $AdminSnoozeLogs = new AdminSnoozeLogs();

	    $AdminSnoozeLogs->upsertBuyerTierLogAndEmail($postsetupID, $status);
	    $row = $PostSetups->fetchRow($PostSetups->select()->where('id = ?', $postsetupID));

	    if ($status == "P") {
	        $row->paused = 1;
	    }
	    else if ($status == "R") {
	        $row->paused = 0;
	    }
	    $row->save();

	    echo '{"status": "OK"}';
	}
}
?>