<?php
class AffiliateController extends Zend_Controller_Action 
{
    private $baseurl;
	
	function init()
    {
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if(!$AdminNameSpace->userid)
		{
	    		$this->_redirect('index/login');	
		}
	    $this->baseurl = $this->_request->getBaseUrl();
    }
    
    
    function addAction()
    {
    	$message = "";
    	$error = 0;
    	$success = 0;
    	
    	if ($this->_request->isPost()) 
			{
    		$commonobj = new Commonfunctions();
    		
				$f = new Zend_Filter_StripTags();
				$columns = array();
			
    		$masteraffilaite = $f->filter($this->_request->getPost('masteraff'));
    		$password        = $f->filter($this->_request->getPost('password'));	
    		$email           = $f->filter($this->_request->getPost('email'));	
    		$company         = $f->filter($this->_request->getPost('company'));	
    		$header          = $f->filter($this->_request->getPost('header'));	
    		$columns         = @$_POST['reports'];
			$active          = $this->_request->getPost('active');
			
    		if(count($columns)==0) $columns = array();

    		$csv = "";
    		if(count($columns))
    		for ($a=0;$a<count($columns);$a++)
    		$csv.=$columns[$a].",";
    		if($csv)
    		$csv = substr($csv,0,strlen($csv)-1);

    		if(empty($masteraffilaite)){
    			$message.="Please provide master affiliate.<br>";
    			$error = 1;
    		}
    		if(empty($password)){
    			$message.="Please provide password.<br>";
    			$error = 1;
    		}
    		if(empty($email)){
    			$message.="Please provide email.<br>";
    			$error = 1;
    		}
    		if(!empty($email)){
    			if($commonobj->isvalidemail($email)==0){
    			$message.="Invalid email.<br>";
    			$error = 1;
    			}
    		}
    		if(empty($company)){
    			$message.="Please provide company.<br>";
    			$error = 1;
    		}
			
    		if($error==0)
    		{

    			$Form_Data = array('masteraff'=>$masteraffilaite,'email'=>$email,'password'=>$password,'company'=>$company,'dynamicheader'=>$header
    			,'reportcolumns'=>$csv,'active' => $active);
		    
			    $ae_Data  = new Affiliates();
			    try 
			    { 
			   		$ae_Data->insert($Form_Data);	
			   		$message = "Affiliate successfully added.";	

					return $this->_helper->redirector('view','affiliate');
			    }
			    catch (Zend_Exception $e)
			    {
			   		$error = 1;
			    	$message = "Some error occurred please try latter.";
			    }
    		}
    		
    		if($error==1){
    			
    		$this->view->masteraff = $masteraffilaite;
    		$this->view->email = $email;
    		$this->view->password = $password;
    		$this->view->company = $company;
    		$this->view->header = $header;
    		$this->view->columns = $columns;
			$this->view->active = $active;
    		
    		}
    		else {
    			
    		$this->view->masteraff = "";
    		$this->view->email = "";
    		$this->view->password = "";
    		$this->view->company = "";
    		$this->view->header = "";
    		$this->view->columns = array();
    		}
    		
    		
    	}
    	else {
    		$this->view->masteraff = "";
    		$this->view->email = "";
    		$this->view->password = "";
    		$this->view->company = "";
    		$this->view->header = "";
    		$this->view->columns = array();
    	}
    		
    	$this->view->baseurl = $this->baseurl;
    	$this->view->message = $message;
    	$this->view->error = $error;
    	$this->view->success = $success;
    }
    
    function viewAction()
    {
			$Affiliates = new Affiliates();
    	$accountexecutives = $Affiliates->fetchAll(NULL,"masteraff");
    	$this->view->baseurl = $this->baseurl;
    	$this->view->data = $accountexecutives;
    }
    
    function editAction()
    {
    	$id = $_REQUEST['id'];
    	
    	$message = "";
    	$error = 0;
    	$success = 0;
    	
    	if ($this->_request->isPost()) 
			{
    		$commonobj = new Commonfunctions();
    		
				$f = new Zend_Filter_StripTags();
			
    		$masteraffilaite = $f->filter($this->_request->getPost('masteraff'));
    		$password        = $f->filter($this->_request->getPost('password'));	
    		$email           = $f->filter($this->_request->getPost('email'));	
    		$company         = $f->filter($this->_request->getPost('company'));	
    		$header          = $f->filter($this->_request->getPost('header'));	
    		$columns         = @$_POST['reports'];
			$active          = $this->_request->getPost('active');
    		
    		if(count($columns)==0) $columns = array();

    		$csv = "";
    		if(count($columns))
    		for ($a=0;$a<count($columns);$a++)
    		$csv.=$columns[$a].",";
    		if($csv)
    		$csv = substr($csv,0,strlen($csv)-1);
    		
    		
    		if(empty($masteraffilaite)){
    			$message.="Please provide master affiliate.<br>";
    			$error = 1;
    		}
    		if(empty($password)){
    			$message.="Please provide password.<br>";
    			$error = 1;
    		}
    		if(empty($email)){
    			$message.="Please provide email.<br>";
    			$error = 1;
    		}
    		if(!empty($email)){
    			if($commonobj->isvalidemail($email)==0){
    			$message.="Invalid email.<br>";
    			$error = 1;
    			}
    		}
    		if(empty($company)){
    			$message.="Please provide company.<br>";
    			$error = 1;
    		}

    		if($error==0)
    		{

    			$Form_Data = array('masteraff'=>$masteraffilaite,'email'=>$email,'password'=>$password,'company'=>$company,'dynamicheader'=>$header,
    			'reportcolumns'=>$csv,'active' => $active);

			    $ae_Data  = new Affiliates();
			    try 
			    { 
			   		$where = "id = $id";
			    	$ae_Data->update($Form_Data,$where);	
			   		$message = "Affiliate successfully updated.";	
			   		$success = 1;		   		
			    }
			    catch (Zend_Exception $e)
			    {
			   		$error = 1;
			    	$message = "Some error occurred please try later.";
			    	
			    }
    		}
    		
    		if($error==1){
    			
    		$this->view->masteraff = $masteraffilaite;
    		$this->view->email = $email;
    		$this->view->password = $password;
    		$this->view->company = $company;
    		$this->view->header = $header;
    		$this->view->id = $id;
    		$this->view->columns = $columns;
			$this->view->active = $active;
    		}
    		
    	}
    	
    	if($error==0) 
    	{
			$Affiliates = new Affiliates();
    		$data = $Affiliates->fetchRow("id = $id");
    		$this->view->masteraff = $data['masteraff'];
    		$this->view->email = $data['email'];
    		$this->view->password = $data['password'];
    		$this->view->company = $data['company'];
    		$this->view->header = $data['dynamicheader'];
    		$this->view->id    = $data['id'];	
    		$this->view->columns = explode(",",$data['reportcolumns']);
			$this->view->active = $data['active'];
    	}
    	
    	$this->view->baseurl = $this->baseurl;
    	$this->view->message = $message;
    	$this->view->error = $error;
    	$this->view->success = $success;
    }
    
    function deleteAction()
    {
    	$id= $_GET['id'];
			if($id > 0)
			{
    		$where = "id=$id";
		    $ae_Data  = new Affiliates();
		    $ae_Data->delete($where);
			}
	    
	    $this->_redirect('affiliate/view');	
    }
}
?>
