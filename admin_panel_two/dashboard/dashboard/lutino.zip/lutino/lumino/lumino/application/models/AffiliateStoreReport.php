<?php
/**
 * facade class for getting reports by affiliate by store sold
 */
class AffiliateStoreReport
{
	public function __construct()
	{
		$this->db = Zend_Registry::get('db');
	}

	public function execute($fromDate, $toDate, $fromTime, $toTime)
	{
		$sql = "SELECT
			company,
			Leads.campaign,
			storeID,
			state,
			price,
			Count(1) totalPurchased,
			price * count(1) as costByProvider
			FROM Leads JOIN Affiliates ON Leads.affiliateID = Affiliates.id
			JOIN LeadSold ON Leads.id = LeadSold.leadID
			WHERE originaldate >= '$fromDate' AND originaldate <= '$toDate'
			AND originaltime >= '$fromTime' AND originaltime <= '$toTime'
			GROUP BY company, Leads.campaign, storeID, state, price";

		$reports = $this->db->fetchAll($sql);

		// add totals row
		$reports['totalsRow'] = $this->getTotalsForTotalsRow($reports);

		return $reports;
	}

	public function getTotalsForTotalsRow($reports)
	{
		$totalsRow = array();
		$totalsRow['totalPurchased'] = $this->totalsRowTotalPurchased($reports);
		$totalsRow['costByProvider'] = $this->totalsRowCostByProvider($reports);

		return $totalsRow;
	}

	public function totalsRowTotalPurchased($reports)
	{
		$total = 0;
		foreach ($reports as $report) {
			$total = $total+$report['totalPurchased'];
		}
		return $total;
	}

	public function totalsRowCostByProvider($reports)
	{
		$total = 0;
		foreach ($reports as $report) {
			$total = $total+$report['costByProvider'];
		}
		return $total;
	}
}
