<?php
/**
 * this table handles credentials for FactorTrust
 */
class TrueScoreCredentials extends Zend_Db_Table
{
	protected $_name = 'TrueScoreCredentials';
	const VENDOR_ID = 5;

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}

	public function getDefault()
	{
		$select = $this->select();
		$select->setIntegrityCheck(false);
		$select->from($this->_name, array("accountID", "apiKey"));
		$select->where("isDefault = 1");

		$row = $this->fetchRow($select);
		if ($row)
			$row = $row->toArray();

		return($row);
	}

	/**
	 * Updates or inserts a row
	 */
	public function upsert($vendorStrategyID, $insertData)
	{
		$existingRow = $this->findByVendorStrategyID($vendorStrategyID);

		if($existingRow) {
			$this->update($insertData, $this->_db->quoteInto("id = ?", $existingRow['id']));
			return $existingRow['id'];
		}
		else {
			return $this->insert($insertData);
		}
	}

	public function findByVendorStrategyID($vendorStrategyID) {
		$TrueScoreCredentialsVendorStrategy = new TrueScoreCredentialsVendorStrategy();
		$result = $TrueScoreCredentialsVendorStrategy->findByVendorStrategyID($vendorStrategyID);
		if ($result['truescoreCredentialID']) {
			$sql = $this->select()
				->where("id = " . $result['truescoreCredentialID']);
			return $this->fetchRow($sql);
		}
	}
}

