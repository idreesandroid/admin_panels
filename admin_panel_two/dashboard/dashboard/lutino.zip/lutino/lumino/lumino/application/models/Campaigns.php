<?php
class Campaigns extends Zend_Db_Table
{
	protected $_name = 'Campaigns';

	const PURCHASING_TYPE_NONE = 4;
	/**
	 * after inserting row, we need to update the campaign field
	 *
	 * @param array $data
	 * @return integer the newly created id
	 */
	public function trySave($data)
	{
		try {
			$id = $this->insert($data);
			$this->update(array('campaign' => $id), "id = $id");
		} catch (Exception $e) {
			return FALSE;
		}
		return $id;
	}

	/**
	 * Gets the affiliateID from the campaignID
	 *
	 * @param	int	$campaignID 	id of campaign
	 *
	 * @return	int			id of affiliate
	 */
	public function getAffiliateIDFromCampaignID($campaignID)
	{
		$sql = $this->_db->select()
				->from($this->_name, array())
				->join("Affiliates", "Affiliates.masteraff = " . $this->_name . ".masteraff", array("id"))
				->where($this->_db->quoteInto($this->_name . ".id = ?", $campaignID));

		$result = $this->_db->fetchRow($sql);

		if(count($result) > 0) {
			return $result['id'];
		}
		else {
			return NULL;
		}
	}

	/**
	 * Gets Distro Purchasing types by campaignID
	 *
	 * @param	int	$campaignID 	id of campaign
	 *
	 * @return	array	 bying strategies
	 */
	public function getLeadDistroPurchasingTypes($campaignID=0)
	{
		$LeadDistroPurchasingType = new LeadDistroPurchasingType();
		$select = $LeadDistroPurchasingType->select();
		$leadDistroPurchasingTypes =  $this->fetchAll($select);

		if ($leadDistroPurchasingTypes) {
			$sql = $this->_db->select()
				->from($this->_name, array("leadDistroPurchasingTypeID"))
				->join("LeadDistroPurchasingTypes", "LeadDistroPurchasingTypes.id = " . $this->_name . ".leadDistroPurchasingTypeID", array("name"))
				->where($this->_db->quoteInto($this->_name . ".id = ?", $campaignID));

			$selectedLeadDistroPurchasingType = $this->_db->fetchRow($sql);

			$result = array();

			if($selectedLeadDistroPurchasingType) {
				foreach ($leadDistroPurchasingTypes->toArray() as $value) {
					if ($selectedLeadDistroPurchasingType["leadDistroPurchasingTypeID"] == $value["id"]) {
						$value["selected"] = TRUE;
						$result[] = $value;
					} else {
						$value["selected"] = FALSE;
						$result[] = $value;
					}
				}
			} else {
				foreach ($leadDistroPurchasingTypes->toArray() as $value) {
					if ($value["id"] == self::PURCHASING_TYPE_NONE) {
						$value["selected"] = TRUE;
						$result[] = $value;
					} else {
						$value["selected"] = FALSE;
						$result[] = $value;
					}
				}
			}

			return $result;
		}

		return NULL;
	}


	/**
	 * Saves lead distro purchasing type to DB
	 * @param integer $campaignID
	 * @param integer $leadDistroPurchasingTypeID
	 * @return boolean
	 */
	public function saveLeadDistroPurchasingType($campaignID, $leadDistroPurchasingTypeID)
	{
		try {
			$this->update(array('leadDistroPurchasingTypeID' => $leadDistroPurchasingTypeID), "id = $campaignID");
		} catch (Exception $e) {
			return FALSE;
		}
	}

	/**
	 * Gets list of campaigns  based on affiliate ID
	 *
	 * @return  array campaigns
	 */
	public function getCampaignsByAffiliateID($affiliateID)
	{
	    $campaigns = array();
	    $sql = "SELECT
	    c.id,c.title
	    FROM
	    Affiliates a
	    LEFT JOIN
	    Campaigns c ON a.masteraff = c.masteraff
	    WHERE
	    campaign IS NOT NULL
	    AND
	    a.active = 1
	    AND ".$this->_db->quoteInto("a.id = ?",$affiliateID);

	    $result = $this->_db->fetchAll($sql);
	    if ($result) {
    	    foreach ($result as $value) {
    	        $campaigns[] = array('id' => $value['id'],'title' => $value['title']);
    	    }
	    }
	    return $campaigns;
	}

	/**
	 * Checks if a campaign has campaign type 'Split' Or 'Organic'
	 *
	 * @param	int	$campaignID 	id of campaign
	 *
	 * @return	boolean
	 */
	public function isCampaignSplitOrOrganicType($campaignID)
	{
		$sql = $this->_db->select()
			->from($this->_name)
			->where($this->_db->quoteInto("id = ?", $campaignID))
			->where("campaignType = 'Split' OR campaignType = 'Organic'");

		$result = $this->_db->fetchRow($sql);

		return $result ? true : false;
	}
}
