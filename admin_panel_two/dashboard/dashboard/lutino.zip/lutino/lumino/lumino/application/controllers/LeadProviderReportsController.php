<?php

/**
 * Lead Provider Reports class
 *
 * @category    Model
 * @package     none
 * @subpackage  Lead Provider Reports
 * @author      Andrew Ahn <andrewa@mediaenvy.com>
 */

set_time_limit(0);
ini_set('memory_limit','256M');

class LeadProviderReportsController extends Zend_Controller_Action
{
	public function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if(!$AdminNameSpace->userid)
		{
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();

		$this->LeadProviderReport = new LeadProviderReport();
		$this->Campaigns = new Campaigns();
		$this->Affiliates = new Affiliates();
		$this->Leads = new Leads();
	}

	public function attemptsAction()
	{
		$campaignID = ($this->_request->campaignID) ? $this->_request->campaignID : "";
		$affiliateID = ($this->_request->affiliateID) ? $this->_request->affiliateID : "";
		$affiliateName = ($this->_request->affiliateName) ? $this->_request->affiliateName : "";

		if(!empty($campaignID) && empty($affiliateID)) {
			$affiliateID = $this->Campaigns->getAffiliateIDFromCampaignID($campaignID);
		} else if (empty($campaignID) && empty($affiliateID)) {
			$data = $this->Affiliates->fetchRow($this->Affiliates->select()->where($this->Affiliates->getAdapter()->quoteInto("masteraff = ?", $affiliateName)));
			if ($data) {
				$affiliateID = $data['id'];
			}
		}

		$affiliateData = $this->Affiliates->fetchRow($this->Affiliates->select()->where($this->Affiliates->getAdapter()->quoteInto("id = ?", $affiliateID)));

		$scoreTypes = array();
		$scoreData = $this->LeadProviderReport->getScoreColumns();
		foreach($scoreData as $type) {
			$scoreTypes[] = $type['name'];
		}

		$scoreTypes[] = 'Veritec Max Loan Amt';
		$scoreTypes[] = 'Vertiec Max Term desc';

		$this->view->affiliate = $affiliateData['masteraff'];

		$this->view->campaignID = $campaignID;
		$this->view->affiliateID = $affiliateID;
		$this->view->scoreCols = $scoreTypes;
		$this->view->fromDate = ($this->_request->fromDate) ? $this->_request->fromDate : date("Y-m-d");
		$this->view->fromTime = ($this->_request->fromTime) ? $this->_request->fromTime : "00:00:00";
		$this->view->toDate = ($this->_request->toDate) ? $this->_request->toDate : date("Y-m-d");
		$this->view->toTime = ($this->_request->toTime) ? $this->_request->toTime : "23:59:59";

		$this->view->storeIDs = $this->_request->storeIDs;
	}

	public function attemptsDataAction()
	{
		$columns = array("datetime", "id", "storeID", "campaign", "costPerLead",
		"numDiffLeadProviders", "leadsold", "email", "ssn", "ip","mphone", "fname", "lname",
		"loanamount", "citystate", "geolocation","address","address2","zip","hphone","wphone","wphone_ext","dob","title","campaign","sourceurl","subid","subid2"
		,"employer","monthlyincome","military","paymethod","payperiod","paydate1","paydate2","aba","ownrent","timetocall","licensenumber","licensestate","citizen"
		,"incomesource","timeatjob","occupation","empaddress","empcity","empstate","empzip","bank","accountnumber","accounttype","bankphone","loanamount","ref1name"
		,"ref2name","ref1phone","ref2phone","ref1relation","ref2relation","bankruptcy","yearsatresidence","monthsatresidence","bankinstitutionnumber","bankbranchnumber");

		$fromDate = ($this->_request->fromDate) ? $this->_request->fromDate : date("Y-m-d");
		$fromTime = ($this->_request->fromTime) ? $this->_request->fromTime : date("H:i:s");
		$toDate = ($this->_request->toDate) ? $this->_request->toDate : date("Y-m-d");
		$toTime = ($this->_request->toTime) ? $this->_request->toTime : date("H:i:s");
		$rp = ($this->_request->rp) ? $this->_request->rp : 50;
		$page =  ($this->_request->page) ? $this->_request->page : 1;
		$sortBy = ($this->_request->sortname) ? $this->_request->sortname : "datetime";
		$sortOrder = ($this->_request->sortorder) ? $this->_request->sortorder : "DESC";
		$storeIDs = ($this->_request->storeIDs) ? $this->_request->storeIDs : "";

		$campaignID = $this->_request->campaignID;
		$affiliateID = $this->_request->affiliateID;

		if(!empty($campaignID) && empty($affiliateID)) {
			$affiliateID = $this->Campaigns->getAffiliateIDFromCampaignID($campaignID);
		}
		$start = (($page-1) * $rp);

		$reportData = $this->LeadProviderReport->getAttemptsData($fromDate, $fromTime, $toDate, $toTime, $start, $rp, $affiliateID, $campaignID, $sortBy, $sortOrder, $storeIDs);
		$total = $this->LeadProviderReport->getTotalAttempts($fromDate, $fromTime, $toDate, $toTime, $affiliateID, $campaignID, $storeIDs);

		$scoreTypes = array();
		$scoreData = $this->LeadProviderReport->getScoreColumns();
		foreach($scoreData as $type) {
			$scoreTypes[] = $type['name'];
		}

		$jsonData = array('page'=>$page,'total'=>$total,'rows'=>array());

		$allLeadIds = array();
		foreach($reportData as $row) {
			$allLeadIds[] = $row['id'];
		}

		if (!empty($allLeadIds)) {
			$internalRejectReasons = $this->LeadProviderReport->getInternalRejectReasons($allLeadIds, $campaignID);
			$clientRejectReasons = $this->LeadProviderReport->getClientRejectReasons($allLeadIds, $campaignID);
			$campaignRejectReasons = $this->LeadProviderReport->getCampaignRejectReasons($allLeadIds, $campaignID);
			$clientOrVendorRejects = $this->LeadProviderReport->getClientOrVendorRejects($allLeadIds, $campaignID);
			$vendorTimeOutRejects = $this->LeadProviderReport->getVendorTimeOutsRejects($allLeadIds);

			$denyReasonType[] = 'Deny Reason';

			$denyReasons = array();
			foreach($internalRejectReasons as $data) {
				$denyReasons[$data['leadID']]['Deny Reason'] = $data['denyReason'];
			}

			foreach($clientRejectReasons as $data) {
				if ($denyReasons[$data['leadID']]['Deny Reason'] == "") {
					$denyReasons[$data['leadID']]['Deny Reason'] = $data['denyReason'];
				}
			}

			foreach($campaignRejectReasons as $data) {
				if ($denyReasons[$data['leadID']]['Deny Reason'] == "") {
					$denyReasons[$data['leadID']]['Deny Reason'] = $data['denyReason'];
				}
			}

			foreach($clientOrVendorRejects as $data) {
				if ($denyReasons[$data['leadID']]['Deny Reason'] == "") {
					$denyReasons[$data['leadID']]['Deny Reason'] = $data['denyReason'];
				}
			}

            foreach($vendorTimeOutRejects as $data) {
                if ($denyReasons[$data['leadID']]['Deny Reason'] == "") {
                    $denyReasons[$data['leadID']]['Deny Reason'] = $data['denyReason'];
                }
            }

			$veritecScores = array();
			$veritecScoreData = $this->LeadProviderReport->getVeritecScores($allLeadIds);

			$veritecScoreTypes[] = 'Veritec Max Loan Amt';
			$veritecScoreTypes[] = 'Vertiec Max Term desc';

			foreach($veritecScoreData as $data) {
				$veritecScores[$data['leadID']]['Veritec Max Loan Amt'] = $data['responseother'];
				$veritecScores[$data['leadID']]['Vertiec Max Term desc'] = $data['responsedescription'];
			}

			$scoreCols = array();
			$leadScores = array();

			$scoresData = $this->LeadProviderReport->getLeadsScores($allLeadIds);
			foreach($scoresData as $data) {
				$leadScores[$data['leadID']][$data['name']] = $data['score'];
				$scoreCols[$data['name']] = $data['name'];
			}

			foreach($reportData as $rowNum => $row) {
				$dataRow = array();

				$entry = array(
					'id' => $rowNum,
					'cell'=>array(
						'datetime'   => $row['datetime'],
						'id'         => '<a target="_blank" href="/leadedit?leadid='. $row['id'] .'">' . $row['id'] . '</a>',
						'storeID'    => $row['storeID'],
						'status'    => $row['leadsold'] == '1' ? 'Accepted' : 'Rejected',
						'campaign'   => $row['campaign'],
						'costPerLead'=> $row['costPerLead'],
						'numDiffLeadProviders'    => (!empty($row['numDiffLeadProviders'])) ? $row['numDiffLeadProviders'] : 0,
						'leadsold'    => $row['leadsold'],
						'email'    => '<a target="_blank" href="/lead-provider-reports/details?leadID=' . $row['id'] . '&search=email">' . $row['email'] . '</a>',
						'ssn'    => '<a target="_blank" href="/lead-provider-reports/details?leadID=' . $row['id'] . '&search=ssn">' . ((!empty($row['ssn'])) ? substr_replace($row['ssn'], "xxx-xx-", 0, 5) : "") . '</a>',
						'ip'    => $row['ip'],
						'mphone'    => $row['mphone'],
						'fname'    => $row['fname'],
						'lname'    => $row['lname'],
						'loanamount'    => $row['loanamount'],
						'citystate'    => ((!empty($row['city'])) ? $row['city'] . ", " : "") . $row['state'],
						'iplocation'    => ((!empty($row['ipCity'])) ? $row['ipCity'] . ", " : "") . $row['ipState'],
						'address'    => $row['address'],
						'address2'    => $row['address2'],
						'zip'    => $row['zip'],
						'hphone'    => $row['hphone'],
						'wphone'    => $row['wphone'],
						'wphone_ext'    => $row['wphone_ext'],
						'dob'    => $row['dob'],
						'title'    => $row['title'],
						'sourceurl'    => $row['sourceurl'],
						'subid'    => $row['subid'],
						'subid2'    => $row['subid2'],
						'subid3'    => $row['subid3'],
						'employer'    => $row['employer'],
						'monthlyincome'    => $row['monthlyincome'],
						'military'    => $row['military'],
						'paymethod'    => $row['paymethod'],
						'payperiod'    => $row['payperiod'],
						'paydate1'    => $row['paydate1'],
						'paydate2'    => $row['paydate2'],
						'aba'    => $row['aba'],
						'ownrent'    => $row['ownrent'],
						'timetocall'    => $row['timetocall'],
						'licensenumber'    => $row['licensenumber'],
						'licensestate'    => $row['licensestate'],
						'citizen'    => $row['citizen'],
						'incomesource'    => $row['incomesource'],
						'timeatjob'    => $row['timeatjob'],
						'occupation'    => $row['occupation'],
						'empaddress'    => $row['empaddress'],
						'empcity'    => $row['empcity'],
						'empstate'    => $row['empstate'],
						'empzip'    => $row['empzip'],
						'bank'    => $row['bank'],
						'acntnumber'    => (!empty($row['accountnumber'])) ? substr_replace($row['accountnumber'], "xxxxxx-", 0, strlen($row['accountnumber'])-4) : "",
						'accounttype'    => $row['accounttype'],
						'bankphone'    => $row['bankphone'],
						'loanamount'    => $row['loanamount'],
						'ref1name'    => $row['ref1name'],
						'ref2name'    => $row['ref2name'],
						'ref1phone'    => $row['ref1phone'],
						'ref2phone'    => $row['ref2phone'],
						'ref1relation'    => $row['ref1relation'],
						'ref2relation'    => $row['ref2relation'],
						'bankruptcy'    => $row['bankruptcy'],
						'yearsatresidence'    => $row['yearsatresidence'],
						'monthsatresidence'    => $row['monthsatresidence'],
						'bankinstitutionnumber'    => $row['bankinstitutionnumber'],
						'bankbranchnumber'    => $row['bankbranchnumber'],
						'lead_id' => $row['id'],
						'variate' => $row['variatename'],
						'multivariate' => $row['multivariatename'],
						'vendor_deny_description' => $row['denyDescription'],
						'vendor' => $row['vendorName'],
					)
				);

				foreach($scoreTypes as $col) {
					$columnValue = "";
					if(@array_key_exists($col,$leadScores[$entry['cell']['lead_id']])) {
						$columnValue = $leadScores[$entry['cell']['lead_id']][$col];
					}
					else {
						$columnValue = "";
					}
					$entry['cell'][str_replace(" ","_",strtolower($col))] = $columnValue;
				}

				foreach($veritecScoreTypes as $col) {
					if(@array_key_exists($col,$veritecScores[$entry['cell']['lead_id']])) {
						$columnValue = $veritecScores[$entry['cell']['lead_id']][$col];
					}
					else {
						$columnValue = "";
					}
					$entry['cell'][str_replace(" ","_",strtolower($col))] = $columnValue;
				}

				foreach($denyReasonType as $col) {
					if(@array_key_exists($col,$denyReasons[$entry['cell']['lead_id']])) {
						$columnValue = $denyReasons[$entry['cell']['lead_id']][$col];
					}
					else {
						$columnValue = "";
					}
					$entry['cell'][str_replace(" ","_",strtolower($col))] = $columnValue;

                    if ($entry['cell']['status'] ==  'Accepted' || $columnValue == "" || $columnValue == "Denied by Vendor" || $columnValue == "Denied by LMS") {
                        $entry['cell']['loghistory'] = '<a href="javascript:void(0);" onclick="searchPostLogs('.$row['id'].')">Log History</a>';
                    }
                    else {
                        $entry['cell']['loghistory'] = '';
                    }
				}

				$jsonData['rows'][] = $entry;
			}
		}

		echo Zend_Json::encode($jsonData);
		$this->_helper->viewRenderer->setNoRender();
	}

	public function detailsAction()
	{
		$leadID = $this->_request->leadID;

		$leadData = $this->Leads->find($leadID);

		if(count($leadData) > 0) {
			$leadArray = $leadData->current()->toArray();
			$Date = new DateTime($leadArray['originaldate']);
			$Date->sub(new DateInterval('P7D'));
			$fromDate = $Date->format("Y-m-d");
			$fromTime = $Date->format("H:i:s");
			$toDate = $leadArray['originaldate'];
			$toTime = $leadArray['originaltime'];
		}
		else {
			$this->_helper->flashMessenger->addMessage("No Valid LeadID");
			$this->_redirect("/main");
		}

		$this->view->fromDate = $fromDate;
		$this->view->fromTime = $fromTime;
		$this->view->toDate = $toDate;
		$this->view->toTime = $toTime;

		$this->view->leadID = $leadID;
		$this->view->search = $this->_request->search;

		if($this->_request->search == "ssn") {
			$this->view->ssn = (isset($leadArray['ssn']) && !empty($leadArray['ssn'])) ? substr_replace($leadArray['ssn'], "xxx-xx-", 0, 5) : "";
		}
		else {
			$this->view->email = $email;
		}
	}

	public function detailsDataAction()
	{
		$columns = array("datetime", "id", "storeID", "masteraff", "campaign", "leadsold",
				"ip", "geolocation", "citystate", "fname", "lname", "email", "ssn", "mphone",
				"dob", "monthlyincome");

		$start = ($this->_request->iDisplayStart) ? $this->_request->iDisplayStart : 0;
		$limit = ($this->_request->iDisplayLength) ? $this->_request->iDisplayLength : 50;
		$sortColNum = ($this->_request->iSortCol_0) ? $this->_request->iSortCol_0 : 0;
		$sortOrder = ($this->_request->sSortDir_0) ? $this->_request->sSortDir_0 : "ASC";

		$leadID = ($this->_request->leadID) ? $this->_request->leadID : 0;

		$fromDate = ($this->_request->fromDate) ? $this->_request->fromDate : "";
		$fromTime = ($this->_request->fromTime) ? $this->_request->fromTime : "";
		$toDate = ($this->_request->toDate) ? $this->_request->toDate : "";
		$toTime = ($this->_request->toTime) ? $this->_request->toTime : "";

		$leadData = $this->Leads->getLeadWithCashData($leadID);

		if(count($leadData) > 0) {
			// if no date is passed default to 7 days range back from leadID
			$Date = new DateTime($leadData['originaldate']);
			$Date->sub(new DateInterval('P7D'));
			$fromDate = (empty($fromDate)) ? $Date->format("Y-m-d") : $fromDate;
			$fromTime = (empty($fromTime)) ? $Date->format("H:i:s") : $fromTime;
			$toDate = (empty($toDate)) ? $leadData['originaldate'] : $toDate;
			$toTime = (empty($toTime)) ? $leadData['originaltime'] : $toTime;

			// search either on ssn or email for dupes
			if($this->_request->search == "ssn") {
				$ssn = $leadData['ssn'];
			}
			else {
				$email = $leadData['email'];
			}

			$page = ($start / $limit) + 1;

			// data for current page
			$reportData = $this->LeadProviderReport->getLeadDupes($fromDate, $fromTime, $toDate, $toTime, $email, $ssn, $page, $limit, $columns[$sortColNum], $sortOrder);

			// total count for pagination
			$total = $this->LeadProviderReport->getTotalLeadDupes($fromDate, $fromTime, $toDate, $toTime, $email, $ssn);

			$returnArray['iTotalRecords'] = $total;
			$returnArray['iTotalDisplayRecords'] = $total;
			$returnArray['sEcho'] = (int)$this->_request->sEcho;
			$returnArray['aaData'] = array();

			foreach($reportData as $row) {
				$dataRow = array();

				$dataRow[] = $row['datetime'];
				$dataRow[] = $row['id'];
				$dataRow[] = $row['storeID'];
				$dataRow[] = $row['masteraff'];
				$dataRow[] = $row['campaign'];
				$dataRow[] = $row['leadsold'];
				$dataRow[] = $row['ip'];
				$dataRow[] = ((!empty($row['ipCity'])) ? $row['ipCity'] . ", " : "") . $row['ipState'];
				$dataRow[] = ((!empty($row['city'])) ? $row['city'] . ", " : "") . $row['state'];
				$dataRow[] = $row['fname'];
				$dataRow[] = $row['lname'];
				$dataRow[] = $row['email'];
				$dataRow[] = (isset($row['ssn']) && !empty($row['ssn'])) ? substr_replace($row['ssn'], "xxx-xx-", 0, 5) : "";
				$dataRow[] = isset($row['mphone']) ? $row['mphone'] : "";

				if(!empty($row['dob'])) {
					$DOB = new DateTime($row['dob']);
					$Date = new DateTime();
					$dobInterval = $Date->diff($DOB);
					$dataRow[] = $row['dob'] . " (" . $dobInterval->y . ")";
				}
				else {
					$dataRow[] = "";
				}

				$dataRow[] = $row['monthlyincome'];

				$returnArray['aaData'][] = $dataRow;
			}
		}
		else {
			$returnArray = array();
		}

		echo Zend_Json::encode($returnArray);

		$this->_helper->viewRenderer->setNoRender();
	}

	public function dupesAction()
	{
		$this->view->fromDate = ($this->_request->fromDate) ? $this->_request->fromDate : date("Y-m-d");
		$this->view->fromTime = ($this->_request->fromTime) ? $this->_request->fromTime : "00:00:00";
		$this->view->toDate = ($this->_request->toDate) ? $this->_request->toDate : date("Y-m-d");
		$this->view->toTime = ($this->_request->toTime) ? $this->_request->toTime : "23:59:59";
	}

	public function dupesDataAction()
	{
		$columns = array("affiliateID", "affiliate", "attempts", "uniques", "uniquesPercentage", "dupes", "dupesPercentage");

		$start = ($this->_request->iDisplayStart) ? $this->_request->iDisplayStart : 0;
		$limit = ($this->_request->iDisplayLength) ? $this->_request->iDisplayLength : 50;
		$sortColNum = ($this->_request->iSortCol_0) ? $this->_request->iSortCol_0 : 0;
		$sortOrder = ($this->_request->sSortDir_0) ? $this->_request->sSortDir_0 : "DESC";

		$fromDate = ($this->_request->fromDate) ? $this->_request->fromDate : "";
		$fromTime = ($this->_request->fromTime) ? $this->_request->fromTime : "";
		$toDate = ($this->_request->toDate) ? $this->_request->toDate : "";
		$toTime = ($this->_request->toTime) ? $this->_request->toTime : "";

		// data for current page
		$reportData = $this->LeadProviderReport->getDupesByAffiliate($fromDate, $fromTime, $toDate, $toTime, $page, $limit, $columns[$sortColNum], $sortOrder);

		// total count for pagination
		$total = $this->LeadProviderReport->getTotalDupesByAffiliate($fromDate, $fromTime, $toDate, $toTime);

		$returnArray['iTotalRecords'] = $total;
		$returnArray['iTotalDisplayRecords'] = $total;
		$returnArray['sEcho'] = (int)$this->_request->sEcho;
		$returnArray['aaData'] = array();

		foreach($reportData as $row) {
			$dataRow = array();

			$dataRow[] = $row['affiliateID'];
			$dataRow[] = '<a target="_blank" href="/lead-provider-reports/attempts?affiliateID=' . $row['affiliateID'] . '&fromDate=' . $fromDate . '&fromTime=' . $fromTime . '&toDate=' . $toDate . '&toTime=' . $toTime . '">' . $row['attempts'] . '</a>';
			$dataRow[] = ($row['uniques']) ? $row['uniques'] : 0;
			$dataRow[] = number_format((($row['uniquesPercentage']) ? round($row['uniquesPercentage'], 2) : 0), 2) . "%";
			$dataRow[] = ($row['dupes']) ? $row['dupes'] : 0;
			$dataRow[] = number_format((($row['dupesPercentage']) ? round($row['dupesPercentage'], 2) : 0), 2) . "%";

			$returnArray['aaData'][] = $dataRow;
		}

		echo Zend_Json::encode($returnArray);

		$this->_helper->viewRenderer->setNoRender();
	}

	public function attemptsexcelAction()
	{
		$this->_helper->viewRenderer->setNoRender();

		$fromDate = ($this->_request->fromDate) ? $this->_request->fromDate : date("Y-m-d");
		$fromTime = ($this->_request->fromTime) ? $this->_request->fromTime : date("H:i:s");
		$toDate = ($this->_request->toDate) ? $this->_request->toDate : date("Y-m-d");
		$toTime = ($this->_request->toTime) ? $this->_request->toTime : date("H:i:s");
		$sortBy = ($this->_request->sortname) ? $this->_request->sortname : "datetime";
		$sortOrder = ($this->_request->sortorder) ? $this->_request->sortorder : "DESC";

		$campaignID = $this->_request->campaignID;
		$affiliateID = $this->_request->affiliateID;

		if(!empty($campaignID) && empty($affiliateID)) {
			$affiliateID = $this->Campaigns->getAffiliateIDFromCampaignID($campaignID);
		}

		$scoreTypes = array();
		$scoreData = $this->LeadProviderReport->getScoreColumns();
		foreach($scoreData as $type) {
			$scoreTypes[] = $type['name'];
		}

		$scoreCols = "";
		foreach($scoreTypes as $col) {
		    $scoreCols.='"'.$col.'",';
		}

		$denyReasonType[] = 'Deny Reason';

		// in order to avoid memory issues, we will get the lead attempts in separate batches
		$limit = 5000;
		$total = $this->LeadProviderReport->getTotalAttempts($fromDate, $fromTime, $toDate, $toTime, $affiliateID, $campaignID, $storeIDs);

		$totalBatches = ceil( $total/ $limit );

		header("Content-Disposition: attachment; filename=leadProviderAttemptsReports_" . $fromDate . "_" . $toDate . ".csv");

		echo '"DateTime","LeadID","Store","Status","Deny Reason","Vendor","Vendor Deny Description","Campaign","Variate","Multivariate Strategy","Cost (campaign cost)","# of Diff Lead Providers","Lead Sold","Email","IP Address","MPhone","First Name","Last Name","Loan Amount","City,State","IP Geo Location","Address","Address 2","Zip","Home Phone","Work Phone","Work Phone Ext","DOB","Title","Source Url","Subid","Subid2","Employer","Monthly Income","Military","Pay Method","Pay Period","Pay Date1","Pay Date2","Aba","Own/Rent","Time To Call","License Number","License State","Citizen","Income Source","Time At Job","Occupation","Emp Address","Emp city","Emp State","Emp zip","Bank","Account Type","Bank Phone","Ref1 Name","Ref2 Name","Ref1 Phone","Ref2 Phone","Ref1 Relation","Ref2 Relation","Bankruptcy","Years At Residence","Months At Residence","Bank inst Number","Bank branch Number",'.$scoreCols;
			echo "\n";

		for ($batch=1;$batch<=$totalBatches;$batch++) {

			$offset = ($batch - 1) * $limit;

			$reportData = $this->LeadProviderReport->getAttemptsData($fromDate, $fromTime, $toDate, $toTime, $offset, $limit, $affiliateID, $campaignID, $sortBy, $sortOrder, $storeIDs);

			$allLeadIds = array();
			foreach($reportData as $row) {
				$allLeadIds[] = $row['id'];
			}

			$internalRejectReasons = $this->LeadProviderReport->getInternalRejectReasons($allLeadIds, $campaignID);
			$clientRejectReasons = $this->LeadProviderReport->getClientRejectReasons($allLeadIds, $campaignID);
			$campaignRejectReasons = $this->LeadProviderReport->getCampaignRejectReasons($allLeadIds, $campaignID);
			$clientOrVendorRejects = $this->LeadProviderReport->getClientOrVendorRejects($allLeadIds, $campaignID);

			$denyReasons = array();
			foreach($internalRejectReasons as $data) {
			    $denyReasons[$data['leadID']]['Deny Reason'] = $data['denyReason'];
			}

			foreach($clientRejectReasons as $data) {
			    if ($denyReasons[$data['leadID']]['Deny Reason'] == "") {
			        $denyReasons[$data['leadID']]['Deny Reason'] = $data['denyReason'];
			    }
			}

			foreach($campaignRejectReasons as $data) {
			    if ($denyReasons[$data['leadID']]['Deny Reason'] == "") {
			        $denyReasons[$data['leadID']]['Deny Reason'] = $data['denyReason'];
			    }
			}

			foreach($clientOrVendorRejects as $data) {
			    if ($denyReasons[$data['leadID']]['Deny Reason'] == "") {
			        $denyReasons[$data['leadID']]['Deny Reason'] = $data['denyReason'];
			    }
			}

			$scoresData = $this->LeadProviderReport->getLeadsScores($allLeadIds);

			$leadScores = array();
			foreach($scoresData as $data) {
				$leadScores[$data['leadID']][$data['name']] = $data['score'];
			}

			foreach($reportData as $rowNum => $row) {
				$dataRow = array();

				$entry = array(
				'id' => $rowNum,
				'cell'=>array(
				    'datetime'   		=> $row['datetime'],
				    'id'         		=> $row['id'],
				    'storeID'    		=> $row['storeID'],
				    'status'    => $row['leadsold'] == '1' ? 'Accepted' : 'Rejected',
				    'campaign'   		=> $row['campaign'],
				    'campaign'   		=> $row['campaign'],
				    'campaign'   		=> $row['campaign'],
				    'costPerLead'		=> $row['costPerLead'],
				    'numDiffLeadProviders'    	=> (!empty($row['numDiffLeadProviders'])) ? $row['numDiffLeadProviders'] : 0,
				    'leadsold'    		=> $row['leadsold'],
				    'email'    			=>  $row['email'] ,
				    'ssn'   			=> (!empty($row['ssn']) ? substr_replace($row['ssn'], "xxx-xx-", 0, 5) : ""),
				    'ip'    			=> $row['ip'],
				    'mphone'    		=> $row['mphone'],
				    'fname'    			=> $row['fname'],
				    'lname'    			=> $row['lname'],
				    'loanamount'    		=> $row['loanamount'],
				    'citystate'    		=> ((!empty($row['city'])) ? $row['city'] . ", " : "") . $row['state'],
				    'iplocation'    		=> ((!empty($row['ipCity'])) ? $row['ipCity'] . ", " : "") . $row['ipState'],
				    'address'    		=> $row['address'],
				    'address2'    		=> $row['address2'],
				    'zip'    			=> $row['zip'],
				    'hphone'    		=> $row['hphone'],
				    'wphone'    		=> $row['wphone'],
				    'wphone_ext'    		=> $row['wphone_ext'],
				    'dob'    			=> $row['dob'],
				    'title'    			=> $row['title'],
				    'sourceurl'    		=> $row['sourceurl'],
				    'subid'    			=> $row['subid'],
				    'subid2'    		=> $row['subid2'],
				    'employer'    		=> $row['employer'],
				    'monthlyincome'    		=> $row['monthlyincome'],
				    'military'    		=> $row['military'],
				    'paymethod'    		=> $row['paymethod'],
				    'payperiod'    		=> $row['payperiod'],
				    'paydate1'    		=> $row['paydate1'],
				    'paydate2'    		=> $row['paydate2'],
				    'aba'    			=> $row['aba'],
				    'ownrent'    		=> $row['ownrent'],
				    'timetocall'    		=> $row['timetocall'],
				    'licensenumber'    		=> $row['licensenumber'],
				    'licensestate'    		=> $row['licensestate'],
				    'citizen'    		=> $row['citizen'],
				    'incomesource'    		=> $row['incomesource'],
				    'timeatjob'    		=> $row['timeatjob'],
				    'occupation'    		=> $row['occupation'],
				    'empaddress'    		=> $row['empaddress'],
				    'empcity'    		=> $row['empcity'],
				    'empstate'    		=> $row['empstate'],
				    'empzip'    		=> $row['empzip'],
				    'bank'    			=> $row['bank'],
				    'acntnumber'    		=> (!empty($row['accountnumber'])) ? substr_replace($row['accountnumber'], "xxxxxx-", 0, strlen($row['accountnumber'])-4) : "",
				    'accounttype'    		=> $row['accounttype'],
				    'bankphone'    		=> $row['bankphone'],
				    'loanamount'    		=> $row['loanamount'],
				    'ref1name'    		=> $row['ref1name'],
				    'ref2name'    		=> $row['ref2name'],
				    'ref1phone'    		=> $row['ref1phone'],
				    'ref2phone'    		=> $row['ref2phone'],
				    'ref1relation'    		=> $row['ref1relation'],
				    'ref2relation'    		=> $row['ref2relation'],
				    'bankruptcy'    		=> $row['bankruptcy'],
				    'yearsatresidence'    	=> $row['yearsatresidence'],
				    'monthsatresidence'    	=> $row['monthsatresidence'],
				    'bankinstitutionnumber'    	=> $row['bankinstitutionnumber'],
				    'bankbranchnumber'    	=> $row['bankbranchnumber'],
				    'lead_id' 			=> $row['id'],
				    'variate' => $row['variatename'],
				    'multivariate' => $row['multivariatename'],
					'vendor_deny_description' => $row['denyDescription'],
					'vendor' => $row['vendorName'],
				)
				);

				foreach($scoreTypes as $col) {
					$columnValue = "";
					if(@array_key_exists($col,$leadScores[$entry['cell']['lead_id']])) {
					   $columnValue = $leadScores[$entry['cell']['lead_id']][$col];
					}
					else {
					   $columnValue = "";
					}
					$entry['cell'][str_replace(" ","_",strtolower($col))] = $columnValue;
				}

				foreach($denyReasonType as $col) {
				    if(@array_key_exists($col,$denyReasons[$entry['cell']['lead_id']])) {
				        $columnValue = $denyReasons[$entry['cell']['lead_id']][$col];
				    }
				    else {
				        $columnValue = "";
				    }
				    $entry['cell'][str_replace(" ","_",strtolower($col))] = $columnValue;
				}

				$reportData = $entry['cell'];

				echo '"' . $reportData['datetime'] . '",';
				echo '"' . $reportData['id'] . '",';
				echo '"' . $reportData['storeID'] . '",';
				echo '"' . $reportData['status'] . '",';
				echo '"' . $reportData['deny_reason'] . '",';
				echo '"' . $reportData['vendor'] . '",';
				echo '"' . $reportData['vendor_deny_description'] . '",';
				echo '"' . $reportData['campaign'] . '",';
				echo '"' . $reportData['variate'] . '",';
				echo '"' . $reportData['multivariate'] . '",';
				echo '"' . $reportData['costPerLead'] . '",';
				echo '"' . $reportData['numDiffLeadProviders'] . '",';
				echo '"' . $reportData['leadsold'] . '",';
				echo '"' . $reportData['email'] . '",';
				echo '"' . $reportData['ip'] . '",';
				echo '"' . $reportData['mphone'] . '",';
				echo '"' . $reportData['fname'] . '",';
				echo '"' . $reportData['lname'] . '",';
				echo '"' . $reportData['loanamount'] . '",';
				echo '"' . $reportData['citystate'] . '",';
				echo '"' . $reportData['iplocation'] . '",';
				echo '"' . $reportData['address'] . '",';
				echo '"' . $reportData['address2'] . '",';
				echo '"' . $reportData['zip'] . '",';
				echo '"' . $reportData['hphone'] . '",';
				echo '"' . $reportData['wphone'] . '",';
				echo '"' . $reportData['wphone_ext'] . '",';
				echo '"' . $reportData['dob'] . '",';
				echo '"' . $reportData['title'] . '",';
				echo '"' . $reportData['sourceurl'] . '",';
				echo '"' . $reportData['subid'] . '",';
				echo '"' . $reportData['subid2'] . '",';
				echo '"' . $reportData['employer'] . '",';
				echo '"' . $reportData['monthlyincome'] . '",';
				echo '"' . $reportData['military'] . '",';
				echo '"' . $reportData['paymethod'] . '",';
				echo '"' . $reportData['payperiod'] . '",';
				echo '"' . $reportData['paydate1'] . '",';
				echo '"' . $reportData['paydate2'] . '",';
				echo '"' . $reportData['aba'] . '",';
				echo '"' . $reportData['ownrent'] . '",';
				echo '"' . $reportData['timetocall'] . '",';
				echo '"' . $reportData['licensenumber'] . '",';
				echo '"' . $reportData['licensestate'] . '",';
				echo '"' . $reportData['citizen'] . '",';
				echo '"' . $reportData['incomesource'] . '",';
				echo '"' . $reportData['timeatjob'] . '",';
				echo '"' . $reportData['occupation'] . '",';
				echo '"' . $reportData['empaddress'] . '",';
				echo '"' . $reportData['empcity'] . '",';
				echo '"' . $reportData['empstate'] . '",';
				echo '"' . $reportData['empzip'] . '",';
				echo '"' . $reportData['bank'] . '",';
				echo '"' . $reportData['accounttype'] . '",';
				echo '"' . $reportData['bankphone'] . '",';
				echo '"' . $reportData['ref1name'] . '",';
				echo '"' . $reportData['ref2name'] . '",';
				echo '"' . $reportData['ref1phone'] . '",';
				echo '"' . $reportData['ref2phone'] . '",';
				echo '"' . $reportData['ref1relation'] . '",';
				echo '"' . $reportData['ref2relation'] . '",';
				echo '"' . $reportData['bankruptcy'] . '",';
				echo '"' . $reportData['yearsatresidence'] . '",';
				echo '"' . $reportData['monthsatresidence'] . '",';
				echo '"' . $reportData['bankinstitutionnumber'] . '",';
				echo '"' . $reportData['bankbranchnumber'] . '",';

				foreach($scoreTypes as $col) {
					echo '"'.$reportData[str_replace(" ","_",strtolower($col))].'",';
				}

				echo "\n";
			}
		}
	}
}
?>