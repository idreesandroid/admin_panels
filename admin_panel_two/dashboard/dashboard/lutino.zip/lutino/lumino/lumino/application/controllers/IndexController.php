<?php
class IndexController extends Zend_Controller_Action
{
	private $baseurl;
	private $restrictedUser = FALSE;
	private $restrictedMember = FALSE;

	function init()
	{

		$this->baseurl = $this->_request->getBaseUrl();
	}

	function indexAction()
	{
		$this->_helper->redirector('login');
	}

	function loginAction()
	{
		$message = "";
		$error = 0;
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if ($this->_request->isPost()) {

			Zend_Loader::loadClass('Zend_Filter_StripTags');
			$f = new Zend_Filter_StripTags();
			$username = $f->filter($this->_request->getPost('username'));
			$password = $f->filter($this->_request->getPost('password'));
			$loginType = $this->_request->getPost('logintype');

			if(empty($username))
			{
				$message.="Please provide a username.<br>";
				$error =1;
			}
			if(empty($password))
			{
				$message.="Please provide password.<br>";
				$error =1;
			}
			if(empty($loginType))
			{
				$message.="Please provide login type.<br>";
				$error =1;
			}

			if($error==0){
				// session time out for admin user is 20 minutes
				$AdminNameSpace->setExpirationSeconds( 999999 );
				Zend_Loader::loadClass('Zend_Auth_Adapter_DbTable');
				$db = Zend_Registry::get('db');
				$authAdapter = new Zend_Auth_Adapter_DbTable($db);

				// Affiliate tried to login
				if ($loginType == 'affiliate') {
						// Affiliates will be authenticated form Affiliates table
						$authAdapter->setTableName('Affiliates');
						$authAdapter->setIdentityColumn('email');
						$select = $authAdapter->getDbSelect();
						$select->where('active = 1');
				}
				else {
						// Clients will be authenticated form adminusers table
						$authAdapter->setTableName('adminusers');
						$authAdapter->setIdentityColumn('username');
				}

				$authAdapter->setCredentialColumn('password');
				// Set the input credential values to authenticate against
				$authAdapter->setIdentity($username);
				$authAdapter->setCredential($password);
				// do the authentication
				$auth = Zend_Auth::getInstance();
				$result = $auth->authenticate($authAdapter);

				if ($result->isValid()) {
					// success: store database row to auth's storage
					// system. (Not the password though!)
					$data = $authAdapter->getResultRowObject(null,'password');
					$temp = Zend_Auth::getInstance()->getIdentity();

					$std = new stdClass();
					$std = $data;

					if ($loginType == 'affiliate') {
						$AdminNameSpace->userid = $std->id;
					}
					else {
						$AdminNameSpace->userid = $std->adminuserid;
					}

					$AdminNameSpace->username = $username;
					$auth->getStorage()->write($data);
					$this->UserSession = new Zend_Session_Namespace('UserSession');
					$config = Zend_Registry::get('config');

					if ($loginType == 'client') {

						if (isset($config->restrictedusers)) {
							$userLoggedIn = $AdminNameSpace->username;
							if (in_array($userLoggedIn, $config->restrictedusers->toArray())) {
								$this->restrictedUser = TRUE;
							}
						}

						if (isset($config->restrictedmembers)) {
							$userLoggedIn = $AdminNameSpace->username;
							if (in_array($userLoggedIn, $config->restrictedmembers->toArray())) {
								$this->restrictedUser = TRUE;
								$this->restrictedMember = TRUE;
							}
						}

						$this->UserSession->restrictedUser = $this->restrictedUser;
						$this->UserSession->restrictedMember = $this->restrictedMember;

						if($data->role != 'csr') {
						    $this->UserSession->role = "client";
						}
						else {
						    $this->UserSession->role = "csr";
						}

						$this->UserSession->userid = $std->adminuserid;
					}
					else {
						$this->UserSession->role = "affiliate";
						$this->UserSession->userid = $std->id;
					}

					if($data->role == 'csr') {
					    $this->_redirect('veritec');
					}
					else {
					    $this->_redirect('main');
					}

				} else {
					// failure: clear database row from session
					$message = 'Invalid Username or Password.<br>';
				}
			}
		}

		$this->view->baseurl = $this->baseurl;
		$this->view->message = $message;
	}

	function logoutAction()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		Zend_Auth::getInstance()->clearIdentity();
		$AdminNameSpace->userid = "";
		$this->_redirect('/');
	}

	function privacyAction()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		echo "called";
		die();
	}
}
?>
