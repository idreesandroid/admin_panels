<?php

class MultiVariateLeadExceptionMultiVariate extends Zend_Db_Table
{
	protected $_name = 'MultiVariateLeadExceptionMultiVariates';

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}

	public function findByMultivariateID($id) {
		$sql = $this->select()
			->where("multiVariateID = " . $id);
		return $this->fetchRow($sql);
	}

	/**
	 * Updates or inserts a row
	 */
	public function upsert($id, $insertData)
	{
		$existingRow = $this->findByMultivariateID($id);

		if($existingRow) {
			$this->update($insertData, $this->_db->quoteInto("multiVariateID = ?", $existingRow['multiVariateID']));
			return $id;
		}
		else {
			return $this->insert($insertData);
		}
	}

	public function getDataByMultivariateID($multivariateID)
	{
		$sql = $this->select()->where("multiVariateID = " . $multivariateID);
		return $this->fetchRow($sql);
	}

	public function deleteByMultivariateID($multivariateID)
	{
		$existingRow = $this->findByMultivariateID($multivariateID);
		if ($existingRow) {
			$this->delete('multiVariateID='. $multivariateID);
		}
	}
}
?>
