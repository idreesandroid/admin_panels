<?php
class DecisionLogicResponseParameters extends Zend_Db_Table
{
    protected $_name = 'DecisionLogicResponseParameters';

    public function init()
    {
            $this->db = Zend_Registry::get('db');
    }

    public function getDecesionLogicResponseParameters()
    {
        $sql = $this->select()->order('id asc');
        return $this->fetchAll($sql);
    }
}

