<?php
class LeadeditController extends Zend_Controller_Action 
{
    private $baseurl;

	function init()
    {
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if(!$AdminNameSpace->userid)
		{
	    		$this->_redirect('index/login');	
		}
            $this->Leads = new Leads();
	    $this->baseurl = $this->_request->getBaseUrl();
    }

    function indexAction()
    {
    	$leadId = $this->_request->leadid;
        $cashid = $this->_request->cashid;

        $leadData = $this->Leads->getLeadWithCashData($leadId);
        if (!isset($leadData['cashID'])) {
            $this->_helper->flashMessenger->addMessage(array(
		    'errors' => array('Lead not found in CashData table.' => 'fail')));
        }
        $leadData['ssn'] = (!empty($leadData['ssn'])) ? substr_replace($leadData['ssn'], "xxx-xx-", 0, strlen($leadData['ssn'])-4) : "";
        $leadData['accountnumber'] = (!empty($leadData['accountnumber'])) ? substr_replace($leadData['accountnumber'], "xxx-xx-", 0, strlen($leadData['accountnumber'])-4) : "";

		$this->view->flashMessages = $this->_helper->flashMessenger->getMessages();
        $this->view->leaddata = $leadData;
        $this->view->baseurl = $this->baseurl;
    }

    function updateAction() {

        $leadId = $this->_request->leadid;
        $cashid = $this->_request->cashid;

        if ($this->_request->isPost()) {
            try{
                $lead = new Leads();
                $cash = new CashData();

                $leaddatarow = array(
                'fname' => $this->_request->fname,
                'lname' => $this->_request->lname,
                'address' => $this->_request->address,
				'address2' => $this->_request->address2,
                'city' => $this->_request->city,
                'state' => $this->_request->city,
                'zip' => $this->_request->zip,
                'email' => $this->_request->email,
                'hphone' => $this->_request->hphone,
                'wphone' => $this->_request->wphone,
                'wphone_ext' => $this->_request->wphone_ext,
                'mphone' => $this->_request->mphone,
                'dob' => $this->_request->dob,
                'title' => $this->_request->title,
                'ip' => $this->_request->ip,
                'optin' => $this->_request->optin,
                'sourceurl' => $this->_request->sourceurl,
                'subid' => $this->_request->subid,
                'subid2' => $this->_request->subid2,
                'subid3' => $this->_request->subid3
                );

                $cashdatarow = array(
                'employer' => $this->_request->employer,
                'monthlyincome' => $this->_request->monthlyincome,
                'military' => $this->_request->military,
                'payperiod' => $this->_request->payperiod,
				'paymethod' => $this->_request->paymethod,
                'paydate1' => $this->_request->paydate1,
                'paydate2' => $this->_request->paydate2,
                'aba' => $this->_request->aba,
                'ownrent' => $this->_request->ownrent,
                'timetocall' => $this->_request->timetocall,
                'incomesource' => $this->_request->incomesource,
                'timeatjob' => $this->_request->timeatjob,
                'occupation' => $this->_request->occupation,
                'empaddress' => $this->_request->empaddress,
                'empcity' => $this->_request->empcity,
                'empstate' => $this->_request->empstate,
                'empzip' => $this->_request->empzip,
                'bank' => $this->_request->bank,
                'accountnumber' => $this->_request->accountnumber,
                'accounttype' => $this->_request->accounttype,
                'bankphone' => $this->_request->bankphone,
                'loanamount' => $this->_request->loanamount,
                'ref1name' => $this->_request->ref1name,
                'ref2name' => $this->_request->ref2name,
                'ref1phone' => $this->_request->ref1phone,
                'ref2phone' => $this->_request->ref2phone,
                'ref1relation' => $this->_request->ref1relation,
                'ref2relation' => $this->_request->ref2relation,
                'optin' => $this->_request->optin,
                'bankruptcy' => $this->_request->bankruptcy,
                'yearsatresidence' => $this->_request->yearsatresidence,
                'monthsatresidence' => $this->_request->monthsatresidence,
                'bankinstitutionnumber' => $this->_request->bankinstitutionnumber,
                'bankbranchnumber' => $this->_request->bankbranchnumber
                );
                // Update record in leads table
                $where = "id = ".$leadId;
                $lead->update($leaddatarow,$where);
                // Update record in CashData table
                $where = "id = ".$cashid;
                $cash->update($cashdatarow,$where);

                $this->_helper->flashMessenger->addMessage(array(
		    'message' => array('Lead successfully updated.' => 'success')));		   		
            }
            catch (Zend_Exception $e)
	    {
                $this->_helper->flashMessenger->addMessage(array(
		    'errors' => array('Some error occurred please try again latter.' => 'fail')));
	    }

            $params = array('leadid' => $leadId);
            $this->_helper->redirector->gotoUrl('leadedit?leadid='.$leadId);
        }
    }
}
?>
