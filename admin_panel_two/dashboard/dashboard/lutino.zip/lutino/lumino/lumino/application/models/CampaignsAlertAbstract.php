<?php
/**
 * email alerts for Campaigns
 */
class CampaignsAlertAbstract
{
	/**
	 * @boolean set this to TRUE if you don't want to send an email
	 */
	public $testMode = FALSE;

	public function __construct()
	{
		$this->db = Zend_Registry::get('db');
	}

	public function setTestMode($mode)
	{
		$this->testMode = $mode;
	}
}
