<?php

/**
 * Client Post Setup Time Block Cap class 
 *
 * @category    Model 
 * @package     none      
 * @subpackage  ClientPostSetupTimeBlockCap 
 * @author      Andrew Ahn <andrewa@mediaenvy.com>
 */
class ClientPostSetupTimeBlockCap extends Zend_Db_Table_Abstract
{
	protected $_name = 'ClientPostSetupTimeBlockCaps';

	/**
	 * Gets the Time Block Caps for a post setup
	 *
	 * @param		int		$postSetupID	id of post setup
	 * @param		int		$dayOfWeek	numerical day of week	
	 * @param		int		$startTime	start time in (H:i:s - 00:00:00)	
	 * @param		int		$endTime		end time in (H:i:s - 00:00:00)	
	 *
	 * @return	array				array of time blocks
	 */
	public function getSpecificTimeBlockForPostSetup($postSetupID, $dayOfWeek, $startTime, $endTime)
	{
		$sql = $this->select()
					->where($this->_db->quoteInto("postSetupID = ?", $postSetupID))
					->where($this->_db->quoteInto("dayOfWeek = ?", $dayOfWeek))
					->where($this->_db->quoteInto("startTime = ?", $startTime))
					->where($this->_db->quoteInto("endTime = ?", $endTime));

		$result = $this->fetchRow($sql);

		return $result;

	}

	/**
	 * Gets all the time blocks for a post setup 
	 *
	 * @param		int		$postSetupID		id of post setup
	 *
	 * @return	array					array of post setup time blocks
	 */
	public function getFullDayBlocksForPostSetup($postSetupID)
	{
		$DateUtility = new DateUtility();	
		$daysOfWeek = $DateUtility->getDaysOfWeek();
		$fullTimeBlocks = $DateUtility->getTimeBlocks("00:00:00", "23:59:59", 15);

		$blocks = array();

		// loops through the days of the week
		foreach($daysOfWeek as $day => $dayName) {
			// loop through a full day's time blocks
			foreach($fullTimeBlocks as $timeBlock) { 
				$postSetupTimeBlock = $this->getSpecificTimeBlockForPostSetup($postSetupID, $day, $timeBlock['startTime'], $timeBlock['endTime']);
				if(!empty($postSetupTimeBlock)) { 
					$timeBlock['cap'] = $postSetupTimeBlock->maxLeadSold;
				}	
				
				$blocks[$day][] = $timeBlock;
			}	
		}

		return $blocks;
	}

	/**
	 * Save time blocks for a post setup
	 * 
	 * @param		int		$postSetupID		id of post setup
	 * @param		array	$timeBlocks		array of time blocks
	 *
	 */ 
	public function saveTimeBlocks($postSetupID, $timeBlocks)
	{

		foreach($timeBlocks as $day => $caps) { 
			foreach($caps as $timeBlockCap) {
                if ($timeBlockCap['cap'] === "0" || $timeBlockCap['cap']) {
					   $timeBlockData = array("postSetupID" => $postSetupID,	
										"dayOfWeek" => $day,
										"startTime" => $timeBlockCap['startTime'],
										"endTime" => $timeBlockCap['endTime'],
										"maxLeadSold" => $timeBlockCap['cap']);

					   $this->insert($timeBlockData);
				}
			}
		}

	}

}
