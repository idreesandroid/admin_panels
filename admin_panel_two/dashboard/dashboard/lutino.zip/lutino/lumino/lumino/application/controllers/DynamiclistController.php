<?php

class DynamiclistController extends Zend_Controller_Action 
{
	function getcompaniesAction()
	{
		$type = $_GET['postSetupType'];
		if($type == 'Vendor')
		{
			$Vendors = new Vendors();
 		 	$results = $Vendors->fetchAll();
		}
		if($type == 'Client')
		{
			$Clients = new Clients();
 		 	$results = $Clients->fetchAll();
		}
		$this->view->data = $results;
	}
}
?>
