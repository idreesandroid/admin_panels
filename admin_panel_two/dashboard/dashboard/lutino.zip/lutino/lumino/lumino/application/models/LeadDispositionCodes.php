<?php

class LeadDispositionCodes extends Zend_Db_Table
{
    protected $_name = 'LeadDispositionCodes';
    
    public function getIDByCode($code) {
	
	$sql = $this->_db->select()
		->from($this->_name, array('id'))
		->where($this->_db->quoteInto($this->_name . ".code = ?", $code));

	$result = $this->_db->fetchRow($sql);

	if(count($result) > 0) { 
		return $result['id'];
	}
	else {
		return NULL;
	}
    }
}
?>
