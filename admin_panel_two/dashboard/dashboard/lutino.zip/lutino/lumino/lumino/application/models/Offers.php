<?php

class Offers extends Zend_Db_Table
{
	protected $_name = 'offers';

	public function getTotalLeads($fromDate,$toDate)
	{
		$select = $this->_db->select()
			->from($this->_name,'masteraff, count(distinct(email)) totalLeads')
			->where("originaldate >= '" .$fromDate ."'")
			->where("originaldate <= '" .$toDate ."'")
			->group("masteraff");
		$result = $this->_db->fetchAll($select);
		return $result;
	}

}
?>
