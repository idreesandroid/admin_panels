<?php
/**
 * facade class that handles getting all data for building Denial Report
 */
class DenialReportSummary extends DenialReportAbstract
{
	protected $scorecardNames;

	/**
	 * this is the main interface to this class
	 * @return array
	 */
	public function execute()
	{
		$reports = array();

		$campaigns = $this->getCampaigns();
		$affiliates = array();

		$internals = $this->getInternalRejects();
		$clientCriterias = $this->getClientCriteriaRejects();
		$scorecards = $this->getHiddenVendorScorecardRejects();
		$clients = $this->getClientRejects();
		$campaignRejects = $this->getCampaignRejects();
		$leads = $this->getLeadAttempts();
		$leadSold = $this->getLeadSold();
		$preCheckedVendorRejects = $this->getVendorRejectsByRejectCode(VendorRejectCode::CUST_DENIED_IN_THE_PAST);
		$timeoutVendorRejects = $this->getVendorRejectsByRejectCode(VendorRejectCode::API_TIMEOUT);
		$vendorstrategyVendorRejects = $this->getVendorRejectsByRejectCode(VendorRejectCode::VENDORSTRATEGY_RULE_FAILED);

		foreach ($campaigns['campignid'] as $k => $v) {
			$affiliates[$k] = $campaigns['affname'][$k];
		}

		foreach ($campaigns['campignid'] as $k => $v) {
			$campaignTitles[$k] = $campaigns['campaignTitle'][$k];
		}

		// adding to final report array
		foreach ($internals as $k => $v) {
			if (array_key_exists($v['campaign'], $campaigns['campignid'])) {
				$reports[$v['campaign']]['internalRejects'][] = $internals[$k];
			}
		}
		foreach ($clientCriterias as $k => $v) {
			if (array_key_exists($v['campaign'], $campaigns['campignid'])) {
				$reports[$v['campaign']]['clientCriteriaRejects'][] = $clientCriterias[$k];
			}
		}
		foreach ($campaignRejects as $k => $v) {
			if (array_key_exists($v['campaign'], $campaigns['campignid'])) {
				$reports[$v['campaign']]['campaignRejects'][] = $campaignRejects[$k];
			}
		}
		foreach ($scorecards as $k => $v) {
			$reports[$v['campaign']]['scorecardRejects'][$v['name']] = $v['total'];
		}
		foreach ($clients as $k => $v) {
			$reports[$v['campaign']]['clientRejects'][$v['postSetupID']] = $v['total'];
		}
		foreach ($leads as $k => $v) {
			$reports[$v['campaign']]['leadAttempts'] = $v['total'];
		}
		foreach ($leadSold as $k => $v) {
			$reports[$v['campaign']]['leadSold'] = $v['total'];
		}

		foreach ($preCheckedVendorRejects as $k => $v) {
			$reports[$v['campaign']]['preCheckedVendorRejects'] = $v['total'];
		}

		foreach ($timeoutVendorRejects as $k => $v) {
			$reports[$v['campaign']]['timeoutVendorRejects'] = $v['total'];
		}

		foreach ($vendorstrategyVendorRejects as $k => $v) {
			$reports[$v['campaign']]['vendorstrategyVendorRejects'] = $v['total'];
		}

		foreach ($reports as $k => $v) {
			$reports[$k]['affname'] = $affiliates[$k];
		}

		foreach ($reports as $k => $v) {
			$reports[$k]['campaignTitle'] = $campaignTitles[$k];
		}

		$reports = $this->restructureForView($reports);
		$reports = $this->sortReportByAffiliateName($reports);
		return $reports;
	}

	/**
	 * @param $scorecardHeaders
	 * @param $headerVal
	 * @return bool
	 */
	private function isScorecardRejectHeader($scorecardHeaders, $headerVal)
	{
		foreach ($scorecardHeaders as $v) {
			if ($v['name']  == $headerVal) {
				return TRUE;
			}
		}
		return FALSE;
	}

	/**
	 * Scorecard Rejects
	 * @param $scorecardHeaders
	 * @param $headerVal
	 * @return bool|string
	 */
	private function getScorecardHeaderName($scorecardHeaders, $headerVal)
	{
		foreach ($scorecardHeaders as $v) {
			if ($v['name'] == $headerVal) {
				return 'scorecard_' . $v['name'];
			}
		}
		return FALSE;
	}

	/**
	 * NOTE: maybe make this a view helper.
	 * It reformats the array so we can plug it right into the view.
	 * (each array key is the html table column)
	 *
	 * format: [[2190] => ['campaign'] => 2190, [100] => NULL, [101] => 4,... [10] => NULL]]
	 *
	 * @param array $reports organized by campaign
	 * @return array
	 */
	public function restructureForView($reports)
	{
		$restructured = array();

		// all internal reject codes
		$InternalRejectCode = new InternalRejectCode();
		$internalResults = $InternalRejectCode->fetchAll(array('id'))->toArray();
		$internalCodes = array_map(function($v) { return $v['id']; }, $internalResults);

		// all criteria reject codes
		$ClientRejectCode = new ClientRejectCode();
		$criteriaResults = $ClientRejectCode->fetchAll(array('id'))->toArray();
		$criteriaCodes = array_map(function($v) { return $v['id']; }, $criteriaResults);

		// all campaign reject codes
		$CampaignRejectCode = new CampaignRejectCode();
		$campaignRejectCodeResults = $CampaignRejectCode->fetchAll(array('id'))->toArray();
		$campaignCodes = array_map(function($v) { return $v['id']; }, $campaignRejectCodeResults);

		foreach ($reports as $k => $report)
		{
			//print_r($report);exit;
			$restructured[$k]['campaign'] = $k;
			$restructured[$k]['affiliate'] = $report['affname'];
			$restructured[$k]['campaignTitle'] = $report['campaignTitle'];
//print_r($report);
			// internal rejects
			if (array_key_exists('internalRejects', $report)) {
				foreach ($internalCodes as $code) {
					foreach ($report['internalRejects'] as $reject) {
						if ($reject['rejectCode'] == $code) {
							$restructured[$k][$code] = $reject['total'];
						}
					}
				}
			}

			// clientCriteria rejects
			if (array_key_exists('clientCriteriaRejects', $report)) {
				foreach ($criteriaCodes as $code) {
					foreach ($report['clientCriteriaRejects'] as $reject) {
						if ($reject['rejectCode'] == $code) {
							$restructured[$k][$code] = $reject['total'];
						}
					}
				}
			}

			// campaign rejects
			if (array_key_exists('campaignRejects', $report)) {
				foreach ($campaignCodes as $code) {
					foreach ($report['campaignRejects'] as $reject) {
						if ($reject['rejectCode'] == $code) {
							$restructured[$k]['campaign_' . $code] = $reject['total'];
						}
					}
				}
			}

			// scorecard rejects - used in summary
			if (array_key_exists('scorecardRejects', $report)) {
				foreach ($report['scorecardRejects'] as $scorecardKey => $reject) {
					$restructured[$k]['scorecard_' . $scorecardKey] = $reject;
				}
			}

			// client rejects
			if (array_key_exists('clientRejects', $report)) {
				foreach ($report['clientRejects'] as $clientKey => $reject) {
					$restructured[$k]['client_' . $clientKey] = $reject;
				}
			}

			// lead attempts
			if (array_key_exists('leadAttempts', $report)) {
				$restructured[$k]['leadAttempts'] = $report['leadAttempts'];
			}

			// lead sold
			if (array_key_exists('leadSold', $report)) {
				$restructured[$k]['leadSold'] = $report['leadSold'];
			}

			if (array_key_exists('preCheckedVendorRejects', $report)) {
				$restructured[$k]['preCheckedVendorRejects'] = $report['preCheckedVendorRejects'];
			}

			if (array_key_exists('timeoutVendorRejects', $report)) {
				$restructured[$k]['timeoutVendorRejects'] = $report['timeoutVendorRejects'];
			}

			if (array_key_exists('vendorstrategyVendorRejects', $report)) {
				$restructured[$k]['vendorstrategyVendorRejects'] = $report['vendorstrategyVendorRejects'];
			}
		}
		return $restructured;
	}

	public function getHiddenVendorScorecardRejects()
	{
		$join = "";
		$condition = "";
		if (!empty($this->affiliateId) || count($this->storeIds)) {
			$join = " INNER JOIN Leads l on l.id = pl.leadID ";
			if (!empty($this->affiliateId)) {
				$condition.= " and l.affiliateID = ".$this->affiliateId." ";
			}
			if (count($this->storeIds)) {
				$condition.= " and l.storeID in (".implode(",",$this->storeIds).") ";
			}
		}

		$sql = "SELECT replace(pl.campaign,' ','') campaign, name, count(1) total
			FROM  PostLogs pl $join
			LEFT OUTER JOIN LeadStrategies ON LeadStrategies.leadID = pl.leadID
			LEFT OUTER JOIN Variates ON Variates.id = LeadStrategies.variateID
			WHERE  pl.postdate >= '" . $this->fromDate . "'
			AND pl.postdate <= '" . $this->toDate . "'
			AND pl.startTime >= '00:00:00' AND pl.startTime <= '23:59:59'
			$condition
			AND postsetupid IN (  SELECT   postSetupID  FROM   VendorPostSetups ) AND poststatus = 'no' and Variates.hideInAdmin = 1
			GROUP BY  pl.campaign, NAME";

		return $this->slave->fetchAll($sql);
	}


	/**
	 * @return array
	 */
	public function prepareScorecardRejectHeader()
	{
		$MultiVariate = new MultiVariate();
		$multiVariateData = $MultiVariate->getHiddenActiveVariates();

		$scorecardHeaders = array();
		foreach ($multiVariateData AS $v) {
				$scorecardHeaders[] = $v;
		}

		return $scorecardHeaders;
	}

	public function prepareReportForTableView($scorecardHeaders, $vendorsHeaders, $clientHeaders, $reports)
	{
		$reportsFormatted = array();
		$result = array();

		// If we don't have any data, we set empty fields to default empty
		if (empty($reports)) {
			foreach ($scorecardHeaders as $scorecardVal) {
				$header = 'scorecard_' . $scorecardVal['name'];
				$result['empty'][$header] = '';
			}
			foreach ($clientHeaders as $headerVal) {
				$header = 'client_' . $headerVal['postSetupID'];
				$result['empty'][$header] = '';
			}
			return $result;
		}
		// prepare Scorecard Rejects
		foreach ($reports as $reportKey => $reportValue) {
			foreach ($reportValue as $v) {
				if (count($scorecardHeaders) > 0) {

					foreach ($scorecardHeaders as $headerVal) {
						$header = 'scorecard_' . $headerVal['name'];
						if (array_key_exists($header, $reportValue)) {
							$reportsFormatted[$reportKey][$header] = $reportValue[$header];
						} else {
							$reportsFormatted[$reportKey][$header] = '';
						}
					}
				}
			}

			if (count($scorecardHeaders) > 0) {
			    $result[$reportKey] = $reportValue + $reportsFormatted[$reportKey];
			}
			else  {
			    $result[$reportKey] = $reportValue;
			}

		}

		// prepare Client Rejects
		foreach ($reports as $reportKey => $reportValue) {
			foreach ($reportValue as $v) {
				foreach ($clientHeaders as $headerVal) {
					$header = 'client_' . $headerVal['postSetupID'];
					if (array_key_exists($header, $reportValue)) {
						$reportsFormatted[$reportKey][$header] = $reportValue[$header];
					} else {
						$reportsFormatted[$reportKey][$header] = '';
					}
				}
			}
			$result[$reportKey] = $reportValue + $reportsFormatted[$reportKey];
		}

		return $result;
	}


	/**
	 * used by Denial Report Summary
	 */
	public function prepareColumnHeadersForCsv($internalHeaders, $criteriaHeaders, $campaignCodeHeaders, $scorecardHeaders, $clientsHeaders)
	{
		$csvHeaders = array();
		$csvHeaders[] = 'affiliate';
		$csvHeaders[] = 'campaign';
		$csvHeaders[] = 'campaignTitle';
		$csvHeaders[] = 'leadAttempts';
		$csvHeaders[] = 'campaignTitle';

		foreach($internalHeaders as $v) {
			$csvHeaders[] = $v['id'];
		}
		foreach($criteriaHeaders as $v) {
			$csvHeaders[] = $v['id'];
		}
		foreach($campaignCodeHeaders as $v) {
			$csvHeaders[] = "campaign_" . $v['id'];
		}

		$csvHeaders[] = 'preCheckedVendorRejects';
		$csvHeaders[] = 'timeoutVendorRejects';
		$csvHeaders[] = 'vendorstrategyVendorRejects';

		$csvVendorsClients = array();

		foreach ($scorecardHeaders as $scorecardHeader) {
			$csvVendorsClients[] = $scorecardHeader['name'];
		}

		foreach ($clientsHeaders as $clientsHeader) {
			$csvVendorsClients[] = $clientsHeader['title'];
		}
		$csvVendorsClients[] = 'leadSold';

		foreach($csvVendorsClients as $v) {
			$csvHeaders[] = $v;
		}
		return $csvHeaders;
	}

	/**
	 * format Denial Report Summary data as it has missing array elements if there's no data
	 *
	 * @param array $csvHeaders
	 * @param array $reports
	 * @return array
	 */
	public function prepareReportForCsv($csvHeaders, $reports, $total, $scorecardHeaders, $clientsHeaders)
	{
		$reportsFormatted = array();
		foreach ($reports as $reportKey => $reportValue) {
			foreach ($reportValue as $k => $v) {
				foreach ($csvHeaders as $headerVal) {
					if ($this->isScorecardRejectHeader($scorecardHeaders, $headerVal)) {
						$scorecardHeaderName = $this->getScorecardHeaderName($scorecardHeaders, $headerVal);
						$reportsFormatted[$reportKey][$headerVal] = $reportValue[$scorecardHeaderName];
					} else if ($this->isClientRejectHeader($clientsHeaders, $headerVal)) {
						$clientRejectPostSetupID = $this->getClientRejectPostSetupID($clientsHeaders, $headerVal);
						$reportsFormatted[$reportKey][$headerVal] = $reportValue[$clientRejectPostSetupID];
					} else if (array_key_exists($headerVal, $reportValue)) {
						$reportsFormatted[$reportKey][$headerVal] = $reportValue[$headerVal];
					} else {
						$reportsFormatted[$reportKey][$headerVal] = '';
					}
				}
			}
		}

		$total['affiliate'] = 'Total';
		$total['campaign'] = '';
		$total['campaignTitle'] = '';

		foreach ($total as $k => $v) {
			foreach ($csvHeaders as $headerVal) {
				if ($this->isScorecardRejectHeader($scorecardHeaders, $headerVal)) {
					$scorecardHeaderName = $this->getScorecardHeaderName($scorecardHeaders, $headerVal);
					$reportsFormatted['total'][$headerVal] = $total[$scorecardHeaderName];
				} else if ($this->isClientRejectHeader($clientsHeaders, $headerVal)) {
					$clientRejectPostSetupID = $this->getClientRejectPostSetupID($clientsHeaders, $headerVal);
					$reportsFormatted['total'][$headerVal] = $total[$clientRejectPostSetupID];
				} else if (array_key_exists($headerVal, $total)) {
					$reportsFormatted['total'][$headerVal] = $total[$headerVal];
				} else {
					$reportsFormatted['total'][$headerVal] = '';
				}
			}
		}

		return $reportsFormatted;
	}
}
