<?php
class BuyerRejectsController extends Zend_Controller_Action
{
    private $baseurl;

    function init()
    {
        $AdminNameSpace = new Zend_Session_Namespace('AdminUser');
        if (!$AdminNameSpace->userid) {
            $this->_redirect('index/login');
        }
        $this->baseurl = $this->_request->getBaseUrl();
    }

    function errorscountAction()
    {
        $this->_helper->viewRenderer->setnoRender();

        $BuyerRejectErrors = new BuyerRejectErrors();
        $errors = $BuyerRejectErrors->getTodaysErrorsCount();

        $data = array('count' => $errors['cnt']);
        echo json_encode($data);
    }

    function reportAction()
    {
        $fromDate = ($this->_request->fromDate) ? date('Y-m-d', strtotime($this->_request->fromDate)) : date('Y-m-d');
		$toDate = ($this->_request->toDate) ? date('Y-m-d', strtotime($this->_request->toDate)) : date('Y-m-d');

        $BuyerRejectErrors = new BuyerRejectErrors();
        $data = $BuyerRejectErrors->getErrors($fromDate,$toDate);

        $this->view->data = $data;
        $this->view->fromDate = $fromDate;
        $this->view->toDate = $toDate;
    }
}