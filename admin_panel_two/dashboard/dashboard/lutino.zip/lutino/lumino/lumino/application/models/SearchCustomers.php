<?php

/**
 * Search Customers Report class
 * pulls data about customer
 *
 * @category    Model
 * @package     none
 * @subpackage  SearchCustomersReport
 * @author      Andrei Shkolin <andrews@mediaenvy.com>
 */
class SearchCustomers
{
	public function __construct()
	{
		$bootstrap = Zend_Controller_Front::getInstance()->getParam("bootstrap");
		$resource = $bootstrap->getPluginResource('multidb');
		$this->db_slave = $resource->getDb('slave');
	}

	/**
	 * Gets information about customer
	 * NOTE: This method DOES NOT query LeadDupes table.
	 *
	 * @param    date $fromDate start date
	 * @param    date $toDate end date
	 * @param    string $email email
	 * @param    string $ssn ssn
	 *
	 * @return    int            number of total dupes
	 */
	public function getTotalCustomerData($fromDate, $toDate, $email, $ssn)
	{

		$dateWhere = $this->db_slave->quoteInto("originaldate >= ?", $fromDate) . " AND " .
			$this->db_slave->quoteInto("originaldate <= ?", $toDate);

		$sql = $this->db_slave->select()
			->from("Leads", array("total" => "COUNT(1)"))
			->join("CashData", "Leads.id = CashData.leadID", array())
			->where($dateWhere);

		if (!empty($email)) {
			$sql->where($this->db_slave->quoteInto("Leads.email = ?", $email));
		} else if (!empty($ssn)) {
			$sql->where($this->db_slave->quoteInto("CashData.ssn = ?", $ssn));
		}

		$result = $this->db_slave->fetchRow($sql);

		if (count($result) > 0) {
			return $result['total'];
		} else {
			return 0;
		}
	}

	/**
	 * Gets information about customer
	 *
	 * @param    string $fromDate start date
	 * @param    string $toDate end date
	 * @param    string $email email
	 * @param    string $ssn ssn
	 * @param    int $page page for pagination
	 * @param    int $limit limit of rows per page
	 * @param    string $sortCol column to sort on
	 * @param    string $sortOrder sort order
	 *
	 * @return    array            array of lead dupe data
	 */
	public function getCustomerData($fromDate, $toDate, $email, $ssn, $page = 0, $limit = 50, $sortCol = "datetime", $sortOrder = "ASC")
	{

		$dateWhere = $this->db_slave->quoteInto("originaldate >= ?", $fromDate) . " AND " .
			$this->db_slave->quoteInto("originaldate <= ?", $toDate);

		$sql = $this->db_slave->select()
			->from("Leads", array("originaldate", "originaltime", "datetime" => new Zend_Db_Expr("CONCAT(originaldate, ' ', originaltime)"), "id", "storeID", "affiliateID", "campaign", "leadsold", "ip", "fname", "lname", "email", "dob", "city", "state", "mphone"))
			->joinLeft("CashData", "Leads.id = CashData.leadID", array("ssn", "monthlyincome"))
			->joinLeft("Affiliates", "Leads.affiliateID = Affiliates.id", array("masteraff"))
			->where($dateWhere)
			->limitPage($page, $limit);

		if (!empty($email)) {
			$sql->where($this->db_slave->quoteInto("Leads.email = ?", $email));
		} else if (!empty($ssn)) {
			$sql->where($this->db_slave->quoteInto("CashData.ssn = ?", $ssn));
		}

		if (empty($sortCol) || $sortCol == "datetime") {
			$sql->order("originaldate $sortOrder");
			$sql->order("originaltime $sortOrder");
		} else if ($sortCol == "citystate") {
			$sql->order("city $sortOrder");
			$sql->order("state $sortOrder");
		} else if ($sortCol == "geolocation") {
			$sql->order("ipCity $sortOrder");
			$sql->order("ipState $sortOrder");
		} else {
			$sql->order($sortCol . " " . $sortOrder);
		}

		$result = $this->db_slave->fetchAll($sql);

		return $result;

	}

	/**
	 * Gets information about customer by leadID
	 *
	 * @param    string $fromDate start date
	 * @param    string $toDate end date
	 * @param    string $leadID lead id
	 * @param    int $page page for pagination
	 * @param    int $limit limit of rows per page
	 * @param    string $sortCol column to sort on
	 * @param    string $sortOrder sort order
	 *
	 * @return    array            array of lead dupe data
	 */
	public function getCustomerDataByLeadID($fromDate, $toDate, $leadID, $page = 0, $limit = 50, $sortCol = "datetime", $sortOrder = "ASC")
	{

		$dateWhere = $this->db_slave->quoteInto("originaldate >= ?", $fromDate) . " AND " .
			$this->db_slave->quoteInto("originaldate <= ?", $toDate);

		$sql = $this->db_slave->select()
			->from("Leads", array("originaldate", "originaltime", "datetime" => new Zend_Db_Expr("CONCAT(originaldate, ' ', originaltime)"), "id", "storeID", "affiliateID", "campaign", "leadsold", "ip", "fname", "lname", "email", "dob", "city", "state", "mphone"))
			->joinLeft("CashData", "Leads.id = CashData.leadID", array("ssn", "monthlyincome"))
			->joinLeft("Affiliates", "Leads.affiliateID = Affiliates.id", array("masteraff"))
			->where($dateWhere)
			->limitPage($page, $limit);

		if (!empty($leadID)) {
			$sql->where($this->db_slave->quoteInto("Leads.id = ?", $leadID));
		}

		if (empty($sortCol) || $sortCol == "datetime") {
			$sql->order("originaldate $sortOrder");
			$sql->order("originaltime $sortOrder");
		} else if ($sortCol == "citystate") {
			$sql->order("city $sortOrder");
			$sql->order("state $sortOrder");
		} else if ($sortCol == "geolocation") {
			$sql->order("ipCity $sortOrder");
			$sql->order("ipState $sortOrder");
		} else {
			$sql->order($sortCol . " " . $sortOrder);
		}

		$result = $this->db_slave->fetchAll($sql);

		return $result;

	}

	/**
	 * Method gets merged data about vendors and clients
	 * @return array with vendors and clients
	 */
	public function getAllVendorsAndClients() {
		$sql = "SELECT
					v.company,
					vps.vendorID,
					vps.postSetupID
				FROM
					Vendors v
				LEFT JOIN
					VendorPostSetups vps ON v.id = vps.vendorID";

		$vendors = $this->db_slave->fetchAll($sql);

		$sql = "SELECT
					c.company,
					cps.clientID,
					cps.postSetupID
				FROM
					Clients c
				LEFT JOIN
					ClientPostSetups cps ON c.id = cps.clientID";

		$clients = $this->db_slave->fetchAll($sql);

		return array_merge($vendors, $clients);
	}
}
