<?php
class CampaignReport extends CampaignReportAbstract
{
	/**
	 * Gets the campaign report data
	 *
	 * @param		startDate	date	start of date range
	 * @param		endDate		date	end of date range
	 * @param		campaign	string	campaign filter
	 * @return		array	array of campaign report data
	 */
	public function getCampaignReports($isxml = false, $startDate, $endDate, $originalTimeStart, $originalTimeEnd, $storeIds, $multiVarStart=0, $multiVarEnd=0, $originationDate="", $selectedStrategyID=0, $selectedAffiliate="")
	{
		$Leads = new Leads();
		$Leads->initSettingsForSlaveDB();

		$leadData = $Leads->getCampaignReportData($startDate, $endDate, $originalTimeStart, $originalTimeEnd, $storeIds, $multiVarStart, $multiVarEnd, $originationDate, $selectedStrategyID, $selectedAffiliate);
		$campaignsWithNotSubIDs = $Leads->campaignsWithNotSubIDs($startDate, $endDate, $originalTimeStart, $originalTimeEnd);

		$reportData	= $this->calculateValues($leadData);
		$reportData	= $this->addHasSubIdsElement($reportData, $campaignsWithNotSubIDs);

		return $reportData;
	}

	public function getSubIdReports($isxml = false, $startDate, $endDate, $originalTimeStart, $originalTimeEnd, $storeIds, $campaign = NULL, $multiVarStart=0, $multiVarEnd=0, $originationDate="", $selectedStrategyID=0)
	{
		$Leads = new Leads();
		$Leads->initSettingsForSlaveDB();

		$leadData = $Leads->getSubIDReportData($startDate, $endDate, $originalTimeStart, $originalTimeEnd, $storeIds, $campaign, $multiVarStart, $multiVarEnd, $originationDate, $selectedStrategyID);

		$reportData	= $this->calculateValues($leadData);

		return $reportData;
	}

	public function getSubId2Reports($isxml = false, $startDate, $endDate, $originalTimeStart, $originalTimeEnd, $storeIds, $campaign = NULL, $multiVarStart=0, $multiVarEnd=0, $originationDate="", $selectedStrategyID=0)
	{
		$Leads = new Leads();
		$Leads->initSettingsForSlaveDB();

		$leadData = $Leads->getSubID2ReportData($startDate, $endDate, $originalTimeStart, $originalTimeEnd, $storeIds, $campaign, $multiVarStart, $multiVarEnd, $originationDate, $selectedStrategyID);

		$reportData	= $this->calculateValues($leadData);

		return $reportData;
	}

	public function getSubId3Reports($isxml = false, $startDate, $endDate, $originalTimeStart, $originalTimeEnd, $storeIds, $campaign = NULL, $multiVarStart=0, $multiVarEnd=0, $originationDate="", $selectedStrategyID=0)
	{
		$Leads = new Leads();
		$Leads->initSettingsForSlaveDB();

		$leadData = $Leads->getSubID3ReportData($startDate, $endDate, $originalTimeStart, $originalTimeEnd, $storeIds, $campaign, $multiVarStart, $multiVarEnd, $originationDate, $selectedStrategyID);

		$reportData	= $this->calculateValues($leadData);

		return $reportData;
	}
}
