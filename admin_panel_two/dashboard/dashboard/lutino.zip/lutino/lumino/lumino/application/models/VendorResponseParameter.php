<?php

class VendorResponseParameter extends Zend_Db_Table
{
	protected $_name = 'VendorResponseParameters';

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}

	public function findParameterByVendorIDandName($vendorID, $paramName)
	{
		$sql = "SELECT
					*
				FROM
					VendorResponseParameters vrp
				WHERE
					vrp.vendorID = $vendorID AND vrp.description LIKE '%".$paramName."%'";

		$sqlresult = $this->db->fetchAll($sql);

		return $sqlresult;
	}

	public function findParameterByName($paramName)
	{
		$sql = "SELECT
					*
				FROM
					VendorResponseParameters vrp
				WHERE
					vrp.description LIKE '%".$paramName."%'";

		$sqlresult = $this->db->fetchAll($sql);

		return $sqlresult;
	}

	public function findParameterByVendorStrategyIDsAndByName($vendorStrategyIDs, $paramName)
	{
		// using union as we always want vendorid 10000 params available
	    $sql = "SELECT
				vrp.*
				FROM
					VendorStrategies vs
				LEFT JOIN
					VendorResponseParameters vrp ON vs.vendorID = vrp.vendorID
				WHERE
					vs.id IN ($vendorStrategyIDs) AND vrp.description LIKE '%".$paramName."%'
			    UNION
				SELECT vrp.* FROM VendorResponseParameters vrp WHERE vendorID = 10000";

		$sqlresult = $this->db->fetchAll($sql);

		return $sqlresult;
	}
}
