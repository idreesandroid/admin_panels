<?php
class AffiliateDashBoardReport {

    private $fromDate;
    private $toDate;
    private $chartType;
    private $currentTime;

    const HOURLY = 'hourly';
    const SEVEN_DAYS = 'sevendays';
    const FIVE_WEEKS = 'fiveweeks';

    public function __construct()
    {
        // we want to run all queries against slave db
        $bootstrap = Zend_Controller_Front::getInstance()->getParam("bootstrap");
        $this->config = Zend_Registry::get('config');
        $resource = $bootstrap->getPluginResource('multidb');
        $this->slave = $resource->getDb('slave');

        $originalTimeStart = $date = date('H:i:s');
        $userSession = new Zend_Session_Namespace('UserSession');
        $this->affiliateID = $userSession->userid;

        $dashboardReportLMSFactory = new DashboardReportLMSFactory();
        $this->dashboardReportLMSFactoryObject = $dashboardReportLMSFactory->create($this->config->lmsName);
    }

    public function setChartType($chartType, $fromDate, $toDate, $isCurrentTimeSnapshot = 'false') {

        $this->fromDate = $fromDate;
        $this->toDate = $toDate;
        $this->chartType = $chartType;
        $originalTimeStart = $date = date('H:i:s');
        if ($isCurrentTimeSnapshot == 'true') {
            $this->currentTime = "AND Leads.originaltime <= '$originalTimeStart'";
        }
    }

    public function getDashboardData()
    {
        $dashboardData = array();

        if ($this->chartType == self::HOURLY) {

            $dashboardData['totalAttemptsToday'] = number_format($this->getTotalAttemptsToday());
            $dashboardData['totalActiveCampaigns'] = $this->getTotalActiveCampaigns();
            $dashboardData['totalCostToday'] = number_format($this->getTotalCostToday(),2,".",",");
            $dashboardData['totalSoldToday'] = $this->getTotalSoldToday();

            $totalNewCustomers = $this->getTotalNewCustomers();
            $dashboardData['totalNewCustomers'] = $totalNewCustomers;
            $totalNewCustomersPercentage = ($totalNewCustomers > 0 && $dashboardData['totalSoldToday'] > 0) ? 100 * ($totalNewCustomers / $dashboardData['totalSoldToday']) : 0;
            $dashboardData['totalNewCustomersPercentage'] = number_format($totalNewCustomersPercentage,2,".",",");

            $totalReturningCustomers = $this->getTotalReturningCustomers();
            $dashboardData['totalReturningCustomers'] = $totalReturningCustomers;
            $totalReturningCustomersPercentage = ($totalReturningCustomers > 0 && $dashboardData['totalSoldToday'] > 0) ? 100 * ($totalReturningCustomers / $dashboardData['totalSoldToday']) : 0;
            $dashboardData['totalReturningCustomersPercentage'] = number_format($totalReturningCustomersPercentage,2,".",".");

            $totalNewCustomersOriginations = $this->getTotalNewCustomersOriginations();
            $totalNewCustomersOriginationsPercentage = ($totalNewCustomersOriginations > 0 && $dashboardData['totalSoldToday'] > 0) ? 100 * ($totalNewCustomersOriginations / $totalNewCustomers) : 0;
            $dashboardData['totalNewCustomersOriginations'] = number_format($totalNewCustomersOriginationsPercentage,2,".",".");

            $totalReturningCustomersOriginations = $this->getTotalReturningCustomersOriginations();
            $totalReturningCustomersOriginationsPercentage = ($totalReturningCustomersOriginations > 0 && $dashboardData['totalSoldToday'] > 0) ? 100 * ($totalReturningCustomersOriginations / $totalReturningCustomers) : 0;
            $dashboardData['totalReturningCustomersOriginations'] = number_format($totalReturningCustomersOriginationsPercentage,2,".",".");

            $totalLeadPurchasedByHour = $this->getTotalLeadPurchasedByHour();
            $totalLeadAttemptsByHour = $this->getTotalAttemptsByHour();

            $hours = array();
            foreach (range(0, 23) as $hour) {
                $hours[] = $hour;
            }

            $totalHourlyAttempts = array();
            foreach ($hours as $hour) {
                if ($total = $this->getDataByHour($totalLeadAttemptsByHour, $hour)) {
                    $totalHourlyAttempts[] = $total;
                } else {
                    $totalHourlyAttempts[] = 0;
                }
            }

            $totalHourlyPurchased = array();
            foreach ($hours as $hour) {
                if ($total = $this->getDataByHour($totalLeadPurchasedByHour, $hour)) {
                    $totalHourlyPurchased[] = $total;
                } else {
                    $totalHourlyPurchased[] = 0;
                }
            }

            $dashboardData['chartHours'] = json_encode($hours);
            $dashboardData['chartLeadsAttemptsHourly'] = json_encode($totalHourlyAttempts);
            $dashboardData['chartLeadsPurchaseHourly'] = json_encode($totalHourlyPurchased);

        } else if($this->chartType == self::SEVEN_DAYS) {

            $totalLeadPurchasedForLastSevenDays = $this->getTotalLeadPurchasedForLastSevenDays();
            $totalLeadAttemptsForLastSevenDays = $this->getTotalAttemptsForLastSevenDays();

            $labelNames = array();
            $chartLeadsAttemptsForLastSevenDaysData = array();
            foreach ($totalLeadAttemptsForLastSevenDays as $v) {
                $labelNames[] = $v['name'];
                $chartLeadsAttemptsForLastSevenDaysData[] = $v['total'];
            }

            $chartLeadsPurchaseForLastSevenDaysData = array();
            foreach ($labelNames as $date) {
                if ($total = $this->getDataByDate($totalLeadPurchasedForLastSevenDays, $date)) {
                    $chartLeadsPurchaseForLastSevenDaysData[] = $total;
                } else {
                    $chartLeadsPurchaseForLastSevenDaysData[] = 0;
                }
            }

            $dashboardData['chartDays'] = json_encode($labelNames);
            $dashboardData['chartLeadsAttemptsForLastSevenDays'] = json_encode($chartLeadsAttemptsForLastSevenDaysData);
            $dashboardData['chartLeadsPurchaseForLastSevenDays'] = json_encode($chartLeadsPurchaseForLastSevenDaysData);

        } else if($this->chartType == self::FIVE_WEEKS) {

            $totalTotalLeadPurchasedCurrentDayForLastFiveWeeks = $this->getTotalLeadPurchasedCurrentDayForLastFiveWeeks();
            $totalLeadAttemptsCurrentDayForLastFiveWeeks = $this->getTotalLeadAttemptsCurrentDayForLastFiveWeeks();
            $labelNames = array();

            $chartLeadAttemptsCurrentDayForLastFiveWeeksData = array();
            foreach ($totalLeadAttemptsCurrentDayForLastFiveWeeks as $v) {
                $labelNames[] = $v['name'];
                $chartLeadAttemptsCurrentDayForLastFiveWeeksData[] = $v['total'];
            }

            $chartTotalLeadPurchasedCurrentDayForLastFiveWeeksData = array();
            foreach ($labelNames as $date) {
                if ($total = $this->getDataByDate($totalTotalLeadPurchasedCurrentDayForLastFiveWeeks, $date)) {
                    $chartTotalLeadPurchasedCurrentDayForLastFiveWeeksData[] = $total;
                } else {
                    $chartTotalLeadPurchasedCurrentDayForLastFiveWeeksData[] = 0;
                }
            }

            $dashboardData['chartDays'] = json_encode($labelNames);
            $dashboardData['chartLeadPurchasedCurrentDayForLastFiveWeeksData'] = json_encode($chartTotalLeadPurchasedCurrentDayForLastFiveWeeksData);
            $dashboardData['chartLeadAttemptsCurrentDayForLastFiveWeeksData'] = json_encode($chartLeadAttemptsCurrentDayForLastFiveWeeksData);
        }

        return $dashboardData;
    }

    /**
     * gets the avg leads per hour from 0900 - 1800
     * for the last 7 days
     * @return array
     */
    public function hourlyAvgForThePastWeek()
    {
        $sql = "SELECT
				ROUND(AVG(hourly_totals.total),0) as averageLeads,
				hourly_totals.hour,
				CONCAT(hourly_totals.hour, ':00') as prettyHour
				FROM (
					select
					count(1) as total,
						originaldate,
						LEFT(originaltime,2) as hour
						from Leads
						where affiliateID = $this->affiliateID
						AND originaldate >= (curdate() - INTERVAL 7 DAY) and originaldate < curdate()
						GROUP BY originaldate,
						LEFT(originaltime,2)
					) as hourly_totals
					GROUP BY hourly_totals.hour
					having hourly_totals.hour >= 9 and hourly_totals.hour <= 18";

        $results = $this->slave->fetchAll($sql);
        return $results;
    }

    /**
     * gets the leads per hour from 0900 - 1800 for today
     * @return array
     */
    public function totalTodayPerHour()
    {
        $sql = "select
			count(1) as total,
			LEFT(originaltime,2) as hour,
			CONCAT(LEFT(originaltime,2), ':00') as prettyHour
			from Leads
            where affiliateID = $this->affiliateID
			AND originaldate=curdate()
			group by hour
			having hour >= 9 and hour <= 18";

        $results = $this->slave->fetchAll($sql);
        return $results;
    }

    /**
     * gets the avg leads per hour from 0900 - 1800
     * for a specific day, looking back 6 weeks.
     * e.g. last 6 'Mondays', 2012-12-31, 2012-12-24, etc.
     *
     * @param string $dayOfWeekDates comma-delim string of 6 dates for a specific day
     * @return array
     */
    public function hourlyAvgForSpecificDay($dayOfWeekDates)
    {
        $sql = "SELECT
        ROUND(AVG(hourly_totals.total),0) as averageLeads,
        hourly_totals.hour,
        CONCAT(hourly_totals.hour, ':00') as prettyHour
        FROM
        (
        select
        count(1) as total,
        originaldate,
        LEFT(originaltime,2) as hour
        from Leads
        where affiliateID = $this->affiliateID
        and originaldate IN ($dayOfWeekDates)
        GROUP BY originaldate,
        LEFT(originaltime,2)
        ) as hourly_totals
        GROUP BY hourly_totals.hour
        having hourly_totals.hour >= 9 and hourly_totals.hour <= 18";

        $results = $this->slave->fetchAll($sql);
        return $results;
    }

    private function getTotalAttemptsToday()
    {
        $sql = "SELECT
					count(*) total
				FROM
					Leads l
				WHERE
                    l.affiliateID = $this->affiliateID
                AND
					l.originaldate >= '" . $this->fromDate . "'
				AND
					l.originaldate <= '" . $this->toDate . "'";
        $result = $this->slave->fetchAll($sql);
        if ($result) {
            return $result[0]['total'];
        }
        return 0;
    }

    private function getTotalSoldToday()
    {
        $sql = "SELECT
					count(*) total
				FROM
					Leads l
				WHERE
				    l.affiliateID = $this->affiliateID
                AND
					l.originaldate >= '" . $this->fromDate . "'
				AND
					l.originaldate <= '" . $this->toDate . "'
				AND
					l.leadsold = 1";

        $result = $this->slave->fetchAll($sql);
        if ($result) {
            return $result[0]['total'];
        }
        return array();
    }

    private function getTotalActiveCampaigns()
    {
        $sql = "SELECT
					count(*) total
				FROM
					Campaigns c
                INNER JOIN
                    Affiliates ON c.masteraff = Affiliates.masteraff
                WHERE
                    Affiliates.id = $this->affiliateID
				AND
					c.active = 1
                ";

        $result = $this->slave->fetchAll($sql);
        if ($result) {
            return $result[0]['total'];
        }
        return array();
    }

    private function getTotalCostToday()
    {
        $sql = "SELECT
					SUM(c.costPerLead) total
				FROM
					Leads l
				LEFT JOIN Campaigns c ON l.campaign = c.id
				WHERE
                    l.affiliateID = $this->affiliateID
                AND
					l.originaldate >= '" . $this->fromDate . "'
				AND
					l.originaldate <= '" . $this->toDate . "'
				AND l.leadsold = 1";

        $result = $this->slave->fetchAll($sql);
        if ($result) {
            return $result[0]['total'];
        }
        return 0;
    }


    private function getTotalNewCustomers()
    {
        $sql = "SELECT
					count(*) total
				FROM
					Leads l
				LEFT JOIN
				    ReturningCustomers rc ON l.id = rc.leadID
				WHERE
				    l.affiliateID = $this->affiliateID
				AND
					l.originaldate >= '" . $this->fromDate . "'
				AND
					l.originaldate <= '" . $this->toDate . "'
				AND
					l.leadsold = 1
				AND ISNULL(rc.leadID)
				";

        $result = $this->slave->fetchAll($sql);
        if ($result) {
            return $result[0]['total'];
        }
        return array();
    }

    private function getTotalReturningCustomers()
    {
        $sql = "SELECT
					count(*) total
				FROM
					Leads l
				LEFT JOIN ReturningCustomers rc ON l.id = rc.leadID
				WHERE
                    l.affiliateID = $this->affiliateID
                AND
					l.originaldate >= '" . $this->fromDate . "'
				AND
					l.originaldate <= '" . $this->toDate . "'
				AND
					l.leadsold = 1
				AND (rc.leadID) IS NOT NULL";

        $result = $this->slave->fetchAll($sql);
        if ($result) {
            return $result[0]['total'];
        }
        return array();
    }

    private function getTotalNewCustomersOriginations()
    {
        return $this->dashboardReportLMSFactoryObject->getTotalNewCustomersOriginations($this->fromDate, $this->toDate,$this->affiliateID);
    }

    private function getTotalReturningCustomersOriginations()
    {
        $sql = "SELECT
					count(1) total
				FROM
					Master m
				LEFT JOIN Leads l ON l.id = m.leadID
				LEFT JOIN ReturningCustomers rc ON l.id = rc.leadID
				WHERE
					m.Loan_Type = 'S'
				AND m.Loan_Status NOT IN ('I', 'V', 'W')
				AND LEFT(m.Loan_Date, 10) >= '" . $this->fromDate . "'
				AND LEFT(m.Loan_Date, 10) <= '" . $this->toDate . "'
				AND
					l.leadsold = 1
				AND
				    l.affiliateID = $this->affiliateID
				AND (rc.leadID) IS NOT NULL";

        $result = $this->slave->fetchAll($sql);
        if ($result) {
            return $result[0]['total'];
        }
        return array();
    }

    private function getTotalLeadPurchasedByHour()
    {
        $sql = "SELECT
					HOUR(Leads.originaltime) hour,
					count(1) total
				FROM
					Leads
				JOIN CashData ON Leads.id = CashData.leadID
				WHERE
                    Leads.affiliateID = $this->affiliateID
                AND
					Leads.leadsold = 1
				AND
					Leads.originaldate >= '" . $this->fromDate . "'
				AND
					Leads.originaldate <= '" . $this->toDate . "'
				GROUP BY
					HOUR(Leads.originaltime)";

        $result = $this->slave->fetchAll($sql);
        if ($result) {
            return $result;
        }
        return array();
    }

    private function getTotalAttemptsByHour()
    {
        $sql = "SELECT
					HOUR(Leads.originaltime) hour,
					count(1) total
				FROM
					Leads
				JOIN CashData ON Leads.id = CashData.leadID
				WHERE
                    Leads.affiliateID = $this->affiliateID
                AND
					Leads.originaldate >= '" . $this->fromDate . "'
				AND
					Leads.originaldate <= '" . $this->toDate . "'
				GROUP BY
					HOUR(Leads.originaltime)";

        $result = $this->slave->fetchAll($sql);
        if ($result) {
            return $result;
        }
        return array();
    }

    private function getDataByHour($data, $hour) {
        foreach ($data as $v) {
            if ($hour == $v['hour']) {
                return $v['total'];
            }
        }

        return NULL;
    }


    private function getDataByDate($data, $date) {
        foreach ($data as $v) {
            if ($date == $v['name']) {
                return $v['total'];
            }
        }

        return NULL;
    }

    private function getTotalLeadPurchasedForLastSevenDays()
    {
        $sql = "SELECT
        CONCAT(Leads.originaldate, ' (',DATE_FORMAT(Leads.originaldate,'%a'),')') name,
        count(1) total
        FROM
        Leads
        JOIN CashData ON Leads.id = CashData.leadID
        WHERE
        Leads.affiliateID = $this->affiliateID
        AND
        Leads.leadsold = 1
        AND
        Leads.originaldate > DATE_SUB(NOW(), INTERVAL 8 DAY)
        {$this->currentTime}
        GROUP BY
        Leads.originaldate";

        $result = $this->slave->fetchAll($sql);
        if ($result) {
        return $result;
        }
        return array();
    }

    private function getTotalAttemptsForLastSevenDays()
    {
        $sql = "SELECT
        CONCAT(Leads.originaldate, ' (',DATE_FORMAT(Leads.originaldate,'%a'),')') name,
        count(1) total
        FROM
        Leads
        JOIN CashData ON Leads.id = CashData.leadID
        WHERE
        Leads.affiliateID = $this->affiliateID
        AND
        Leads.originaldate > DATE_SUB(NOW(), INTERVAL 8 DAY)
        {$this->currentTime}
        GROUP BY
        Leads.originaldate";

        $result = $this->slave->fetchAll($sql);
        if ($result) {
        return $result;
        }
        return array();
    }

    private function getTotalLeadPurchasedCurrentDayForLastFiveWeeks()
    {
        $sql = "SELECT
        Leads.originaldate name,
        count(1) total
        FROM
        Leads
        JOIN CashData ON Leads.id = CashData.leadID
        WHERE
        Leads.affiliateID = $this->affiliateID
        AND
        Leads.leadsold = 1
        AND
        (DAYOFWEEK(Leads.originaldate) = DAYOFWEEK(NOW()))
        AND
        Leads.originaldate > DATE_SUB(NOW(), INTERVAL 5 WEEK)
        {$this->currentTime}
        GROUP BY
        DAYOFWEEK(NOW()), Leads.originaldate";

        $result = $this->slave->fetchAll($sql);
        if ($result) {
        return $result;
        }
        return array();
    }

    private function getTotalLeadAttemptsCurrentDayForLastFiveWeeks()
    {
        $sql = "SELECT
        Leads.originaldate name,
        count(1) total
        FROM
        Leads
        JOIN CashData ON Leads.id = CashData.leadID
        WHERE
        Leads.affiliateID = $this->affiliateID
        AND
        (DAYOFWEEK(Leads.originaldate) = DAYOFWEEK(NOW()))
        AND
        Leads.originaldate > DATE_SUB(NOW(), INTERVAL 5 WEEK)
        {$this->currentTime}
        GROUP BY
        DAYOFWEEK(NOW()), Leads.originaldate";

        $result = $this->slave->fetchAll($sql);
        if ($result) {
        return $result;
        }
        return array();
    }
}