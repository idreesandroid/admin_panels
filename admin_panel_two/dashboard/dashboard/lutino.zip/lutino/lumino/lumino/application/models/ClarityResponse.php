<?php

class ClarityResponse extends Zend_Db_Table
{
    protected $_name = 'ClarityResponses';

    public function init()
    {
        $bootstrap = Zend_Controller_Front::getInstance()->getParam("bootstrap");
        $resource = $bootstrap->getPluginResource('multidb');
        $this->db_slave = $resource->getDb('slave');
    }

    public function getVendorNameDenyQuery() {

        $sql = $this->db_slave->select()
            ->from("ClarityResponses", array())
            ->joinInner("PostLogs", "PostLogs.leadID = ClarityResponses.leadID", array())
            ->joinInner("VendorPostSetups", "PostLogs.postSetupID = VendorPostSetups.postSetupID", array())
            ->joinInner("Vendors", "VendorPostSetups.vendorID = Vendors.id", array("vendorName"=>"company"))
            ->where('ClarityResponses.leadID = Leads.id')
            ->where('Vendors.id = 22')
            ->where('PostLogs.postStatus = "no"')
            ->where('ClarityResponses.denyDescription is not null')
            ->where('ClarityResponses.denyDescription != ""')
            ->limit(1);

        return $sql;
    }

    public function getVendorDenyReasonQuery() {

        $sql = $this->db_slave->select()
            ->from("ClarityResponses", array('denyDescription'))
            ->joinInner("PostLogs", "PostLogs.leadID = ClarityResponses.leadID", array())
            ->where('ClarityResponses.leadID = Leads.id')
            ->where('ClarityResponses.denyDescription is not null')
            ->where('ClarityResponses.denyDescription != ""')
            ->where('PostLogs.postStatus = "no"')
            ->limit(1);

        return $sql;
    }
}