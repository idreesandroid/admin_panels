<?php
class DailySfiCampaignReports
{
	/**
	 * @var this is current cost for all leads
	 */
	const LEAD_COST = 35;

	/**
	 * @var current gnarly cost per unique transaction. ie ssn
	 */
	const GNARLY_COST = .30;

	public function __construct()
	{
		$this->originalDateStart = date('Y-m-d');
		$this->originalDateEnd = date('Y-m-d');
		$this->originalTimeStart = "00:00:00";
		$this->originalTimeEnd = "18:30:00";

		$this->config = Zend_Registry::get('config');

		// for ad-hoc queries
		$this->dbSlave = Zend_Db::factory($this->config->resources->multidb->slave->adapter, 
			$this->config->resources->multidb->slave->toArray());
	}

	public function execute()
	{
		// $dataCols holds the string that will be written to csv file.
		// ie 9 columns in csv.
		$dataCols = '"Campaign","Attempted","Bought","Originated","PurchaseRate","CPF","Conversion","ESIG","Redirect"';
		$dataCols.="\n";

		$Factory = new CampaignReportLMSFactory();
		$CampaignReport	= $Factory->create($this->config->lmsName);

		// we just need storeIDs to pass to getCampaignReports method
		$storeIDs = array();
		foreach ($CampaignReport->getStoreIDs() as $store) {
			if ($store['storeID']) {
				$storeIDs[] = "'".$store['storeID']."'";
			}
		}
		$storeIDs = implode(',', $storeIDs);

		// lets get report now
		$data = $CampaignReport->getCampaignReports(true,
			$this->originalDateStart,
			$this->originalDateEnd,
			$this->originalTimeStart,
			$this->originalTimeEnd,
			$storeIDs,
			0,
			0,
			"",
			"");

		// lets get all active campaignIDs.
		$campaignPostSetup = new CampaignsClientPostSetup();
		$campaignPostSetup->initSettingsForSlaveDB();
		$reportCampaigns = $campaignPostSetup->getPostSetupCampaigns(array());

		// initializing some vars for summing
		$totalLeads = 0;
		$totalCost = 0;
		$leadsBought = 0;
		$leadsOriginated = 0;
		$totalesigs = 0;
		$totalRedirects = 0;

		foreach ($data as $key => $reportData) 
		{
			if ($key === "totals") { 
				continue;
			}

			// we only want report data if it pertains to an active campaign
			if ((in_array($reportData['campaign'], $reportCampaigns)) || 
				$reportData['campaign'] == "other") 
			{
				// originations
				$leadsOriginated = $this->getFundedForTodayByCampaign($reportData['campaign']);

				$dataCols.= '"'.$reportData['campaign'].'",';
				$dataCols.='"'.number_format($reportData['leads']).'",';
				$dataCols.='"'.number_format($reportData['bought']).'",';
				$dataCols.='"'.number_format($leadsOriginated).'",';

				// purchase rate
				$dataCols.='"' . round(($reportData['bought'] / $reportData['leads']) * 100, 2) . '%",';

				// cpf
				$dataCols .= '"$' . round($this->costPerFundedByCampaign($reportData['campaign'], 
					$reportData['bought']), 2) . '",';

				$dataCols.='"' . round(($leadsOriginated / $reportData['bought']) * 100, 2) . '%",';
				$dataCols.='"'.number_format($reportData['esigRate'],2).'%",';
				$dataCols.='"'.number_format($reportData['redirectsRate'],2).'%"';

				$dataCols.="\n";

				// running totals which will be used for the last row
				$totalLeads +=$reportData['leads'];
				$leadsBought +=$reportData['bought'];
				$totalesigs += $reportData['esigs'];
				$totalCost += $reportData['cost'];
				$totalRedirects += $reportData['redirects'];
				$totalOriginations += $leadsOriginated;
			}
		}

		// bottom row for grant totals
		$dataCols.='"Totals",';
		$dataCols.= '"'.number_format($totalLeads).'",';
		$dataCols.= '"'.number_format($leadsBought).'",';
		$dataCols.= '"'.number_format($totalOriginations).'",';

		// purchase rate
		$dataCols.= '"' . round(($leadsBought / $totalLeads) * 100, 2) .'%",';

		// cpf
		$dataCols .= '"$' . round($this->costPerFunded($leadsBought), 2) . '",';

		$dataCols.='"' . round(($totalOriginations / $leadsBought) * 100, 2).'%",';
		$dataCols.= '"'.number_format(ReportCalc::esigRate($totalesigs, $leadsBought),2).'%",';
		$dataCols.= '"'.number_format(ReportCalc::redirectsRate($leadsBought, $totalRedirects),2).'%"';

		$fileName =  "DailyRecap_".date("m-d-Y").".csv";
		$fileLocation = __DIR__."/../../dailyReports/digitaljobler/".$fileName;

		if(file_put_contents($fileLocation,$dataCols) !== FALSE) {
			
			$attData = file_get_contents($fileLocation);
			$mail= new Mail();
			$mail->setAttachment($attData);
			$mail->setFileName($fileName);
			$mail->setBody("Daily Campaign report is attached.");
			$mail->setSubject($this->config->daily_campaign_report->email_subject);
			$mail->setToEmail("reports@mediaenvy.com",'Daily Reports');
			$mail->send();
			unlink($fileLocation);
		}
	}

	// TODO: move all below methods to their own class
	public function costPerFunded($bought)
	{
		$leadCost = $this->getLeadCost($bought);
		$gnarlyCost = $this->getGnarlyLabCost();
		$microbiltCost = 0; //$this->microbiltCost();

		$funded = $this->getFundedForToday();

		return ($leadCost + $gnarlyCost + $microbiltCost) / $funded;
	}

	public function costPerFundedByCampaign($campaignID, $bought)
	{
		$leadCost = $this->getLeadCost($bought);
		$gnarlyCost = $this->getGnarlyLabCostByCampaign($campaignID);
		$microbiltCost = 0; //$this->microbiltCostByCampaign($campaignID);

		$funded = $this->getFundedForTodayByCampaign($campaignID);

		return ($leadCost + $gnarlyCost + $microbiltCost) / $funded;
	}

	// NOTE: we dont need campaignID as param is the total for this campaign only
	public function getLeadCost($bought)
	{
		return self::LEAD_COST * $bought;
	}

	/**
	 * total unique leads are the size of the rows returned
	 */
	public function getGnarlyLabCost()
	{
		$sql = "SELECT COUNT(1),
			ssn 
			FROM Leads JOIN CashData ON Leads.id = CashData.leadID
			WHERE originaldate = curdate() 
			GROUP BY ssn;";
		$rows = $this->dbSlave->fetchAll($sql);

		return count($rows) * self::GNARLY_COST;
	}

	/**
	 * total unique leads are the size of the rows returned
	 */
	public function getGnarlyLabCostByCampaign($campaignID)
	{
		$sql = "SELECT COUNT(1),
			ssn 
			FROM Leads JOIN CashData ON Leads.id = CashData.leadID
			WHERE originaldate = curdate() 
			and campaign = " . $campaignID . " 
			GROUP BY ssn;";
		$rows = $this->dbSlave->fetchAll($sql);

		return count($rows) * self::GNARLY_COST;
	}

	/**
	 * this is the sum of all 4 microbilt products
	 */
	public function microbiltCost()
	{
		$results = array();

		$sql = "SELECT pl.campaign, 
			SUM(IF(pl.postResponse LIKE '%<IDV>%', 1,0)) AS Fraud, 
			SUM(IF(pl.postResponse LIKE '%<PDA>%', 1,0)) AS Credit,
			SUM(IF(pl.postResponse LIKE '%<BANK-INFORMATION>%', 1,0)) AS BAV, 
			SUM(IF(pl.postResponse LIKE '%<DDA>%', 1,0)) AS DDA 
			FROM PostLogs pl 
			WHERE pl.postDate = curdate() 
			AND pl.clientID = 4";
		$row = $this->dbSlave->fetchRow($sql);

		$Fraud = $row['Fraud'] * .39;
		$Credit = $row['Credit'] * .5;
		$BAV = $row['BAV'] * .61;
		$DDA = $row['DDA'] * .79;

		$totalCost = $Fraud + $Credit + $BAV + $DDA;

		return $totalCost;
	}

	/**
	 * this is the sum of all 4 microbilt products
	 */
	public function microbiltCostByCampaign($campaignID)
	{
		$results = array();

		$sql = "SELECT pl.campaign, 
			SUM(IF(pl.postResponse LIKE '%<IDV>%', 1,0)) AS Fraud, 
			SUM(IF(pl.postResponse LIKE '%<PDA>%', 1,0)) AS Credit,
			SUM(IF(pl.postResponse LIKE '%<BANK-INFORMATION>%', 1,0)) AS BAV, 
			SUM(IF(pl.postResponse LIKE '%<DDA>%', 1,0)) AS DDA 
			FROM PostLogs pl 
			WHERE pl.postDate = curdate() 
			AND pl.clientID = 4 
			AND pl.campaign = " . $campaignID;
		$row = $this->dbSlave->fetchRow($sql);

		$Fraud = $row['Fraud'] * .39;
		$Credit = $row['Credit'] * .5;
		$BAV = $row['BAV'] * .61;
		$DDA = $row['DDA'] * .79;

		$totalCost = $Fraud + $Credit + $BAV + $DDA;

		return $totalCost;
	}

	/**
	 * use Applicants table to determine if loan was funded. ie approved
	 * @param integer $campaignID
	 *
	 * @return integer the total funded for the campaign
	 */
	public function getFundedForToday()
	{
		$sql = "select count(1) total 
			from Applicants 
			where applicationdate = curdate() 
			and leadoutcomeid=4";
		$row = $this->dbSlave->fetchRow($sql);

		return $row['total'];
	}

	/**
	 * use Applicants table to determine if loan was funded. ie approved
	 * @param integer $campaignID
	 *
	 * @return integer the total funded for the campaign
	 */
	public function getFundedForTodayByCampaign($campaignID)
	{
		$sql = "select count(1) total 
			from Applicants 
			where applicationdate = curdate() 
			and leadoutcomeid=4 
			and campaignID = " . $campaignID;
		$row = $this->dbSlave->fetchRow($sql);

		return $row['total'];
	}
}
