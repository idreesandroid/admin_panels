<?php

class VeritecController extends Zend_Controller_Action
{
	private $Uploader;

	const TMP_VERITEC_RESULT = '/tmp/veritec/result/';
	const TMP_VERITEC_CHUNKS = '/tmp/veritec/chunks';
	const TMP_VERITEC_FILES = '/tmp/veritec/files';

	public function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if (!$AdminNameSpace->userid) {
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();
		$this->Logger = new DataLogger('Veritec', 'daily');
		$this->flashMessenger = $this->_helper->getHelper('FlashMessenger');
		$this->Uploader = new UploadHandler();

		// let's create directories that we're going to use
		$this->Uploader->makePath(self::TMP_VERITEC_FILES);
		$this->Uploader->makePath(self::TMP_VERITEC_RESULT);
		$this->Uploader->makePath(self::TMP_VERITEC_CHUNKS);

	}

	public function indexAction()
	{
		$this->view->messages = $this->flashMessenger->getMessages();

		$files = array_diff(preg_grep('~\.(csv)$~', scandir(self::TMP_VERITEC_RESULT)), array('.', '..'));

		$VeritecAdminPageCredential = new VeritecAdminPageCredential();
		$credentials = $VeritecAdminPageCredential->getCurrentCredentials();
		$this->view->username = $credentials->username;
		$this->view->password = $credentials->password;

		$this->view->veritecResultFiles = $files;
	}

	public function uploadAction()
	{
		$this->_helper->viewRenderer->setnoRender();

		// Specify the list of valid extensions, ex. array("jpeg", "xml", "bmp")
		$this->Uploader->allowedExtensions = array("csv"); // all files types allowed by default

		// Specify max file size in bytes.
		$this->Uploader->sizeLimit = null;

		// Specify the input name set in the javascript.
		$this->Uploader->inputName = "qqfile"; // matches Fine Uploader's default inputName value by default

		// If you want to use the chunking/resume feature, specify the folder to temporarily save parts.
		$this->Uploader->chunksFolder = self::TMP_VERITEC_CHUNKS;

		if ($this->_request->isPost()) {
			header("Content-Type: text/plain");

			// Assumes you have a chunking.success.endpoint set to point here with a query parameter of "done".
			// For example: /myserver/handlers/endpoint.php?done

			if ($this->_request->getParam('done') !== null) {
				$totalParts = isset($_REQUEST['qqtotalparts']) ? (int)$_REQUEST['qqtotalparts'] : 1;
				if ($totalParts > 1) {
					$result = $this->Uploader->combineChunks(self::TMP_VERITEC_FILES);
					$pathToCsvFile = self::TMP_VERITEC_FILES .'/'. $result["uuid"] . '/' . $this->Uploader->getName();
				} else {
					$pathToCsvFile = self::TMP_VERITEC_FILES .'/'. $_REQUEST['qquuid'] . '/' . $_REQUEST['qqfilename'];
				}

				// Let's submit to Veritec
				$VeritecBatchFileSubmitter = new VeritecBatchFileSubmitter();
				$resultFileName = $VeritecBatchFileSubmitter->submit($pathToCsvFile);

//				$files = array_diff(preg_grep('~\.(csv)$~', scandir(self::TMP_VERITEC_RESULT)), array('.', '..'));
				$result["uploadedNameResult"] = $resultFileName;

//				$this->view->veritecResultFiles = $files;
			}
			// Handles upload requests
			else {
				// Call handleUpload() with the name of the folder, relative to PHP's getcwd()
				$result = $this->Uploader->handleUpload(self::TMP_VERITEC_FILES);
				// To return a name used for uploaded file you can use the following line.
				$result["uploadName"] = $this->Uploader->getUploadName();
			}

			$result["uploadedFilesList"] = array_diff(preg_grep('~\.(csv)$~', scandir(self::TMP_VERITEC_RESULT)), array('.', '..'));

			echo json_encode($result);
		}
		// for delete file requests
		else if ($this->_request->isDelete) {
			$result = $this->Uploader->handleDelete(self::TMP_VERITEC_FILES);
			echo json_encode($result);
		}
	}

	public function downloadAction()
	{
		$this->_helper->viewRenderer->setnoRender();

		ignore_user_abort(true);
		set_time_limit(0); // disable the time limit for this script

		$path = self::TMP_VERITEC_RESULT;

		$dl_file = preg_replace("([^\w\s\d\-_~,;:\[\]\(\).]|[\.]{2,})", '', $_GET['download_file']); // simple file name validation
		$dl_file = filter_var($dl_file, FILTER_SANITIZE_URL); // Remove (more) invalid characters
		$fullPath = $path.$dl_file;

		if ($fd = fopen ($fullPath, "r")) {
			$fsize = filesize($fullPath);
			$path_parts = pathinfo($fullPath);

			header("Content-type: application/octet-stream");
			header("Content-Disposition: filename=\"".$path_parts["basename"]."\"");
			header("Content-length: $fsize");
			header("Cache-control: private"); //use this to open files directly
			while(!feof($fd)) {
				$buffer = fread($fd, 2048);
				echo $buffer;
			}
		}
		fclose ($fd);
	}

	public function checkbyproductAction() {
		$this->_helper->viewRenderer->setnoRender();

		$message = "";
		$hasError = 'false';
		$veritecResponseXML = "";
		if ($this->_request->isPost()) {
			$f = new Zend_Filter_StripTags();

			$ssn = $f->filter($this->_request->getPost('ssn'));
			$monthlyincome = $f->filter($this->_request->getPost('monthlyincome'));
			$dob = $f->filter($this->_request->getPost('dob'));
			$fname = $f->filter($this->_request->getPost('fname'));
			$lname = $f->filter($this->_request->getPost('lname'));

			$id = $f->filter($this->_request->getPost('id'));

			if ($id == "CEI") {
				if (empty($monthlyincome)) {
					$message .= "Please provide monthly income.<br>";
					$hasError = 'true';
				}
			} else if ($id == "SN") {
				if (empty($dob)) {
					$message .= "Please provide a date of birth.<br>";
					$hasError = 'true';
				}
			} else if ($id == "OF") {
				if (empty($fname)) {
					$message .= "Please provide a first name.<br>";
					$hasError = 'true';
				}
				if (empty($lname)) {
					$message .= "Please provide a last name.<br>";
					$hasError = 'true';
				}
			}

			if (empty($ssn) || strlen($ssn) < 9) {
				$message .= "Please provide ssn.<br>";
				$hasError = 'true';
			}
			$VeritecAdminPageCredential = new VeritecAdminPageCredential();
			$credentials = $VeritecAdminPageCredential->getCurrentCredentials();

			if (empty($credentials->username) || empty($credentials->password))  {
				$message .= "Please provide username and/or password.<br>";
				$hasError = 'true';
			}

			if ($hasError != 'true') {
				try {
					$lead = array();
					$lead['username'] = $credentials->username;
					$lead['password'] = $credentials->password;

					if ($id == "CEI") {
						$lead['ssn'] = $ssn;
						$lead['monthlyincome'] = $monthlyincome;

						$VeritecSubmitter = new VeritecSubmitter(new VeritecCheckEligibility());
						$response = $VeritecSubmitter->submit($lead);
						$veritecResponseXML = $response['xml'];

					} else if ($id == "SN") {
						$lead['ssn'] = $ssn;
						$lead['dob'] = $dob;

						$VeritecSubmitter = new VeritecSubmitter(new VeritecSSNValitator());
						$response = $VeritecSubmitter->submit($lead);
						$veritecResponseXML = $response['xml'];

					} else if ($id == "OF") {
						$lead['ssn'] = $ssn;
						$lead['fname'] = $fname;
						$lead['lname'] = $lname;

						$VeritecSubmitter = new VeritecSubmitter(new VeritecOFACCompliance());
						$response = $VeritecSubmitter->submit($lead);
						$veritecResponseXML = $response['xml'];
					}

					$message = "Success!";
				} catch (Zend_Exception $e) {
					$hasError = 'true';
					$message = "Some error occurred please try later.";
				}
			}
			$result = array('hasError' => $hasError, 'message' => $message, 'veritecResponseXML' => $veritecResponseXML);

			echo json_encode($result);
		}
	}


	public function savecredentialsAction() {
		$this->_helper->viewRenderer->setnoRender();

		$result = array();
		$hasError = 'false';
		$message = '';

		if ($this->_request->isPost()) {
			$f = new Zend_Filter_StripTags();

			$username = $f->filter($this->_request->getPost('username'));
			$password = $f->filter($this->_request->getPost('password'));


			if (empty($username)) {
				$message .= "Please provide a username.<br>";
				$hasError = 'true';
			}

			if (empty($password)) {
				$message .= "Please provide a password.<br>";
				$hasError = 'true';
			}


			if ($hasError != 'true') {
				try {
					$VeritecAdminPageCredential = new VeritecAdminPageCredential();
					$VeritecAdminPageCredential->save($username, $password);

					$message = "Saved.";

				} catch (Zend_Exception $e) {
					$hasError = 'true';
					$message = "Some error occurred please try later.";
				}
			}
			$result = array('hasError' => $hasError, 'message' => $message);
		}

		echo json_encode($result);
	}
}