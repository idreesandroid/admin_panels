<?php
/**
 * this table handles credentials for Ebureau
 */
class EbureauCredentials extends Zend_Db_Table 
{
	protected $_name = 'EbureauCredentials';

	const VENDOR_ID = 1;
	const VENDOR_ID_FINANCE = 2;

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}

	public function getDefault()
	{
		$row = $this->fetchRow("isDefault = 1");
		if ($row)
			$row = $row->toArray();

		return($row);
	}

	/**
	 * Updates or inserts a row
	 */
	public function upsert($vendorStrategyID, $insertData)
	{
		$existingRow = $this->findByID($vendorStrategyID);

		if($existingRow) {
			$this->update($insertData, $this->_db->quoteInto("id = ?", $existingRow['id']));
			return $existingRow['id'];
		}
		else {
			return $this->insert($insertData);
		}
	}

	public function findByID($vendorStrategyID) {
            
		$EbureauCredentialsVendorStrategies = new EbureauCredentialsVendorStrategies();
		$result = $EbureauCredentialsVendorStrategies->findByVendorStrategyID($vendorStrategyID);
		if ($result['EbureauCredentialID']) {
			$sql = $this->select()
				->where("id = " . $result['EbureauCredentialID']);
			return $this->fetchRow($sql);
		}
	}
}

