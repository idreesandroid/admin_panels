<?php
/**
 * facade to handle Cash (ie Client) postsetups
 * that have been mapped to a specific campaign
 */
class CampaignCashPostSetups
{
	/**
	 * param integer $campaignID
	 * @return void
	 */
	public function __construct($campaignID)
	{
		$this->campaignID = $campaignID;

		$this->db = Zend_Registry::get('db');
	}

	/**
	 * @param array $postSetupIDs
	 * @param integer $storeID
	 * @return void
	 */
	public function save($postSetupIDs, $storeID = NULL)
	{
		$CampaignsClientPostSetup = new CampaignsClientPostSetup();
		
		// easier to delete and resave
		$CampaignsClientPostSetup->delete('campaignID = ' . $this->campaignID);
		foreach ($postSetupIDs as $postSetup) {
			$CampaignsClientPostSetup->insert(
				array('campaignID' => $this->campaignID,
				'postSetupID' => $postSetup['id'],
				'lockPosition' => $postSetup['position'],
				'storeID' => $storeID));
		}
	}
}
