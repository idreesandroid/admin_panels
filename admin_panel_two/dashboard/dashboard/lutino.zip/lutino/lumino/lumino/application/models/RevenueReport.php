<?php
/**
 * facade class that handles getting all data for building Denial Report
 */
class RevenueReport extends ReportAbstract
{
	/**
	 * this is the main interface to this class
	 * @return array
	 */
	public function execute()
	{
		$reports = array();

		$campaigns = $this->getCampaigns();

		$costPerLead = $this->getCostPerLead();
		$ebureaus = $this->getEbureauCost();

		// adding to final report array
		foreach ($costPerLead as $v) {
			$reports[$v['campaign']]['clientCost_' . $v['postSetupID']] = $v['total'];
		}
		foreach ($ebureaus as $v) {
			$reports[$v['campaign']]['vendorCost_247'] = $v['total'];
		}

		$reports = $this->restructureForView($reports);

		return $reports;
	}

	/**
	 * cost per lead is Campaign.costPerLead + ClientPostSetups.markupValue
	 *
	 * @return mixed
	 */
	public function getCostPerLead()
	{
		$sql = "select 
				count(1) * (c.costPerLead + cps.markupValue) total,
				pl.campaign,
				pl.postSetupID 
				from PostLogs pl 
				join ClientPostSetups cps on cps.postSetupID = pl.postSetupID 
				join Campaigns c on c.id = pl.campaign
				where postDate >= '" . $this->fromDate . "' 
				and postDate <= '" . $this->toDate . "' 
				and pl.postSetupID in (select postSetupID from ClientPostSetups) 
				and postStatus = 'accept' 
				group by pl.campaign, 
				pl.postSetupID;";

		return $this->slave->fetchAll($sql);
	}

	public function getEbureauCost()
	{
		$sql = "select sum(cost) total,
			campaign 
			from PostLogs 
			where postSetupID = 247 
			and postDate >= '" . $this->fromDate . "' 
			and postDate <= '" . $this->toDate . "' 
			group by campaign;";

		return $this->slave->fetchAll($sql);
	}

	/**
	 * NOTE: maybe make this a view helper.
	 * It reformats the array so we can plug it right into the view.
	 * (each array key is the html table column. ie keysForView)
	 *
	 * format: [[2190] => ['campaign'] => 2190, ['costPerLead'] => 80.00, ... ]
	 *
	 * @param array $reports organized by campaign
	 * @return array
	 */
	public function restructureForView($reports)
	{
		$restructured = array();

		$keysForView = array(
			'clientCost_239', 
			'clientCost_252', 
			'clientCost_253', 
			'clientCost_256', 
			'clientCost_257', 
			'vendorCost_247');

		foreach ($reports as $k => $report) 
		{
			$restructured[$k]['campaign'] = $k;

			foreach ($keysForView as $keyForView) {
				if (array_key_exists($keyForView, $report)) {
					$restructured[$k][$keyForView] = $report[$keyForView];
				}
			}
		}
		return $restructured;
	}
}
