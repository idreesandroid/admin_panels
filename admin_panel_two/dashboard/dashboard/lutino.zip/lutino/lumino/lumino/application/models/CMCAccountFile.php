<?php

/**
 * AccountFile Model
 *
 * model for TRAN Account_File table
 *
 */
class CMCAccountFile extends TranAbstract
{

	protected $_name = 'CMCAccount_File';
		
	public function init()
	{

		$this->fileName = "Account_File";
		// db columns that are dates, used to format the date from data file
		$this->dateFields = array(6,7,10,13,14);
		// file type
		$this->cboFileType = "A";

		$this->fieldNames = array("Merchant_Id",
				"Loan_Originating_Store_Id",
				"Transaction_Originating_Store_Id",
				"Loan_Id",
				"Cust_SSN",
				"Cust_Name",
				"Loan_Orig_Date",
				"Loan_Due_Date",
				"Loan_Type",
				"Loan_Status",
				"OC_CollectionDate",
				"Assigned_Collector",
				"Emp_User_Id",
				"Tran_Date_Time",
				"Report_Date",
				"Tran_Id",
				"Tran_Lynk_Id",
				"Tran_Type_Id",
				"Tran_Mode",
				"Total_Amount_Of_Transaction",
				"Tran_Account",
				"Fee_Type",
				"Loan_Disburse_Subtype",
				"Payment_Sub_Type",
				"Check_Number",
				"Returntype",
				"Return_Item_Count",
				"GL_Code_Debit1",
				"GL_Code_Debit2",
				"GL_Code_Credit1",
				"GL_Code_Credit2",
				"Cust_State",
				"ACH_No",
				"Emp_Origin_UserID",
				);
	}

	/**
	 * Updates or inserts a row
	 */
	public function upsert($insertData)
	{

		$existingRow = $this->findByKeyFields($insertData);

		if($existingRow) {
			
			$updateKeys = $this->_db->quoteInto("Loan_Originating_Store_Id = ?", $insertData['Loan_Originating_Store_Id']);
			$updateKeys .= " AND " . $this->_db->quoteInto("Loan_Id = ?", $insertData['Loan_Id']);
			$updateKeys .= " AND " . $this->_db->quoteInto("Tran_Date_Time = ?", $insertData['Tran_Date_Time']);
			$updateKeys .= " AND " . $this->_db->quoteInto("Tran_Type_Id = ?", $insertData['Tran_Type_Id']);
			$updateKeys .= " AND " . $this->_db->quoteInto("Tran_Id = ?", $insertData['Tran_Id']);
			$updateKeys .= " AND " . $this->_db->quoteInto("Total_Amount_Of_Transaction = ?", $insertData['Total_Amount_Of_Transaction']);
			$updateKeys .= " AND " . $this->_db->quoteInto("Tran_Account = ?", $insertData['Tran_Account']);

			$this->update($insertData, $updateKeys);
		}
		else {
			$this->insert($insertData);
		}

	}

	/**
 	 * Finds a row by the key fields
	 * 
	 * @param		insertData	array	array of insert data
	 *
	 * @return				array	array of AccountFile row
	 */
	public function findByKeyFields($insertData)
	{

		$sql = $this->_db->select()
				->from($this->_name)
				->where($this->_db->quoteInto("Loan_Originating_Store_Id = ?", $insertData['Loan_Originating_Store_Id']))
				->where($this->_db->quoteInto("Loan_Id = ?", $insertData['Loan_Id']))
				->where($this->_db->quoteInto("Tran_Date_Time = ?", $insertData['Tran_Date_Time']))
				->where($this->_db->quoteInto("Tran_Type_Id = ?", $insertData['Tran_Type_Id']))
				->where($this->_db->quoteInto("Tran_Id = ?", $insertData['Tran_Id']))
				->where($this->_db->quoteInto("Total_Amount_Of_Transaction = ?", $insertData['Total_Amount_Of_Transaction']))
				->where($this->_db->quoteInto("Tran_Account = ?", $insertData['Tran_Account']));

		$result = $this->_db->fetchRow($sql);

		return $result;
	}

}
