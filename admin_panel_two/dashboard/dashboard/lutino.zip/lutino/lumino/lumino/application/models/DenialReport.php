<?php
/**
 * facade class that handles getting all data for building Denial Report
 */
class DenialReport extends DenialReportAbstract
{
	/**
	 * this is the main interface to this class
	 * @return array
	 */
	public function execute()
	{
		$reports = array();

		$campaigns = $this->getCampaigns();

		$internals = $this->getInternalRejects();
		$clientCriterias = $this->getClientCriteriaRejects();
		$vendors = $this->getVendorRejects();
		$clients = $this->getClientRejects();
		$campaignRejects = $this->getCampaignRejects();
		$leads = $this->getLeadAttempts();
		$leadSold = $this->getLeadSold();
		$preCheckedVendorRejects = $this->getVendorRejectsByRejectCode(VendorRejectCode::CUST_DENIED_IN_THE_PAST);
		$timeoutVendorRejects = $this->getVendorRejectsByRejectCode(VendorRejectCode::API_TIMEOUT);
		$vendorstrategyVendorRejects = $this->getVendorRejectsByRejectCode(VendorRejectCode::VENDORSTRATEGY_RULE_FAILED);

		foreach ($campaigns['campignid'] as $k => $v) {
			$affiliates[$k] = $campaigns['affname'][$k];
		}

		foreach ($campaigns['campignid'] as $k => $v) {
			$campaignTitles[$k] = $campaigns['campaignTitle'][$k];
		}

		// adding to final report array
		foreach ($internals as $k => $v) {
			if (array_key_exists($v['campaign'], $campaigns['campignid'])) {
				$reports[$v['campaign']]['internalRejects'][] = $internals[$k];
			}
		}
		foreach ($clientCriterias as $k => $v) {
			if (array_key_exists($v['campaign'], $campaigns['campignid'])) {
				$reports[$v['campaign']]['clientCriteriaRejects'][] = $clientCriterias[$k];
			}
		}
		foreach ($campaignRejects as $k => $v) {
			if (array_key_exists($v['campaign'], $campaigns['campignid'])) {
				$reports[$v['campaign']]['campaignRejects'][] = $campaignRejects[$k];
			}
		}

		foreach ($vendors as $k => $v) {
			$reports[$v['campaign']]['vendorRejects'][$v['postSetupID']] = $v['total'];
		}
		foreach ($clients as $k => $v) {
			$reports[$v['campaign']]['clientRejects'][$v['postSetupID']] = $v['total'];
		}
		foreach ($leads as $k => $v) {
			$reports[$v['campaign']]['leadAttempts'] = $v['total'];
		}
		foreach ($leadSold as $k => $v) {
			$reports[$v['campaign']]['leadSold'] = $v['total'];
		}

		foreach ($preCheckedVendorRejects as $k => $v) {
			$reports[$v['campaign']]['preCheckedVendorRejects'] = $v['total'];
		}

		foreach ($timeoutVendorRejects as $k => $v) {
			$reports[$v['campaign']]['timeoutVendorRejects'] = $v['total'];
		}

		foreach ($vendorstrategyVendorRejects as $k => $v) {
			$reports[$v['campaign']]['vendorstrategyVendorRejects'] = $v['total'];
		}

		foreach ($reports as $k => $v) {
			$reports[$k]['affname'] = $affiliates[$k];
		}

		foreach ($reports as $k => $v) {
			$reports[$k]['campaignTitle'] = $campaignTitles[$k];
		}

		$reports = $this->restructureForView($reports);
		$reports = $this->sortReportByAffiliateName($reports);

		return $reports;
	}

	/**
	 * NOTE: maybe make this a view helper.
	 * It reformats the array so we can plug it right into the view.
	 * (each array key is the html table column)
	 *
	 * format: [[2190] => ['campaign'] => 2190, [100] => NULL, [101] => 4,... [10] => NULL]]
	 *
	 * @param array $reports organized by campaign
	 * @return array
	 */
	public function restructureForView($reports)
	{
		$restructured = array();

		// all internal reject codes
		$InternalRejectCode = new InternalRejectCode();
		$internalResults = $InternalRejectCode->fetchAll(array('id'))->toArray();
		$internalCodes = array_map(function($v) { return $v['id']; }, $internalResults);

		// all criteria reject codes
		$ClientRejectCode = new ClientRejectCode();
		$criteriaResults = $ClientRejectCode->fetchAll(array('id'))->toArray();
		$criteriaCodes = array_map(function($v) { return $v['id']; }, $criteriaResults);

		// all campaign reject codes
		$CampaignRejectCode = new CampaignRejectCode();
		$campaignRejectCodeResults = $CampaignRejectCode->fetchAll(array('id'))->toArray();
		$campaignCodes = array_map(function($v) { return $v['id']; }, $campaignRejectCodeResults);

		foreach ($reports as $k => $report) 
		{
			$restructured[$k]['campaign'] = $k;
			$restructured[$k]['affiliate'] = $report['affname'];
			$restructured[$k]['campaignTitle'] = $report['campaignTitle'];

			// internal rejects
			if (array_key_exists('internalRejects', $report)) {
				foreach ($internalCodes as $code) {
					foreach ($report['internalRejects'] as $reject) {
						if ($reject['rejectCode'] == $code) {
							$restructured[$k][$code] = $reject['total'];
						}
					}
				}
			}

			// clientCriteria rejects
			if (array_key_exists('clientCriteriaRejects', $report)) {
				foreach ($criteriaCodes as $code) {
					foreach ($report['clientCriteriaRejects'] as $reject) {
						if ($reject['rejectCode'] == $code) {
							$restructured[$k][$code] = $reject['total'];
						}
					}
				}
			}

			// campaign rejects
			if (array_key_exists('campaignRejects', $report)) {
				foreach ($campaignCodes as $code) {
					foreach ($report['campaignRejects'] as $reject) {
						if ($reject['rejectCode'] == $code) {
							$restructured[$k]['campaign_' . $code] = $reject['total'];
						}
					}
				}
			}

			// vendor rejects
			if (array_key_exists('vendorRejects', $report)) {
				foreach ($report['vendorRejects'] as $vendorKey => $reject) {
					$restructured[$k]['vendor_' . $vendorKey] = $reject;
				}
			}

			// client rejects
			if (array_key_exists('clientRejects', $report)) {
				foreach ($report['clientRejects'] as $clientKey => $reject) {
					$restructured[$k]['client_' . $clientKey] = $reject;
				}
			}

			// lead attempts
			if (array_key_exists('leadAttempts', $report)) {
				$restructured[$k]['leadAttempts'] = $report['leadAttempts'];
			}

			// lead sold
			if (array_key_exists('leadSold', $report)) {
				$restructured[$k]['leadSold'] = $report['leadSold'];
			}

			if (array_key_exists('preCheckedVendorRejects', $report)) {
				$restructured[$k]['preCheckedVendorRejects'] = $report['preCheckedVendorRejects'];
			}

			if (array_key_exists('timeoutVendorRejects', $report)) {
				$restructured[$k]['timeoutVendorRejects'] = $report['timeoutVendorRejects'];
			}

			if (array_key_exists('vendorstrategyVendorRejects', $report)) {
				$restructured[$k]['vendorstrategyVendorRejects'] = $report['vendorstrategyVendorRejects'];
			}
		}
		return $restructured;
	}

	public function getVendorRejects()
	{
		// first get all vendor postsetupIDs
		$sqlVendors = "select postSetupID 
			from VendorPostSetups";
		$vendors = $this->slave->fetchAll($sqlVendors);

		// flatten array so we can stringify it for sql query
		$vendorPostSetupIDs = array();
		foreach ($vendors as $v) {
			$vendorPostSetupIDs[] = $v['postSetupID'];
		}
		
		$join = "";
		$condition = "";
		if (!empty($this->affiliateId) || count($this->storeIds)) {
			$join = " INNER JOIN Leads l on l.id = pl.leadID ";
			if (!empty($this->affiliateId)) {
				$condition.= " and l.affiliateID = ".$this->affiliateId." ";
			}
			if (count($this->storeIds)) {
				$condition.= " and l.storeID in (".implode(",",$this->storeIds).") ";
			}
		}
		
		$strategy = "";
		$selectedStrategy = "";

		if ($this->selectedStrategyID > 0) {
			$strategy = " LEFT OUTER JOIN LeadStrategies ON LeadStrategies.leadID = pl.leadID
								LEFT OUTER JOIN Variates ON Variates.id = LeadStrategies.variateID";

			$selectedStrategyID = $this->selectedStrategyID;
			$selectedStrategy = "AND Variates.id = $selectedStrategyID";
		}

		$sql = "select count(1) total,
			postSetupID,
			replace(pl.campaign,' ','') campaign  
			from PostLogs pl
			$join
			".$strategy."
			where pl.postdate >= '" . $this->fromDate . "' 
			and pl.postdate <= '" . $this->toDate . "'
			and pl.startTime >= '" . $this->fromTime . "'
			and pl.startTime <= '" . $this->toTime . "'
			and postsetupid IN (" . implode(',', $vendorPostSetupIDs) . ") 
			and poststatus='no'
			$condition
			".$selectedStrategy."
			group by campaign, postSetupID";
		return $this->slave->fetchAll($sql);
	}



	/**
	 * Vendor Names
	 * @return array
	 */
	public function prepareVendorRejectHeader()
	{
		$Vendors = new Vendors();
		$vendorData = $Vendors->getVendorData();
		$this->sortByPriority($vendorData, "priority", TRUE);
		$vendorsHeaders = array();
		foreach ($vendorData AS $v) {
			if ($v['active'] == "1") {
				$vendorsHeaders[] = $v;
			}
		}
		return $vendorsHeaders;
	}

	/**
	 * @param $vendorsHeaders
	 * @param $headerVal
	 * @return bool
	 */
	private function isVendorRejectHeader($vendorsHeaders, $headerVal)
	{
		foreach ($vendorsHeaders as $v) {
			if ($v['company'] . " " . $v['fname'] == $headerVal) {
				return TRUE;
			}
		}
		return FALSE;
	}

	/**
	 * Vendor Rejects
	 * @param $vendorsHeaders
	 * @param $headerVal
	 * @return bool|string
	 */
	private function getVendorRejectPostSetupID($vendorsHeaders, $headerVal)
	{
		foreach ($vendorsHeaders as $v) {
			if ($v['company'] . " " . $v['fname'] == $headerVal) {
				return 'vendor_' . $v['postSetupID'];
			}
		}
		return FALSE;
	}


	/**
	 * Format Denial report data as it has missing array elements if there's no data
	 * @param array $vendorsHeaders
	 * @param array $clientHeaders
	 * @param array $reports
	 * @return array
	 */

	public function prepareReportForTableView($vendorsHeaders, $clientHeaders, $reports)
	{
		$reportsFormatted = array();
		$result = array();

		// If we don't have any data, we set empty fields to default empty
		if (empty($reports)) {
			foreach ($vendorsHeaders as $vendorsHeader) {
				$result['empty']['vendor_' . $vendorsHeader['postSetupID']] = '';
			}
			foreach ($clientHeaders as $clientHeader) {
				$result['empty']['client_' . $clientHeader['postSetupID']] = '';
			}
			return $result;
		}

		// prepare Vendor Rejects
		foreach ($reports as $reportKey => $reportValue) {
			foreach ($reportValue as $v) {
				if (count($vendorsHeaders) > 0)
				{
					foreach ($vendorsHeaders as $vendorsHeader) 
					{
						$header = 'vendor_' . $vendorsHeader['postSetupID'];

						if (array_key_exists($header, $reportValue)) {
							$reportsFormatted[$reportKey][$header] = $reportValue[$header];
						} else {
							$reportsFormatted[$reportKey][$header] = '';
						}
					}
				}
			}
			$result[$reportKey] = $reportValue + $reportsFormatted[$reportKey];
		}

		// prepare Client Rejects
		foreach ($reports as $reportKey => $reportValue) {
			foreach ($reportValue as $v) {
				foreach ($clientHeaders as $clientHeader) 
				{
					$header = 'client_' . $clientHeader['postSetupID'];

					if (array_key_exists($header, $reportValue)) {
						$reportsFormatted[$reportKey][$header] = $reportValue[$header];
					} else {
						$reportsFormatted[$reportKey][$header] = '';
					}
				}
			}
			$result[$reportKey] = $reportValue + $reportsFormatted[$reportKey];
		}

		return $result;
	}

	/**
	 * used by Denial Report
	 */
	public function prepareColumnHeadersForCsv($internalHeaders, $criteriaHeaders, $campaignCodeHeaders, $vendorsHeaders, $clientsHeaders)
	{
		$csvHeaders = array();
		$csvHeaders[] = 'affiliate';
		$csvHeaders[] = 'campaign';
		$csvHeaders[] = 'campaignTitle';
		$csvHeaders[] = 'leadAttempts';

		// number of columns depends on db values
		foreach($internalHeaders as $v) {
			$csvHeaders[] = $v['id'];
		}
		foreach($criteriaHeaders as $v) {
			$csvHeaders[] = $v['id'];
		}
		foreach($campaignCodeHeaders as $v) {
			$csvHeaders[] = "campaign_" . $v['id'];
		}

		$csvHeaders[] = 'preCheckedVendorRejects';
		$csvHeaders[] = 'timeoutVendorRejects';
		$csvHeaders[] = 'vendorstrategyVendorRejects';

		$csvVendorsClients = array();
		foreach ($vendorsHeaders as $vendorsHeader) {
			$csvVendorsClients[] = $vendorsHeader['company'] . " " . $vendorsHeader['fname'];
		}

		foreach ($clientsHeaders as $clientsHeader) {
			$csvVendorsClients[] = $clientsHeader['title'];
		}

		$csvVendorsClients[] = 'leadSold';

		foreach($csvVendorsClients as $v) {
			$csvHeaders[] = $v;
		}

		return $csvHeaders;
	}

	/**
	 * format Denial report data as it has missing array elements if there's no data
	 *
	 * @param array $csvHeaders
	 * @param array $reports
	 * @return array
	 */
	public function prepareReportForCsv($csvHeaders, $reports, $total, $vendorsHeaders, $clientsHeaders)
	{
		$reportsFormatted = array();
		foreach ($reports as $reportKey => $reportValue) {
			foreach ($reportValue as $k => $v) {
				foreach ($csvHeaders as $csvHeader) {
					if ($this->isVendorRejectHeader($vendorsHeaders, $csvHeader)) 
					{
						$vendorRejectPostSetupID = $this->getVendorRejectPostSetupID($vendorsHeaders, $csvHeader);
						$reportsFormatted[$reportKey][$csvHeader] = $reportValue[$vendorRejectPostSetupID];
					}
					elseif ($this->isClientRejectHeader($clientsHeaders, $csvHeader)) 
					{
						$clientRejectPostSetupID = $this->getClientRejectPostSetupID($clientsHeaders, $csvHeader);
						$reportsFormatted[$reportKey][$csvHeader] = $reportValue[$clientRejectPostSetupID];
					}
					elseif (array_key_exists($csvHeader, $reportValue)) 
					{
						$reportsFormatted[$reportKey][$csvHeader] = $reportValue[$csvHeader];
					}
					else
					{
						$reportsFormatted[$reportKey][$csvHeader] = '';
					}
				}
			}
		}

		$total['affiliate'] = 'Total';
		$total['campaign'] = '';
		$total['campaignTitle'] = '';

		foreach ($total as $k => $v) {
			foreach ($csvHeaders as $csvHeader)
			{
				if ($this->isVendorRejectHeader($vendorsHeaders, $csvHeader))
				{
					$vendorRejectPostSetupID = $this->getVendorRejectPostSetupID($vendorsHeaders, $csvHeader);
					$reportsFormatted['total'][$csvHeader] = $total[$vendorRejectPostSetupID];
				}
				elseif ($this->isClientRejectHeader($clientsHeaders, $csvHeader)) 
				{
					$clientRejectPostSetupID = $this->getClientRejectPostSetupID($clientsHeaders, $csvHeader);
					$reportsFormatted['total'][$csvHeader] = $total[$clientRejectPostSetupID];
				}
				elseif (array_key_exists($csvHeader, $total))
				{
					$reportsFormatted['total'][$csvHeader] = $total[$csvHeader];
				}
				else
				{
					$reportsFormatted['total'][$csvHeader] = '';
				}
			}
		}

		return $reportsFormatted;
	}
}
