<?php
class VendorController extends Zend_Controller_Action
{
	private $baseurl;

	function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if (!$AdminNameSpace->userid) {
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();
	}

	function addAction()
	{
		$message = "";
		$error = 0;
		$success = 0;
		$supportedVendors = new SupportedVendors();

		if ($this->_request->isPost()) {
			$commonobj = new Commonfunctions();

			$f = new Zend_Filter_StripTags();
			$columns = array();

			$companyid = $f->filter($this->_request->getPost('companyid'));
			$email = $f->filter($this->_request->getPost('email'));

			if (empty($companyid)) {
				$message .= "Please provide company.<br>";
				$error = 1;
			}
			if (empty($email)) {
				$message .= "Please provide email.<br>";
				$error = 1;
			}
			if (!empty($email)) {
				if ($commonobj->isvalidemail($email) == 0) {
					$message .= "Invalid email.<br>";
					$error = 1;
				}
			}

			if ($error == 0) {
				$company = $supportedVendors->getCompanyById($companyid);
				$Form_Data = array('id' => $companyid, 'company' => $company, 'email' => $email);

				$vendors = new Vendors();
				try {
					$vendors->insert($Form_Data);
					$message = "Data Provider successfully added.";
					$success = 1;

					return $this->_helper->redirector('view');
				} catch (Zend_Exception $e) {
					$error = 1;
					$message = "Some error occurred please try later.";
				}
			}

			if ($error == 1) {
				$this->view->email = $email;
				$this->view->company = $company;
			} else {
				$this->view->email = "";
				$this->view->company = "";
			}
		} else {
			$this->view->email = "";
			$this->view->company = "";
		}


		$this->view->vendors = $supportedVendors->fetchAll();
		$this->view->baseurl = $this->baseurl;
		$this->view->message = $message;
		$this->view->error = $error;
		$this->view->success = $success;
	}

	function viewAction()
	{
		$Vendors = new Vendors();
		$accountexecutives = $Vendors->fetchAll("id != 10000", "company");
		$this->view->baseurl = $this->baseurl;
		$this->view->data = $accountexecutives;
	}


	function editAction()
	{
		$id = $_REQUEST['id'];

		$message = "";
		$error = 0;
		$success = 0;

		$merchantID = 0;
		$storeID = 0;
		$lenderID = 0;

		$groupID = 0;
		$accountID = 0;
		$locationID = 0;
		$controlFileName = 0;
		$apiKey = "";
		$decisionlogickey = "";
		$decisionlogicguid = "";

		if ($this->_request->isPost()) {
			$commonobj = new Commonfunctions();

			$f = new Zend_Filter_StripTags();

			$email = $f->filter($this->_request->getPost('email'));
			$company = $f->filter($this->_request->getPost('company'));

			if ($id == FTCredentials::VENDOR_ID) {
				$username = $f->filter($this->_request->getPost('username'));
				$password = $f->filter($this->_request->getPost('password'));

				if (empty($username)) {
					$message .= "Please provide username.<br>";
					$error = 1;
				}

				if (empty($password)) {
					$message .= "Please provide password.<br>";
					$error = 1;
				}

				$merchantID = $f->filter($this->_request->getPost('merchantID'));
				if (empty($merchantID)) {
					$message .= "Please provide merchant ID.<br>";
					$error = 1;
				}

				$storeID = $f->filter($this->_request->getPost('storeID'));
				if (empty($storeID)) {
					$message .= "Please provide store ID.<br>";
					$error = 1;
				}

				$lenderID = $f->filter($this->_request->getPost('lenderID'));
				if (empty($lenderID)) {
					$message .= "Please provide lender ID.<br>";
					$error = 1;
				}

			} else if ($id == ClarityCredentials::VENDOR_ID) {
				$username = $f->filter($this->_request->getPost('username'));
				$password = $f->filter($this->_request->getPost('password'));

				if (empty($username)) {
					$message .= "Please provide username.<br>";
					$error = 1;
				}

				if (empty($password)) {
					$message .= "Please provide password.<br>";
					$error = 1;
				}

				$groupID = $f->filter($this->_request->getPost('groupID'));
				if (empty($groupID)) {
					$message .= "Please provide group ID.<br>";
					$error = 1;
				}

				$accountID = $f->filter($this->_request->getPost('accountID'));
				if (empty($accountID)) {
					$message .= "Please provide account ID.<br>";
					$error = 1;
				}

				$locationID = $f->filter($this->_request->getPost('locationID'));
				if (empty($locationID)) {
					$message .= "Please provide location ID.<br>";
					$error = 1;
				}

				$controlFileName = $f->filter($this->_request->getPost('controlFileName'));
				if (empty($controlFileName)) {
					$message .= "Please provide Control File Name.<br>";
					$error = 1;
				}

				$inquiryTradelineType = $f->filter($this->_request->getPost('inquiryTradelineType'));
				if (empty($inquiryTradelineType)) {
				    $message .= "Please provide Inquiry Tradeline Type.<br>";
				    $error = 1;
				}
			} else if ($id == VeritecCredentials::VENDOR_ID) {
				$veritecUsername = $f->filter($this->_request->getPost('veritecUsername'));
				$veritecPassword = $f->filter($this->_request->getPost('veritecPassword'));
				$veritecReglicnum = $f->filter($this->_request->getPost('veritecReglicnum'));
				$veritecActioncode = $f->filter($this->_request->getPost('veritecActioncode'));

				if (empty($veritecUsername)) {
					$message .= "Please provide username.<br>";
					$error = 1;
				}

				if (empty($veritecPassword)) {
					$message .= "Please provide password.<br>";
					$error = 1;
				}

				if (empty($veritecReglicnum)) {
					$message .= "Please provide reglicnum.<br>";
					$error = 1;
				}

				if (empty($veritecActioncode)) {
					$message .= "Please provide action code.<br>";
					$error = 1;
				}
			} else if ($id == TrueScoreCredentials::VENDOR_ID) {
				$accountID = $f->filter($this->_request->getPost('accountID'));
				if (empty($accountID)) {
					$message .= "Please provide account ID.<br>";
					$error = 1;
				}

				$apiKey = $f->filter($this->_request->getPost('apiKey'));
				if (empty($apiKey)) {
					$message .= "Please provide api key.<br>";
					$error = 1;
				}
			} else if ($id == DataXCredentials::VENDOR_ID) {

				$DataXkey = $f->filter($this->_request->getPost('dataxkey'));
				if (empty($DataXkey)) {
					$message .= "Please provide Key.<br>";
					$error = 1;
				}

				$DataXpassword = $f->filter($this->_request->getPost('dataxpassword'));
				if (empty($DataXpassword)) {
					$message .= "Please provide Password.<br>";
					$error = 1;
				}

				$DataXinquirytype = $f->filter($this->_request->getPost('dataxinquiryType'));
				if (empty($DataXinquirytype)) {
					$message .= "Please provide Inquiry Type.<br>";
					$error = 1;
				}


			} else if ($id == MBCredentials::VENDOR_ID) {

				$mbUsername = $f->filter($this->_request->getPost('mbUsername'));
				if (empty($mbUsername)) {
					$message .= "Please provide Username.<br>";
					$error = 1;
				}

				$mbPassword = $f->filter($this->_request->getPost('mbPassword'));
				if (empty($mbPassword)) {
					$message .= "Please provide Password.<br>";
					$error = 1;
				}

			} else if ($id == GVerifyCredentials::VENDOR_ID) {

				$GverifyUsername = $f->filter($this->_request->getPost('gverifyusername'));
				if (empty($GverifyUsername)) {

					$message .= "Please provide Username.<br>";
					$error = 1;
				}
				$Gverifypassword = $f->filter($this->_request->getPost('gverifypassword'));
				if (empty($Gverifypassword)) {
					$message .= "Please provide Password.<br>";
					$error = 1;

				}

			} else if ($id == CPADetectiveCredentials::VENDOR_ID) {

				$CPADectivekey = $f->filter($this->_request->getPost('cpadectivekey'));
				if (empty($CPADectivekey)) {
					$message .= "Please provide Key.<br>";
					$error = 1;
				}

			} else if ($id == RelianceMarkCredentials::VENDOR_ID) {

				$relmarkey = $f->filter($this->_request->getPost('reliancemarkkey'));
				if (empty($relmarkey)) {
					$message .= "Please provide Key.<br>";
					$error = 1;
				}

			} else if ($id == DecisionLogicCredentials::VENDOR_ID) {

				$decisionlogickey = $f->filter($this->_request->getPost('decisionlogickey'));
				if (empty($decisionlogickey)) {
					$message .= "Please provide Key.<br>";
					$error = 1;
				}

				$decisionlogicguid = $f->filter($this->_request->getPost('decisionlogicguid'));
				if (empty($decisionlogicguid)) {
					$message .= "Please provide GUID.<br>";
					$error = 1;
				}

			} else if ($id == EbureauCredentials::VENDOR_ID) {


				$EbureauUserName = $f->filter($this->_request->getPost('ebureauUsername'));
				if (empty($EbureauUserName)) {
					$message .= "Please provide username.<br>";
					$error = 1;
				}

				$EbureauPassword = $f->filter($this->_request->getPost('ebureauPassword'));
				if (empty($EbureauPassword)) {
					$message .= "Please provide password.<br>";
					$error = 1;
				}

				$EbureauMarketScore = $f->filter($this->_request->getPost('ebureaumarketScore'));
				if (empty($EbureauMarketScore)) {
					$message .= "Please provide market score.<br>";
					$error = 1;
				}

				$EbureauFraudScore = $f->filter($this->_request->getPost('ebureaufraudScore'));
				if (empty($EbureauFraudScore)) {
					$message .= "Please provide fraud score.<br>";
					$error = 1;
				}

				$EbureauUseTestUrl = $f->filter($this->_request->getPost('ebureauUseTestUrl'));

			} else if ($id == EbureauCredentials::VENDOR_ID_FINANCE) {

				$EbureauUserName = $f->filter($this->_request->getPost('ebureauUsername'));
				if (empty($EbureauUserName)) {
					$message .= "Please provide username.<br>";
					$error = 1;
				}

				$EbureauPassword = $f->filter($this->_request->getPost('ebureauPassword'));
				if (empty($EbureauPassword)) {
					$message .= "Please provide password.<br>";
					$error = 1;
				}

				$EbureauMarketScore = $f->filter($this->_request->getPost('ebureaumarketScore'));
				if (empty($EbureauMarketScore)) {
					$message .= "Please provide market score.<br>";
					$error = 1;
				}

				$EbureauFraudScore = $f->filter($this->_request->getPost('ebureaufraudScore'));
				if (empty($EbureauFraudScore)) {
					$message .= "Please provide fraud score.<br>";
					$error = 1;
				}

				$EbureauFraudScoreName = $f->filter($this->_request->getPost('ebureaufraudScoreName'));
				if (empty($EbureauFraudScoreName)) {
					$message .= "Please provide fraud score name.<br>";
					$error = 1;
				}

				$EbureauMarketScoreName = $f->filter($this->_request->getPost('ebureaumarketScoreName'));
				if (empty($EbureauMarketScoreName)) {
					$message .= "Please provide market score name.<br>";
					$error = 1;
				}

				$EbureauUseTestUrl = $f->filter($this->_request->getPost('ebureauUseTestUrl'));

			} else if ($id == BriteVerifyCredentials::BRITE_VERIFY_EMAIL_CHECK_VENDOR_ID) {

				$briteVerifyKey = $f->filter($this->_request->getPost('briteverifykey'));
				if (empty($briteVerifyKey)) {
					$message .= "Please provide key.<br>";
					$error = 1;
				}

			} else if ($id == PDSPaymentCredential::VENDOR_ID) {
				$PDSPaymentLogin = $f->filter($this->_request->getPost('pdspaymentLogin'));
				if (empty($PDSPaymentLogin)) {
					$message .= "Please provide login.<br>";
					$error = 1;
				}

				$PDSPaymentPassword = $f->filter($this->_request->getPost('pdspaymentPassword'));
				if (empty($PDSPaymentPassword)) {
					$message .= "Please provide password.<br>";
					$error = 1;
				}

				$PDSPaymentMerchantID = $f->filter($this->_request->getPost('pdspaymentMerchantid'));
				if (empty($PDSPaymentMerchantID)) {
					$message .= "Please provide merchant id.<br>";
					$error = 1;
				}

				$PDSPaymentTrancode = $f->filter($this->_request->getPost('pdspaymentTrancode'));
				if (empty($PDSPaymentTrancode)) {
					$message .= "Please provide trancode.<br>";
					$error = 1;
				}

				$PDSPaymentSec = $f->filter($this->_request->getPost('pdspaymentSec'));
				if (empty($PDSPaymentSec)) {
					$message .= "Please provide sec.<br>";
					$error = 1;
				}

				$PDSPaymentDescription = $f->filter($this->_request->getPost('pdspaymentDescription'));
				if (empty($PDSPaymentDescription)) {
					$message .= "Please provide description.<br>";
					$error = 1;
				}
			} else if ($id == DataTwentyFourSevenCredentials::VENDOR_ID) {
				$dataTwentyFourSevenUsername = $f->filter($this->_request->getPost('dataTwentyFourSevenUsername'));
				if (empty($dataTwentyFourSevenUsername)) {
					$message .= "Please provide username.<br>";
					$error = 1;
				}

				$dataTwentyFourSevenPassword = $f->filter($this->_request->getPost('dataTwentyFourSevenPassword'));
				if (empty($dataTwentyFourSevenPassword)) {
					$message .= "Please provide password.<br>";
					$error = 1;
				}

			}
			else if($id == WhitePagesCredentials::VENDOR_ID) {

			    $whitePagesApiKey = $f->filter($this->_request->getPost('apiKey'));
			    $whitePagesProducts = $this->_request->getPost('products');
			    if (empty($whitePagesApiKey)) {
			        $message .= "Please provide api key.<br>";
			        $error = 1;
			    }
			    if(count($whitePagesProducts) == 0) {
			        $message .= "Please select atleast one product to parse.<br>";
			        $error = 1;
			    }
			}

			if (empty($email)) {
				$message .= "Please provide email.<br>";
				$error = 1;
			}
			if (!empty($email)) {
				if ($commonobj->isvalidemail($email) == 0) {
					$message .= "Invalid email.<br>";
					$error = 1;
				}
			}
			if (empty($company)) {
				$message .= "Please provide company.<br>";
				$error = 1;
			}

			if ($error == 0) {
				$formData = array('email' => $email, 'company' => $company);

				$Vendors = new Vendors();
				$ClarityCredentials = new ClarityCredentials();
				$FTCredentials = new FTCredentials();
				$TrueScoreCredentials = new TrueScoreCredentials();

				try {
					$where = "id = $id";
					$Vendors->update($formData, $where);

					if ($id == FTCredentials::VENDOR_ID) {
						$formData = array('username' => $username,
							'password' => $password,
							'merchantID' => $merchantID,
							'storeID' => $storeID,
							'lenderID' => $lenderID);

						// First lets check if we have default credentials
						$row = $FTCredentials->fetchRow('isDefault = 1');
						// We have default credentials so lets update them
						if(count($row)>0) {
							$where = "isDefault = 1";
							$FTCredentials->update($formData, $where);
						}
						else {
							$formData['isDefault'] = '1';
							$FTCredentials->insert($formData);
						}

					} else if ($id == ClarityCredentials::VENDOR_ID) {
						$formData = array(
								'username' => $username,
								'password' => $password,
								'groupID' => $groupID,
								'accountID' => $accountID,
								'locationID' => $locationID,
								'controlFileName' => $controlFileName,
						        'inquiryTradelineType' => $inquiryTradelineType
						);
						// First lets check if we have default credentials
						$row = $ClarityCredentials->fetchRow('isDefault = 1');
						// We have default credentials so lets update them
						if(count($row)>0) {
							$where = "isDefault = 1";
							$ClarityCredentials->update($formData, $where);
						}
						else {
							$formData['isDefault'] = '1';
							$ClarityCredentials->insert($formData);
						}


					} else if ($id == TrueScoreCredentials::VENDOR_ID) {
						$formData = array('accountID' => $accountID,
							'apiKey' => $apiKey);

						// First lets check if we have default credentials
						$row = $TrueScoreCredentials->fetchRow('isDefault = 1');
						// We have default credentials so lets update them
						if(count($row)>0) {
							$where = "isDefault = 1";
							$TrueScoreCredentials->update($formData, $where);
						}
						else {
							$formData['isDefault'] = '1';
							$TrueScoreCredentials->insert($formData);
						}

					} else if ($id == DataXCredentials::VENDOR_ID) {
						$formData = array('key' => $DataXkey,
							'password' => $DataXpassword,'inquiryType' => $DataXinquirytype);

						$DataXCredentials = new DataXCredentials();
						// First lets check if we have default credentials
						$row = $DataXCredentials->fetchRow('isDefault = 1');
						// We have default credentials so lets update them
						if(count($row)>0) {
							$where = "isDefault = 1";
							$DataXCredentials->update($formData, $where);
						}
						else {
							$formData['isDefault'] = '1';
							$DataXCredentials->insert($formData);
						}

					} else if ($id == MBCredentials::VENDOR_ID) {

						$mbUseTestUrl = $f->filter($this->_request->getPost('mbUseTestUrl'));
						$formData = array('username' => $mbUsername,
							'password' => $mbPassword,
							'useTestUrl' => $mbUseTestUrl);

						$MBCredentials = new MBCredentials();
						// First lets check if we have default credentials
						$row = $MBCredentials->fetchRow('isDefault = 1');
						// We have default credentials so lets update them
						if(count($row)>0) {
							$where = "isDefault = 1";
							$MBCredentials->update($formData, $where);
						}
						else {
							$formData['isDefault'] = '1';
							$MBCredentials->insert($formData);
						}

					} else if ($id == GVerifyCredentials::VENDOR_ID) {
						$formData = array('username' => $GverifyUsername,
							'password' => $Gverifypassword);

						$GVerifyCredentials = new GVerifyCredentials();
						// First lets check if we have default credentials
						$row = $GVerifyCredentials->fetchRow('isDefault = 1');
						// We have default credentials so lets update them
						if(count($row)>0) {
							$where = "isDefault = 1";
							$GVerifyCredentials->update($formData, $where);
						}
						else {
							$formData['isDefault'] = '1';
							$GVerifyCredentials->insert($formData);
						}

					} else if ($id == CPADetectiveCredentials::VENDOR_ID) {

						$formData = array('key' => $CPADectivekey);
						$where = "isDefault = 1";

						$CPADetectiveCredentials = new CPADetectiveCredentials();
						// First lets check if we have default credentials
						$row = $CPADetectiveCredentials->fetchRow('isDefault = 1');
						// We have default credentials so lets update them
						if(count($row)>0) {
							$where = "isDefault = 1";
							$CPADetectiveCredentials->update($formData, $where);
						}
						else {
							$formData['isDefault'] = '1';
							$CPADetectiveCredentials->insert($formData);
						}

					} else if ($id == RelianceMarkCredentials::VENDOR_ID) {

						$formData = array('key' => $relmarkey);
						$RelianceMarkCredentials = new RelianceMarkCredentials();

						// First lets check if we have default credentials
						$row = $RelianceMarkCredentials->fetchRow('isDefault = 1');
						// We have default credentials so lets update them
						if(count($row)>0) {
							$where = "isDefault = 1";
							$RelianceMarkCredentials->update($formData, $where);
						}
						else {
							$formData['isDefault'] = '1';
							$RelianceMarkCredentials->insert($formData);
						}
					} else if ($id == DecisionLogicCredentials::VENDOR_ID) {

						$formData = array('key' => $decisionlogickey, 'guid' => $decisionlogicguid);
						$DecisionLogicCredentials = new DecisionLogicCredentials();

						// First lets check if we have default credentials
						$row = $DecisionLogicCredentials->fetchRow('isDefault = 1');
						// We have default credentials so lets update them
						if(count($row)>0) {
							$where = "isDefault = 1";
							$DecisionLogicCredentials->update($formData, $where);
						}
						else {
							$formData['isDefault'] = '1';
							$DecisionLogicCredentials->insert($formData);
						}
					} else if ($id == EbureauCredentials::VENDOR_ID) {

						$formData = array('username' => $EbureauUserName,'password' => $EbureauPassword,
								  'useTestUrl' => $EbureauUseTestUrl,'fraudScore' => $EbureauFraudScore,
								  'marketScore' => $EbureauMarketScore);
						$EbureauCredentials = new EbureauCredentials();

						// First lets check if we have default credentials
						$row = $EbureauCredentials->fetchRow('isDefault = 1');
						// We have default credentials so lets update them
						if(count($row)>0) {
							$where = "isDefault = 1";
							$EbureauCredentials->update($formData, $where);
						}
						else {
							$formData['isDefault'] = '1';
							$EbureauCredentials->insert($formData);
						}
					}
					else if ($id == EbureauCredentials::VENDOR_ID_FINANCE) {

						$formData = array('username' => $EbureauUserName,'password' => $EbureauPassword,
							'useTestUrl' => $EbureauUseTestUrl,'fraudScore' => $EbureauFraudScore,
							'marketScore' => $EbureauMarketScore, 'fraudScoreName'=> $EbureauFraudScoreName, 'marketScoreName'=> $EbureauMarketScoreName);
						$EbureauCredentials = new EbureauCredentials();

						// First lets check if we have default credentials
						$row = $EbureauCredentials->fetchRow('isDefault = 1');
						// We have default credentials so lets update them
						if(count($row)>0) {
							$where = "isDefault = 1";
							$EbureauCredentials->update($formData, $where);
						}
						else {
							$formData['isDefault'] = '1';
							$EbureauCredentials->insert($formData);
						}
					}
					else if ($id == BriteVerifyCredentials::BRITE_VERIFY_EMAIL_CHECK_VENDOR_ID) {

						$formData = array('key' => $briteVerifyKey);

						$BriteVerifyCredentials = new BriteVerifyCredentials();
						// First lets check if we have default credentials
						$row = $BriteVerifyCredentials->fetchRow('isDefault = 1');
						// We have default credentials so lets update them
						if(count($row)>0) {
							$where = "isDefault = 1";
							$BriteVerifyCredentials->update($formData, $where);
						}
						else {
							$formData['isDefault'] = '1';
							$BriteVerifyCredentials->insert($formData);
						}

					} else if ($id == PDSPaymentCredential::VENDOR_ID) {
						$formData = array(
							'login' => $PDSPaymentLogin,
							'password' => $PDSPaymentPassword,
							'merchantid' => $PDSPaymentMerchantID,
							'trancode' => $PDSPaymentTrancode,
							'sec' => $PDSPaymentSec,
							'description' => $PDSPaymentDescription
						);
						$PDSPaymentCredential = new PDSPaymentCredential();
						// First lets check if we have default credentials
						$row = $PDSPaymentCredential->fetchRow('isDefault = 1');
						// We have default credentials so lets update them
						if(count($row)>0) {
							$where = "isDefault = 1";
							$PDSPaymentCredential->update($formData, $where);
						}
						else {
							$formData['isDefault'] = '1';
							$PDSPaymentCredential->insert($formData);
						}
					} else if ($id == DataTwentyFourSevenCredentials::VENDOR_ID) {
						$formData = array(
							'username' => $dataTwentyFourSevenUsername,
							'password' => $dataTwentyFourSevenPassword,
						);
						$DataTwentyFourSevenCredentials = new DataTwentyFourSevenCredentials();
						// First lets check if we have default credentials
						$row = $DataTwentyFourSevenCredentials->fetchRow('isDefault = 1');
						// We have default credentials so lets update them
						if(isset($row) && count($row)>0) {
							$where = "isDefault = 1";
							$DataTwentyFourSevenCredentials->update($formData, $where);
						}
						else {
							$formData['isDefault'] = '1';
							$DataTwentyFourSevenCredentials->insert($formData);
						}
					} else if ($id == VeritecCredentials::VENDOR_ID) {
						$VeritecCredentials = new VeritecCredentials();
						$formData = array(
							'username' => $veritecUsername,
							'password' => $veritecPassword,
							'reglicnum' => $veritecReglicnum,
							'actioncode' => $veritecActioncode
						);

						// First lets check if we have default credentials
						$row = $VeritecCredentials->fetchRow('isDefault = 1');
						// We have default credentials so lets update them
						if(count($row)>0) {
							$where = "isDefault = 1";
							$VeritecCredentials->update($formData, $where);
						}
						else {
							$formData['isDefault'] = '1';
							$VeritecCredentials->insert($formData);
						}
					} else if ($id == WhitePagesCredentials::VENDOR_ID) {

					    $WhitePagesCredentials = new WhitePagesCredentials();
					    $formData = array(
					        'apiKey' => $whitePagesApiKey,
					        'products' => implode(",", $whitePagesProducts)
					    );
					    // First lets check if we have default credentials
					    $row = $WhitePagesCredentials->fetchRow('isDefault = 1');
					    // We have default credentials so lets update them
					    if(count($row)>0) {
					        $where = "isDefault = 1";
					        $WhitePagesCredentials->update($formData, $where);
					    }
					    else {
					        $formData['isDefault'] = '1';
					        $WhitePagesCredentials->insert($formData);
					    }
					}

					$message = "Data Provider successfully updated.";
					$success = 1;
				} catch (Zend_Exception $e) {
					$error = 1;
					$message = "Some error occurred please try later.";

				}
			}

			if ($error == 1) {
				$this->view->email = $email;
				$this->view->company = $company;
				$this->view->id = $id;

				$this->view->username = $username;
				$this->view->password = $password;

				if ($id == FTCredentials::VENDOR_ID) {
					$this->view->merchantID = $merchantID;
					$this->view->storeID = $storeID;
					$this->view->lenderID = $lenderID;

				} else if ($id == ClarityCredentials::VENDOR_ID) {
					$this->view->username = $username;
					$this->view->password = $password;
					$this->view->groupID = $groupID;
					$this->view->accountID = $accountID;
					$this->view->locationID = $locationID;
					$this->view->controlFileName = $controlFileName;
					$this->view->inquiryTradelineType = $inquiryTradelineType;

				} else if ($id == TrueScoreCredentials::VENDOR_ID) {
					$this->view->accountID = $accountID;
					$this->view->apiKey = $apiKey;

				} else if ($id == DataXCredentials::VENDOR_ID) {
					$this->view->key = $DataXkey;
					$this->view->password = $DataXpassword;
					$this->view->inquiryType = $DataXinquirytype;

				} else if ($id == MBCredentials::VENDOR_ID) {
					$this->view->mbUsername = $mbUsername;
					$this->view->mbPassword = $mbPassword;
					$this->view->mbUseTestUrl = $mbUseTestUrl;

				} else if ($id == GVerifyCredentials::VENDOR_ID) {
					$this->view->username = $GverifyUsername;
					$this->view->password = $Gverifypassword;

				} else if ($id == CPADetectiveCredentials::VENDOR_ID) {
					$this->view->cpadectivekey = $CPADectivekey;
					$this->view->password = $Gverifypassword;

				} else if ($id == RelianceMarkCredentials::VENDOR_ID) {
					$this->view->reliancemarkkey = $relmarkey;

				} else if ($id == DecisionLogicCredentials::VENDOR_ID) {
					$this->view->decisionlogickey = $decisionlogickey;
					$this->view->decisionlogicguid = $decisionlogicguid;

				} else if ($id == EbureauCredentials::VENDOR_ID) {
					$this->view->ebureauUsername = $EbureauUserName;
					$this->view->ebureauPassword = $EbureauPassword;
					$this->view->ebureaufraudScore = $EbureauFraudScore;
					$this->view->ebureaumarketScore = $EbureauMarketScore;
					$this->view->ebureauUseTestUrl = $EbureauUseTestUrl;

				} else if ($id == EbureauCredentials::VENDOR_ID_FINANCE) {
					$this->view->ebureauUsername = $EbureauUserName;
					$this->view->ebureauPassword = $EbureauPassword;
					$this->view->ebureaufraudScore = $EbureauFraudScore;
					$this->view->ebureaumarketScore = $EbureauMarketScore;
					$this->view->ebureauUseTestUrl = $EbureauUseTestUrl;
					$this->view->ebureaufraudScoreName = $EbureauFraudScoreName;
					$this->view->ebureaumarketScoreName = $EbureauMarketScoreName;

				}
				else if ($id == BriteVerifyCredentials::BRITE_VERIFY_EMAIL_CHECK_VENDOR_ID) {

					$this->view->briteverifykey = $briteVerifyKey;

				} else if ($id == PDSPaymentCredential::VENDOR_ID) {
					$this->view->pdspaymentLogin = $PDSPaymentLogin;
					$this->view->pdspaymentPassword = $PDSPaymentPassword;
					$this->view->pdspaymentMerchantid = $PDSPaymentMerchantID;
					$this->view->pdspaymentTrancode = $PDSPaymentTrancode;
					$this->view->pdspaymentSec = $PDSPaymentSec;
					$this->view->pdspaymentDescription = $PDSPaymentDescription;

				} else if ($id == DataTwentyFourSevenCredentials::VENDOR_ID) {
					$this->view->dataTwentyFourSevenUsername = $dataTwentyFourSevenUsername;
					$this->view->dataTwentyFourSevenPassword = $dataTwentyFourSevenPassword;

				} else if ($id == VeritecCredentials::VENDOR_ID) {
					$this->view->veritecUsername = $veritecUsername;
					$this->view->veritecPassword = $veritecPassword;
					$this->view->veritecActioncode = $veritecActioncode;
					$this->view->veritecReglicnum = $veritecReglicnum;

				} else if ($id == WhitePagesCredentials::VENDOR_ID) {
					$this->view->apiKey = $whitePagesApiKey;
					$this->view->products = implode(",", $whitePagesProducts);
				}
			}

		}

		if ($error == 0) {
			$Vendors = new Vendors();
			$data = $Vendors->fetchRow("id = $id");
			$this->view->email = $data['email'];
			$this->view->company = $data['company'];

			if ($id == FTCredentials::VENDOR_ID) {
				$FTCredentials = new FTCredentials();
				$FTdata = $FTCredentials->fetchRow("isDefault = 1");
				$this->view->username = $FTdata['username'];
				$this->view->password = $FTdata['password'];
				$this->view->merchantID = $FTdata['merchantID'];
				$this->view->storeID = $FTdata['storeID'];
				$this->view->lenderID = $FTdata['lenderID'];

			} else if ($id == ClarityCredentials::VENDOR_ID) {
				$ClarityCredentials = new ClarityCredentials();
				$CLdata = $ClarityCredentials->fetchRow("isDefault = 1");
				$this->view->username = $CLdata['username'];
				$this->view->password = $CLdata['password'];
				$this->view->groupID = $CLdata['groupID'];
				$this->view->accountID = $CLdata['accountID'];
				$this->view->locationID = $CLdata['locationID'];
				$this->view->controlFileName = $CLdata['controlFileName'];
				$this->view->inquiryTradelineType = $CLdata['inquiryTradelineType'];

			} else if ($id == TrueScoreCredentials::VENDOR_ID) {
				$TrueScoreCredentials = new TrueScoreCredentials();
				$TRdata = $TrueScoreCredentials->fetchRow("isDefault = 1");
				$this->view->accountID = $TRdata['accountID'];
				$this->view->apiKey = $TRdata['apiKey'];

			} else if ($id == DataXCredentials::VENDOR_ID) {
				$DataXCredentials = new DataXCredentials();
				$Dataxdata = $DataXCredentials->fetchRow("isDefault = 1");
				$this->view->key = $Dataxdata['key'];
				$this->view->password = $Dataxdata['password'];
				$this->view->inquiryType = $Dataxdata['inquiryType'];

			} else if ($id == MBCredentials::VENDOR_ID) {
				$MBCredentials = new MBCredentials();
				$mbdata = $MBCredentials->fetchRow("isDefault = 1");
				$this->view->mbUsername = $mbdata['username'];
				$this->view->mbPassword = $mbdata['password'];
				$this->view->mbUseTestUrl = $mbdata['useTestUrl'];
				$this->view->inquiryType = $Dataxdata['inquiryType'];

			} else if ($id == GVerifyCredentials::VENDOR_ID) {
				$GVerifyCredentials = new GVerifyCredentials();
				$Gverifydata = $GVerifyCredentials->fetchRow("isDefault = 1");
				$this->view->username = $Gverifydata['username'];
				$this->view->password = $Gverifydata['password'];

			} else if ($id == CPADetectiveCredentials::VENDOR_ID) {
				$CPADetectiveCredentials = new CPADetectiveCredentials();
				$CPADectivedata = $CPADetectiveCredentials->fetchRow("isDefault = 1");
				$this->view->cpadectivekey = $CPADectivedata['key'];

			} else if ($id == RelianceMarkCredentials::VENDOR_ID) {
				$RelianceMarkCredentials = new RelianceMarkCredentials();
				$Relmardata = $RelianceMarkCredentials->fetchRow("isDefault = 1");
				$this->view->reliancemarkkey = $Relmardata['key'];
			} else if ($id == DecisionLogicCredentials::VENDOR_ID) {
				$DecisionLogicCredentials = new DecisionLogicCredentials();
				$Decisionlogicdata = $DecisionLogicCredentials->fetchRow("isDefault = 1");
				$this->view->decisionlogickey = $Decisionlogicdata['key'];
				$this->view->decisionlogicguid = $Decisionlogicdata['guid'];
			} else if ($id == EbureauCredentials::VENDOR_ID) {
				$EbureauCredentials = new EbureauCredentials();
				$EbureauData = $EbureauCredentials->fetchRow("isDefault = 1");
				$this->view->ebureauUsername = $EbureauData['username'];
				$this->view->ebureauPassword = $EbureauData['password'];
				$this->view->ebureaufraudScore = $EbureauData['fraudScore'];
				$this->view->ebureaumarketScore = $EbureauData['marketScore'];
				$this->view->ebureauUseTestUrl = $EbureauData['useTestUrl'];
			} else if ($id == EbureauCredentials::VENDOR_ID_FINANCE) {
				$EbureauCredentials = new EbureauCredentials();
				$EbureauData = $EbureauCredentials->fetchRow("isDefault = 1");
				$this->view->ebureauUsername = $EbureauData['username'];
				$this->view->ebureauPassword = $EbureauData['password'];
				$this->view->ebureaufraudScore = $EbureauData['fraudScore'];
				$this->view->ebureaumarketScore = $EbureauData['marketScore'];
				$this->view->ebureauUseTestUrl = $EbureauData['useTestUrl'];
				$this->view->ebureaufraudScoreName = $EbureauData['fraudScoreName'];
				$this->view->ebureaumarketScoreName = $EbureauData['marketScoreName'];
			}
			else if ($id == BriteVerifyCredentials::BRITE_VERIFY_EMAIL_CHECK_VENDOR_ID) {

				$BriteVerifyCredentials = new BriteVerifyCredentials();
				$BriteVerifyData = $BriteVerifyCredentials->fetchRow("isDefault = 1 ");
				$this->view->briteverifykey = $BriteVerifyData['key'];
			} else if ($id == PDSPaymentCredential::VENDOR_ID) {
				$PDSPaymentCredential = new PDSPaymentCredential();
				$PDSPaymentData = $PDSPaymentCredential->fetchRow("isDefault = 1");
				$this->view->pdspaymentLogin = $PDSPaymentData['login'];
				$this->view->pdspaymentPassword = $PDSPaymentData['password'];
				$this->view->pdspaymentMerchantid = $PDSPaymentData['merchantid'];
				$this->view->pdspaymentTrancode = $PDSPaymentData['trancode'];
				$this->view->pdspaymentSec = $PDSPaymentData['sec'];
				$this->view->pdspaymentDescription = $PDSPaymentData['description'];
			} else if ($id == DataTwentyFourSevenCredentials::VENDOR_ID) {
				$DataTwentyFourSevenCredentials = new DataTwentyFourSevenCredentials();
				$DataTwentyFourSevenData = $DataTwentyFourSevenCredentials->fetchRow("isDefault = 1");
				$this->view->dataTwentyFourSevenUsername = $DataTwentyFourSevenData['username'];
				$this->view->dataTwentyFourSevenPassword = $DataTwentyFourSevenData['password'];
			} else if ($id == VeritecCredentials::VENDOR_ID) {
				$VeritecCredentials = new VeritecCredentials();
				$VeritecData = $VeritecCredentials->fetchRow("isDefault = 1");
				$this->view->veritecUsername = $VeritecData['username'];
				$this->view->veritecPassword = $VeritecData['password'];
				$this->view->veritecActioncode = $VeritecData['actioncode'];
				$this->view->veritecReglicnum = $VeritecData['reglicnum'];

			} else if ($id == WhitePagesCredentials::VENDOR_ID) {
			    $WhitePagesCredentials = new WhitePagesCredentials();
			    $whitePagesData = $WhitePagesCredentials->fetchRow("isDefault = 1");
			    $this->view->apiKey = $whitePagesData['apiKey'];
			    $this->view->products = $whitePagesData['products'];
			}
			$this->view->id = $data['id'];
		}

		$this->view->baseurl = $this->baseurl;
		$this->view->message = $message;
		$this->view->error = $error;
		$this->view->success = $success;
		$this->view->clarityVendorID = ClarityCredentials::VENDOR_ID;
		$this->view->factortrustVendorID = FTCredentials::VENDOR_ID;
		$this->view->truescoreVendorID = TrueScoreCredentials::VENDOR_ID;
		$this->view->mbVendorID = MBCredentials::VENDOR_ID;
		$this->view->dataxVendorID = DataXCredentials::VENDOR_ID;
		$this->view->gverifyVendorID = GVerifyCredentials::VENDOR_ID;
		$this->view->cpadetectiveVendorID = CPADetectiveCredentials::VENDOR_ID;
		$this->view->gverifyVendorID = GVerifyCredentials::VENDOR_ID;
		$this->view->relmarVendorID = RelianceMarkCredentials::VENDOR_ID;
		$this->view->decisionlogicVendorID = DecisionLogicCredentials::VENDOR_ID;
		$this->view->ebureauVendorID = EbureauCredentials::VENDOR_ID;
		$this->view->ebureauFinanceVendorID = EbureauCredentials::VENDOR_ID_FINANCE;
		$this->view->briteverifyemailcheckVendorID  = BriteVerifyCredentials::BRITE_VERIFY_EMAIL_CHECK_VENDOR_ID;
		$this->view->pdsPaymentVendorID = PDSPaymentCredential::VENDOR_ID;
		$this->view->dataTwentyFourSevenVendorID = DataTwentyFourSevenCredentials::VENDOR_ID;
		$this->view->veritecVendorID = VeritecCredentials::VENDOR_ID;
		$this->view->whitePagesVendorID = WhitePagesCredentials::VENDOR_ID;
	}

	function deleteAction()
	{
		$id = $_GET['id'];
		if ($id > 0) {
			$where = "id=$id";
			$ae_Data = new Vendors();
			$ae_Data->delete($where);
		}

		$this->_redirect('vendor/view');
	}
}

?>