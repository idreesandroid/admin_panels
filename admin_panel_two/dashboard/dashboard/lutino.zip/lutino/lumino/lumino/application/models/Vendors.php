<?php

class Vendors extends Zend_Db_Table
{
	protected $_name = 'Vendors';

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}

	public function findAll()
	{
		$sql = "SELECT *
				FROM
				Vendors v WHERE id != 10000";
		$result = $this->db->fetchAll($sql);

		return $result;
	}

	public function getVendorData()
	{
		$sql = "SELECT
					company,
					fname,
					postSetupID,
					ps.active,
					priority
				FROM
					Vendors v
				LEFT JOIN VendorPostSetups vps ON v.id = vps.vendorID
				LEFT JOIN PostSetups ps ON ps.id = vps.postSetupID";

		$result = $this->db->fetchAll($sql);

		return $result;
	}

    public function getDataById($vendorId)
	{
	$select = $this->select()
		    ->where('id=' . $vendorId);
	return $this->fetchRow($select);
	}
}

?>
