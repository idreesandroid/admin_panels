<?php
class ReportsController extends Zend_Controller_Action
{
	private $baseurl;

	public function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if(!$AdminNameSpace->userid)
		{
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();

		$this->config = Zend_Registry::get('config');
	}

	public function campaignFrAction()
	{

	}

    public function campaignAction()
	{
		$originalDateStart = date("m/d/Y");
		$originalDateEnd = date("m/d/Y");
		$originalTimeStart = date("H:i:s", strtotime("Today"));
		$originalTimeEnd = date("H:i:s", strtotime("Today last second"));

		$this->view->originalDateStart = $originalDateStart;
		$this->view->originalDateEnd = $originalDateEnd;
		$this->view->originalTimeStart = $originalTimeStart;
		$this->view->originalTimeEnd = $originalTimeEnd;
		$this->view->originationDate = "";

		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		$this->view->userid = $AdminNameSpace->userid;

		$Factory = new CampaignReportLMSFactory();
		$CampaignReport	= $Factory->create($this->config->lmsName);

		$masteraffData = $CampaignReport->getLeadProviders($originalDateStart, $originalDateEnd, $originalTimeStart, $originalTimeEnd);

		$storeIDs = array();
		$storeIDs[''] = '';

		foreach ($CampaignReport->getStoreIDs() as $store) {
			if ($store['storeID']) {
				$storeIDs[$store['storeID']] = $store['storeID'];
			}
		}

		$strategies = array();
		$strategies[''] = '';
		foreach ($CampaignReport->getVendorStrategies() as $strategy) {
			if ($strategy['id']) {
				$select = "<option value=''></option>";
				$name = $strategy['name'];
				$id = $strategy['id'];
				if ($strategy['active'] == 1) {
					$select .= "<option value=$id class='activestrategy'>$name</option>";
				} else if ($strategy['active'] == 0) {
					$select .= "<option value=$id class='noactivestrategy'>$name</option>";
				}
			}
		}

		$this->view->masteraff =  $masteraffData;
		$this->view->storeid =  $storeIDs;
		$this->view->strategies =  $select;
	}

	/**
	 * this is currently called within campaign report view. (dataTables via ajax)
	 * It returns the actual campaign report data.
	 * NOTE: you can pass format=json to call this action directly and get raw data.
	 */
	public function campaigndataAction()
	{
		// required request params
		$originalDateStart = date('Y-m-d', strtotime($this->_request->originalDateStart));
		$originalDateEnd = date('Y-m-d', strtotime($this->_request->originalDateEnd));
		$originalTimeStart = date("H:i:s", strtotime($this->_request->originalTimeStart));
		$originalTimeEnd = date("H:i:s", strtotime($this->_request->originalTimeEnd));
		$selectedStoreIDs = $this->_request->selectedStoreIDs;

		// need to wrap quotes around storeIDs when passing to CampaignReport model
		$storeIdsQuoted = array();
		foreach ($selectedStoreIDs as $v) {
			$storeIdsQuoted[] = "'" . $v . "'";
		}

		if ($this->_request->originationDate != "") {
			$originationDate = date('Y-m-d', strtotime($this->_request->originationDate));
		} else {
			$originationDate = "";
		}

		$multiVarStart = (!$this->_request->multiVarStart) ? 0 : $this->_request->multiVarStart;
		$multiVarEnd = (!$this->_request->multiVarEnd) ? 0 : $this->_request->multiVarEnd;

		// lets retrieve actual report now
		$Factory = new CampaignReportLMSFactory();
		$CampaignReport	= $Factory->create($this->config->lmsName);
		$reportData = $CampaignReport->getCampaignReports(
			false,
			$originalDateStart,
			$originalDateEnd,
			$originalTimeStart,
			$originalTimeEnd,
			implode(',', $storeIdsQuoted),
			$multiVarStart,
			$multiVarEnd,
			$originationDate,
			$this->_request->selectedStrategy);

		// finally, we assemble report data so it can be used by our jquery 'data tables' library.
		// we will return the full json report within this array
		$result = array();

		$result['sEcho'] = 1;
		$result['iTotalRecords'] = count($reportData) - 1;
		$result['iTotalDisplayRecords'] = 10;

		// for displaying affiliate name
		$Affiliates = new Affiliates();
		$affiliates = $Affiliates->fetchAll();

		// build querystring for clicking on hyperlink to lead-provider-reports
		$storeIDQueryString = '';
		foreach ($selectedStoreIDs as $v) {
			$storeIDQueryString .= "&storeIDs[]='" . $v . "'";
		}

		// jquery 'data tables' requires our data to be within an aaData array index
		$result['aaData'] = array();
		foreach ($reportData as $val) {
			$row = array();
			$row[] = $val['affiliateID'];
			$row[] = $val['isHotTransfer'];
			$row[] = $val['storeID'];
			$row[] = $Affiliates->getAffiliateNameByID($affiliates, $val['affiliateID']);
			$row[] = $val['title'];

			if (!$val['campaign']) {
				continue;
			}

			if ($val['hasSubIDs']) {
				$row[] = '<a href="#" class="submit-link"> '. $val['campaign'] . ' </a>';
			} else {
				$row[] = $val['campaign'];
            }

			$row[] ="$" .  number_format($val['costPerLead'], 2);

			$row[] = '<a target="_blank" href="/lead-provider-reports/attempts?campaignID=' . $val['campaign'] .
				'&fromDate=' . $originalDateStart .
				'&fromTime=' . $originalTimeStart .
				'&toDate=' . $originalDateEnd .
				'&toTime=' . $originalTimeEnd .
				'&multiVarStart=' . $multiVarStart .
				'&multiVarEnd=' . $multiVarEnd . $storeIDQueryString .
				'">' . $val['leads'] . '</a>';

			$row[] =  '<a target="_blank" href="/lead-purchased-reports?customertype=all&campaignID=' . $val['campaign'] .
				'&fromDate=' . $originalDateStart .
				'&fromTime=' . $originalTimeStart .
				'&toDate=' . $originalDateEnd .
				'&toTime=' . $originalTimeEnd . '">' . $val['bought'] . '</a>';

			$row[] = $val['cost'];
			$row[] =  '<a target="_blank" href="/lead-purchased-reports?customertype=all&orig=1&campaignID=' . $val['campaign'] .
			'&fromDate=' . $originalDateStart .
			'&fromTime=' . $originalTimeStart .
			'&toDate=' . $originalDateEnd .
			'&toTime=' . $originalTimeEnd . '">' . $val['originated'] . '</a>';

			$row[] = $val['totaloriginated'];

			if ($val['bought'] > 0 && $val['totaloriginated'] == 0) {
				$row[] = '<img src=/public/images/bomb.png alt="" height="14" style="display:block;" />';
			} else {
				$row[] = "$" . number_format($val['cpf'], 2);
			}

			$row[] = number_format($val['perTodayOrigBought'], 2);
			$row[] = number_format($val['perTotalOrigBought'], 2);
			$row[] = number_format($val['perBoughtAttempted'], 2);
			$row[] = number_format($val['esigs']);
			$row[] = number_format($val['esigRate'], 2) . "%";
			$row[] = number_format($val['FPD']);
			$row[] = number_format($val['FPDRate'], 2) . "%";
			$row[] = number_format($val['redirects']);
			$row[] = number_format($val['redirectsRate'], 2) . "%";

			$result['aaData'][] = $row;
		}

		$this->_helper->viewRenderer->setNoRender();

		// for outputting raw json. ie we dont care about aaData param, as that is used in campaign view
		if ($this->_request->format == "json") {
			echo Zend_Json::encode($reportData);
			exit;
		}

		echo Zend_Json::encode($result);
		exit;
	}

	public function subiddataAction()
	{
		$originalDateStart = date('Y-m-d', strtotime($this->_request->originalDateStart));
		$originalDateEnd = date('Y-m-d', strtotime($this->_request->originalDateEnd));
		$originalTimeStart = date("H:i:s", strtotime($this->_request->originalTimeStart));
		$originalTimeEnd = date("H:i:s", strtotime($this->_request->originalTimeEnd));
		$selectedStoreIDs = $this->_request->selectedStoreIDs;

		if ($this->_request->originationDate != "")
			$originationDate = date('Y-m-d', strtotime($this->_request->originationDate));
		else
			$originationDate = "";

		$multiVarStart = $this->_request->multiVarStart;
		$multiVarEnd = $this->_request->multiVarEnd;
		$campaignID = $this->_request->campaignID;

		if (!$multiVarStart)
			$multiVarStart = 0;
		if (!$multiVarEnd)
			$multiVarEnd = 0;

		$storeIdsQuoted = array();
		foreach ($selectedStoreIDs as $v) {
			$storeIdsQuoted[] = "'" . $v . "'";
		}

		$selectedStrategy = $this->_request->selectedStrategy;

		$Factory = new CampaignReportLMSFactory();
		$CampaignReport	= $Factory->create($this->config->lmsName);

		if ($this->_request->subidtype == "subID") {
			$reportData = $CampaignReport->getSubIdReports(
				false,
				$originalDateStart,
				$originalDateEnd,
				$originalTimeStart,
				$originalTimeEnd,
				implode(',', $storeIdsQuoted),
				$campaignID,
				$multiVarStart,
				$multiVarEnd,
				$originationDate,
				$selectedStrategy);

		} else if ($this->_request->subidtype == "subID2") {
			$reportData = $CampaignReport->getSubId2Reports(
				false,
				$originalDateStart,
				$originalDateEnd,
				$originalTimeStart,
				$originalTimeEnd,
				implode(',', $storeIdsQuoted),
				$campaignID,
				$multiVarStart,
				$multiVarEnd,
				$originationDate,
				$selectedStrategy);
		} else if ($this->_request->subidtype == "subID3") {
			$reportData = $CampaignReport->getSubId3Reports(
				false,
				$originalDateStart,
				$originalDateEnd,
				$originalTimeStart,
				$originalTimeEnd,
				implode(',', $storeIdsQuoted),
				$campaignID,
				$multiVarStart,
				$multiVarEnd,
				$originationDate,
				$selectedStrategy);
		}

		$result = array();
		$result['sEcho'] = 1;
		$result['iTotalRecords'] = count($reportData) - 1;
		$result['iTotalDisplayRecords'] = 5;
		foreach ($reportData as $val) {
			$row = array();
			if ($this->_request->subidtype == "subID") {
				$row[] = $val['subID'];
			} else if ($this->_request->subidtype == "subID2") {
				$row[] = $val['subID2'];
			} else if ($this->_request->subidtype == "subID3") {
				$row[] = $val['subID3'];
			}

			$row[] ="$" .  number_format($val['costPerLead'], 2);
			$row[] = $val['leads'];
			$row[] = $val['bought'];
			$row[] = "$" . $val['cost'];
			$row[] = $val['originated'];
			$row[] = $val['totaloriginated'];

			if ($val['bought'] > 0 && $val['totaloriginated'] == 0) {
				$row[] = '<img src=/public/images/bomb.png alt="" height="14" style="display:block;" />';
			} else {
				$row[] = "$" . number_format($val['cpf'], 2);
			}

			$row[] = number_format($val['perTodayOrigBought'], 2);
			$row[] = number_format($val['perTotalOrigBought'], 2);
			$row[] = number_format($val['perBoughtAttempted'], 2) . "%";
			$row[] = $val['esigs'];
			$row[] = number_format($val['esigRate'], 2) . "%";
			$row[] = $val['FPD'];
			$row[] = number_format($val['FPDRate'], 2) . "%";
			$row[] = $val['redirects'];
			$row[] = number_format($val['redirectsRate'], 2) . "%";

			$result['aaData'][] = $row;
		}

		$this->view->json = Zend_Json::encode($result);
	}

	public function subidreportexcelAction()
	{
		$originalDateStart = date('Y-m-d', strtotime($this->_request->originalDateStart));
		$originalDateEnd = date('Y-m-d', strtotime($this->_request->originalDateEnd));
		$originalTimeStart = date("H:i:s", strtotime($this->_request->originalTimeStart));
		$originalTimeEnd = date("H:i:s", strtotime($this->_request->originalTimeEnd));
		$selectedStoreIDs = explode(',', $this->_request->selectedStoreIDs);

		$this->view->originalDateStart = $originalDateStart;
		$this->view->originalDateEnd = $originalDateEnd;

		// need to wrap quotes around stores as we now use char strings
		$storeIdsQuoted = array();
		foreach ($selectedStoreIDs as $v) {
			$storeIdsQuoted[] = "'" . $v . "'";
		}

		if ($this->_request->originationDate != "")
			$originationDate = date('Y-m-d', strtotime($this->_request->originationDate));
		else
			$originationDate = "";

		$multiVarStart = $this->_request->multiVarStart;
		$multiVarEnd = $this->_request->multiVarEnd;

		$campaignID = $this->_request->campaignID;
		$this->view->campaignID = trim($campaignID);

		if (!$multiVarStart)
			$multiVarStart = 0;
		if (!$multiVarEnd)
			$multiVarEnd = 0;

		$Factory = new CampaignReportLMSFactory();
		$CampaignReport	= $Factory->create($this->config->lmsName);
		$reportData = $CampaignReport->getSubIdReports(
			true,
			$originalDateStart,
			$originalDateEnd,
			$originalTimeStart,
			$originalTimeEnd,
			implode(',', $storeIdsQuoted),
			$campaignID,
			$multiVarStart,
			$multiVarEnd,
			$originationDate,
			$this->_request->selectedStrategy);

		$this->view->subidReports = $reportData;
		$this->view->totalRecord = count($this->view->subidReports) - 1;
	}

	function subid2reportexcelAction()
	{
		$originalDateStart = date('Y-m-d', strtotime($this->_request->originalDateStart));
		$originalDateEnd = date('Y-m-d', strtotime($this->_request->originalDateEnd));
		$originalTimeStart = date("H:i:s", strtotime($this->_request->originalTimeStart));
		$originalTimeEnd = date("H:i:s", strtotime($this->_request->originalTimeEnd));
		$selectedStoreIDs = explode(',', $this->_request->selectedStoreIDs);

		$this->view->originalDateStart = $originalDateStart;
		$this->view->originalDateEnd = $originalDateEnd;

		// need to wrap quotes around stores as we now use char strings
		$storeIdsQuoted = array();
		foreach ($selectedStoreIDs as $v) {
			$storeIdsQuoted[] = "'" . $v . "'";
		}

		if ($this->_request->originationDate != "")
			$originationDate = date('Y-m-d', strtotime($this->_request->originationDate));
		else
			$originationDate = "";

		$multiVarStart = $this->_request->multiVarStart;
		$multiVarEnd = $this->_request->multiVarEnd;
		$campaignID = $this->_request->campaignID;
		$this->view->campaignID = trim($campaignID);

		if (!$multiVarStart)
			$multiVarStart = 0;
		if (!$multiVarEnd)
			$multiVarEnd = 0;

		$Factory = new CampaignReportLMSFactory();
		$CampaignReport	= $Factory->create($this->config->lmsName);
		$reportData = $CampaignReport->getSubId2Reports(true,
			$originalDateStart,
			$originalDateEnd,
			$originalTimeStart,
			$originalTimeEnd,
			implode(',', $storeIdsQuoted),
			$campaignID,
			$multiVarStart,
			$multiVarEnd,
			$originationDate,
			$this->_request->selectedStrategy);

		$this->view->subid2Reports = $reportData;
		$this->view->totalRecord = count($this->view->subidReports2) - 1;
	}

	public function subid3reportexcelAction()
	{
		$originalDateStart = date('Y-m-d', strtotime($this->_request->originalDateStart));
		$originalDateEnd = date('Y-m-d', strtotime($this->_request->originalDateEnd));
		$originalTimeStart = date("H:i:s", strtotime($this->_request->originalTimeStart));
		$originalTimeEnd = date("H:i:s", strtotime($this->_request->originalTimeEnd));
		$selectedStoreIDs = explode(',', $this->_request->selectedStoreIDs);

		$this->view->originalDateStart = $originalDateStart;
		$this->view->originalDateEnd = $originalDateEnd;

		// need to wrap quotes around stores as we now use char strings
		$storeIdsQuoted = array();
		foreach ($selectedStoreIDs as $v) {
			$storeIdsQuoted[] = "'" . $v . "'";
		}

		if ($this->_request->originationDate != "")
			$originationDate = date('Y-m-d', strtotime($this->_request->originationDate));
		else
			$originationDate = "";

		$multiVarStart = $this->_request->multiVarStart;
		$multiVarEnd = $this->_request->multiVarEnd;
		$campaignID = $this->_request->campaignID;
		$this->view->campaignID = trim($campaignID);

		if (!$multiVarStart)
			$multiVarStart = 0;
		if (!$multiVarEnd)
			$multiVarEnd = 0;

		$Factory = new CampaignReportLMSFactory();
		$CampaignReport	= $Factory->create($this->config->lmsName);
		$reportData = $CampaignReport->getSubId3Reports(
			true,
			$originalDateStart,
			$originalDateEnd,
			$originalTimeStart,
			$originalTimeEnd,
			implode(',', $storeIdsQuoted),
			$campaignID,
			$multiVarStart,
			$multiVarEnd,
			$originationDate,
			$this->_request->selectedStrategy);

		$this->view->subid3Reports = $reportData;
		$this->view->totalRecord = count($this->view->subidReports3) - 1;
	}

	function campaignreportexcelAction()
	{
		$originalDateStart = date('Y-m-d', strtotime($this->_request->originalDateStart));
		$originalDateEnd = date('Y-m-d', strtotime($this->_request->originalDateEnd));
		$originalTimeStart = date("H:i:s", strtotime($this->_request->originalTimeStart));
		$originalTimeEnd = date("H:i:s", strtotime($this->_request->originalTimeEnd));
		$selectedStoreIDs = explode(',', $this->_request->selectedStoreIDs);
		$selectedAffiliate = $this->_request->selectedAffiliate;

		$this->view->originalDateStart = $originalDateStart;
		$this->view->originalDateEnd = $originalDateEnd;

		// need to wrap quotes around stores as we now use char strings
		$storeIdsQuoted = array();
		foreach ($selectedStoreIDs as $v) {
			$storeIdsQuoted[] = "'" . $v . "'";
		}

		if ($this->_request->originationDate != "")
			$originationDate = date('Y-m-d', strtotime($this->_request->originationDate));
		else
			$originationDate = "";

		$multiVarStart = $this->_request->multiVarStart;
		$multiVarEnd = $this->_request->multiVarEnd;

		if (!$multiVarStart)
			$multiVarStart = 0;
		if (!$multiVarEnd)
			$multiVarEnd = 0;

		$Factory = new CampaignReportLMSFactory();
		$CampaignReport	= $Factory->create($this->config->lmsName);
		$reportData = $CampaignReport->getCampaignReports(
			true,
			$originalDateStart,
			$originalDateEnd,
			$originalTimeStart,
			$originalTimeEnd,
			implode(',', $storeIdsQuoted),
			$multiVarStart,
			$multiVarEnd,
			$originationDate,
			$this->_request->selectedStrategy,
			$selectedAffiliate);

		$Affiliates = new Affiliates();
		$affiliates = $Affiliates->fetchAll();

		//  get affiliate names using affiliateID
		for ($a=0;$a<count($reportData);$a++) {
			$val = $reportData[$a];
			if ($val['affiliateID']) {
				// Get affiliate name
				$affiliateName = $Affiliates->getAffiliateNameByID($affiliates, $val['affiliateID']);;
				// Push affiliate name back to reports data
				$reportData[$a]['affname'] = $affiliateName;
			}
		}

		$this->view->campaignReports = $reportData;
		$this->view->totalRecord = count($this->view->campaignReports) - 1;
	}

	public function updateaffiliatesAction()
	{
		$Factory = new CampaignReportLMSFactory();
		$CampaignReport	= $Factory->create($this->config->lmsName);
		$masteraffData = $CampaignReport->getLeadProviders($this->_request->originalDateStart, $this->_request->originalDateEnd, $this->_request->originalTimeStart, $this->_request->originalTimeEnd);
		$this->view->json = Zend_Json::encode($masteraffData);
	}
}
