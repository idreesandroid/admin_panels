<?php
/**
 * this class contains methods for PostSetups intending to be sold to Sovereign client
 */
class SovereignPostSetup
{
	/**
	 * @var posturl for sovereign webservice
	 */
	protected $sovereignPostUrl = 'https://www.sovereignadvance.com/leads.aspx';

	public function __construct()
	{
		$this->db = Zend_Registry::get('db');
	}

	/**
	 * @return array
	 */
	public function getPostSetupIDs()
	{
		$postSetupIDs = array();

		$sql = "select id from PostSetups where posturl='" . $this->sovereignPostUrl . "'";
		if ($results = $this->db->fetchAll($sql)) {
			foreach ($results as $result) {
				$postSetupIDs[] = $result['id'];
			}
		}

		return $postSetupIDs;
	}
}
