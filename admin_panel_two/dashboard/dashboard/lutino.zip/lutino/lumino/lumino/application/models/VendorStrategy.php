<?php

class VendorStrategy extends Zend_Db_Table 
{
	protected $_name = 'VendorStrategies';

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}
	public function getAllVendorStrategies()
	{
		$sql = "SELECT
					id,
					description
				FROM
					".$this->_name."";

		$sqlresult = $this->db->fetchAll($sql);

		$result = array();
		foreach ($sqlresult as $v) {
			$result[$v['id']] = $v['description'];
		}

		return $result;
	}

	public function getVendorStrategiesByVariateID($variateID)
	{
		$sql = "SELECT
					*
				FROM
					VariatesVendorStrategies vvs
				LEFT JOIN
					VendorStrategies vs ON vs.id = vvs.vendorStrategyID
				WHERE
					vvs.variateID = $variateID";

		$sqlresult = $this->db->fetchAll($sql);

		$result = array();
		foreach ($sqlresult as $v) {
			$result[$v['vendorStrategyID']] = $v['description'];
		}

		return $result;
	}
}
