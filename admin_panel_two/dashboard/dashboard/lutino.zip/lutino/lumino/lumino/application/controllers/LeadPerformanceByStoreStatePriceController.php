<?php

class LeadPerformanceByStoreStatePriceController extends Zend_Controller_Action
{
    public function indexAction() {

        $fromDate = ($this->_request->fromDate) ?
        date('Y-m-d', strtotime($this->_request->fromDate)) : date('Y-m-d');
        $toDate = ($this->_request->toDate) ?
        date('Y-m-d', strtotime($this->_request->toDate)) : date('Y-m-d');

        $fromTime = ($this->_request->fromTime) ?
        date('Y-m-d', strtotime($this->_request->fromTime)) : "00:00:00";

        $toTime = ($this->_request->toTime) ?
        date('Y-m-d', strtotime($this->_request->toTime)) : "23:59:59";
        $LeadPerformanceReport = new LeadPerformanceReport($fromDate, $toDate, $fromTime, $toTime);
        $reportData = $LeadPerformanceReport->getReportData();

        $data = array();
        foreach($reportData as $rdata) {
            if ($rdata['price'] != NULL) {
                $data[$rdata['storeid']][$rdata['state']][$rdata['price']]['price'] = '$'.number_format($rdata['price'],2,'.','');
            }
            else {
                $data[$rdata['storeid']][$rdata['state']][$rdata['price']]['price'] = "-";
            }

            // We need to group data by Storeid, State and Price using PHP array. For this we need multidimensional array
            $data[$rdata['storeid']][$rdata['state']][$rdata['price']]['leadsPurchased'] = $rdata['leadsPurchased'];
            $data[$rdata['storeid']][$rdata['state']][$rdata['price']]['totalLoansOrigSameDayPurchased'] = $rdata['totalLoansOrigSameDayPurchased'];
            $data[$rdata['storeid']][$rdata['state']][$rdata['price']]['totalLoansOrig'] = $rdata['totalLoansOrig'];
            $data[$rdata['storeid']][$rdata['state']][$rdata['price']]['loanamountfunded'] = number_format($rdata['loanamountfunded'],2,'.','');
            $data[$rdata['storeid']][$rdata['state']][$rdata['price']]['scrubbingcost'] = number_format($rdata['scrubbingcost'],2,'.','');
            $data[$rdata['storeid']][$rdata['state']][$rdata['price']]['firstleadpurchased'] = $rdata['firstleadpurchased'];
            $data[$rdata['storeid']][$rdata['state']][$rdata['price']]['lastleadpurchased'] = $rdata['lastleadpurchased'];
            $data[$rdata['storeid']][$rdata['state']][$rdata['price']]['costPerHundredFunded'] =  number_format($rdata['costPerHundredFunded'], 2, '.', '');
            $data[$rdata['storeid']][$rdata['state']][$rdata['price']]['totalConversion'] =  number_format($rdata['totalConversion'], 2, '.', '');

            if ($rdata['totalPrice'] != NULL) {

                $data[$rdata['storeid']][$rdata['state']][$rdata['price']]['totalPrice'] = number_format($rdata['totalPrice'],2,'.','');

            }
            else {
                $data[$rdata['storeid']][$rdata['state']][$rdata['price']]['totalPrice'] = number_format($rdata['totalPrice'],2,'.','');
            }

            $data[$rdata['storeid']][$rdata['state']][$rdata['price']]['totalConversion'] = number_format($rdata['totalConversion'],2,'.','')."%";
        }

        foreach ($data as $store => $storeLevelData) {

            foreach ($storeLevelData as $state => $stateLevelData) {

                foreach ($stateLevelData as $price => $priceLevelData) {

                    // Store level sum
                    $data[$store]['total']['leadsPurchased']+= $priceLevelData['leadsPurchased'];
                    $data[$store]['total']['totalLoansOrigSameDayPurchased']+= $priceLevelData['totalLoansOrigSameDayPurchased'];
                    $data[$store]['total']['totalLoansOrig']+= $priceLevelData['totalLoansOrig'];
                    $data[$store]['total']['loanamountfunded']+= $priceLevelData['loanamountfunded'];
                    $data[$store]['total']['scrubbingcost']+= $priceLevelData['scrubbingcost'];
                    $data[$store]['total']['totalPrice']+= $priceLevelData['totalPrice'];
                    $data[$store]['total']['totalConversion'] = ($data[$store]['total']['totalLoansOrig']/$data[$store]['total']['leadsPurchased'])*100;
                    $data[$store]['total']['costPerHundredFunded'] = (($data[$store]['total']['totalPrice']+$data[$store]['total']['scrubbingcost'])/$data[$store]['total']['loanamountfunded'])*100;

                    // State level sum
                    $data[$store][$state]['total']['leadsPurchased']+= $stateLevelData[$price]['leadsPurchased'];
                    $data[$store][$state]['total']['totalLoansOrigSameDayPurchased']+= $stateLevelData[$price]['totalLoansOrigSameDayPurchased'];
                    $data[$store][$state]['total']['totalLoansOrig']+= $stateLevelData[$price]['totalLoansOrig'];
                    $data[$store][$state]['total']['loanamountfunded']+= $stateLevelData[$price]['loanamountfunded'];
                    $data[$store][$state]['total']['scrubbingcost']+= $stateLevelData[$price]['scrubbingcost'];
                    $data[$store][$state]['total']['totalPrice']+= $stateLevelData[$price]['totalPrice'];
                    $data[$store][$state]['total']['totalConversion'] = ($data[$store][$state]['total']['totalLoansOrig']/$data[$store][$state]['total']['leadsPurchased'])*100;
                    $data[$store][$state]['total']['costPerHundredFunded'] = (($data[$store][$state]['total']['totalPrice']+$data[$store][$state]['total']['scrubbingcost'])/$data[$store][$state]['total']['loanamountfunded'])*100;

                    // Footer total for all stores
                    $data['total']['leadsPurchased']+=$priceLevelData['leadsPurchased'];
                    $data['total']['totalLoansOrigSameDayPurchased']+=$priceLevelData['totalLoansOrigSameDayPurchased'];
                    $data['total']['totalLoansOrig']+=$priceLevelData['totalLoansOrig'];
                    $data['total']['loanamountfunded']+=$priceLevelData['loanamountfunded'];
                    $data['total']['scrubbingcost']+=$priceLevelData['scrubbingcost'];
                    $data['total']['totalPrice']+=$priceLevelData['totalPrice'];
                    $data['total']['costPerHundredFunded'] =(($data['total']['totalPrice']+$data['total']['scrubbingcost'])/$data['total']['loanamountfunded'])*100;

                }
            }
        }

        $data['total']['totalConversion'] = ($data['total']['totalLoansOrig']/$data['total']['leadsPurchased'])*100;

        $this->view->fromDate = date("m/d/Y",strtotime($fromDate));
        $this->view->toDate = date("m/d/Y",strtotime($toDate));
        $this->view->timeStart = "00:00:00";
        $this->view->timeEnd = "23:59:59";
        $this->view->data = $data;
    }
}
