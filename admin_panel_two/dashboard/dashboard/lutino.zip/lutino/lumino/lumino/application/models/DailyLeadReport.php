<?php
class DailyLeadReport
{
    
 
    
public function getDailyLeadReports($originalDateStart,$originalDateEnd,$campaignID,$strategy = NULL)
{
    $db= Zend_Registry::get("db");
	$dailyLeadReports[]="";
    $count =0;

    $query="
    SELECT id,originaldate,campaign
	FROM Leads  
	WHERE originaldate >= '$originalDateStart' and  originaldate <= '$originalDateEnd'";
    if($campaignID !="")
	{
	    $query =  $query." and  campaign='$campaignID' GROUP BY originaldate,campaign";
	}
	else
	{
	    
	    $query =  $query." GROUP BY originaldate"; 
	}
    
    $query =  $query." ORDER BY originaldate, campaign"; 
    
        $dailyLeadReportLooper = $db->fetchAll($query);   
    
        foreach ($dailyLeadReportLooper as $data)
    	{
            $originalDate = $data['originaldate'];
            $campaignID = $data['campaign'];
            $leadID = $data['id'];
    		
            
            $dailyQuery=" SELECT 
            $campaignID AS campaign,
            '$originalDate' AS originaldate
            
            /*CACULATE NUMBER OF LOANS ORIGINATED TO BE USED IN QUERY BELOW*/
            ,(SELECT count(L.campaign)FROM  Master M INNER JOIN CashData C on M.Cust_SSN = C.ssn 
      			  INNER JOIN Leads L on L.id = C.leadID INNER JOIN LeadSold LS on L.id = LS.leadID 
        		  WHERE Loan_Type = 'S' AND Loan_Status not in ('I','V','W') AND 
        		  L.originaldate = left(M.ApplicationDate,10) AND L.campaign=MainLeads.campaign 
        		  AND L.originaldate=MainLeads.originaldate) as NumberOfLoanOriginated
    		
        	
        	/*Apps Purchased:# of leads sold*/	  
    		,(SELECT (SELECT count(campaign) FROM `LeadSold` LS WHERE campaign=MainLeads.campaign  
    		 AND LS.solddate=MainLeads.originaldate)) AS AppsPurchased

    		 
            /*COST:campaigns.costPerLead *number of leads for this campaign*/
    		,(SELECT (count(LS.Campaign) * C.costPerLead)FROM `LeadSold` LS INNER JOIN Campaigns C 
    		ON LS.Campaign = C.campaign WHERE LS.solddate=MainLeads.originaldate AND 
    		LS.Campaign=MainLeads.campaign) AS Cost 
    
            /*ACCEPTANCE RATE:leadsold/leads table- count by campaign*/
    		,(SELECT (AppsPurchased)/
			(SELECT count(campaign) FROM `Leads` LS WHERE campaign=MainLeads.campaign AND 
			LS.originaldate=MainLeads.originaldate)  *100 ) AS AcceptanceRate 
    
			
			/*CONVERSION RATE:# loan originated originated/#leads sold  */
            ,(SELECT
                 (NumberOfLoanOriginated)/(AppsPurchased) 
    		 )*100 AS ConversionRate
    
    
    		 /*Cost per Funded Loan:leadsold.cost + 15.00 / #loans originated*/
    		,(SELECT (SELECT sum(cost + 15) AS cost FROM `LeadSold` 
    		  WHERE campaign =MainLeads.campaign 
    		  AND soldDate=MainLeads.originaldate)/(NumberOfLoanOriginated)) AS CostPerFundedLoan
    		
    
        	
    		 
    	   FROM Leads AS MainLeads 	
		   WHERE originaldate = '$originalDate' AND campaign='$campaignID' GROUP BY campaign"; 
		   
		   if ($strategy)
		   {
		   		if ($strategy == 'bau')
		   		{
		   			$dailyQuery=" SELECT 
            $campaignID AS campaign,
            '$originalDate' AS originaldate
            
            /*CACULATE NUMBER OF LOANS ORIGINATED TO BE USED IN QUERY BELOW*/
            ,(SELECT count(L.campaign)FROM  Master M INNER JOIN CashData C on M.Cust_SSN = C.ssn 
      			  INNER JOIN Leads L on L.id = C.leadID INNER JOIN LeadSold LS on L.id = LS.leadID 
        		  WHERE Loan_Type = 'S' AND Loan_Status not in ('I','V','W') AND 
        		  L.originaldate = left(M.ApplicationDate,10) AND L.campaign=MainLeads.campaign 
        		  AND L.originaldate=MainLeads.originaldate) as NumberOfLoanOriginated
    		
        	
        	/*Apps Purchased:# of leads sold*/	  
    		,(SELECT (SELECT count(campaign) FROM `LeadSold` LS WHERE campaign=MainLeads.campaign  
    		 AND LS.solddate=MainLeads.originaldate)) AS AppsPurchased

    		 
            /*COST:campaigns.costPerLead *number of leads for this campaign*/
    		,(SELECT (count(LS.Campaign) * C.costPerLead)FROM `LeadSold` LS INNER JOIN Campaigns C 
    		ON LS.Campaign = C.campaign WHERE LS.solddate=MainLeads.originaldate AND 
    		LS.Campaign=MainLeads.campaign) AS Cost 
    
            /*ACCEPTANCE RATE:leadsold/leads table- count by campaign*/
    		,(SELECT (AppsPurchased)/
			(SELECT count(campaign) FROM `Leads` LS WHERE campaign=MainLeads.campaign AND 
			LS.originaldate=MainLeads.originaldate)  *100 ) AS AcceptanceRate 
    
			
			/*CONVERSION RATE:# loan originated originated/#leads sold  */
            ,(SELECT
                 (NumberOfLoanOriginated)/(AppsPurchased) 
    		 )*100 AS ConversionRate
    
    
    		 /*Cost per Funded Loan:leadsold.cost + 15.00 / #loans originated*/
    		,(SELECT (SELECT sum(cost + 15) AS cost FROM `LeadSold` 
    		  WHERE campaign =MainLeads.campaign 
    		  AND soldDate=MainLeads.originaldate)/(NumberOfLoanOriginated)) AS CostPerFundedLoan
    
    	   FROM Leads AS MainLeads 	
		   WHERE originaldate = '$originalDate' AND campaign='$campaignID' AND multiVarTestNum <= 84 GROUP BY campaign"; 
		   		}
		   		if ($strategy == 'challenger3')
		   		{
		   			$dailyQuery=" SELECT 
            $campaignID AS campaign,
            '$originalDate' AS originaldate
            
            /*CACULATE NUMBER OF LOANS ORIGINATED TO BE USED IN QUERY BELOW*/
            ,(SELECT count(L.campaign)FROM  Master M INNER JOIN CashData C on M.Cust_SSN = C.ssn 
      			  INNER JOIN Leads L on L.id = C.leadID INNER JOIN LeadSold LS on L.id = LS.leadID 
        		  WHERE Loan_Type = 'S' AND Loan_Status not in ('I','V','W') AND 
        		  L.originaldate = left(M.ApplicationDate,10) AND L.campaign=MainLeads.campaign 
        		  AND L.originaldate=MainLeads.originaldate) as NumberOfLoanOriginated
    		
        	
        	/*Apps Purchased:# of leads sold*/	  
    		,(SELECT (SELECT count(campaign) FROM `LeadSold` LS WHERE campaign=MainLeads.campaign  
    		 AND LS.solddate=MainLeads.originaldate)) AS AppsPurchased

    		 
            /*COST:campaigns.costPerLead *number of leads for this campaign*/
    		,(SELECT (count(LS.Campaign) * C.costPerLead)FROM `LeadSold` LS INNER JOIN Campaigns C 
    		ON LS.Campaign = C.campaign WHERE LS.solddate=MainLeads.originaldate AND 
    		LS.Campaign=MainLeads.campaign) AS Cost 
    
            /*ACCEPTANCE RATE:leadsold/leads table- count by campaign*/
    		,(SELECT (AppsPurchased)/
			(SELECT count(campaign) FROM `Leads` LS WHERE campaign=MainLeads.campaign AND 
			LS.originaldate=MainLeads.originaldate)  *100 ) AS AcceptanceRate 
    
			
			/*CONVERSION RATE:# loan originated originated/#leads sold  */
            ,(SELECT
                 (NumberOfLoanOriginated)/(AppsPurchased) 
    		 )*100 AS ConversionRate
    
    
    		 /*Cost per Funded Loan:leadsold.cost + 15.00 / #loans originated*/
    		,(SELECT (SELECT sum(cost + 15) AS cost FROM `LeadSold` 
    		  WHERE campaign =MainLeads.campaign 
    		  AND soldDate=MainLeads.originaldate)/(NumberOfLoanOriginated)) AS CostPerFundedLoan
    		
    
        	
    		 
    	   FROM Leads AS MainLeads 	
		   WHERE originaldate = '$originalDate' AND campaign='$campaignID' and multiVarTestNum > 84 GROUP BY campaign"; 
		   		}
		   }
		
           // echo $dailyQuery."<p></p>";
            
    		$dailyReport = $db->fetchAll($dailyQuery); 
    		/*add results of $dailyLeadReport to $dailyLeadReports*/
            $dailyLeadReports[$count] =  $dailyReport; 
            $count = $count+1;
           
    	}
	//exit;
    	return $dailyLeadReports;
    }
}

 ?>

 