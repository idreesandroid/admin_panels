<?php

class ClientRejectCode extends Zend_Db_Table
{
	protected $_name = 'ClientRejectCodes';
}
