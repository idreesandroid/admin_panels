<?php
class ScorecardController extends Zend_Controller_Action
{
	function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if (!$AdminNameSpace->userid)
		{
			$this->_redirect('index/login');
		}

		$this->config = Zend_Registry::get("config");
	}

	function indexAction()
	{
		$Variate = new Variate();
		$variates = $Variate->fetchAll("hideInAdmin = 0", "createdAt");
		$this->view->variates = $variates;
	}

	function editAction()
	{
		$variateID = $this->getRequest()->getParam('variateID');

		$VendorStrategy = new VendorStrategy();
		$vendorStrategies = $VendorStrategy->getVendorStrategiesByVariateID($variateID);
		$this->view->vendorStrategies = $vendorStrategies;

		$VendorStrategy = new VendorStrategy();
		$allvendorStrategies = $VendorStrategy->getAllVendorStrategies();

		$strategies = array_diff_assoc($allvendorStrategies, $vendorStrategies);
		$this->view->allvendorStrategies = $strategies;

		$Variate = new Variate();
		$this->view->variateName = $Variate->getNameByVariateID($variateID);;
		$this->view->variateID = $variateID;

		$VariateRuleset = new VariateRuleset();
		$variateRulesets = $VariateRuleset->generateRulesetsDataByVariateID($variateID);
		$this->view->variateRulesets = $variateRulesets;

		$VariateTranslationRule = new VariateTranslationRule();
		$rulesRow = $VariateTranslationRule->fetchRow($VariateTranslationRule->select()->where('variateID = ?', $variateID));
		$this->view->customRules = $rulesRow['translationRule'];

		$PriceRejectRulesets = new PriceRejectRulesets();
		$this->view->priceRejectRules = $PriceRejectRulesets->generatePriceRejectRulesetsDataByVariateID($variateID);

		$this->view->priceRejectEnabled = $this->config->priceRejectEnabled;
	}

	function deleteAction()
	{
		$variateID = $this->getRequest()->getParam('variateID');
		$response = array();

		if ($variateID) {
			$Variate = new Variate();

			if ($Variate->isVariateInUseByMultipleMultivariates($variateID)) {
				$response['status'] = 'error';
				$response['message'] = 'Static scorecard cannot be deleted. You should delete it from Champion / Challenger Scorecard first';
			} else {
				$deleted = $Variate->safeDelete($variateID);
				if (!$deleted) {
					$response['status'] = 'error';
					$response['message'] = 'Static scorecard cannot be deleted for historical reasons.';
				}
			}
		}

		echo Zend_Json::encode($response);
		$this->_helper->viewRenderer->setnoRender();

	}

	function cancelAction()
	{
		$this->_redirect('/scorecard');
	}

	function saveAction()
	{
		if ($this->_request->isPost()) {

			$edit = $this->getRequest()->getParam('edit');
			$variateID = $this->getRequest()->getParam('variateID');
			$sortable1Order = $this->getRequest()->getParam('sortable1Order');
			$scorecardname = $this->getRequest()->getParam('scorecardname');
			$priceRejectRuleSets = $this->getRequest()->getParam('priceRejectRuleSets');
			$customRules = $this->getRequest()->getParam('customRules');

			$storeIDparam = explode(',', $sortable1Order);
			$Variate = new Variate();
			$VariatesVendorStrategy = new VariatesVendorStrategy();
			$VariateTranslationRule = new VariateTranslationRule();

			$MultiVariate = new MultiVariate();
			if ($edit == "true") {
				$insertData = array('name' => $scorecardname);
				$Variate->updateData($insertData, $variateID);
				$MultiVariate->updateNameByVariateID($insertData, $variateID);

				$where = "variateID=$variateID";
				$VariatesVendorStrategy->delete($where);
				$where = $VariateTranslationRule->getAdapter()->quoteInto('variateID = ?', $variateID);
				$VariateTranslationRule->delete($where);

			} else {
				$dataForSave = array('name' => $scorecardname);
				$variateID = $Variate->insert($dataForSave);

				$MultiVariatesVariate = new MultiVariatesVariate();
				$data = array(
					'name' => $scorecardname,
					'description' => $scorecardname . ' 0-99 - Static Scorecard');
				$multivariateID = $MultiVariate->insert($data);

				$data = array(
					'minPercent' => "0",
					'maxPercent' => "99",
					'multiVariateID' => $multivariateID,
					'variateID' => $variateID
				);

				$MultiVariatesVariate->saveData($data);
			}

			$priority = 1;
			foreach ($storeIDparam AS $strategyID) {
				$dataForSave = array(
					'variateID' => $variateID,
					'vendorStrategyID' => $strategyID,
					'priority' => $priority);
				$VariatesVendorStrategy->insert($dataForSave);
				$priority++;
			}


			$rulesets = Zend_Json::decode($this->getRequest()->getParam('rulesets'));
			$rulesetOperators = Zend_Json::decode($this->getRequest()->getParam('rulesetOperators'));

			$ruleData = Zend_Json::decode($this->getRequest()->getParam('rules'));
			$ruleOperators = Zend_Json::decode($this->getRequest()->getParam('ruleOperators'));

			$ruleIDs = Zend_Json::decode($this->getRequest()->getParam('ruleIDs'));

			$VariateRuleset = new VariateRuleset();
			$VariateRuleset->buildRuleset($rulesets, $variateID, $rulesetOperators, $ruleIDs, $ruleData, $ruleOperators);

			if (isset($customRules) && !empty($customRules))
			{
			    $VariateTranslationRule->insert(array('variateID' => $variateID, 'translationRule' => $customRules));
			}

			$PriceRejectRulesets = new PriceRejectRulesets();
			if (isset($priceRejectRuleSets) && !empty($priceRejectRuleSets)) {
			    if ($edit == "true") {
			        // First delete previous price reject rulesets and then add new
			        $PriceRejectRulesets->deletePriceRejectRuleSetsDataByVariateID($variateID);
			    }
			    $PriceRejectRulesets->buildRuleset($variateID,$priceRejectRuleSets);
			}
			else {
			    $PriceRejectRulesets->deletePriceRejectRuleSetsDataByVariateID($variateID);
			}

		}
		$this->_helper->viewRenderer->setnoRender();
	}

	function newAction()
	{
		$VendorStrategy = new VendorStrategy();
		$vendorStrategies = $VendorStrategy->getAllVendorStrategies();
		$this->view->vendorStrategies = $vendorStrategies;
		$this->view->priceRejectEnabled = $this->config->priceRejectEnabled;
	}

	public function searchAction()
	{
		$this->_helper->viewRenderer->setnoRender();
		$paramName = $this->getRequest()->getParam('query');
		$vendorID = $this->getRequest()->getParam('vendorId');
		$vendorStrategyIDs = $this->getRequest()->getParam('vendorStrategyIDs');
		$VendorResponseParameter = new VendorResponseParameter();
		$data = $VendorResponseParameter->findParameterByVendorStrategyIDsAndByName($vendorStrategyIDs, $paramName);

		$result = array();
		$parameters = array();
		foreach ($data as $v) {
			$result['id'] = $v['id'];
			$result['name'] = $v['name'];
			$result['description'] = $v['description'];
			$parameters[] = $result;
		}

		echo Zend_Json::encode($parameters);
	}
}
?>
