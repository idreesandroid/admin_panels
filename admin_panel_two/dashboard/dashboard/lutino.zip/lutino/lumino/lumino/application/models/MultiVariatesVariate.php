<?php

class MultiVariatesVariate extends Zend_Db_Table
{
	protected $_name = 'MultiVariatesVariates';

	public function init()
	{
		$this->db = Zend_Registry::get('db');
	}

	public function saveData($data)
	{
		$this->insert($data);
	}


	public function getDataByMultivariateID($multivariateID)
	{
		$sql = $this->select()
			->where("multiVariateID = " . $multivariateID)
			->order('id asc');
		return $this->fetchAll($sql);
	}

	public function updateData($insertData, $id)
	{
		$this->update($insertData, $this->_db->quoteInto("id = ?", $id));
		return $id;
	}

	public function getDataByVariateID($variateID)
	{
		$sql = $this->select()
			->where("variateID = " . $variateID)
			->order('id asc');
		return $this->fetchAll($sql);
	}
}
?>
