<?php

class DailyCampaignReports
{
	public function __construct()
	{
		$this->config = Zend_Registry::get('config');
		// for ad-hoc queries
		$this->dbSlave = Zend_Db::factory($this->config->resources->multidb->slave->adapter,
		$this->config->resources->multidb->slave->toArray());
	}

	public function execute() {

	    echo '-- begin report --' . "\n";

	    $originalDateStart = date('Y-m-d');
	    $originalDateEnd = date('Y-m-d');
	    $originalTimeStart = "00:00:00";
	    $originalTimeEnd = "23:59:59";

	    $storeIDs = array();
	    $Factory = new DailyCampaignReportLMSFactory();
	    $CampaignReport	= $Factory->create($this->config->lmsName);
	    $CampaignReport->initSettingsForSlaveDB();

	    echo '-- getting storeIDs --' . "\n";
	    // get all storeIDs
	    foreach ($CampaignReport->getStoreIDs() as $store) {
	        if ($store['storeID']) {
	            $storeIDs[] = "'" . $store['storeID'] . "'";
	        }
	    }
	    $storeIDs = implode(',', $storeIDs);

	    $DailyCampaignReportAttempts = new DailyCampaignReportAttempts();
	    $DailyCampaignReportAttempts->initSettingsForSlaveDB();

	    echo '-- getting new customers campaigns --' . "\n";

	    // Get new customers campaigns
	    $newCustomersCampaings = $DailyCampaignReportAttempts->getLeadsAttemtCampaigns("new",$originalDateStart,$originalDateEnd,
	        $originalTimeStart,$originalTimeEnd);

	    // Csv header
	    $dataCols='"NEW CUSTOMERS","","","","","","","",""';
	    $dataCols.="\n";
	    $dataCols.= '"Campaign","Attempted","Bought","Loans Originated","Total Loans Originated","PurchaseRate","CPF","Total Conversion","ESIG","Redirect"';
	    $dataCols .= "\n";

	    $totalLeads = 0;
	    // NOTE: we are using LeadSold.price value as 'cost'
	    $totalCost = 0;
	    $leadsBought = 0;
	    $leadsOriginated = 0;
	    $totalLeadsOriginated = 0;
	    $totalesigs = 0;
	    $totalRedirects = 0;

	    echo '-- getting new customer campigns data --' . "\n";

	    // Loop over the campaings to get campaign data
	    foreach ($newCustomersCampaings as $campaign) {

	        $data = $CampaignReport->getCampaignReports("new", $campaign['campaign'] ,$originalDateStart, $originalDateEnd,
	            $originalTimeStart, $originalTimeEnd, $storeIDs);

	         foreach ($data as $key => $reportData) {
	            if ($key === "totals") {
	                continue;
	            }
	            // Format csv data
	            $dataCols.=$this->formatData($reportData);
	            // Caculate totals for each campaign
	            $totalLeads += $reportData['leads'];
	            $leadsBought += $reportData['bought'];
	            $leadsOriginated += $reportData['LoansOriginated'];
	            $totalLeadsOriginated+= $reportData['TotalLoansOriginated'];
	            $totalesigs += $reportData['esigs'];
	            $totalCost += $reportData['cost'];
	            $totalRedirects += $reportData['redirects'];
	        }
	    }

	    echo '-- formatting new customers data total row --' . "\n";
	    // Format total row
	    $dataCols.=$this->formatTotalRow($totalLeads, $leadsBought, $leadsOriginated, $totalLeadsOriginated, $totalesigs, $totalCost, $totalRedirects);

	    echo '-- getting returning customers campaigns --' . "\n";

	    // Get returning customers campaigns
	    $returningCustomersCampaings = $DailyCampaignReportAttempts->getLeadsAttemtCampaigns("returning",$originalDateStart,$originalDateEnd,
	        $originalTimeStart,$originalTimeEnd);

	    $totalLeads = 0;
	    // NOTE: we are using LeadSold.price value as 'cost'
	    $totalCost = 0;
	    $leadsBought = 0;
	    $leadsOriginated = 0;
	    $totalLeadsOriginated = 0;
	    $totalesigs = 0;
	    $totalRedirects = 0;

	    echo '-- getting returning customer campigns data --' . "\n";

	    $dataCols.="\n\n";
	    $dataCols.='"RETURNING CUSTOMERS","","","","","","","",""';
	    $dataCols.="\n";

	    // Loop over the campaings to get campaign data
	    foreach ($returningCustomersCampaings as $campaign) {

	        $data = $CampaignReport->getCampaignReports("returning", $campaign['campaign'] ,$originalDateStart, $originalDateEnd,
	            $originalTimeStart, $originalTimeEnd, $storeIDs);

	        foreach ($data as $key => $reportData) {
	            if ($key === "totals") {
	                continue;
	            }
	            // Format csv data
	            $dataCols.=$this->formatData($reportData);
	            // Caculate totals for each campaign
	            $totalLeads += $reportData['leads'];
	            $leadsBought += $reportData['bought'];
	            $leadsOriginated += $reportData['LoansOriginated'];
	            $totalLeadsOriginated+= $reportData['TotalLoansOriginated'];
	            $totalesigs += $reportData['esigs'];
	            $totalCost += $reportData['cost'];
	            $totalRedirects += $reportData['redirects'];
	        }
	    }

	    echo '-- formatting returning customers data total row --' . "\n";
	    // Format total row
	    $dataCols.=$this->formatTotalRow($totalLeads, $leadsBought, $leadsOriginated, $totalLeadsOriginated, $totalesigs, $totalCost, $totalRedirects);

	    //echo '-- about to create csv file..' . "\n";

	    $fileName = "DailyRecap_" . date("m-d-Y") . ".csv";
	    $fileLocation = "/tmp/".$fileName;

	    if (file_put_contents($fileLocation, $dataCols) !== FALSE) {

	        echo '-- csv file created. about to send email..' . "\n";

	        try {
				$DailyCampaignReportsEmailer = new DailyCampaignReportsEmailer();
				$DailyCampaignReportsEmailer->execute($fileName, $fileLocation);
	            unlink($fileLocation);

	        } catch(Exception $e) {

	            echo 'exception:' . $e->getMessage();
	        }
	        echo '-- email sent. DONE' . "\n";
	    }
	}

	public function formatTotalRow($totalLeads,$leadsBought,$leadsOriginated,$totalLeadsOriginated,$totalesigs,$totalCost,$totalRedirects) {

	    // Prepare Total row data
	    $dataCols .= '"Totals",';
	    $dataCols .= '"' . number_format($totalLeads) . '",';
	    $dataCols .= '"' . number_format($leadsBought) . '",';
	    $dataCols .= '"' . number_format($leadsOriginated) . '",';
	    $dataCols .= '"' . number_format($totalLeadsOriginated) . '",';

	    // purchase rate
	    $dataCols .= '"' . round(($leadsBought / $totalLeads) * 100, 2) . '%",';

	    $dataCols .= '"$' . number_format(ReportCalc::costPerOriginated($totalCost, $leadsOriginated), 2) . '",';
	    $dataCols .= '"' . number_format(ReportCalc::percentOriginatedvsBought($leadsOriginated, $leadsBought), 2) . '%",';
	    $dataCols .= '"' . number_format(ReportCalc::esigRate($totalesigs, $leadsBought), 2) . '%",';
	    $dataCols .= '"' . number_format(ReportCalc::redirectsRate($leadsBought, $totalRedirects), 2) . '%"';

	    return $dataCols;

	}

	/* Format data as per csv columns
	 * @param reportData array report data to be formatted
	 * @return string formatted string as per csv cols
	 */
	public function formatData($reportData) {

	    $dataCols = "";

	    $dataCols .= '"' . $reportData['campaign'] . '",';
	    $dataCols .= '"' . number_format($reportData['leads']) . '",';
	    $dataCols .= '"' . number_format($reportData['bought']) . '",';
	    $dataCols .= '"' . number_format($reportData['LoansOriginated']) . '",';
	    $dataCols .= '"' . number_format($reportData['TotalLoansOriginated']) . '",';

	    // purchase rate
	    $dataCols .= '"' . round(($reportData['bought'] / $reportData['leads']) * 100, 2) . '%",';

	    $dataCols .= '"$' . number_format($this->costPerFundedByCampaign($reportData['campaign'],
	        $reportData['bought'], $reportData['cost'], $reportData['LoansOriginated'])) . '",';

	    $dataCols .= '"' . number_format(ReportCalc::percentOriginatedvsBought($reportData['LoansOriginated'], $reportData['bought']), 2) . '%",';

	    $dataCols .= '"' . number_format($reportData['esigRate'], 2) . '%",';
	    $dataCols .= '"' . number_format($reportData['redirectsRate'], 2) . '%"';

	    $dataCols .= "\n";

	    return $dataCols;
	}

	public function costPerFundedByCampaign($campaignID, $bought, $cost, $totalOriginated)
	{
		if ($campaignID == "other") {
			$microbiltCost = 0;
			$ebureauCost = 0;
		} else {
			$microbiltCost = $this->microbiltCostByCampaign($campaignID);
			$ebureauCost = $this->ebureauCostByCampaign($campaignID);
		}
		return round(($cost + $microbiltCost + $ebureauCost) / $totalOriginated, 2);
	}

	/**
	 * this is the sum of all 4 microbilt products
	 */
	public function microbiltCostByCampaign($campaignID)
	{
		$sql = "SELECT pl.campaign,
			SUM(IF(pl.postResponse LIKE '%<IDV>%', 1,0)) AS Fraud,
			SUM(IF(pl.postResponse LIKE '%<PDA>%', 1,0)) AS Credit,
			SUM(IF(pl.postResponse LIKE '%<BANK-INFORMATION>%', 1,0)) AS BAV,
			SUM(IF(pl.postResponse LIKE '%<DDA>%', 1,0)) AS DDA
			FROM PostLogs pl
			WHERE pl.postDate = curdate()
			AND pl.clientID = 4
			AND pl.campaign = " . $campaignID;
		$row = $this->dbSlave->fetchRow($sql);

		$Fraud = $row['Fraud'] * .39;
		$Credit = $row['Credit'] * .5;
		$BAV = $row['BAV'] * .61;
		$DDA = $row['DDA'] * .79;

		$totalCost = $Fraud + $Credit + $BAV + $DDA;

		return $totalCost;
	}

	public function ebureauCostByCampaign($campaignID)
	{
		$sql = "SELECT SUM(pl.cost) as totalCost
			FROM PostLogs pl
			WHERE pl.postDate = curdate()
			AND pl.clientID = 1
			AND pl.campaign = " . $campaignID;
		$row = $this->dbSlave->fetchRow($sql);
		$totalCost = $row['totalCost'];

		return $totalCost;
	}
}
