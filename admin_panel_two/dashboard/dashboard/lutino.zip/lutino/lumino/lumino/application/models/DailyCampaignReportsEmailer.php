<?php
/**
 * sends the daily campaign report in email
 */
class DailyCampaignReportsEmailer
{
	public function __construct()
	{
		$this->config = Zend_Registry::get('config');
	}

	/**
	 * @param string $fileName
	 * @param string $fileLocation
	 * return void
	 */
	public function execute($fileName, $fileLocation)
	{
		$mail= new Mail();
		$mail->setAttachment(file_get_contents($fileLocation));
		$mail->setFileName($fileName);
		$mail->setBody("Daily Campaign report is attached.");
		$mail->setSubject($this->config->daily_campaign_report->email_subject);
		$mail->setToEmail("reports@mediaenvy.com", 'Daily Reports');
		$mail->setToEmail("clyde@lead-envy.com", 'Clyde');
		$mail->send();
	}
}
