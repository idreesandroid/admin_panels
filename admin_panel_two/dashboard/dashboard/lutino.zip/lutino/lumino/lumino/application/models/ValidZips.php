<?php
class ValidZips extends BaseZendDbTable
{
	protected $_name = 'validzips';

	public function getStates()
	{
		$select = $this->select()
			->distinct()
			->from($this,array("state" => "state"))
			->order("state"); 
		$result = $this->fetchAll($select);

		return $result;
	}
}
