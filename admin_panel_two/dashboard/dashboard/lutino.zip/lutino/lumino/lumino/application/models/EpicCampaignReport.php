<?php

class EpicCampaignReport extends CampaignReportAbstract
{
	/**
	 * Gets the campaign report data
	 *
	 * @param		startDate	date	start of date range
	 * @param		endDate		date	end of date range
	 * @param		campaign	string	campaign filter
	 *
	 * @return		array	array of campaign report data
	 */
	public function getCampaignReports($isxml = false, $startDate, $endDate, $originalTimeStart, $originalTimeEnd, $storeIds, $multiVarStart=0, $multiVarEnd=0, $originationDate="", $selectedStrategyID=0, $selectedAffiliate="")
	{
		$EpicCampaignReportDataModel = new EpicCampaignReportDataModel();
		$EpicCampaignReportDataModel->initSettingsForSlaveDB();

		$leadData = $EpicCampaignReportDataModel->getCampaignReportData($startDate, $endDate, $originalTimeStart, $originalTimeEnd, $storeIds, $multiVarStart, $multiVarEnd, $originationDate, $selectedStrategyID, $selectedAffiliate);
		$campaignsWithNotSubIDs = $EpicCampaignReportDataModel->campaignsWithNotSubIDs($startDate, $endDate, $originalTimeStart, $originalTimeEnd);

		$reportData	= $this->calculateValues($leadData);
		$reportData	= $this->addHasSubIdsElement($reportData, $campaignsWithNotSubIDs);

		if ($isxml) {
			$reportData	= $this->totalCalculatedValues($reportData);
		}

		return $reportData;
	}

	public function getSubIdReports($isxml = false, $startDate, $endDate, $originalTimeStart, $originalTimeEnd, $storeIds, $campaign = NULL, $multiVarStart=0, $multiVarEnd=0, $originationDate="", $selectedStrategyID=0)
	{
		$EpicCampaignReportDataModel = new EpicCampaignReportDataModel();
		$EpicCampaignReportDataModel->initSettingsForSlaveDB();

		$leadData = $EpicCampaignReportDataModel->getSubIDReportData($startDate, $endDate, $originalTimeStart, $originalTimeEnd, $storeIds, $campaign, $multiVarStart, $multiVarEnd, $originationDate, $selectedStrategyID);

		$reportData	= $this->calculateValues($leadData);
		if ($isxml) {
			$reportData	= $this->totalCalculatedValues($reportData);
		}

		return $reportData;
	}

	public function getSubId2Reports($isxml = false, $startDate, $endDate, $originalTimeStart, $originalTimeEnd, $storeIds, $campaign = NULL, $multiVarStart=0, $multiVarEnd=0, $originationDate="", $selectedStrategyID=0)
	{
		$EpicCampaignReportDataModel = new EpicCampaignReportDataModel();
		$EpicCampaignReportDataModel->initSettingsForSlaveDB();

		$leadData = $EpicCampaignReportDataModel->getSubID2ReportData($startDate, $endDate, $originalTimeStart, $originalTimeEnd, $storeIds, $campaign, $multiVarStart, $multiVarEnd, $originationDate, $selectedStrategyID);

		$reportData	= $this->calculateValues($leadData);
		if ($isxml) {
			$reportData	= $this->totalCalculatedValues($reportData);
		}

		return $reportData;
	}

	public function getSubId3Reports($isxml = false, $startDate, $endDate, $originalTimeStart, $originalTimeEnd, $storeIds, $campaign = NULL, $multiVarStart=0, $multiVarEnd=0, $originationDate="", $selectedStrategyID=0)
	{
		$EpicCampaignReportDataModel = new EpicCampaignReportDataModel();
		$EpicCampaignReportDataModel->initSettingsForSlaveDB();

		$leadData = $EpicCampaignReportDataModel->getSubID3ReportData($startDate, $endDate, $originalTimeStart, $originalTimeEnd, $storeIds, $campaign, $multiVarStart, $multiVarEnd, $originationDate, $selectedStrategyID);

		$reportData	= $this->calculateValues($leadData);
		if ($isxml) {
			$reportData	= $this->totalCalculatedValues($reportData);
		}

		return $reportData;
	}
}
