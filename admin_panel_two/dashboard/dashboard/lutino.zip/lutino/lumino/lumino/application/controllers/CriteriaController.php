<?php
class CriteriaController extends Zend_Controller_Action
{
	private $baseurl;
	private $allIncomeSources;
	private $allOwnRentTypes;

	public function init()
	{
		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		if(!$AdminNameSpace->userid)
		{
			$this->_redirect('index/login');
		}
		$this->baseurl = $this->_request->getBaseUrl();
		// hard coded values from coming leads.
		$this->allIncomeSources = array('employment','socialsecurity','other','unemployment','retirement','disability');
		$this->allOwnRentTypes = array('own','rent','other');
	}

	public function newAction()
	{
		// select box for postsetups
		$Clients = new PostSetups();
		$this->view->clientSelectBox = $Clients->findByActive();
		$postSetupID = ($this->_request->postsetupid) ? $this->_request->postsetupid : '';

		// state checkboxes
		$States = new ValidZips();
		$this->view->states = $States->getStates();
		// Canadian province checkboxes
		$Postals = new ValidPostals();
		$this->view->provinces = $Postals->getProvinces();
		$this->view->allincomesources = $this->allIncomeSources;
		$this->view->allownrenttypes = $this->allOwnRentTypes;
		$this->view->postsetupid = $postSetupID;

		$this->view->flashMessages = $this->_helper->flashMessenger->getMessages();

        // parameter for fields that should be hidden
        $this->view->isHidden = TRUE;
    }

	public function createAction()
	{
		// save these as comma-separated
		// TODO: create necessary db tables instead of jaywalking
		$payMethod = (count($this->_request->paymethod) > 0) ? implode(',', $this->_request->paymethod) : '';
		$payFrequency = (count($this->_request->payfrequency) > 0) ? implode(',', $this->_request->payfrequency) : '';
		$states = (count($this->_request->states) > 0) ? implode(',', $this->_request->states) : '';
		$provinces = (count($this->_request->provinces) > 0) ? implode(',', $this->_request->provinces) : '';
		$selectedincomesources = (count($this->_request->selectedincomesources) > 0) ? implode(',', $this->_request->selectedincomesources) : '';
		$selectedownrenttypes = (count($this->_request->selectedownrenttypes) > 0) ? implode(',', $this->_request->selectedownrenttypes) : '';


		if (!empty($provinces)) {
			$states = $states . ',' . $provinces;
		}
		$newRow = array('postSetupID' => $this->_request->postsetupid,
			'payMethodBlacklist' => $payMethod,
			'payPeriodBlacklist' => $payFrequency,
			'denyMilitary' => $this->_request->military,
			'ageMin' => $this->_request->agemin,
			'ageMax' => $this->_request->agemax,
			'loanAmountMin' => $this->_request->loanamountmin,
			'loanAmountMax' => $this->_request->loanamountmax,
			'monthlyIncomeMin' => $this->_request->incomeminimum,
			'monthlyIncomeMax' => $this->_request->incomemaximum,
			'incomeSourceBlacklist' => $selectedincomesources,
			'employerBlacklist' => $this->_request->employer,
			'ABABlacklist' => $this->_request->aba,
			'bankInstitutionNumberBlacklist' => $this->_request->bankinstitutionnumber,
			'bankBranchNumberBlacklist' => $this->_request->bankbranchnumber,
			'emailExtBlacklist' => $this->_request->emailext,
			'zipBlacklist' => $this->_request->zip,
			'poboxBlacklist' => $this->_request->pobox,
			'masteraffBlacklist' => $this->_request->masteraff,
			'campaignBlacklist' => $this->_request->campaign,
			'bankAccountMax' => $this->_request->bankaccountmax,
			'dupeDays' => $this->_request->dupedays,
			'stateBlacklist' => $states,
			'residenceMinDays' => $this->_request->residencemindays,
			'ownRentBlacklist' => $selectedownrenttypes,
			'spouseMilitary' => $this->_request->spousemilitary,
			'accountType' => $this->_request->accounttype,
			'isDupeDriversLicenseOk' => $this->_request->isdupedriverslicenseok,
			'newLoanAmountMin' => $this->_request->minamountnewloan,
			'dueDateWkndHolidayOk' => $this->_request->requestedduedate,
			'loanDurationMinDays' => $this->_request->loandurationmindays,
			'prevDeniedApplicationDays' => $this->_request->prevdeniedapplicationdays,
			'timeAtJob' => $this->_request->timeAtJob);

		try
		{
			$CashCriterias = new CashCriteria();
			if (!$CashCriterias->insert($newRow)) {
				$this->_helper->flashMessenger->addMessage(array('errors' => $CashCriterias->displayErrors()));
				return $this->_helper->redirector('new');
			}
		}
		catch(Exception $e)
		{

		    $DataLogger = new DataLogger("BuyerTierCriteria");
		    $DataLogger->logtofile("Exception:".$e->getMessage());
		    $DataLogger->logtofile("Trace String:".$e->getTraceAsString());

			// this postSetupID already exists
			// TODO: fix flash message array structure
			$this->_helper->flashMessenger->addMessage(
				array('errors' => array('This Client already has a Criteria' => 'fail')));

			return $this->_helper->redirector('new');
		}
		$this->_helper->flashMessenger->addMessage(
					array('message' => array('Criteria successfully created' => 'success')));

		return $this->_helper->redirector('index');
	}

	public function editAction()
	{
		// select box for postsetups
		$Clients = new PostSetups();
		$this->view->clientSelectBox = $Clients->findByActive();

		// state checkboxes
		$States = new ValidZips();
		$states = $States->getStates();
		$this->view->states = $states;

		// Canadian province checkboxes
		$Postals = new ValidPostals();
		$provinces = $Postals->getProvinces();
		$this->view->provinces = $provinces;

		$this->view->flashMessages = $this->_helper->flashMessenger->getMessages();

		// get custom settings
		$CashCriterias = new CashCriteria();
		$row = $CashCriterias->findByID($this->_request->id);

		// turn comma-separated values to arrays
		$payMethod = (strlen($row->payMethodBlacklist) > 0) ? explode(',', $row->payMethodBlacklist) :
			array();
		$payFrequency = (strlen($row->payPeriodBlacklist) > 0) ? explode(',', $row->payPeriodBlacklist) :
			array();
		$currentStates = (strlen($row->stateBlacklist) > 0) ? explode(',', $row->stateBlacklist) :
			array();
		// so we can have states and provinces in the same field, and we need to find them and separate
		$curStates = array();
		foreach ($states as $state) {
			if (in_array($state->state, $currentStates)) {
				$curStates[] = $state->state;
			}
		}
		$curProvinces = array();
		foreach ($provinces as $province) {
			if (in_array($province->province, $currentStates)) {
				$curProvinces[] = $province->province;
			}
		}

		$this->view->allincomesources = $this->allIncomeSources;
		$this->view->allownrenttypes = $this->allOwnRentTypes;
		$currentIncomesource = (strlen($row->incomeSourceBlacklist) > 0) ? explode(',', $row->incomeSourceBlacklist) :
			array();

		$currentOwnRentType = (strlen($row->ownRentBlacklist) > 0) ? explode(',', $row->ownRentBlacklist) :
			array();

		// populate form fields
		$this->view->id = $this->_request->id;
		$this->view->currentPostSetupID = $row->postSetupID;
		$this->view->paymethod = $payMethod;
		$this->view->payfrequency = $payFrequency;
		$this->view->military = $row->denyMilitary;
		$this->view->agemin = $row->ageMin;
		$this->view->agemax = $row->ageMax;
		$this->view->loanamountmin = $row->loanAmountMin;
		$this->view->loanamountmax = $row->loanAmountMax;
		$this->view->incomeminimum = $row->monthlyIncomeMin;
		$this->view->incomemaximum = $row->monthlyIncomeMax;
		$this->view->aba = $row->ABABlacklist;
		$this->view->bankinstitutionnumber = $row->bankInstitutionNumberBlacklist;
		$this->view->bankbranchnumber = $row->bankBranchNumberBlacklist;
		$this->view->employer = $row->employerBlacklist;
		$this->view->currentincomesource = $currentIncomesource;
		$this->view->currentownrenttype = $currentOwnRentType;
		$this->view->emailext = $row->emailExtBlacklist;
		$this->view->zip = $row->zipBlacklist;
		$this->view->pobox = $row->poboxBlacklist;
		$this->view->masteraff = $row->masteraffBlacklist;
		$this->view->campaign = $row->campaignBlacklist;
		$this->view->bankaccountmax = $row->bankAccountMax;
		$this->view->dupedays = $row->dupeDays;
		$this->view->currentStates = $curStates;
		$this->view->currentProvinces = $curProvinces;
		$this->view->residencemindays = $row->residenceMinDays;
		$this->view->spousemilitary = $row->spouseMilitary;
		$this->view->accounttype = $row->accountType;
		$this->view->isdupedriverslicenseok = $row->isDupeDriversLicenseOk;
		$this->view->minamountnewloan = $row->newLoanAmountMin;
		$this->view->requestedduedate = $row->dueDateWkndHolidayOk;
		$this->view->loandurationmindays = $row->loanDurationMinDays;
		$this->view->prevdeniedapplicationdays = $row->prevDeniedApplicationDays;
		$this->view->timeAtJob = $row->timeAtJob;

        // parameter for fields that should be hidden
        $this->view->isHidden = TRUE;
	}

	public function updateAction()
	{
		// save these as comma-separated
		// TODO: create necessary db tables instead of jaywalking
		$payMethod = (count($this->_request->paymethod) > 0) ? implode(',', $this->_request->paymethod) : '';
		$payFrequency = (count($this->_request->payfrequency) > 0) ? implode(',', $this->_request->payfrequency) : '';
		$states = (count($this->_request->states) > 0) ? implode(',', $this->_request->states) : '';
		$provinces = (count($this->_request->provinces) > 0) ? implode(',', $this->_request->provinces) : '';
		if (!empty($provinces)) {
			$states = $states . ',' . $provinces;
		}
		$selectedincomesources = (count($this->_request->selectedincomesources) > 0) ? implode(',', $this->_request->selectedincomesources) : '';
		$selectedownrenttypes = (count($this->_request->selectedownrenttypes) > 0) ? implode(',', $this->_request->selectedownrenttypes) : '';

		$data = array('postSetupID' => $this->_request->postsetupid,
			'payMethodBlacklist' => $payMethod,
			'payPeriodBlacklist' => $payFrequency,
			'denyMilitary' => $this->_request->military,
			'ageMin' => $this->_request->agemin,
			'ageMax' => $this->_request->agemax,
			'loanAmountMin' => $this->_request->loanamountmin,
			'loanAmountMax' => $this->_request->loanamountmax,
			'monthlyIncomeMin' => $this->_request->incomeminimum,
			'monthlyIncomeMax' => $this->_request->incomemaximum,
			'incomeSourceBlacklist' => $selectedincomesources,
			'employerBlacklist' => $this->_request->employer,
			'ABABlacklist' => $this->_request->aba,
			'bankInstitutionNumberBlacklist' => $this->_request->bankinstitutionnumber,
			'bankBranchNumberBlacklist' => $this->_request->bankbranchnumber,
			'emailExtBlacklist' => $this->_request->emailext,
			'zipBlacklist' => $this->_request->zip,
			'poboxBlacklist' => $this->_request->pobox,
			'masteraffBlacklist' => $this->_request->masteraff,
			'campaignBlacklist' => $this->_request->campaign,
			'bankAccountMax' => $this->_request->bankaccountmax,
			'dupeDays' => $this->_request->dupedays,
			'stateBlacklist' => $states,
			'residenceMinDays' => $this->_request->residencemindays,
			'ownRentBlacklist' => $selectedownrenttypes,
			'spouseMilitary' => $this->_request->spousemilitary,
			'accountType' => $this->_request->accounttype,
			'isDupeDriversLicenseOk' => $this->_request->isdupedriverslicenseok,
			'newLoanAmountMin' => $this->_request->minamountnewloan,
			'dueDateWkndHolidayOk' => $this->_request->requestedduedate,
			'loanDurationMinDays' => $this->_request->loandurationmindays,
			'prevDeniedApplicationDays' => $this->_request->prevdeniedapplicationdays,
			'timeAtJob' => $this->_request->timeAtJob);

		try
		{
			$CashCriterias = new CashCriteria();
			if (!$CashCriterias->update($data, "id = " . $this->_request->id)) {
				$this->_helper->flashMessenger->addMessage(array('errors' => $CashCriterias->displayErrors()));
			} else {
				// TODO: fix flash message array structure
				$this->_helper->flashMessenger->addMessage(
					array('message' => array('Criteria successfully updated' => 'success')));
			}
		}
		catch(Exception $e)
		{
			// TODO: fix flash message array structure
			$this->_helper->flashMessenger->addMessage(
				array('errors' => array('Oops. Update failed. Did you try and change the client?' => 'fail')));
		}
		return $this->_helper->redirector('edit', 'criteria', NULL, array('id' => $this->_request->id));
	}

	public function indexAction()
	{
		$Criteria = new ClientCashCriteria();
		$criterias = $Criteria->all();

		$PostSetups = new PostSetups();

		foreach ($criterias as $k => $v) {
			$result = $PostSetups->getClientPostSetupByID($v["postSetupID"]);
			$criterias[$k]["title"] = $result["title"];

			if ($result['clientActive'] != "1") {
				unset($criterias[$k]);
			}
		}

		$this->view->baseurl = $this->baseurl;
		$this->view->criterias = $criterias;
	}

	function deleteAction()
	{
		$id= $_GET['id'];
		$where = "cashcriteriaid='$id'";
		Zend_Loader::loadClass('Clientcriteria');
		$cc  = new Clientcriteria();
		$cc->delete($where);

		$this->_redirect('criteria/view');
	}

	public function showAction()
	{
		// get custom settings
		$CashCriterias = new CashCriteria();
		$row = array();
		$row = $CashCriterias->findByPostSetupID($this->_request->postSetupID);
		if ($row != null) {
			$row = $row->toArray();
		}
		if ($this->_request->format == 'json') {
			$this->_helper->viewRenderer->setNoRender();
			$results = Zend_Json::encode($row);
			echo $results;
		}
		// TODO: remove this die if/when we use the show view
		die;
	}
}
?>
