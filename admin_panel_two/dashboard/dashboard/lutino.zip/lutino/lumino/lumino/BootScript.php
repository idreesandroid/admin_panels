<?php
// Define path to application directory
chdir(__DIR__);
defined('APPLICATION_PATH')
  || define('APPLICATION_PATH', realpath(dirname(__FILE__)) . '/application');

// Define application environment
if(isset($_SERVER['APPLICATION_ENV']))
  define('APPLICATION_ENV', $_SERVER['APPLICATION_ENV']);
else
  define('APPLICATION_ENV', 'development');

ini_set('include_path', ini_get('include_path').":/software/ZendFramework/ZendFramework/library");
error_reporting(E_ALL);
date_default_timezone_set('America/New_York');


set_include_path('.' . PATH_SEPARATOR . './library'. PATH_SEPARATOR . './library/clients'. PATH_SEPARATOR . './application/models/'. PATH_SEPARATOR . './library/vendors/' . PATH_SEPARATOR . get_include_path());

require_once 'Zend/Loader/Autoloader.php';
$autoloader = Zend_Loader_Autoloader::getInstance();
$autoloader->setFallbackAutoloader(true);

$registry = Zend_Registry::getInstance();
$registry->set('autoloader', $autoloader);

/***** load  database configuration  ******/
$config = new Zend_Config_Ini('./application/configs/cron_afterhours.ini', APPLICATION_ENV);
$registry = Zend_Registry::getInstance();
$registry->set('config', $config);

/***** setup databse  ******/
$db = Zend_Db::factory($config->db->adapter, $config->db->config->toArray());
Zend_Db_Table::setDefaultAdapter($db);
Zend_Registry::set('db', $db);

?>
