<?php
/** the base application include **/
require_once 'application/base.php';

$application->bootstrap()->run();

