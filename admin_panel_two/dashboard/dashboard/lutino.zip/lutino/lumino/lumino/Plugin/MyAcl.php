<?php

class Plugin_MyAcl extends Zend_Controller_Plugin_Abstract
{
	public function preDispatch(Zend_Controller_Request_Abstract $request)
	{
		$config = Zend_Registry::get('config');

		$AdminNameSpace = new Zend_Session_Namespace('AdminUser');
		$userLoggedIn = $AdminNameSpace->username;
		$UserSession = new Zend_Session_Namespace('UserSession');

		if ($UserSession->role == 'affiliate') {

			if ($request->getControllerName() != "lead-purchased-reports" AND $request->getControllerName() != "main" AND $request->getControllerName() != "index")
			{
				$redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('redirector');
				$redirector->gotoSimple('index', 'main');
			}
		}
		else if ($UserSession->role == 'csr') {

		    if($request->getControllerName() != "index" && $request->getActionName() != 'logout') {
		        if (($request->getControllerName() != "veritec")) {
		            $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('redirector');
		            $redirector->gotoSimple('index', 'veritec');
		        }
		    }
		}
	}
}
