/**
 * After an user clicked button "campaign download excel" we should get all data and send it as parameters
 * to the server
 */
JQ('#campaign-download-excel').live('click', 'a', function(e) {
	var campaignID = JQ('#campaignID').val(); //
	var multiVarStart = JQ('#multiVarStart').val();
	var multiVarEnd = JQ('#multiVarEnd').val();
	var originationDate = JQ('#originationDateForSubmit').val();
	var originalDateStart = JQ('#originalDateStart').val(); //
	var originalTimeStart = JQ('#originalTimeStart').val(); //
	var originalDateEnd = JQ('#originalDateEnd').val(); //
	var originalTimeEnd = JQ('#originalTimeEnd').val(); //
	var selectedAffiliate = JQ('#affiliate-filter').val();

	var selectedStrategy = JQ('#selectedStrategy').val();

	var storeIDparams="&selectedStoreIDs=";
	for (i = 0; i < storeIDs.length; i++) {
		if (JQ("[id='"+storeIDs[i]+"']").is(':checked')) {
			if (i==0) {
				storeIDparams = storeIDparams+storeIDs[i];
			} else {
				storeIDparams = storeIDparams+','+storeIDs[i];
			}
		}
	}

	JQ(this).attr('href', 'campaignreportexcel?selectedAffiliate='+selectedAffiliate+'&campaignID=' + campaignID + '&originalDateEnd=' + originalDateEnd + '&originalDateStart=' + originalDateStart + '&originalTimeStart=' + originalTimeStart + '&originalTimeEnd=' + originalTimeEnd + '&multiVarStart=' + multiVarStart + '&multiVarEnd=' + multiVarEnd + '&originationDate=' + originationDate + storeIDparams + '&selectedStrategy=' + selectedStrategy);
});

JQ('#subid-download-excel').live('click', 'a', function(e) {
	var campaignID = JQ('input[id=campaignID]').val(); //
	var multiVarStart = JQ('#multiVarStart').val();
	var multiVarEnd = JQ('#multiVarEnd').val();
	var originationDate = JQ('#originationDateForSubmit').val();
	var originalDateStart = JQ('#originalDateStart').val(); //
	var originalTimeStart = JQ('#originalTimeStart').val(); //
	var originalDateEnd = JQ('#originalDateEnd').val(); //
	var originalTimeEnd = JQ('#originalTimeEnd').val(); //
	var selectedStrategy = JQ('#selectedStrategy').val();

	var storeIDparams="&selectedStoreIDs=";
	for (i = 0; i < storeIDs.length; i++) {
		if (JQ("[id='"+storeIDs[i]+"']").is(':checked')) {
			if (i==0) {
				storeIDparams = storeIDparams+storeIDs[i];
			} else {
				storeIDparams = storeIDparams+','+storeIDs[i];
			}
		}
	}

	JQ(this).attr('href', 'subidreportexcel?campaignID=' + campaignID + '&originalDateEnd=' + originalDateEnd + '&originalDateStart=' + originalDateStart + '&originalTimeStart=' + originalTimeStart + '&originalTimeEnd=' + originalTimeEnd + '&multiVarStart=' + multiVarStart + '&multiVarEnd=' + multiVarEnd + '&originationDate=' + originationDate + storeIDparams + '&selectedStrategy=' + selectedStrategy);
});

JQ('#subid2-download-excel').live('click', 'a', function(e) {
	var campaignID = JQ('input[id=campaignID]').val(); //
	var multiVarStart = JQ('#multiVarStart').val();
	var multiVarEnd = JQ('#multiVarEnd').val();
	var originationDate = JQ('#originationDateForSubmit').val();
	var originalDateStart = JQ('#originalDateStart').val(); //
	var originalTimeStart = JQ('#originalTimeStart').val(); //
	var originalDateEnd = JQ('#originalDateEnd').val(); //
	var originalTimeEnd = JQ('#originalTimeEnd').val(); //
	var selectedStrategy = JQ('#selectedStrategy').val();

	var storeIDparams="&selectedStoreIDs=";
	for (i = 0; i < storeIDs.length; i++) {
		if (JQ("[id='"+storeIDs[i]+"']").is(':checked')) {
			if (i==0) {
				storeIDparams = storeIDparams+storeIDs[i];
			} else {
				storeIDparams = storeIDparams+','+storeIDs[i];
			}
		}
	}

	JQ(this).attr('href', 'subid2reportexcel?campaignID=' + campaignID + '&originalDateEnd=' + originalDateEnd + '&originalDateStart=' + originalDateStart + '&originalTimeStart=' + originalTimeStart + '&originalTimeEnd=' + originalTimeEnd + '&multiVarStart=' + multiVarStart + '&multiVarEnd=' + multiVarEnd + '&originationDate=' + originationDate + storeIDparams + '&selectedStrategy=' + selectedStrategy);
});

JQ('#subid3-download-excel').live('click', 'a', function(e) {
	var campaignID = JQ('input[id=campaignID]').val(); //
	var multiVarStart = JQ('#multiVarStart').val();
	var multiVarEnd = JQ('#multiVarEnd').val();
	var originationDate = JQ('#originationDateForSubmit').val();
	var originalDateStart = JQ('#originalDateStart').val(); //
	var originalTimeStart = JQ('#originalTimeStart').val(); //
	var originalDateEnd = JQ('#originalDateEnd').val(); //
	var originalTimeEnd = JQ('#originalTimeEnd').val(); //
	var selectedStrategy = JQ('#selectedStrategy').val();

	var storeIDparams="&selectedStoreIDs=";
	for (i = 0; i < storeIDs.length; i++) {
		if (JQ("[id='"+storeIDs[i]+"']").is(':checked')) {
			if (i==0) {
				storeIDparams = storeIDparams+storeIDs[i];
			} else {
				storeIDparams = storeIDparams+','+storeIDs[i];
			}
		}
	}

	JQ(this).attr('href', 'subid3reportexcel?campaignID=' + campaignID + '&originalDateEnd=' + originalDateEnd + '&originalDateStart=' + originalDateStart + '&originalTimeStart=' + originalTimeStart + '&originalTimeEnd=' + originalTimeEnd + '&multiVarStart=' + multiVarStart + '&multiVarEnd=' + multiVarEnd + '&originationDate=' + originationDate + storeIDparams + '&selectedStrategy=' + selectedStrategy);
});
