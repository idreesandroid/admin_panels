/**
 * Create table for subid report
 */
function drawSubIdReportTable(subidtype)
{
	var subidtableID = '';
	if (subidtype == 'subID') {
		subidtableID = 'subidtable';
	} else if (subidtype == 'subID2') {
		subidtableID = 'subidtable2';
	} else if (subidtype == 'subID3') {
		subidtableID = 'subidtable3';
	}

	return JQ("#"+subidtableID).dataTable({
		"bJQueryUI": true,
		"bProcessing": true,
		"bServerSide": false,
		"sAjaxSource": "subiddata",
		"iDisplayLength":50,
		"bAutoWidth": false,
		"oLanguage": {
			"sProcessing": ""
		},
		"fnDrawCallback" : function() {
			JQ.unblockUI();
		},

		/**
		 * Footer callback is always invokes after the table redraw
		 * @param nRow - "TR" element for the footer
		 * @param aaData - Full table data (as derived from the original HTML).
		 * @param iStart - Index for the current display starting point in the display array
		 * @param iEnd  - Index for the current display ending point in the display array
		 * @param aiDisplay - Index array to translate the visual position to the full data array
		 */
		"fnFooterCallback": function ( nRow, aaData, iStart, iEnd, aiDisplay ) {
			var attempted = 0;
			var bought = 0;
			var cost = 0;
			var originated = 0;
			var totaloriginated = 0;
			var cpf;
			var perTotalOrigBought;
			var perCurrentOrigBought;
			var perBoughtAttempted;
			var esigs = 0;
			var FPD = 0;
			var redirects = 0;

			/**
			 * Calculate result for the total row
			 */
			for (var i = 0; i < aaData.length; i++) {
				attempted += aaData[i][2] * 1;
				bought += aaData[i][3] * 1;
				var costVar = (aaData[i][4]).substring(1);
				cost += costVar * 1;
				originated += aaData[i][5] * 1;
				totaloriginated += aaData[i][6] * 1;
				perBoughtAttempted = aaData[i][10].replace('%', '') * 1;
				esigs += aaData[i][11] * 1;
				FPD += aaData[i][13] * 1;
				redirects += aaData[i][15] * 1;
			}

			/**
			// Modify the footer row to match what we want
			 * also we are doing different calculations here
			 */
			var nCells = nRow.getElementsByTagName('th');

			cpf = (totaloriginated > 0 && cost > 0) ? (parseInt(cost) / parseInt(totaloriginated)) : 0;

			perCurrentOrigBought = (originated > 0 && bought > 0) ? (100 * (parseInt(originated)) / parseInt(bought)) : 0;
			perTotalOrigBought = (totaloriginated > 0 && bought > 0) ? (100 * (parseInt(totaloriginated)) / parseInt(bought)) : 0;

			perBoughtAttempted = (bought > 0 && attempted > 0) ? (100 * (parseInt(bought)) / parseInt(attempted)) : 0;
			esigRate = (esigs > 0 && bought > 0) ? (100 * (parseInt(esigs)) / parseInt(bought)) : 0;
			FPDrate = (FPD > 0 && totaloriginated > 0) ? (100 * (parseInt(FPD) / parseInt(totaloriginated))) : 0;
			redirectsRate = (redirects > 0 && bought > 0) ? (100 * (parseInt(redirects)) / parseInt(bought)) : 0;

			nCells[ATTEMPTS_INDEX_SUBID].innerHTML = parseInt(attempted );
			nCells[LEADS_BOUGHT_INDEX_SUBID].innerHTML = parseInt(bought );
			nCells[TOTAL_COST_INDEX_SUBID].innerHTML = "$" + parseInt(cost );
			nCells[LOANS_ORIGINATED_INDEX_SUBID].innerHTML = parseInt(originated );
			nCells[TOTAL_LOANS_ORIGINATED_INDEX_SUBID].innerHTML = parseInt(totaloriginated );
			nCells[CPF_INDEX_SUBID].innerHTML = "$" + parseFloat(cpf).toFixed(2);
			nCells[CONVERSION_RATE_CURRENT_DATE_INDEX_SUBID].innerHTML = parseFloat(perCurrentOrigBought).toFixed(2) + "%";
			nCells[CONVERSION_RATE_TOTAL_INDEX_SUBID].innerHTML = parseFloat(perTotalOrigBought).toFixed(2) + "%";
			nCells[PURCHASE_RATE_INDEX_SUBID].innerHTML = parseFloat(perBoughtAttempted).toFixed(2) + "%";
			nCells[ESIG_INDEX_SUBID].innerHTML = parseInt(esigs);
			nCells[ESIG_RATE_INDEX_SUBID].innerHTML = parseFloat(esigRate).toFixed(2) + "%";
			nCells[FPD_INDEX_SUBID].innerHTML = parseInt(FPD);
			nCells[FPD_RATE_INDEX_SUBID].innerHTML = FPDrate.toFixed(2) + "%";
			nCells[REDIRECTS_INDEX_SUBID].innerHTML = parseInt(redirects);
			nCells[REDIRECTS_RATE_INDEX_SUBID].innerHTML = redirectsRate.toFixed(2) + "%";
		},

		/**
		 * we can set some parameters here for columns (name, width, type of column etc.)
		 */
		"aoColumns":[
			{ "sName": "subid", "sWidth": "5%" },
			{ "sName": "cpl", "sWidth": "5%" },
			{ "sName": "leads", "sWidth": "5%" },
			{ "sName": "bought", "sWidth": "5%" },
			{ "sName": "cost", "sType":"currency", "sWidth": "5%" },
			{ "sName": "originated", "sWidth": "5%" },
			{ "sName": "totaloriginated", "sWidth": "5%"},
			{ "sName": "cpf", "sType":"currency", "sWidth": "5%" },
			{ "sName": "pertodayorigbought", "sType":"currency", "sWidth": "5%" },
			{ "sName": "pertotalorigbought", "sType":"currency", "sWidth": "5%" },
			{ "sName": "perboughtattempted", "sType":"currency", "sWidth": "5%"},
			{ "sName": "esigs", "sWidth": "5%"},
			{ "sName": "esigrate", "sType":"currency", "sWidth": "5%"},
			{ "sName": "fpd", "sWidth": "5%" },
			{ "sName": "fpdrate", "sType":"currency", "sWidth": "5%"},
			{ "sName": "redirects", "sWidth": "5%" },
			{ "sName": "redirectsRate", "sType":"currency", "sWidth": "5%"}
		],

		/**
		 * This parameter allows you to override the default function which obtains the data
		 * from the server (for ex. json)
		 * @param sSource   -  HTTP source to obtain the data from (sAjaxSource)
		 * @param aoData    - A key/value pair object containing the data to send to the server
		 * @param fnCallback - data on the page
		 * @param oSettings - DataTables settings object
		 */
		"fnServerData": function (sSource, aoData, fnCallback, oSettings) {
			oSettings.jqXHR = JQ.ajax({
				"dataType": 'json',
				"type": "POST",
				"url": sSource,
				"data": aoData,
				beforeSend : function(xhr, opts){
					JQ.blockUI({
						message: 'Processing...',
						css: {
							border: 'none',
							padding: '15px',
							'font-size': '28px',
							backgroundColor: '#000',
							'-webkit-border-radius': '10px',
							'-moz-border-radius': '10px',
							opacity: .5,
							color: '#fff'
						} });
				},
				"success": fnCallback
			});
		},

		/**
		 * It is often useful to send extra data to the server when making an Ajax request -
		 * for example custom filtering information, and this callback function makes it trivial
		 * to send extra information to the server.
		 * @param aoData -  A key/value pair object containing the data to send to the server
		 */
		fnServerParams: function (aoData) {
			TblServerParams(aoData);
			aoData.push( { "name": "subidtype", "value": subidtype } );
		}
	});
}