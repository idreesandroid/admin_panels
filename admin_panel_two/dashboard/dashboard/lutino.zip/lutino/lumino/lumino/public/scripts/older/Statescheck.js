// JavaScript Document
function checkall()
{
	var len = document.frm.elements.length;
	var i=0;
	for( i=0 ; i<len ; i++) 
	{
		if (document.frm.elements[i].name=='states[]') 
		{
			document.frm.elements[i].checked=true;
		}
	}	
}

function uncheckall()
{
	var len = document.frm.elements.length;
	var i=0;
	for( i=0 ; i<len ; i++) 
	{
		if (document.frm.elements[i].name=='states[]') 
		{
			document.frm.elements[i].checked=false;
		}
	}	
}