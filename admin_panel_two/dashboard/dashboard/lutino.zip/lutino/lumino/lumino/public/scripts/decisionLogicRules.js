var iDecisionLogicRuleCounter = 0;
var vendorResponseParams;

$(document).ready(function () {

	$.fn.editable.defaults.mode = 'popup';

	function getSource() {
        var url = $("#baseurl").val();
        return $.ajax({
            type:  'GET',
            async: true,
            url:   url,
            dataType: "json"
        });
    }
	getSource().done(function(result) {
		vendorResponseParams = result;
		initEditableElements();
    });

	// Triggered when add new ruleset is clicked
	$("body").on("click", "#addDecisionLogicRuleset", function (event) {

		iDecisionLogicRuleCounter++;
		$('<div/>', {
			'id': 'set' + iDecisionLogicRuleCounter,
			'class': 'DecisionLogicExtraRuleset',
			html: buildDecisionLogicRulesetHtml()
		}).hide().appendTo('#decisionLogicRulesSpawnArea').slideDown('fast');

		refreshDecisionLogicRuleSetPriority();
	});
});

function rulesetContainsRules() {
	var validation = true;

	$("#decisionLogicRulesSpawnArea").find(".DecisionLogicExtraRuleset").each(function (index, elem) {
		if($(this).find('.ruleSpawnArea').find('.extraRuleDecisionLogic').length == 0) {
			validation = false;
		}
	});
	return validation;
}

function getDecisionLogicRuleSetsCount() {
	return $("#decisionLogicRulesSpawnArea").find(".DecisionLogicExtraRuleset").length;
}

//Function to get JS object size
Object.size = function(obj) {
    var size = 0, key;
    for (key in obj) {
        if (obj.hasOwnProperty(key)) size++;
    }
    return size;
};

function getDecisionLogicRuleSetsData() {

	var tuple = [];

	$("#decisionLogicRulesSpawnArea").find(".DecisionLogicExtraRuleset").each(function (index, elem) {

		var decisionLogicRuleSetData = {};
		var rulesVendorParams = [];
		var rulesVendorParamsOperator = [];
		var rulesVendorParamsValues = [];
		var rulesOperators = [];

		var value = $(this).find(".dlrulesetname").val();
		decisionLogicRuleSetData.ruleSetName = value;

		var value = $(this).find(".dlrulesetstoreid").val();
		decisionLogicRuleSetData.ruleSetStoreID = value;

		var value = $(this).find(".dlrulesetpriority").val();
		decisionLogicRuleSetData.ruleSetPriority = value;

		$(this).find(".decisionLogicRuleOperator").each(function (index, elem) {
			var value = $(this).editable('getValue', true);
			rulesOperators.push(value);
		});
		decisionLogicRuleSetData.ruleOperators = rulesOperators;

		$(this).find('.ruleSpawnArea').find('.extraRuleDecisionLogic').each(function (index, elem) {

			$(this).find('.dlogicresponseparam').each(function (index, elem) {
				var value = $(this).editable('getValue', true);
				rulesVendorParams.push(value);
			});

			decisionLogicRuleSetData.rulesVendorParams = rulesVendorParams;

			$(this).find('.operators').each(function (index, elem) {
				var value = $(this).editable('getValue', true);
				rulesVendorParamsOperator.push(value);
			});
			decisionLogicRuleSetData.rulesVendorParamsOperator = rulesVendorParamsOperator;

			$(this).find('.paramValue').each(function (index, elem) {
				var value = $(this).editable('getValue', true);
				rulesVendorParamsValues.push(value);
			});
			decisionLogicRuleSetData.rulesVendorParamsValues = rulesVendorParamsValues;
		});
		// Push all values to array
		if (Object.size(decisionLogicRuleSetData) > 0) {
			decisionLogicRuleSetData.strategyName = $("#dlstrategyname").val();
			tuple.push(decisionLogicRuleSetData);
		}
	});

	return tuple;
}

function validateDecisionLogicRules() {

	var validation = true;
	var elementsCount = $("#decisionLogicRulesSpawnArea").find(".DecisionLogicExtraRuleset").length;

	if (elementsCount > 0) {

		if($("#dlstrategyname").val() == "") {
			validation = false;
		}

		$("#decisionLogicRulesSpawnArea").find(".DecisionLogicExtraRuleset").find(".dlrulesetname").each(function (index, elem) {
			if($(this).val() == "") {
				validation = false;
			}
		});

		$("#decisionLogicRulesSpawnArea").find(".DecisionLogicExtraRuleset").find(".dlrulesetstoreid").each(function (index, elem) {
			if($(this).val() == "") {
				validation = false;
			}
		});

		$("#decisionLogicRulesSpawnArea").find(".DecisionLogicExtraRuleset").find(".dlrulesetpriority").each(function (index, elem) {
			if($(this).val() == "") {
				validation = false;
			}
		});

		$("#decisionLogicRulesSpawnArea").find(".DecisionLogicExtraRuleset").find(".dlogicresponseparam").each(function (index, elem) {
			var value = $(this).editable('getValue',true);
			if(value == null) {
				validation = false;
			}
		});

		$("#decisionLogicRulesSpawnArea").find(".DecisionLogicExtraRuleset").find(".operators").each(function (index, elem) {
			var value = $(this).editable('getValue',true);
			if(value == null) {
				validation = false;
			}
		});

		$("#decisionLogicRulesSpawnArea").find(".DecisionLogicExtraRuleset").find(".paramValue").each(function (index, elem) {
			var value = $(this).editable('getValue',true);
			if(value == "") {
				validation = false;
			}
		});

		$("#decisionLogicRulesSpawnArea").find(".DecisionLogicExtraRuleset").find(".decisionLogicRuleOperator").each(function (index, elem) {
			var value = $(this).editable('getValue',true);
			if(value == null) {
				validation = false;
			}
		});
	}
	return validation;
}

function buildDecisionLogicRulesetHtml() {
	var $html = $('.decisionLogicRuleSetTemplate').clone();
	return $html.html();
}

function buildDecisionLogicRuleHtml() {
	var $html = $('.decisionLogicRuleTemplate').clone();
	return $html.html();
}

function refreshDecisionLogicRulePriority(element) {
	var counter = 1;
	element.find('.extraRuleDecisionLogic').each(function () {
		$(this).find('.rulePriority').html('[' + counter + ']');
		counter++;
	});
}

function initEditableElements() {

	$('.operators').editable({
		type: 'select',
		send: 'auto',
		emptytext: 'comparison',
		source: [
			{value: 1, text: 'equals'},
			{value: 2, text: 'is greater than'},
			{value: 3, text: 'is greater than or equal to'},
			{value: 4, text: 'is less than'},
			{value: 5, text: 'is less than or equal to'},
			{value: 6, text: 'like'},
			{value: 9, text: 'not equals'}
		],
	});

	$('.paramValue').editable({
		value:''
	});

	$('.decisionLogicRuleOperator').editable({
		send: 'auto',
		type: 'select',
		emptytext: 'Select operator',
		source: [
			{value: 1, text: 'AND'},
			{value: 2, text: 'OR'}
		]
	});

	$('.dlogicresponseparam').editable({
		type: 'select',
		send: 'auto',
		emptytext: 'comparison',
		source: vendorResponseParams,
	});
}

function refreshDecisionLogicRuleSetPriority() {

	var counter = 1;
	// Reset rule priorities by starting from one
	$('.DecisionLogicExtraRuleset').each(function () {
		$(this).find('.decisionLogicRuleSetPriority').html('[' + counter + ']');
		counter++;
	});
}

//Triggered when delete ruleset is clicked
$("body").on("click", ".decisionLogicRemoveRuleSet", function (e) { //user click on remove text

	e.preventDefault();
	if (confirm('Are you sure?')) {
		var parent = $(this).parents().closest('.DecisionLogicExtraRuleset');
		parent.remove();
		refreshDecisionLogicRuleSetPriority();
	}
});

//Triggered when delete rule is clicked
$("body").on("click", ".decisionLogicRemoveRule", function (e) { //user click on remove text

	e.preventDefault();
	if (confirm('Are you sure?')) {

		var parent = $(this).parents().closest('.DecisionLogicExtraRuleset');

		if ($(this).closest('div').parent().parent().parent().parent().next().find('.decisionLogicRuleOperator').length == 1) {
			$(this).closest('div').parent().parent().parent().parent().next().find('.decisionLogicRuleOperator').remove();
		}
		else {
			$(this).closest('div').parent().parent().parent().parent().prev().remove();
		}

		$(this).parent().parent().parent().parent().parent().remove();
		refreshDecisionLogicRulePriority(parent);
	}
});

//Triggered when new rule inside ruleset is added
$("body").on("click", "#decisionLogicaddRule", function (event) {

	iDecisionLogicRuleCounter++;
	var number = $(this).parent().parent().parent().find("div.ruleSpawnArea").find(".extraRuleDecisionLogic").length + 1;
	// Add rule operator if we have more than 1 rules
	if (number > 1) {
		$('<div/>', {
			'class': 'col-lg-12',
			'html' : '<div class="row"><div class="col-lg-12"><a style="color:black" class="decisionLogicRuleOperator" href="#">select operator</a></div></div>'
		}).hide().appendTo($(this).parent().parent().parent().find("div.ruleSpawnArea")).slideDown('fast');
	}

	// build price reject rule html
	$('<div/>', {
		'id': 'rule' + iDecisionLogicRuleCounter,
		'class': 'extraRuleDecisionLogic',
		html: buildDecisionLogicRuleHtml()
	}).hide().appendTo($(this).parent().parent().parent().find("div.ruleSpawnArea")).slideDown('fast');

	refreshDecisionLogicRulePriority($(this).parents('.DecisionLogicExtraRuleset'));
	initEditableElements();
});