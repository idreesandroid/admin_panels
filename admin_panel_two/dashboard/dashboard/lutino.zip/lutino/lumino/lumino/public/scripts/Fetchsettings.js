function copysetup(id)
{

	var bu = $('#baseurl').val();
	var url=bu+"/copysettings/copypostsetup";
	var params = {'id':id};
	$.getJSON(url, params, function(data, textStatus){

	if(data.postsetup.active==1){
	document.getElementById("status").selectedIndex = 0;
	}
	else
	{
	document.getElementById("status").selectedIndex = 1;
	}
	
	if(data.postsetup.postdeliverytype=="get"){
		document.getElementById("deliverytype").selectedIndex = 1;
	}
	else if (data.postsetup.postdeliverytype=="post")
	document.getElementById("deliverytype").selectedIndex = 0;
	
	else
	
	document.getElementById("deliverytype").selectedIndex = 2;
	
	if(data.postsetup.static==0){
		document.getElementById("clienttype").selectedIndex = 1;
	}
	else
	document.getElementById("clienttype").selectedIndex = 0;
	
	if (document.getElementById('price') !== null)
	document.getElementById("price").value = data.postsetup.price;
	
	document.getElementById("priority").value = data.postsetup.priority;
	document.getElementById("testurl").value = data.postsetup.posttesturl;
	document.getElementById("posturl").value = data.postsetup.posturl;
	document.getElementById("postheader").value = data.postsetup.postheader;
	document.getElementById("classname").value = data.postsetup.classname;
	document.getElementById("comments").value = data.postsetup.comments;
	
	for(var a=0;a<data.delivery.length;a++){
		if(data.delivery[a]['dayofweek']==1)
		{
			document.getElementById("sunday").checked=1;
			document.getElementById("sunday_starttime").value=data.delivery[a]['starttime'];
			document.getElementById("sunday_endtime").value=data.delivery[a]['endtime'];
		}
		else if(data.delivery[a]['dayofweek']==2)
		{
			document.getElementById("monday").checked=1;
			document.getElementById("monday_starttime").value=data.delivery[a]['starttime'];
			document.getElementById("monday_endtime").value=data.delivery[a]['endtime'];
		}
		else if(data.delivery[a]['dayofweek']==3)
		{
			document.getElementById("tuesday").checked=1;
			document.getElementById("tuesday_starttime").value=data.delivery[a]['starttime'];
			document.getElementById("tuesday_endtime").value=data.delivery[a]['endtime'];
		}
		else if(data.delivery[a]['dayofweek']==4)
		{
			document.getElementById("wednesday").checked=1;
			document.getElementById("wednesday_starttime").value=data.delivery[a]['starttime'];
			document.getElementById("wednesday_endtime").value=data.delivery[a]['endtime'];
		}
		else if(data.delivery[a]['dayofweek']==5)
		{
			document.getElementById("thursday").checked=1;
			document.getElementById("thursday_starttime").value=data.delivery[a]['starttime'];
			document.getElementById("thursday_endtime").value=data.delivery[a]['endtime'];
		}
		else if(data.delivery[a]['dayofweek']==6)
		{
			document.getElementById("friday").checked=1;
			document.getElementById("friday_starttime").value=data.delivery[a]['starttime'];
			document.getElementById("friday_endtime").value=data.delivery[a]['endtime'];
		}
		else if(data.delivery[a]['dayofweek']==7)
		{
			document.getElementById("saturday").checked=1;
			document.getElementById("saturday_starttime").value=data.delivery[a]['starttime'];
			document.getElementById("saturday_endtime").value=data.delivery[a]['endtime'];
		}
	}
	if(data.postsetup.deliveryholidays==1){
	document.getElementById("holiday1").checked = true;
	}
	else
	document.getElementById("holiday2").checked = true;
	document.getElementById("leadsperday").value = data.postsetup.leadsperday;
	document.getElementById("leadspermonth").value = data.postsetup.leadspermonth;
	document.getElementById("leadsperlife").value = data.postsetup.leadsperlife;
	if(data.postsetup.posttimeout==null){
	document.getElementById("posttimeout").value = "";
	}
	else{
	document.getElementById("posttimeout").value = data.postsetup.posttimeout;
	}
	document.getElementById("translation").value = data.postsetup.posttranslation;
	document.getElementById("poststring").value = data.postsetup.postquerystring;
	});							
}
function copycriteria(crieriaid)
{
	var bu = $('#baseurl').val();
	var url=bu+"/copysettings/copycriteria";
	var params = {'cid':crieriaid};
	$.getJSON(url, params, function(data, textStatus){
	var paymehod = data.criteria.paymethodblacklist;
	if(paymehod.indexOf("checking")!=-1){
		document.getElementById("checking").checked = true;
	}
	if(paymehod.indexOf("savings")!=-1){
		document.getElementById("savings").checked = true;
	}
	if(paymehod.indexOf("paper")!=-1){
		document.getElementById("paper").checked = true;
	}
	if(paymehod.indexOf("other")!=-1){
		document.getElementById("other").checked = true;
	}
	var frequency = data.criteria.payperiodblacklist;
	if(frequency.indexOf("weekly")!=-1){
		document.getElementById("weekly").checked = true;
	}
	if(frequency.indexOf("biweekly")!=-1){
		document.getElementById("biweekly").checked = true;
	}
	if(frequency.indexOf("semimonthly")!=-1){
		document.getElementById("semimonthly").checked = true;
	}
	if(frequency.indexOf("monthly")!=-1){
		document.getElementById("monthly").checked = true;
	}
	if(data.criteria.denymilitary==1){
		document.getElementById("mil1").checked = true;
	}
	else
	document.getElementById("mil1").checked = false;
	document.getElementById("agemin").value = data.criteria.agemin;
	document.getElementById("agemax").value = data.criteria.agemax;
	document.getElementById("loanamountmin").value = data.criteria.loanamountmin;
	document.getElementById("loanamountmax").value = data.criteria.loanamountmax;
	document.getElementById("incomeminimum").value = data.criteria.monthlyincomemin;
	document.getElementById("incomemaximum").value = data.criteria.monthlyincomemax;
	document.getElementById("abablacklist").value = data.criteria.abablacklist;
	document.getElementById("employedblacklist").value = data.criteria.employedblacklist;
	document.getElementById("employerblacklist").value = data.criteria.employerblacklist;
	document.getElementById("zipblacklist").value = data.criteria.zipblacklist;
	document.getElementById("masteraffblacklist").value = data.criteria.masteraffblacklist;
	document.getElementById("campaignblacklist").value = data.criteria.campaignblacklist;
	document.getElementById("emailextblacklist").value = data.criteria.emailextblacklist;
	document.getElementById("bankaccountmax").value = data.criteria.bankaccountmax;
	document.getElementById("dupedays").value = data.criteria.dupedays;
	var statestemp = new Array();
	statestemp = data.criteria.stateblacklist.split(",");
	var len = document.frm.elements.length;
	var i=0;
	
	for( i=0 ; i<len ; i++) 
	{
		if (document.frm.elements[i].name=='states[]') 
		{
			var elemid = document.frm.elements[i].id;
			for(var a=0;a<statestemp.length;a++)
			if(elemid==statestemp[a]){
			document.getElementById(statestemp[a]).checked = true;
			break;
			}
			else
			document.frm.elements[i].checked=false;
		}
	}	
	});

}
