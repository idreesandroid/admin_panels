var table;
var JQ = jQuery.noConflict();

JQ(document).ready(function() {	

        JQ("#fromDate").datepicker({ dateFormat: "yy-mm-dd" });
        JQ("#toDate").datepicker({ dateFormat: "yy-mm-dd" });	
                
        table = JQ('#reportgrid').DataTable( {
            "paging":   false,
            "info":     false,
            "ajax":{
                    "url": "storeid-reports/reportsdata",
                    "data": function ( d ) {
                    d.fromDate = JQ("#fromDate").val();
                    d.toDate = JQ("#toDate").val();
                    d.timeStart = JQ("#timeStart").val();
                    d.timeEnd = JQ("#timeEnd").val();
                },
                beforeSend : function(xhr, opts){
                        
                        JQ("#gridbody").html('<tr><td valign="top" colspan="5" class="dataTables_empty">Loading...</td></tr>');
                },
                
            },
             "footerCallback": function ( row, data, start, end, display ) {
                        var api = this.api(), data;
                        
                        totalPurchased = api
                        .column( 3, { page: 'current'} )
                        .data()
                        .reduce( function (a, b) {
                            return parseInt(a) + parseInt(b);
                        }, 0 );
                        
                        totalAttempted = api
                        .column( 2, { page: 'current'} )
                        .data()
                        .reduce( function (a, b) {
                            return parseInt(a) + parseInt(b);
                        }, 0 );
                        
                        if (totalPurchased == 0 && totalAttempted == 0) {
                            totalPurchaseRate = "0.00";
                        }
                        else {
                            totalPurchaseRate = ((totalPurchased/totalAttempted)*100).toFixed(2)+"%";    
                        }
                        
                        JQ( api.column( 2 ).footer() ).html(
                                totalAttempted
                        );
                        
                        JQ( api.column( 3 ).footer() ).html(
                                totalPurchased    
                        );
                        
                        JQ( api.column( 4 ).footer() ).html(
                                totalPurchaseRate
                        );
                
                },
            "columns": [
                {
                    "className":      'details-control',
                    "orderable":      false,
                    "data":           null,
                    "defaultContent": ''
                },
                { "data": "storeid" },
                { "data": "attempted" },
                { "data": "purchased" },
                { "data": "purchaserate" },
            ],
            "createdRow": function ( row, data, index ) {
                
                    JQ('td', row).eq(4).append('%');
            }
        } );

        // Add event listener for opening and closing details
        JQ('#reportgrid tbody').on('click', 'td.details-control', function () {
            var tr = JQ(this).closest('tr');
            var row = table.row( tr );
     
            if ( row.child.isShown() ) {
                // This row is already open - close it
                row.child.hide();
                tr.removeClass('shown');
            }
            else {
                // Open this row
                var rowid = JQ(tr).attr('id');
                if (!rowid) {
                        
                        var uniqureID = Math.floor(Math.random() * 26) + Date.now();
                        uniqureID = uniqureID.toString();
                        JQ(tr).attr('id', uniqureID);
                        tr.addClass('shown');
                        format(row.data(),row);
                        
                }
                else {
                        row.child.show();
                        tr.addClass('shown');
                }
                
            }
        } );
} );

function reloadTableData() {
        
        table.ajax.reload();
}

function format ( d ,row) {
        
        row.child( "<img src='/public/images/ajax-loader.gif'>" ).show();
        
        // `d` is the original data object for the row
        var html = '<table width="100%" border="0"><tr><td width="10%">&nbsp;</td><td><table width="100%" class="tg">';
        
        var request = JQ.ajax({
                url: "storeid-reports/reportsdatabystoreid?storeid="+d.storeid+"&fromDate="+JQ("#fromDate").val()+"&toDate="+JQ("#toDate").val()+"&timeStart="+JQ("#timeStart").val()+"&timeEnd="+JQ("#timeEnd").val(),
                async:   true
        });
        
        request.done(function( data ) {

                    html+= '<tr><td style="color: #336600; font-size: 12px; font-weight: bold;">State</td><td style="color: #336600; font-size: 12px; font-weight: bold;">Attempted</td>';
                    html+= '<td style="color: #336600; font-size: 12px; font-weight: bold;">Leads Purchased</td><td style="color: #336600; font-size: 12px; font-weight: bold;">Purchase Rate</td></tr>'
                    JQ.each(JQ.parseJSON(data).data, function(idx, obj) {
                        
                        if (obj.purchaserate == null) {
                            obj.purchaserate = "0.00";
                        }
                        html+= '<tr><td class="tg-031e">'+obj.state+'</td><td class="tg-031e">'+obj.attempted+'</td><td class="tg-031e">'+obj.purchased+'</td><td class="tg-031e">'+obj.purchaserate+'%</td></tr>';
                });
                html+="</table></td></tr></table>";
                row.child( html ).show();
        });
       
        request.fail(function( jqXHR, textStatus ) {

            html+= '<tr><td colspan="2" style="color: #336600; font-size: 12px; font-weight: bold;">Some error occured</td></tr>';
            html+="</table></td></tr></table>";
            row.child( html ).show();
        });	
}