/**
 * set DataAo parameters that we will be posting via ajax to get campaign report data
 */
function TblServerParams(DataAo)
{
	DataAo.push(
		{"name": "campaignID", "value":  JQ('#campaignID').val() },
		{"name": "multiVarStart", "value":  JQ('#multiVarStart').val() },
		{"name": "multiVarEnd", "value":  JQ('#multiVarEnd').val() },
		{"name": "originationDate", "value":  JQ('#originationDateForSubmit').val() },
		{"name": "originalDateStart", "value":  JQ('#originalDateStart').val() },
		{"name": "originalTimeStart", "value":  JQ('#originalTimeStart').val() },
		{"name": "originalDateEnd", "value":  JQ('#originalDateEnd').val() },
		{"name": "originalTimeEnd", "value":  JQ('#originalTimeEnd').val() },
		{"name": "selectedStrategy", "value":  JQ('#selectedStrategy').val() }
	);

	var selectedStoreIDs = [];
	for (i = 0; i < storeIDs.length; i++) {
		var storeID = storeIDs[i];
		if (JQ("[id='"+storeID+"']").is(':checked')) {
			DataAo.push({"name": "selectedStoreIDs[]", "value":  storeID });
		}
	}

	return DataAo;
}

JQ.fn.dataTableExt.oApi.fnGetColumnData = function ( oSettings, iColumn, bUnique, bFiltered, bIgnoreEmpty ) {
	// check that we have a column id
	if ( typeof iColumn == "undefined" ) return new Array();

	// by default we only want unique data
	if ( typeof bUnique == "undefined" ) bUnique = true;

	// by default we do want to only look at filtered data
	if ( typeof bFiltered == "undefined" ) bFiltered = true;

	// by default we do not want to include empty values
	if ( typeof bIgnoreEmpty == "undefined" ) bIgnoreEmpty = true;

	// list of rows which we're going to loop through
	var aiRows;

	// use only filtered rows
	if (bFiltered == true) aiRows = oSettings.aiDisplay;
	// use all rows
	else aiRows = oSettings.aiDisplayMaster; // all row numbers

	// set up data array
	var asResultData = new Array();

	for (var i=0,c=aiRows.length; i<c; i++) {
		iRow = aiRows[i];
		var aData = this.fnGetData(iRow);
		var sValue = aData[iColumn];

		if (!sValue) continue;
		// ignore empty values?
		if (bIgnoreEmpty == true && sValue.length == 0) continue;

		// ignore unique values?
		else if (bUnique == true && jQuery.inArray(sValue, asResultData) > -1) continue;

		// else push the value onto the result data array
		else asResultData.push(sValue);
	}

	return asResultData;
};

jQuery.fn.dataTableExt.oSort['sort-urls-asc']  = function(x,y) {
	x = x.replace(/<\/?[^>]+>/gi,'');
	y = y.replace(/<\/?[^>]+>/gi,'');
	return x - y;
};

jQuery.fn.dataTableExt.oSort['sort-urls-desc'] = function(x,y) {
	x = x.replace(/<\/?[^>]+>/gi,'');
	y = y.replace(/<\/?[^>]+>/gi,'');
	return y - x;
};

function testFunc()
{
	alert('getdatat js loaded');
}
