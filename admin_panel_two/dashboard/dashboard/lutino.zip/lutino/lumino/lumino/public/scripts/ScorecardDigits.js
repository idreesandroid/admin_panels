var JQ = jQuery.noConflict();
var textfields = [];
// silder ranges colors array
var CSS_COLOR_NAMES = ['#1ab0f0','#fc5340','#7ec23a','#f89723','#fcdf12','#8c5f3c','#804199','#1e1f26','#af4425','#c7db00','#919636','#061283','#488a99','#6c7a89','#eb974e'];

function updateFieldsOnEdit() {
	  // Remove previous slider and build new one
	  JQ("#updatePanel").empty();
	  // Build new slider table
	  JQ("#updatePanel").append('<div class="datagrid"><table cellspacing="0" cellpadding="0" border="0" width="100%" id="rangesTable" class="JColResizer"><tbody><tr style="height:35px;" id="headerrow"></tr></tbody></table></div>');

	  if (textfields.length > 1) {
		  		// build each score card range and add to slider
				for(index = 0; index < textfields.length; index++) {
					var per = (textfields[index][1].val() - textfields[index][0].val())+1;
					var html = "<th width='"+per+"%' style='color: #ffffff; font-size: 12px; background-color:"+CSS_COLOR_NAMES[index]+"'></th>";
					JQ("#headerrow").append(html);
				}
	  }

	  else {
		var html = "<th width='100%' style='color: #ffffff; font-size: 12px; background-color:"+CSS_COLOR_NAMES[0]+";'></th>";
		JQ("#headerrow").append(html);
	}
	createTable();
}

function updateFields() {
  // Remove previous slider and build new one
  JQ("#updatePanel").empty();
  // Build new slider table
  JQ("#updatePanel").append('<div class="datagrid"><table cellspacing="0" cellpadding="0" border="0" width="100%" id="rangesTable" class="JColResizer"><tbody><tr style="height:35px;" id="headerrow"></tr></tbody></table></div>');

  if (textfields.length > 1) {

	  	// newly added scorecard max value is always 10% less than previous scorecard's min value
	  	textfields[1][0].val(textfields[1][1].val()-9);
	  	// newly added scorecard min value is always 0
		textfields[0][0].val(0);
		textfields[0][1].val(textfields[1][0].val()-1);
		// build each score card range and add to slider
		for(index = 0; index < textfields.length; index++) {
			var per = (textfields[index][1].val() - textfields[index][0].val())+1;
			var html = "<th width='"+per+"%' style='color: #ffffff; font-size: 12px; background-color:"+CSS_COLOR_NAMES[index]+"'></th>";
			JQ("#headerrow").append(html);
		}
  }
	 else {

		var html = "<th width='100%' style='color: #ffffff; font-size: 12px; background-color:"+CSS_COLOR_NAMES[0]+";'></th>";
		JQ("#headerrow").append(html);
	 }
	createTable();
}

//callback function when slider is moved
function onSlide(){

	var columns = JQ("#rangesTable").find("th");
	var ranges = [], total = 0, i, s ="Ranges: ", w;
	// calculate each column's width and push to ranges array
	for(i = 0; i<columns.length; i++){
		w = columns.eq(i).width();
		ranges.push(w);
		total+=w;
	}
	// calculate percentage for each column wirdth
	for(i=0; i<columns.length; i++){
		ranges[i] = Math.round(100*ranges[i]/total);
		carriage = ranges[i]-w;
	}

	var temp = [];
	var outPut = [];
	// loop through ranges array and update labels for each scorecard
	for(i=0; i<ranges.length; i++){

		var tuple = [];
		if (i==0) {
			tuple.push(0);
			tuple.push(ranges[i]-1);
			temp[i] = ranges[i]-1;
		}
		else {
			temp[i] = temp[i-1]+ranges[i];

			if (temp[i-1]+1 >=100) {
				temp[i-1] = 98;
			}
			if (temp[i] >= 100) {
				temp[i] = 99;
			}
			if (i==ranges.length-1) {
				temp[i] = 99;
			}
			if (temp[i] <=  (temp[i-1]+1)) {
				temp[i] = temp[i-1]+1;
			}
			// Push starting value
			tuple.push(temp[i-1]+1);
			// Push ending value
			tuple.push(temp[i]);
		}
		if(tuple[0] <= 0) {
			tuple[0] = 0;
		}
		if(tuple[1] <= 0) {
			tuple[1] = 0;
		}
		outPut.push(tuple);
		// update percentage for each score card range
		columns.eq(i).text((tuple[1]-tuple[0])+1+"%");
		// update values for each score card min, max text fileds
		textfields[i][0].val(tuple[0]);
		textfields[i][1].val(tuple[1]);
	}
	s=s.slice(0,-1);
}

function createTable(){
	// Use plugin to create resizable table for silder
	JQ("#rangesTable").colResizable({
	liveDrag:true,
	draggingClass:"",
	gripInnerHtml:"<div class='rangeGrip'></div>",
	onDrag:onSlide,
	partialRefresh:true,
	minWidth:6
	});
}
