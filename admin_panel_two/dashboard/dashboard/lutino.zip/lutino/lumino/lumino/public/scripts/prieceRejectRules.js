var iRejectRuleCounter = 0;

jQuery(document).ready(function () {

	initRuleOperatorEditable();
	// Triggered when add new ruleset is clicked
	JQ("body").on("click", "#addRejectRuleset", function (event) {

		iRejectRuleCounter++;
		JQ('<div/>', {
			'id': 'set' + iRejectRuleCounter,
			'class': 'PriceRejectextraRuleset',
			html: buildRejectRulesetHtml()
		}).hide().appendTo('#rejectRulesSpawnArea').slideDown('fast');

		refreshPriceRejectSetRulePriority();
	});
});

// Triggered when new rule inside ruleset is added
JQ("body").on("click", "#priceRejectaddRule", function (event) {

	iRejectRuleCounter++;
	var number = JQ(this).parent().children("#rulesettable").find("div.ruleSpawnArea").find(".extraRulePriceReject").length + 1;
	// Add rule operator if we have more than 1 rules
	if (number > 1) {
		JQ('<a/>', {
			'href': '#',
			'class': 'priceRejectRuleOperator',
			'data-title': 'Select operator',
			'data-value': ''
		}).appendTo(JQ(this).parent().children('#rulesettable').find("div.ruleSpawnArea")).slideDown('fast');
	}

	// build price reject rule html
	JQ('<div/>', {
		'id': 'rule' + iRejectRuleCounter,
		'class': 'extraRulePriceReject',
		html: buildPriceRejectRuleHtml()
	}).hide().appendTo(JQ(this).parent().children("#rulesettable").find("div.ruleSpawnArea")).slideDown('fast');

	var lastOperatorElement = JQ(this).parent().find(".ruleOperator").last();
	var prevRuleID = lastOperatorElement.prev('div').attr('id');
	var nextRuleID = lastOperatorElement.next('div').attr('id');

	lastOperatorElement.attr('id',prevRuleID + '-' + nextRuleID);

	refreshPriceRejectRulePriority(JQ(this).parents('.PriceRejectextraRuleset'));
	initEditableElements();
	initRuleOperatorEditable();
});

// Triggered when delete ruleset is clicked
JQ("body").on("click", ".preiceRejectRemoveRuleSet", function (e) { //user click on remove text
	if (confirm('Are you sure?')) {
		if (JQ(this).closest('div').next('.rulesetOperator').length == 1) {
			JQ(this).closest('div').next('.rulesetOperator').remove();
		} else {
			JQ(this).closest('div').prev('.rulesetOperator').remove();
		}

		JQ(this).parent().parent().remove();
		refreshPriceRejectSetRulePriority();
	}
});
// Triggered when rule inside rule set is clicked
JQ("body").on("click", ".priceRejectRemoveRule", function (e) { //user click on remove text
	if (confirm('Are you sure?')) {

		if (JQ(this).closest('div').parent().next('.priceRejectRuleOperator').length == 1) {
			JQ(this).closest('div').parent().next('.priceRejectRuleOperator').remove();
		} else {
			JQ(this).closest('div').parent().prev('.priceRejectRuleOperator').remove();
		}

		var parent = JQ(this).parent().parent().parent().parent().parent();
		JQ(this).parent().parent().parent().remove();
		refreshRulePriority(parent);
	}
});

function buildRejectRulesetHtml() {
	var $html = JQ('.priceRejectRuleSetTemplate').clone();
	return $html.html();
}

function refreshPriceRejectSetRulePriority() {
	var counter = 1;
	// Reset rule priorities by starting from one
	JQ('.PriceRejectextraRuleset').each(function () {
		JQ(this).find('.preiceRejectrulesetPriority').html('[' + counter + ']');
		counter++;
	});
}

function refreshPriceRejectRulePriority(element) {
	var counter = 1;
	element.find('.extraRulePriceReject').each(function () {
		JQ(this).find('.rulePriority').html('[' + counter + ']');
		counter++;
	});
}

function buildPriceRejectRuleHtml() {

	// clone rule template
	var $html = JQ('.priceRejectRuleTemplate').clone();
	// add priceRejectForSave class to each rule element
	$html.find('[name=vendorParams]')[0].addClass('priceRejectForSave');
	$html.find('[name=operators]')[0].addClass('priceRejectForSave');
	$html.find('[name=paramValue]')[0].addClass('priceRejectForSave');

	$html.find('[name=removerule]')[0].name = "removerule" + iRejectRuleCounter;
	return $html.html();
}

function validatePriceRejectRules() {

	var validation = true;

	var elementsCount = JQ("#rejectRulesSpawnArea").find(".PriceRejectextraRuleset").length;

	if (elementsCount > 0) {
		// Check if ruleset name is set
		JQ(".PriceRejectextraRuleset").find(".rulesetNameDiv").each(function (index, elem) {
			var value = JQ(this).find(".priceRejectRulesetName").attr("value");
			if (value === "") {
				validation = false;
			}
		});
		// Check all elements for a rule have values
		JQ(".priceRejectForSave").each(function (index, elem) {
			var value = JQ(this).editable('getValue', true);
			if (value === "") {
				validation = false;
			}
		});
		// Check if ruleset priority is set
		JQ("#rejectRulesSpawnArea").find(".PriceRejectextraRuleset").children(".rulesettable").find("input.rulesetPriority").each(function (index, elem) {
			var value = JQ(this).attr("value");
			if (value === "") {
				validation = false;
			}
		});
		// Check if ruleset price is set
		JQ("#rejectRulesSpawnArea").find(".PriceRejectextraRuleset").children(".rulesettable").find("input.rulesetPrice").each(function (index, elem) {
			var value = JQ(this).attr("value");
			if (value === "") {
				validation = false;
			}
		});
		// Check if ruleset storeid is set
		JQ("#rejectRulesSpawnArea").find(".PriceRejectextraRuleset").children(".rulesettable").find("input.rulesetStoreID").each(function (index, elem) {
			var value = JQ(this).attr("value");
			if (value === "") {
				validation = false;
			}
		});
		// Check if ruleset tierkey is set
		JQ("#rejectRulesSpawnArea").find(".PriceRejectextraRuleset").children(".rulesettable").find("input.rulesetTierKey").each(function (index, elem) {
			var value = JQ(this).attr("value");
			if (value === "") {
				validation = false;
			}
		});
		// Check if rule operators are set
		JQ("#rejectRulesSpawnArea").find(".PriceRejectextraRuleset").children(".rulesettable").find("a.priceRejectRuleOperator").each(function (index, elem) {
			var value = JQ(this).editable('getValue', true);
			if (value === "") {
				validation = false;
			}
		});
	}

	return validation;
}

function validatePriceRejectRulesetsShouldContainRules() {

	var validation = true;
	JQ(".PriceRejectextraRuleset").each(function (index, elem) {
		if (JQ(this).find('.extraRulePriceReject').length == 0) {
			validation = false;
		}
	});

	return validation;
}
// Function to get JS object size
Object.size = function(obj) {
    var size = 0, key;
    for (key in obj) {
        if (obj.hasOwnProperty(key)) size++;
    }
    return size;
};

function getPriceRejectRulesSetsData() {

	var priceRejectRuleSetData = {};
	var tuple = [];

	JQ("#rejectRulesSpawnArea").children().each(function (index, elem) {

		var priceRejectRuleSetData = {};
		var rulesVendorParams = [];
		var rulesVendorParamsOperator = [];
		var rulesVendorParamsValues = [];
		var rulesOperators = [];

		JQ(this).children().each(function (index, elem) {
			// Get ruleset name
			if(JQ(this).attr("class") == "rulesetNameDiv") {

				var ruleSetName = JQ(this).find(".priceRejectRulesetName").attr("value");
				priceRejectRuleSetData.name = ruleSetName;
			}
			else if (JQ(this).attr("class") == "rulesettable") {
				// get values for ruleset priority
				var value = JQ(this).find("input.rulesetPriority").attr("value");
				priceRejectRuleSetData.rulesetPriority = value;
				// get values for ruleset price
				var value = JQ(this).find("input.rulesetPrice").attr("value");
				priceRejectRuleSetData.rulesetPrice = value;
				// get values for ruleset storeid
				var value = JQ(this).find("input.rulesetStoreID").attr("value");
				priceRejectRuleSetData.rulesetStoreID = value;
				// get values for ruleset tierkey
				var value = JQ(this).find("input.rulesetTierKey").attr("value");
				priceRejectRuleSetData.rulesetTierKey = value;
				// get values for ruleset custom code
				var value = JQ(this).find("textarea.rulesetCustomCode").attr("value");
				priceRejectRuleSetData.customCode = value;
				// get values for rules vendor params
				JQ(this).find("div.ruleSpawnArea").find(".extraRulePriceReject").find(".vendorParams").each(function (index, elem) {
					var value = JQ(this).editable('getValue', true);
					rulesVendorParams.push(value);
				});
				priceRejectRuleSetData.rulesVendorParams = rulesVendorParams;
				// get values for rules operators
				JQ(this).find("div.ruleSpawnArea").find(".extraRulePriceReject").find(".operators").each(function (index, elem) {
					var value = JQ(this).editable('getValue', true);
					rulesVendorParamsOperator.push(value);
				});
				priceRejectRuleSetData.rulesVendorParamsOperator = rulesVendorParamsOperator;
				// get values for rule passing value
				JQ(this).find("div.ruleSpawnArea").find(".extraRulePriceReject").find(".paramValue").each(function (index, elem) {
					var value = JQ(this).editable('getValue', true);
					rulesVendorParamsValues.push(value);
				});
				priceRejectRuleSetData.rulesVendorParamsValues = rulesVendorParamsValues;
				// get values for rule operators
				JQ(this).find("div.ruleSpawnArea").find(".priceRejectRuleOperator").each(function (index, elem) {
					var value = JQ(this).editable('getValue', true);
					rulesOperators.push(value);
				});
				priceRejectRuleSetData.ruleOperators = rulesOperators;
			}
		});
		// Push all values to array
		if (Object.size(priceRejectRuleSetData) > 0) {
			tuple.push(priceRejectRuleSetData);
		}
	});

	return tuple;
}

function initRuleOperatorEditable() {

	// initialize editable rule operator
	JQ('.priceRejectRuleOperator').editable({
		send: 'auto',
		type: 'select2',
		emptytext: 'Select operator',
		source: [
			{id: 1, text: 'AND'},
			{id: 2, text: 'OR'}
		],
		select2: {
			placeholder: 'Select',
			allowClear: true,
			width: '100px',
			minimumResultsForSearch: -1,
			id: function (e) {
				return e.id;
			}
		}
	});

	JQ('.paramValue').editable('option', 'validate', function (v) {
		if (!v) return 'Required field!';
	});
}
