/**
 * call dataTable function to draw table for campaign report
 */
function drawReportTable()
{
	return JQ("#campaigntable").dataTable({
		"bJQueryUI": true,
		"bProcessing": true,
		"bServerSide": false,
		"sAjaxSource": "campaigndata",
		"bLengthChange":false,
		"iDisplayLength":1000,
		"aaSorting": [[ 5, "asc" ]],
		"oLanguage": {
		"sProcessing": ""
		},
		"aoColumnDefs":[
		{ "bVisible":false, "aTargets":[ 0 ] },
		{ "bVisible":false, "aTargets":[ 1 ] },
		{ "bVisible":false, "aTargets":[ 2 ] }
		],

		"fnDrawCallback" : function() {
			JQ.unblockUI();
		},

	/**
	 * This function allows you to 'post process' each row after it have been generated
	 * for each table draw.
	 * In our case we are just using it for
	 * @param nRow  "TR" element for the current row
	 * @param aData 	Raw data array for this row
	 * @param iDisplayIndex 	The display index for the current table draw
	 * @param iDisplayIndexFull The index of the data in the full list of rows (after filtering)
	 * @returns "TR" element for the current row
	 */
	"fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
		JQ('td', nRow).each(function (i) {
				if (i == 0 && !!aData[0]) {
				if (aData[1] == "0") {
				JQ(this).removeClass('markrow');
				} else {
				JQ(this).addClass('markrow');
				}
				}
				});
		return nRow;
	},

	/**
	 * Footer callback is always invokes after the table redraw
	 * @param nRow - "TR" element for the footer
	 * @param aaData - Full table data (as derived from the original HTML).
	 * @param iStart - Index for the current display starting point in the display array
	 * @param iEnd  - Index for the current display ending point in the display array
	 * @param aiDisplay - Index array to translate the visual position to the full data array
	 */
	"fnFooterCallback": function ( nRow, aaData, iStart, iEnd, aiDisplay ) {
		var attempted = 0;
		var bought = 0;
		var cost = 0;
		var originated = 0;
		var totaloriginated = 0;
		var cpf;
		var perTotalOrigBought;
		var perCurrentOrigBought;
		var perBoughtAttempted;
		var esigs = 0;
		var FPD = 0;
		var redirects = 0;
		var hotTransferBought = 0;

		/**
		 * Calculate result for the total row
		 */
		for ( var i=iStart ; i<iEnd ; i++ )
		{
			// stripping out html to get attempted number
			attempted += aaData[ aiDisplay[i] ][7].replace(/<\/?[^>]+>/gi,'') * 1;

			if (aaData[ aiDisplay[i] ][3] == "1") {
				hotTransferBought += aaData[ aiDisplay[i] ][8] * 1;
			}
			// stripping out html to get bought number
			bought += aaData[ aiDisplay[i] ][8].replace(/<\/?[^>]+>/gi,'') * 1;
			var costVar = (aaData[ aiDisplay[i] ][9]).substring(1);
			cost += costVar * 1;
			originated += aaData[ aiDisplay[i] ][10].replace(/<\/?[^>]+>/gi,'') * 1;
			totaloriginated += aaData[ aiDisplay[i] ][11] * 1;
			perBoughtAttempted = aaData[ aiDisplay[i] ][12] * 1;
			esigs += aaData[ aiDisplay[i] ][16] * 1;
			FPD += aaData[ aiDisplay[i] ][18] * 1;
			redirects += aaData[ aiDisplay[i] ][20] * 1;
		}

		cpf = (totaloriginated > 0 && cost > 0) ? (parseInt(cost) / parseInt(totaloriginated)) : 0;
		perTotalOrigBought = (totaloriginated > 0 && bought > 0) ? (100 * (parseInt(totaloriginated)) / parseInt(bought)) : 0;
		perCurrentOrigBought = (originated > 0 && bought > 0) ? (100 * (parseInt(originated)) / parseInt(bought)) : 0;
		perBoughtAttempted = (bought > 0 && attempted > 0) ? (100 * (parseInt(bought)) / parseInt(attempted)) : 0;
		var boughtWithoutHotTranfer = bought - hotTransferBought;
		esigRate = (esigs > 0 && bought > 0) ? (100 * (parseInt(esigs)) / parseInt(bought)) : 0;
		FPDrate = (FPD > 0 && totaloriginated > 0) ? (100 * (parseInt(FPD) / parseInt(totaloriginated))) : 0;
		redirectsRate = (redirects > 0 && boughtWithoutHotTranfer > 0) ? (100 * (parseInt(redirects)) / parseInt(boughtWithoutHotTranfer)) : 0;

		// we need to format dates from m/d/Y to Y-m-d
		var datestart = new Date(JQ('#originalDateStart').val());
		var originalDateStart = convertDate(datestart);
		var originalTimeStart = JQ('#originalTimeStart').val();
		var dateend = new Date(JQ('#originalDateEnd').val());
		var originalDateEnd = convertDate(dateend);
		var originalTimeEnd = JQ('#originalTimeEnd').val();

		/**
		 * here we are checking if  esig, fpd, redirects columns are visible.. we should also
		 * do calculations here.
		 */
		var nCells = nRow.getElementsByTagName('th');
		nCells[ATTEMPTS_INDEX].innerHTML = '<a id="total-attempts" href="/lead-provider-reports/attempts?affiliateName=' + JQ('#affiliate-filter').val() + '&fromDate=' + originalDateStart + '&fromTime=' + originalTimeStart + '&toDate=' + originalDateEnd + '&toTime=' + originalTimeEnd + '" target="_blank">' + parseInt(attempted) + '</a>';
		nCells[LEADS_BOUGHT_INDEX].innerHTML = '<a id="total-attempts" href="/lead-purchased-reports?affiliateName=' + JQ('#affiliate-filter').val() + '&customertype=all&campaignID=&fromDate=' + originalDateStart + '&fromTime=' + originalTimeStart + '&toDate=' + originalDateEnd + '&toTime=' + originalTimeEnd + '" target="_blank">' + parseInt(bought) + '</a>';
		nCells[TOTAL_COST_INDEX].innerHTML = "$" + parseInt(cost );
		nCells[LOANS_ORIGINATED_INDEX].innerHTML = '<a id="total-attempts" href="/lead-purchased-reports?affiliateName=' + JQ('#affiliate-filter').val() + '&customertype=all&orig=1&campaignID=&fromDate=' + originalDateStart + '&fromTime=' + originalTimeStart + '&toDate=' + originalDateEnd + '&toTime=' + originalTimeEnd + '" target="_blank">' + parseInt(originated) + '</a>';
		nCells[TOTAL_LOANS_ORIGINATED_INDEX].innerHTML = parseInt(totaloriginated );
		nCells[CPF_INDEX].innerHTML = "$" + parseFloat(cpf).toFixed(2);
		nCells[CONVERSION_RATE_CURRENT_DATE_INDEX].innerHTML = parseFloat(perCurrentOrigBought).toFixed(2) + "%";
		nCells[CONVERSION_RATE_TOTAL_INDEX].innerHTML = parseFloat(perTotalOrigBought).toFixed(2) + "%";
		nCells[PURCHASE_RATE_INDEX].innerHTML = parseFloat(perBoughtAttempted).toFixed(2) + "%";
		nCells[ESIG_INDEX].innerHTML = parseInt(esigs);
		nCells[ESIG_RATE_INDEX].innerHTML = parseFloat(esigRate).toFixed(2) + "%";
		nCells[FPD_INDEX].innerHTML = parseInt(FPD);
		nCells[FPD_RATE_INDEX].innerHTML = FPDrate.toFixed(2) + "%";
		nCells[REDIRECTS_INDEX].innerHTML = parseInt(redirects);
		nCells[REDIRECTS_RATE_INDEX].innerHTML = redirectsRate.toFixed(2) + "%";
	},

	/**
	 * we can set some parameters here for columns (name, width, type of column etc.)
	 */
	"aoColumns": [
		null,
		null,
		null,
		{ "sName": "affiliatename", "sWidth": "5%" },
		{ "sName": "campaigntitle", "sWidth": "5%" },
		{ "sName": "campaign", "sWidth": "5%" },
		{ "sName": "cpl", "sWidth": "5%" },
		{ "sName": "leads", "sType":"sort-urls", "sWidth": "5%" },
		{ "sName": "bought", "sType":"sort-urls", "sWidth": "5%" },
		{ "sName": "cost", "sType":"currency", "sWidth": "5%", "fnRender": function ( oObj ) {
			return "$" + oObj.aData[9];
		} },
		{ "sName": "originated", "sWidth": "5%" },
		{ "sName": "totaloriginated", "sWidth": "8%"},
		{ "sName": "cpf", "sType":"currency", "sWidth": "5%" },
		{ "sName": "pertodayorigbought", "sType":"currency", "sWidth": "5%" },
		{ "sName": "pertotalorigbought", "sType":"currency", "sWidth": "5%" },
		{ "sName": "perboughtattempted", "sType":"currency", "sWidth": "5%"},
		{ "sName": "esigs", "sWidth": "5%"},
		{ "sName": "esigrate", "sType":"currency", "sWidth": "5%"},
		{ "sName": "fpd", "sWidth": "5%" },
		{ "sName": "fpdrate", "sType":"currency", "sWidth": "5%"},
		{ "sName": "redirects", "sWidth": "5%" },
		{ "sName": "redirectsRate", "sType":"currency", "sWidth": "5%"}
	],

	/**
	 * This parameter allows you to override the default function which obtains the data
	 * from the server (for ex. json)
	 * @param sSource   -  HTTP source to obtain the data from (sAjaxSource)
	 * @param aoData    - A key/value pair object containing the data to send to the server
	 * @param fnCallback - data on the page
	 * @param oSettings - DataTables settings object
	 */
	"fnServerData": function (sSource, aoData, fnCallback, oSettings) {
		oSettings.jqXHR = JQ.ajax({
			"dataType": 'json',
			"type": "POST",
			"url": sSource,
			"data": aoData,
			beforeSend : function(xhr, opts){
				JQ.blockUI({
					message: 'Processing...',
					css: {
						border: 'none',
						padding: '15px',
						'font-size': '28px',
						backgroundColor: '#000',
						'-webkit-border-radius': '10px',
						'-moz-border-radius': '10px',
						opacity: .5,
						color: '#fff'
					} });
			},
			complete: function(){
			},
			"success": fnCallback
		});
	},

	/**
	 * It is often useful to send extra data to the server when making an Ajax request -
	 * for example custom filtering information, and this callback function makes it trivial
	 * to send extra information to the server.
	 * @param aoData -  A key/value pair object containing the data to send to the server
	 */
	fnServerParams: function (aoData) {
		TblServerParams(aoData);
	}
	});
}

/**
 * method checks if column in subid's table is visible. We need it for fnFooterCallback.
 * because we don't know what column is visible or not and what index we can use.
 * and number of nCells in the footer can be dynamically changed.
 * @param name of column
 * @returns is visible or not
 */
function isSubIDColumnVisible(name)
{
	if (typeof (oTableSubIDReport) == 'undefined')
		return false;
	name = name.toLowerCase();  // case insensitive match, cast all to lowercase
	var aoColumns = oTableSubIDReport.fnSettings().aoColumns;
	var numcols = aoColumns.length;

	for (i=0; i<numcols; i++) {
		col = aoColumns[i].sName.toLowerCase();
		if (col == name) {
			return aoColumns[i].bVisible
		}
	}
	return false;
}

/**
 * Method re-read an Ajax source and have the table update.
 */
JQ.fn.dataTableExt.oApi.fnReloadAjax = function (oSettings, sNewSource, fnCallback, bStandingRedraw) {
	if (typeof sNewSource != 'undefined' && sNewSource != null) {
		oSettings.sAjaxSource = sNewSource;
	}
	this.oApi._fnProcessingDisplay(oSettings, true);
	var that = this;
	var iStart = oSettings._iDisplayStart;
	var aData = [];

	this.oApi._fnServerParams(oSettings, aData);

	oSettings.fnServerData(oSettings.sAjaxSource, aData, function (json) {
		/* Clear the old information from the table */
		that.oApi._fnClearTable(oSettings);

		/* Got the data - add it to the table */
		var aData = (oSettings.sAjaxDataProp !== "") ?
			that.oApi._fnGetObjectDataFn(oSettings.sAjaxDataProp)(json) : json;

		for (var i = 0; i < aData.length; i++) {
			that.oApi._fnAddData(oSettings, aData[i]);
		}

		oSettings.aiDisplay = oSettings.aiDisplayMaster.slice();
		that.fnDraw();

		if (typeof bStandingRedraw != 'undefined' && bStandingRedraw === true) {
			oSettings._iDisplayStart = iStart;
			that.fnDraw(false);
		}

		that.oApi._fnProcessingDisplay(oSettings, false);

		/* Callback user function - for event handlers etc */
		if (typeof fnCallback == 'function' && fnCallback != null) {
			fnCallback(oSettings);
		}

	}, oSettings);
	JQ('#campaignreport').on('click', 'a', function(e) {});
};

function testFunc2()
{
	alert('draw table js loaded');
}

function convertDate(inputFormat) {

	  function pad(s) { return (s < 10) ? '0' + s : s; }
	  var d = new Date(inputFormat);
	  return [d.getFullYear() , pad(d.getMonth()+1), pad(d.getDate())].join('-');
}
