function copyCriteriaSettings(postSetupID)
{
	url = "show/postSetupID/" + postSetupID + "/format/json";

	$.getJSON(url, function(data){
		var items = [];

		$.each(data, function(k, v) {
			// fill in each form field by hand as the ids dont match db columns
			if (k == 'ageMin') { $("#agemin").val(v); }
			if (k == 'ageMax') { $("#agemax").val(v); }
			if (k == 'loanAmountMin') { $("#loanamountmin").val(v); }
			if (k == 'loanAmountMax') { $("#loanamountmax").val(v); }
			if (k == 'monthlyIncomeMin') { $("#incomeminimum").val(v); }
			if (k == 'monthlyIncomeMax') { $("#incomemaximum").val(v); }
			if (k == 'ABABlacklist') { $("#abablacklist").val(v); }
			if (k == 'employerBlacklist') { $("#employerblacklist").val(v); }
			if (k == 'emailExtBlacklist') { $("#emailextblacklist").val(v); }
			if (k == 'zipBlacklist') { $("#zipblacklist").val(v); }
			if (k == 'masteraffBlacklist') { $("#masteraffblacklist").val(v); }
			if (k == 'campaignBlacklist') { $("#campaignblacklist").val(v); }
			if (k == 'bankAccountMax') { $("#bankaccountmax").val(v); }
			if (k == 'dupeDays') { $("#dupedays").val(v); }
			if (k == 'denyMilitary') {
				if (v == 1) {
					$("#mil1").prop("checked", true);
				}
			}

			// explode comma-delim values and check each one
			if (k == 'payMethodBlacklist') {
				if (v != "") {
					paymethods = v.split(',');
					for (i=0; i < paymethods.length; i++) {
						$("#" + paymethods[i]).prop("checked", true);
					}
				}
			}
			if (k == 'payPeriodBlacklist') {
				if (v != "") {
					payPeriods = v.split(',');
					for (i=0; i < payPeriods.length; i++) {
						$("#" + payPeriods[i]).prop("checked", true);
					}
				}
			}
			if (k == 'stateBlacklist') {
				if (v != "") {
					states = v.split(',');
					for (i=0; i < states.length; i++) {
						$("#" + states[i]).prop("checked", true);
					}
				}
			}
		});
	});
}
