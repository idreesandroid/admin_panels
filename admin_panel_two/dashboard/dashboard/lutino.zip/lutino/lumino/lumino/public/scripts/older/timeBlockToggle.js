function toDate(timeBlock){
	var now = new Date();
	var hms = timeBlock.split(":");
	
	now.setHours(hms[0]);
	now.setMinutes(hms[1]);	
	now.setSeconds(hms[2]);
	return now; /*returns a date object based on the start or end time */

}

$(document).ready(function(){
	$('.timeBlockToggle').click(function(){
		var day = $(this).attr('id').substring(0,$(this).attr('id').length - 15);
		var startTime = toDate($('#' + day + '_starttime').val());
		var endTime = toDate($('#' + day + '_endtime').val());
		if ($('#' + day + 'TimeBlocks').html()) {
			
			$('#' + day + 'TimeBlocks').toggle();
			
			if ($('#' + day + 'TimeBlockToggle').text() == '[+]') {
					$('#' + day + 'TimeBlockToggle').text("[-]");
			} else {
					$('#' + day + 'TimeBlockToggle').text("[+]");
			}

		} else {
			
			if ($('#' + day + 'TimeBlockToggle').text() == '[+]') {
					$('#' + day + 'TimeBlockToggle').text("[-]");
			} else {
					$('#' + day + 'TimeBlockToggle').text("[+]");
			}
			$('#' + day + 'TimeBlocks').toggle(); 
			resetButton = "$('#" + day + "TimeBlocks').html('')";
			var html = '<a href="#" onclick="var blank;' + resetButton + ';return false;">Reset</a><br />';
			html += '<div><span class="capColumn">Block Start</span><span class="capColumn">Block End</span><span class="capColumn">Cap</span></div>';
				
			var timeIncrements = startTime;
			var count = 0;
			while (timeIncrements < endTime) {
					
					html += '<div>';
					html += '<input class="capColumn" name="' + day + 'BlockStartTime' + count + '" type="text" value="';
					var hours = ((timeIncrements.getHours() == '0') ? '00' : timeIncrements.getHours());
					hours = ((parseInt(hours) < 10 && parseInt(hours) > 0) ? '0' + hours : hours);
					var minutes = ((timeIncrements.getMinutes() == '0') ? '00' : timeIncrements.getMinutes());					
					var seconds = ((timeIncrements.getSeconds() == '0') ? '00' : timeIncrements.getSeconds());
					html += hours + ':' + minutes + ':' + seconds;
					html += '" size="6" />\n';
					timeIncrements.setMinutes(timeIncrements.getMinutes() + 30);
					html += ' - ';
					var hours = ((timeIncrements.getHours() == '0') ? '00' : timeIncrements.getHours());
					hours = ((parseInt(hours) < 10 && parseInt(hours) > 0) ? '0' + hours : hours);
					var minutes = ((timeIncrements.getMinutes() == '0') ? '00' : timeIncrements.getMinutes());
					var seconds = ((timeIncrements.getSeconds() == '0') ? '00' : timeIncrements.getSeconds());
					html += '<input class="capColumn" name="' + day + 'BlockEndTime' + count + '" type="text" value="';
					html += hours + ':' + minutes + ':' + seconds;
					html += '" size="6"  />';
					html += '<input class="capColumn" name="timeBlockCap' + count + '" type="text" value="UNC" size="6" /><br />';							html += '</div>';
					count++;
			}
			$('#' + day + 'TimeBlocks').html(html);
			
		}
	});
	
				


});

